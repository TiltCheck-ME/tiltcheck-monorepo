// <define:process>
var define_process_default = { env: {} };

// src/extractor.ts
var CASINO_SELECTORS = [
  {
    casinoId: "stake",
    domain: "stake.com",
    selectors: {
      betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
      winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
      balance: '[data-test="balance"], .balance, [class*="balance-value"]',
      symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
      bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
      freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
      gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
      gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
    }
  },
  {
    casinoId: "stake-us",
    domain: "stake.us",
    selectors: {
      betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
      winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
      balance: '[data-test="balance"], .balance, [class*="balance-value"]',
      symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
      bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
      freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
      gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
      gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
    }
  },
  // Stake mirror domains - same selectors as stake.com
  ...["stake.bet", "stake.games", "staketr.com", "staketr2.com", "staketr3.com", "staketr4.com", "stake.bz", "stake.pet"].map((domain) => ({
    casinoId: "stake",
    domain,
    selectors: {
      betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
      winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
      balance: '[data-test="balance"], .balance, [class*="balance-value"]',
      symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
      bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
      freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
      gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
      gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
    }
  })),
  {
    casinoId: "roobet",
    domain: "roobet.com",
    selectors: {
      betAmount: '.bet-input input, [name="bet"], [class*="betInput"]',
      winAmount: '.win-display, .payout-amount, [class*="winAmount"]',
      balance: '.user-balance, [class*="userBalance"], [class*="balance"]',
      symbols: '.slot-symbol, [class*="reelSymbol"]',
      bonusIndicator: '.bonus-round-active, [class*="bonusActive"]',
      gameResult: ".crash-payout, .multiplier-display"
    },
    extractors: {
      extractResult: (doc) => {
        const el = doc.querySelector(".crash-payout, .multiplier-display");
        if (!el || !el.textContent) return null;
        return parseFloat(el.textContent.replace(/x/i, "").trim());
      }
    }
  },
  {
    casinoId: "bc-game",
    domain: "bc.game",
    selectors: {
      betAmount: '[class*="betAmount"], [class*="bet-amount"], input[type="number"]',
      winAmount: '[class*="winAmount"], [class*="win-amount"], [class*="payout"]',
      balance: '[class*="balance"], [class*="userBalance"]',
      symbols: '[class*="symbol"], [class*="reel"]'
    }
  },
  {
    casinoId: "duelbits",
    domain: "duelbits.com",
    selectors: {
      betAmount: '.bet-value, [class*="betValue"], [class*="bet-amount"]',
      winAmount: '.win-value, [class*="winValue"], [class*="win-amount"]',
      balance: '[class*="balance"], .user-balance',
      symbols: '[data-reel] img, .reel-symbol, [class*="symbol"]'
    }
  },
  {
    casinoId: "rollbit",
    domain: "rollbit.com",
    selectors: {
      betAmount: '[class*="betInput"], [class*="bet-amount"], input[name="bet"]',
      winAmount: '[class*="winAmount"], [class*="payout"]',
      balance: '[class*="balance"], [class*="wallet"]',
      symbols: '[class*="symbol"], [class*="reel"]'
    }
  },
  {
    casinoId: "shuffle",
    domain: "shuffle.com",
    selectors: {
      betAmount: '[class*="bet"], input[type="number"]',
      winAmount: '[class*="win"], [class*="payout"]',
      balance: '[class*="balance"], [class*="wallet"]',
      symbols: '[class*="symbol"]'
    }
  },
  {
    casinoId: "gamdom",
    domain: "gamdom.com",
    selectors: {
      betAmount: '[class*="bet-amount"], [class*="betValue"]',
      winAmount: '[class*="win-amount"], [class*="winValue"]',
      balance: '[class*="balance"]',
      symbols: '[class*="symbol"]'
    }
  },
  {
    casinoId: "generic",
    domain: "*",
    selectors: {
      betAmount: '[data-bet], .bet, .bet-amount, input[name="bet"], [class*="betAmount"], [class*="bet-input"]',
      winAmount: '[data-win], .win, .win-amount, .payout, [class*="winAmount"], [class*="payout"]',
      balance: '[data-balance], .balance, .user-balance, [class*="balance"], [class*="wallet"]',
      symbols: '[data-symbol], .symbol, .reel-symbol, [class*="symbol"], [class*="reel"]',
      gameResult: "[data-result], .game-result, .result-value, .outcome"
    }
  }
];
var CasinoDataExtractor = class {
  casinoConfig = null;
  previousBalance = null;
  lastSpinTime = 0;
  spinDebounceMs = 1e3;
  // Don't capture spins faster than 1/sec
  constructor(casinoDomain) {
    this.detectCasino(casinoDomain);
  }
  /**
   * Initialize with custom user configurations
   */
  async initialize() {
    return new Promise((resolve) => {
      try {
        const storage = chrome.storage.sync || chrome.storage.local;
        storage.get(["tiltcheck_custom_casinos"], (result) => {
          const custom = result.tiltcheck_custom_casinos || [];
          this.detectCasino(void 0, custom);
          resolve();
        });
      } catch (e) {
        console.warn("[TiltCheck] Failed to load custom casinos:", e);
        resolve();
      }
    });
  }
  /**
   * Detect which casino we're on, prioritizing custom user configs
   */
  detectCasino(domain, customSelectors = []) {
    const currentDomain = domain || window.location.hostname;
    const allSelectors = [...customSelectors, ...CASINO_SELECTORS];
    this.casinoConfig = allSelectors.find(
      (config) => currentDomain.includes(config.domain) || config.domain === "*"
    ) || CASINO_SELECTORS.find((c) => c.casinoId === "generic");
    console.log("[TiltCheck] Detected casino:", this.casinoConfig.casinoId);
  }
  /**
   * Extract text content from element
   */
  extractText(selector, doc = document) {
    const element = doc.querySelector(selector);
    if (!element) return null;
    const value = element.getAttribute("data-value") || element.getAttribute("value") || element.textContent;
    return value?.trim() || null;
  }
  /**
   * Parse numeric value from text (handles $, commas, etc.)
   */
  parseNumeric(text) {
    if (!text) return null;
    const cleaned = text.replace(/[$,\s]/g, "");
    const num = parseFloat(cleaned);
    return isNaN(num) ? null : num;
  }
  /**
   * Extract bet amount
   */
  extractBet(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractBet) {
      return this.casinoConfig.extractors.extractBet(doc);
    }
    const selector = this.casinoConfig.selectors.betAmount;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract win amount
   */
  extractWin(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractWin) {
      return this.casinoConfig.extractors.extractWin(doc);
    }
    const selector = this.casinoConfig.selectors.winAmount;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract balance
   */
  extractBalance(doc = document) {
    if (!this.casinoConfig) return null;
    const selector = this.casinoConfig.selectors.balance;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract symbols from reels
   */
  extractSymbols(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractSymbols) {
      return this.casinoConfig.extractors.extractSymbols(doc);
    }
    const selector = this.casinoConfig.selectors.symbols;
    if (!selector) return null;
    const elements = Array.from(doc.querySelectorAll(selector));
    if (elements.length === 0) return null;
    return elements.map((el) => {
      const dataSymbol = el.getAttribute("data-symbol");
      if (dataSymbol) return dataSymbol;
      const alt = el.getAttribute("alt");
      if (alt) return alt;
      const src = el.getAttribute("src");
      if (src) {
        const filename = src.split("/").pop()?.split(".")[0];
        if (filename) return filename;
      }
      return el.textContent?.trim() || "unknown";
    });
  }
  /**
   * Check if bonus round is active
   */
  isBonusActive(doc = document) {
    if (!this.casinoConfig) return false;
    const selector = this.casinoConfig.selectors.bonusIndicator;
    if (!selector) return false;
    return doc.querySelector(selector) !== null;
  }
  /**
   * Extract free spins count
   */
  extractFreeSpinsCount(doc = document) {
    if (!this.casinoConfig) return null;
    const selector = this.casinoConfig.selectors.freeSpinsCounter;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract game title
   */
  extractGameTitle(doc = document) {
    if (!this.casinoConfig) return null;
    const selector = this.casinoConfig.selectors.gameTitle;
    if (!selector) return null;
    return this.extractText(selector, doc);
  }
  /**
   * Extract game result (e.g. dice roll)
   */
  extractGameResult(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractResult) {
      return this.casinoConfig.extractors.extractResult(doc);
    }
    const selector = this.casinoConfig.selectors.gameResult;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Attempt to extract a complete spin event
   */
  extractSpinEvent(doc = document) {
    const now = Date.now();
    if (now - this.lastSpinTime < this.spinDebounceMs) {
      return null;
    }
    const bet = this.extractBet(doc);
    const win = this.extractWin(doc);
    const balance = this.extractBalance(doc);
    if (bet === null && win === null) {
      return null;
    }
    const symbols = this.extractSymbols(doc);
    const bonusActive = this.isBonusActive(doc);
    const freeSpins = this.extractFreeSpinsCount(doc);
    const gameTitle = this.extractGameTitle(doc);
    const gameResult = this.extractGameResult(doc);
    if (balance !== null && this.previousBalance !== null) {
      const balanceChange = balance - this.previousBalance;
      if (Math.abs(balanceChange) > 0.01) {
        this.lastSpinTime = now;
        this.previousBalance = balance;
        return {
          bet: bet !== null ? bet : Math.abs(balanceChange) - (win || 0),
          win: win !== null ? win : 0,
          balance,
          gameResult,
          symbols,
          bonusActive,
          freeSpins,
          gameTitle,
          timestamp: now
        };
      }
    } else if (balance !== null) {
      this.previousBalance = balance;
    }
    return null;
  }
  /**
   * Start observing the DOM for gameplay
   */
  startObserving(callback) {
    console.log("[TiltCheck] Starting DOM observation...");
    const pollInterval = setInterval(() => {
      const spinData = this.extractSpinEvent();
      if (spinData) {
        callback(spinData);
      }
    }, 500);
    const observer = new MutationObserver(() => {
      const spinData = this.extractSpinEvent();
      if (spinData) {
        callback(spinData);
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["data-value", "value", "class"]
    });
    return () => {
      clearInterval(pollInterval);
      observer.disconnect();
      console.log("[TiltCheck] Stopped DOM observation");
    };
  }
};
var AnalyzerClient = class {
  ws = null;
  reconnectAttempts = 0;
  maxReconnectAttempts = 5;
  baseReconnectDelay = 2e3;
  maxReconnectDelay = 3e4;
  reconnectTimer = null;
  shouldReconnect = true;
  isConnecting = false;
  heartbeatTimer = null;
  heartbeatIntervalMs = 25e3;
  onConnectionIssue;
  constructor(wsUrl, onConnectionIssue) {
    this.wsUrl = wsUrl;
    this.onConnectionIssue = onConnectionIssue;
  }
  wsUrl;
  getReadyStateLabel(state) {
    switch (state) {
      case WebSocket.CONNECTING:
        return "CONNECTING";
      case WebSocket.OPEN:
        return "OPEN";
      case WebSocket.CLOSING:
        return "CLOSING";
      case WebSocket.CLOSED:
        return "CLOSED";
      default:
        return "UNKNOWN";
    }
  }
  logSocketEvent(prefix, event) {
    const maybeClose = event;
    const maybeTarget = event?.target;
    const targetState = maybeTarget ? this.getReadyStateLabel(maybeTarget.readyState) : "UNKNOWN";
    if (maybeClose && typeof maybeClose.code === "number") {
      console.error(`${prefix} (close event)`, {
        code: maybeClose.code,
        reason: maybeClose.reason || "(no reason)",
        wasClean: maybeClose.wasClean,
        url: this.wsUrl,
        readyState: targetState
      });
      return;
    }
    console.error(`${prefix} (event)`, {
      type: event?.type || typeof event,
      url: this.wsUrl,
      readyState: targetState
    });
  }
  toConnectionError(event, fallbackMessage) {
    if (event instanceof Error) {
      return event;
    }
    const closeEvent = event;
    if (closeEvent && typeof closeEvent.code === "number") {
      return new Error(
        `${fallbackMessage} (code=${closeEvent.code}, reason=${closeEvent.reason || "none"}, clean=${closeEvent.wasClean})`
      );
    }
    return new Error(fallbackMessage);
  }
  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }
  startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      try {
        this.ws.send(JSON.stringify({ type: "ping", ts: Date.now() }));
      } catch (error) {
        this.logSocketEvent("[TiltCheck] Heartbeat send failed", error);
      }
    }, this.heartbeatIntervalMs);
  }
  /**
   * Connect to analyzer backend
   */
  connect() {
    if (this.isConnecting) {
      return Promise.resolve();
    }
    this.shouldReconnect = true;
    return new Promise((resolve, reject) => {
      console.log("[TiltCheck] Connecting to analyzer...", this.wsUrl);
      this.isConnecting = true;
      let settled = false;
      this.ws = new WebSocket(this.wsUrl);
      this.ws.onopen = () => {
        console.log("[TiltCheck] Connected to analyzer");
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
        this.startHeartbeat();
        settled = true;
        resolve();
      };
      this.ws.onerror = (error) => {
        this.isConnecting = false;
        this.logSocketEvent("[TiltCheck] WebSocket error", error);
        if (!settled) {
          settled = true;
          reject(error);
        }
      };
      this.ws.onclose = (event) => {
        this.isConnecting = false;
        this.stopHeartbeat();
        this.ws = null;
        console.log("[TiltCheck] Disconnected from analyzer");
        this.logSocketEvent("[TiltCheck] WebSocket closed", event);
        if (!settled) {
          settled = true;
          reject(event);
        } else {
          this.onConnectionIssue?.(
            this.toConnectionError(event, "Analyzer connection closed after opening")
          );
        }
        if (this.shouldReconnect) {
          this.attemptReconnect(event);
        }
      };
    });
  }
  /**
   * Attempt to reconnect
   */
  attemptReconnect(lastEvent) {
    if (!this.shouldReconnect) return;
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error("[TiltCheck] Max reconnect attempts reached", {
        attempts: this.reconnectAttempts,
        maxAttempts: this.maxReconnectAttempts,
        url: this.wsUrl
      });
      if (lastEvent) {
        this.logSocketEvent("[TiltCheck] Final reconnect failure context", lastEvent);
      }
      return;
    }
    this.reconnectAttempts++;
    const baseDelay = Math.min(
      this.baseReconnectDelay * Math.pow(2, this.reconnectAttempts - 1),
      this.maxReconnectDelay
    );
    const jitteredDelay = Math.round(baseDelay * (1 + Math.random() * 0.25));
    console.log(`[TiltCheck] Reconnecting in ${jitteredDelay}ms... (attempt ${this.reconnectAttempts})`);
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    this.reconnectTimer = setTimeout(() => {
      this.connect().catch((err) => {
        this.logSocketEvent("[TiltCheck] Reconnect failed", err);
        this.onConnectionIssue?.(this.toConnectionError(err, "Analyzer reconnect attempt failed"));
      });
    }, jitteredDelay);
  }
  /**
   * Send spin data to analyzer
   */
  sendSpin(data) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn("[TiltCheck] WebSocket not connected, buffering spin data");
      return;
    }
    this.ws.send(JSON.stringify({
      type: "spin",
      data
    }));
  }
  /**
   * Request fairness report
   */
  requestReport(sessionId2) {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        reject(new Error("WebSocket not connected"));
        return;
      }
      const messageHandler = (event) => {
        const message = JSON.parse(event.data);
        if (message.type === "report" && message.sessionId === sessionId2) {
          this.ws.removeEventListener("message", messageHandler);
          resolve(message.data);
        }
      };
      this.ws.addEventListener("message", messageHandler);
      this.ws.send(JSON.stringify({
        type: "request_report",
        sessionId: sessionId2
      }));
      setTimeout(() => {
        this.ws.removeEventListener("message", messageHandler);
        reject(new Error("Report request timeout"));
      }, 5e3);
    });
  }
  /**
   * Close connection
   */
  disconnect() {
    this.shouldReconnect = false;
    this.stopHeartbeat();
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close(1e3, "Client disconnect");
      this.ws = null;
    }
  }
};

// src/tilt-detector.ts
var PROFILE_MULTIPLIERS = {
  conservative: 1.2,
  moderate: 1,
  degen: 0.8
};
var ANIMATION_LOOP_MS = 500;
var MICRO_PACING_RETENTION_MS = 6e4;
var TiltDetector = class {
  bets = [];
  clicks = [];
  // Timestamps of clicks
  sessionStartTime = Date.now();
  baselineAvgBet = 0;
  consecutiveLosses = 0;
  totalWagered = 0;
  totalWon = 0;
  currentBalance = null;
  initialBalance = null;
  redeemThreshold = null;
  riskProfile = "moderate";
  // Configuration
  config = {
    // Rage betting thresholds
    fastBetThreshold: 2e3,
    // ms between bets
    rageBetCount: 5,
    // consecutive fast bets
    // Chasing losses
    betIncreaseMultiplier: 2.5,
    // 2.5x increase after loss
    chasingPattern: 3,
    // consecutive increasing bets after losses
    // Fast clicks — "Auto-Pilot Trance" detection.
    // Triggers when bet events arrive faster than 300ms apart (sub-human pacing = autopilot state).
    clickThreshold: 5,
    // clicks in window
    clickWindow: 300,
    // ms — reduced from 3000ms to detect Auto-Pilot Trance pattern
    // Session duration
    warningDuration: 60 * 60 * 1e3,
    // 1 hour
    criticalDuration: 2 * 60 * 60 * 1e3,
    // 2 hours
    // Vault recommendations
    vaultThreshold: 5,
    // 5x initial balance
    profitVaultPercent: 0.5,
    // Vault 50% of profits
    // Stop loss
    stopLossPercent: 0.5,
    // Stop at 50% loss
    // Real-world comparisons (common items people forget to buy)
    realWorldItems: [
      { item: "trash bags", avgCost: 15 },
      { item: "toilet paper", avgCost: 20 },
      { item: "groceries", avgCost: 100 },
      { item: "gas", avgCost: 50 },
      { item: "phone bill", avgCost: 80 },
      { item: "utilities", avgCost: 150 },
      { item: "rent", avgCost: 1500 }
    ]
  };
  constructor(initialBalance, riskLevel = "moderate", redeemThreshold) {
    this.currentBalance = initialBalance;
    this.initialBalance = initialBalance;
    this.redeemThreshold = redeemThreshold || null;
    this.setRiskProfile(riskLevel);
  }
  setRiskProfile(level) {
    this.riskProfile = level;
    this.applyRiskProfile(level);
  }
  getRiskProfile() {
    return this.riskProfile;
  }
  classifyBetResult(bet, payout) {
    if (bet <= 0) {
      return payout > 0 ? "win" : "push";
    }
    if (payout <= 0 || payout < bet) {
      return "loss";
    }
    if (payout === bet) {
      return "push";
    }
    return "win";
  }
  /**
   * Apply risk profile configuration
   */
  applyRiskProfile(level) {
    if (level === "conservative") {
      this.config.fastBetThreshold = 3e3;
      this.config.betIncreaseMultiplier = 1.5;
      this.config.warningDuration = 30 * 60 * 1e3;
      this.config.criticalDuration = 1 * 60 * 1e3;
      this.config.stopLossPercent = 0.3;
    } else if (level === "degen") {
      this.config.fastBetThreshold = 1e3;
      this.config.betIncreaseMultiplier = 5;
      this.config.warningDuration = 4 * 60 * 60 * 1e3;
      this.config.criticalDuration = 8 * 60 * 60 * 1e3;
      this.config.stopLossPercent = 0.8;
    }
  }
  /**
   * Record a bet event
   */
  recordBet(bet, payout) {
    const now = Date.now();
    const result = this.classifyBetResult(bet, payout);
    this.bets.push({
      amount: bet,
      timestamp: now,
      result,
      payout
    });
    this.totalWagered += bet;
    this.totalWon += payout;
    if (this.currentBalance !== null) {
      this.currentBalance = this.currentBalance - bet + payout;
    }
    if (result === "loss") {
      this.consecutiveLosses++;
    } else {
      this.consecutiveLosses = 0;
    }
    const baselineBets = this.bets.filter((entry) => entry.amount > 0).slice(0, 10);
    if (baselineBets.length > 0) {
      this.baselineAvgBet = baselineBets.reduce((sum, entry) => sum + entry.amount, 0) / baselineBets.length;
    }
  }
  /**
   * Update the current balance from an external source.
   */
  updateBalance(newBalance) {
    if (newBalance !== this.currentBalance) {
      this.currentBalance = newBalance;
    }
  }
  setRedeemThreshold(redeemThreshold) {
    this.redeemThreshold = redeemThreshold && redeemThreshold > 0 ? redeemThreshold : null;
  }
  /**
   * Record a click event (for erratic clicking detection)
   */
  recordClick() {
    const now = Date.now();
    this.clicks.push(now);
    this.clicks = this.clicks.filter((t) => now - t < MICRO_PACING_RETENTION_MS);
  }
  /** Recent inter-click deltas (ms), oldest first. */
  computeRecentClickDeltas(maxDeltas = 8) {
    const sorted = [...this.clicks].sort((a, b) => a - b);
    const deltas = [];
    for (let i = 1; i < sorted.length && deltas.length < maxDeltas; i++) {
      deltas.push(sorted[i] - sorted[i - 1]);
    }
    return deltas;
  }
  getLastClickDeltaMs() {
    const deltas = this.computeRecentClickDeltas();
    return deltas.length > 0 ? deltas[deltas.length - 1] : null;
  }
  /**
   * Continuous velocity contribution (0–45) from compressing click pacing.
   */
  getMicroPacingComponent() {
    const deltas = this.computeRecentClickDeltas();
    if (deltas.length < 2) return 0;
    const lastDelta = deltas[deltas.length - 1];
    const recent = deltas.slice(-4);
    const avgDelta = recent.reduce((sum, d) => sum + d, 0) / recent.length;
    let velocity = 0;
    if (lastDelta < ANIMATION_LOOP_MS) {
      velocity += (ANIMATION_LOOP_MS - lastDelta) / ANIMATION_LOOP_MS * 28;
    }
    if (avgDelta < ANIMATION_LOOP_MS) {
      velocity += (ANIMATION_LOOP_MS - avgDelta) / ANIMATION_LOOP_MS * 12;
    }
    let compressingSteps = 0;
    for (let i = 1; i < recent.length; i++) {
      if (recent[i] < recent[i - 1] * 0.92) {
        compressingSteps++;
      }
    }
    if (compressingSteps >= 2 && lastDelta < ANIMATION_LOOP_MS + 100) {
      velocity += compressingSteps * 6;
    }
    return Math.min(45, velocity);
  }
  /**
   * Exponential loss-streak weight when pacing is hot (co-occurrence required).
   */
  getLossStreakCompoundComponent() {
    if (this.consecutiveLosses <= 3) return 0;
    const pacingHot = this.getMicroPacingComponent() >= 10 || this.getLastClickDeltaMs() !== null && this.getLastClickDeltaMs() < ANIMATION_LOOP_MS;
    if (!pacingHot) return 0;
    const streakExcess = this.consecutiveLosses - 3;
    const exponential = Math.pow(1.35, streakExcess);
    const linear = streakExcess * 7;
    return Math.min(35, linear * Math.min(2.5, exponential / 1.8));
  }
  getIndicatorCompositeScore() {
    const tiltSigns = this.detectAllTiltSigns();
    const weights = {
      rage_betting: 22,
      chasing_losses: 26,
      fast_clicks: 12,
      bet_escalation: 18,
      duration_warning: 8,
      emotional_pattern: 16,
      fatigue: 12,
      martingale: 20
    };
    const severityMultipliers = {
      low: 0.5,
      medium: 1,
      high: 1.5,
      critical: 2
    };
    let score = 0;
    for (const sign of tiltSigns) {
      const weight = weights[sign.type] ?? 10;
      const multiplier = severityMultipliers[sign.severity];
      score += weight * multiplier * sign.confidence;
    }
    return Math.min(55, score);
  }
  /**
   * Detect rage betting (fast consecutive bets)
   */
  detectRageBetting() {
    if (this.bets.length < this.config.rageBetCount) return null;
    const recentBets = this.bets.slice(-this.config.rageBetCount);
    const intervals = [];
    for (let i = 1; i < recentBets.length; i++) {
      intervals.push(recentBets[i].timestamp - recentBets[i - 1].timestamp);
    }
    const avgInterval = intervals.reduce((sum, i) => sum + i, 0) / intervals.length;
    if (avgInterval < this.config.fastBetThreshold) {
      const severity = avgInterval < 1e3 ? "critical" : avgInterval < 1500 ? "high" : "medium";
      return {
        type: "rage_betting",
        severity,
        confidence: Math.min(1, this.config.fastBetThreshold / avgInterval - 1),
        description: `Betting very quickly (${(avgInterval / 1e3).toFixed(1)}s between bets)`,
        evidence: {
          avgInterval,
          recentBets: recentBets.length,
          threshold: this.config.fastBetThreshold
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect chasing losses (increasing bets after losses)
   */
  detectChasingLosses() {
    if (this.bets.length < this.config.chasingPattern + 1) return null;
    if (this.consecutiveLosses < this.config.chasingPattern) return null;
    const recentBets = this.bets.slice(-this.config.chasingPattern - 1);
    const isChasing = recentBets.every((bet, i) => {
      if (i === 0) return true;
      return bet.amount > recentBets[i - 1].amount * this.config.betIncreaseMultiplier;
    });
    if (isChasing) {
      const increase = recentBets[recentBets.length - 1].amount / recentBets[0].amount;
      const severity = increase > 10 ? "critical" : increase > 5 ? "high" : increase > 3 ? "medium" : "low";
      return {
        type: "chasing_losses",
        severity,
        confidence: Math.min(1, increase / 10),
        description: `Bet size increased ${increase.toFixed(1)}x after ${this.consecutiveLosses} losses`,
        evidence: {
          consecutiveLosses: this.consecutiveLosses,
          betIncrease: increase,
          startBet: recentBets[0].amount,
          currentBet: recentBets[recentBets.length - 1].amount
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect fast/erratic clicking (Auto-Pilot Trance detection).
   * At 300ms window, this fires when bet events arrive faster than humanly intentional.
   */
  detectFastClicks() {
    if (this.clicks.length < this.config.clickThreshold) return null;
    const recentClicks = this.clicks.filter(
      (t) => Date.now() - t < this.config.clickWindow
    );
    if (recentClicks.length >= this.config.clickThreshold) {
      const severity = recentClicks.length > 10 ? "high" : "medium";
      const sortedRecent = [...recentClicks].sort((a, b) => b - a);
      const lastClickDeltaMs = sortedRecent.length >= 2 ? sortedRecent[0] - sortedRecent[1] : 0;
      return {
        type: "fast_clicks",
        severity,
        confidence: Math.min(1, recentClicks.length / 10),
        description: `${recentClicks.length} clicks in ${this.config.clickWindow}ms \u2014 Auto-Pilot Trance detected`,
        evidence: {
          clickCount: recentClicks.length,
          window: this.config.clickWindow,
          last_click_delta_ms: lastClickDeltaMs
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect bet escalation (beyond baseline)
   */
  detectBetEscalation() {
    if (this.bets.filter((entry) => entry.amount > 0).length < 10 || this.baselineAvgBet <= 0) return null;
    const recentBet = this.bets[this.bets.length - 1];
    if (recentBet.amount <= 0) return null;
    const escalationFactor = recentBet.amount / this.baselineAvgBet;
    if (escalationFactor > 5) {
      const severity = escalationFactor > 20 ? "critical" : escalationFactor > 10 ? "high" : "medium";
      return {
        type: "bet_escalation",
        severity,
        confidence: Math.min(1, escalationFactor / 20),
        description: `Bet ${escalationFactor.toFixed(1)}x larger than your average`,
        evidence: {
          currentBet: recentBet.amount,
          baselineAvg: this.baselineAvgBet,
          escalationFactor
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect session duration warnings
   */
  detectDurationWarning() {
    const duration = Date.now() - this.sessionStartTime;
    if (duration > this.config.criticalDuration) {
      return {
        type: "duration_warning",
        severity: "critical",
        confidence: 1,
        description: `You've been playing for ${(duration / 36e5).toFixed(1)} hours`,
        evidence: {
          duration,
          hours: duration / 36e5
        },
        triggeredAt: Date.now()
      };
    } else if (duration > this.config.warningDuration) {
      return {
        type: "duration_warning",
        severity: "medium",
        confidence: 0.8,
        description: `Session duration: ${(duration / 6e4).toFixed(0)} minutes`,
        evidence: {
          duration,
          minutes: duration / 6e4
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect Martingale Desperation pattern.
   *
   * Pattern: loss -> bet * 1.7x-2.5x -> loss -> bet * 1.7x-2.5x -> ... (3+ consecutive steps).
   * Uses 1.7x floor — real-world players rarely double exactly.
   */
  detectMartingale() {
    if (this.bets.length < 4) return null;
    const window2 = this.bets.slice(-6);
    let consecutiveSteps = 0;
    for (let i = 1; i < window2.length; i++) {
      const prev = window2[i - 1];
      const curr = window2[i];
      const prevWasLoss = prev.result === "loss";
      const multiplier = prev.amount > 0 ? curr.amount / prev.amount : 0;
      const isMartingaleStep = prevWasLoss && multiplier >= 1.7 && multiplier <= 2.5;
      if (isMartingaleStep) {
        consecutiveSteps++;
      } else {
        consecutiveSteps = 0;
      }
      if (consecutiveSteps >= 3) {
        const increase = curr.amount / window2[i - consecutiveSteps].amount;
        const severity = increase > 8 ? "critical" : increase > 4 ? "high" : "medium";
        return {
          type: "emotional_pattern",
          severity,
          confidence: Math.min(1, consecutiveSteps / 4),
          description: `Martingale pattern: ${consecutiveSteps} consecutive loss-double cycles detected`,
          evidence: {
            consecutiveSteps,
            startAmount: window2[i - consecutiveSteps].amount,
            currentAmount: curr.amount,
            multiplierRange: "1.7x-2.5x"
          },
          triggeredAt: Date.now()
        };
      }
    }
    return null;
  }
  /**
   * Detect all tilt indicators
   */
  detectAllTiltSigns() {
    const indicators = [];
    const rageBetting = this.detectRageBetting();
    if (rageBetting) indicators.push(rageBetting);
    const chasing = this.detectChasingLosses();
    if (chasing) indicators.push(chasing);
    const fastClicks = this.detectFastClicks();
    if (fastClicks) indicators.push(fastClicks);
    const escalation = this.detectBetEscalation();
    if (escalation) indicators.push(escalation);
    const duration = this.detectDurationWarning();
    if (duration) indicators.push(duration);
    const martingale = this.detectMartingale();
    if (martingale) indicators.push(martingale);
    return indicators;
  }
  /**
   * Generate vault recommendation
   */
  generateVaultRecommendation() {
    if (this.currentBalance === null || this.initialBalance === null || this.initialBalance <= 0) {
      return null;
    }
    const profit = this.currentBalance - this.initialBalance;
    const profitMultiple = this.currentBalance / this.initialBalance;
    if (profitMultiple >= this.config.vaultThreshold) {
      const suggestedAmount = profit * this.config.profitVaultPercent;
      const comparison = this.findRealWorldComparison(suggestedAmount);
      return {
        reason: `Your balance is ${profitMultiple.toFixed(1)}x your starting amount`,
        suggestedAmount,
        urgency: profitMultiple > 10 ? "critical" : profitMultiple > 7 ? "high" : "medium",
        realWorldComparison: comparison
      };
    }
    const lossPercent = (this.initialBalance - this.currentBalance) / this.initialBalance;
    if (lossPercent >= this.config.stopLossPercent) {
      return {
        reason: `You've lost ${(lossPercent * 100).toFixed(0)}% of your starting balance`,
        suggestedAmount: this.currentBalance,
        // Vault everything
        urgency: "critical",
        realWorldComparison: void 0
      };
    }
    return null;
  }
  /**
   * Detect opportunity to redeem/cash out (Redeem-to-Win)
   */
  detectRedeemOpportunity() {
    if (!this.redeemThreshold || this.currentBalance === null || this.currentBalance < this.redeemThreshold) return null;
    const diff = this.currentBalance - this.redeemThreshold;
    const overshootPercent = diff / this.redeemThreshold * 100;
    let urgency = "medium";
    if (overshootPercent > 50) urgency = "critical";
    else if (overshootPercent > 20) urgency = "high";
    return {
      amount: this.currentBalance,
      threshold: this.redeemThreshold,
      urgency,
      message: `PROFIT TARGET REACHED: You're at $${this.currentBalance.toFixed(2)}, above your $${this.redeemThreshold} goal. Lock in the profit and cash out before the house takes it back.`
    };
  }
  /**
   * Find real-world item comparison
   */
  findRealWorldComparison(amount) {
    const affordableItems = this.config.realWorldItems.filter(
      (item2) => amount >= item2.avgCost
    );
    if (affordableItems.length === 0) return void 0;
    const item = affordableItems[Math.floor(Math.random() * affordableItems.length)];
    const quantity = Math.floor(amount / item.avgCost);
    return {
      item: item.item,
      cost: item.avgCost,
      quantity,
      message: `Spotter check: your balance equals ${quantity}x ${item.item}. Lock up $${item.avgCost} for real life before the reel eats it.`
    };
  }
  /**
   * Generate intervention recommendations
   */
  generateInterventions() {
    const interventions = [];
    const tiltSigns = this.detectAllTiltSigns();
    const vaultRec = this.generateVaultRecommendation();
    const redeemRec = this.detectRedeemOpportunity();
    const criticalSigns = tiltSigns.filter((t) => t.severity === "critical");
    if (criticalSigns.length > 0) {
      interventions.push({
        type: "cooldown",
        message: `TILT DETECTED: ${criticalSigns.map((t) => t.description).join(", ")}. You're chasing. Close the tab and take 5.`,
        actionRequired: true,
        data: { duration: 5 * 60 * 1e3, tiltSigns: criticalSigns }
      });
    }
    const highSigns = tiltSigns.filter((t) => t.severity === "high" || t.severity === "critical");
    if (highSigns.length >= 2) {
      interventions.push({
        type: "phone_friend",
        message: "Multiple tilt indicators firing. Step away from the screen before your balance takes the hit.",
        actionRequired: false,
        data: { tiltSigns: highSigns }
      });
    }
    if (vaultRec) {
      if (vaultRec.urgency === "critical") {
        interventions.push({
          type: "stop_loss_triggered",
          message: `STOP LOSS TRIGGERED: ${vaultRec.reason}. Ed Craven doesn't need your rent money. Vault your remaining balance.`,
          actionRequired: true,
          data: vaultRec
        });
      } else if (vaultRec.realWorldComparison) {
        interventions.push({
          type: "spending_reminder",
          message: vaultRec.realWorldComparison.message,
          actionRequired: false,
          data: vaultRec
        });
      } else {
        interventions.push({
          type: "vault_balance",
          message: `VAULT RECOMMENDATION: ${vaultRec.reason}. Lock up $${vaultRec.suggestedAmount.toFixed(2)} right now.`,
          actionRequired: false,
          data: vaultRec
        });
      }
    }
    if (redeemRec) {
      interventions.push({
        type: "redeem_nudge",
        message: redeemRec.message,
        actionRequired: true,
        data: redeemRec
      });
    }
    const durationWarning = tiltSigns.find((t) => t.type === "duration_warning");
    if (durationWarning && durationWarning.severity === "critical") {
      interventions.push({
        type: "session_break",
        message: `SESSION DURATION LIMIT: ${durationWarning.description}. House edge compounds with time. Step away from the screen.`,
        actionRequired: false,
        data: durationWarning
      });
    }
    return interventions;
  }
  /**
   * Composite tilt risk (0–100): indicators + micro-pacing + loss-streak compound, scaled by profile.
   */
  getTiltRiskScore() {
    const indicatorScore = this.getIndicatorCompositeScore();
    const velocityScore = this.getMicroPacingComponent();
    const lossCompound = this.getLossStreakCompoundComponent();
    const raw = indicatorScore + velocityScore + lossCompound;
    const profileMu = PROFILE_MULTIPLIERS[this.riskProfile];
    return Math.min(100, Math.round(raw * profileMu));
  }
  /**
   * Get session summary
   */
  getSessionSummary() {
    const duration = Date.now() - this.sessionStartTime;
    const netProfit = this.currentBalance !== null && this.initialBalance !== null ? this.currentBalance - this.initialBalance : null;
    const roi = netProfit !== null && this.initialBalance !== null && this.initialBalance > 0 ? netProfit / this.initialBalance * 100 : null;
    return {
      duration,
      // ms
      startTime: this.sessionStartTime,
      totalBets: this.bets.length,
      totalWagered: this.totalWagered,
      totalWon: this.totalWon,
      netProfit,
      roi,
      currentBalance: this.currentBalance,
      initialBalance: this.initialBalance,
      avgBetSize: this.bets.length > 0 ? this.totalWagered / this.bets.length : 0,
      consecutiveLosses: this.consecutiveLosses,
      tiltRisk: this.getTiltRiskScore()
    };
  }
};

// src/license-verifier.ts
var EXTENSION_LICENSE_SOURCE = "Current page DOM scan";
var LICENSE_STALE_WINDOW_MS = 7 * 24 * 60 * 60 * 1e3;
var LEGITIMATE_AUTHORITIES = [
  // Tier 1 (Strictest)
  { name: "UK Gambling Commission", pattern: /UKGC|UK\s*Gambling|39\d{3}/i, jurisdiction: "United Kingdom" },
  { name: "Malta Gaming Authority", pattern: /MGA|Malta\s*Gaming|MGA\/\w+\/\d+/i, jurisdiction: "Malta" },
  { name: "Gibraltar Gambling Commission", pattern: /Gibraltar|RGL/i, jurisdiction: "Gibraltar" },
  // Tier 2 (Reputable)
  { name: "Curacao eGaming", pattern: /Cura[cç]ao|8048\/JAZ|1668\/JAZ/i, jurisdiction: "Curacao" },
  { name: "Kahnawake Gaming Commission", pattern: /Kahnawake/i, jurisdiction: "Canada" },
  { name: "Alderney Gambling Control", pattern: /Alderney/i, jurisdiction: "Alderney" },
  { name: "Isle of Man Gambling", pattern: /Isle\s*of\s*Man/i, jurisdiction: "Isle of Man" },
  // Tier 3 (Emerging)
  { name: "Anjouan Gaming", pattern: /Anjouan/i, jurisdiction: "Comoros" },
  { name: "Costa Rica Gaming", pattern: /Costa\s*Rica/i, jurisdiction: "Costa Rica" },
  // US State licenses
  { name: "Nevada Gaming Control", pattern: /Nevada\s*Gaming/i, jurisdiction: "Nevada, USA" },
  { name: "New Jersey DGE", pattern: /New\s*Jersey|DGE|Division\s*of\s*Gaming/i, jurisdiction: "New Jersey, USA" },
  { name: "Pennsylvania Gaming", pattern: /Pennsylvania\s*Gaming|PGCB/i, jurisdiction: "Pennsylvania, USA" }
];
var RED_FLAGS = [
  { pattern: /no\s*license/i, label: "site claims no license" },
  { pattern: /unlicensed/i, label: "site describes itself as unlicensed" },
  { pattern: /offshore\s+(unlicensed|unregulated)/i, label: "offshore unlicensed/unregulated language detected" },
  { pattern: /unregulated/i, label: "site describes itself as unregulated" },
  { pattern: /bitcoin\s*only/i, label: "bitcoin-only language detected" }
];
var CasinoLicenseVerifier = class {
  /**
   * Scan document for license information
   */
  findLicenseInfo(doc = document) {
    const warnings = [];
    let found = false;
    let licenseNumber;
    let issuingAuthority;
    let jurisdiction;
    let location;
    let source = EXTENSION_LICENSE_SOURCE;
    const lastVerifiedAt = (/* @__PURE__ */ new Date()).toISOString();
    const footer = doc.querySelector("footer") || doc.querySelector('[class*="footer"]') || doc.querySelector('[id*="footer"]');
    if (footer) {
      const footerText = footer.textContent || "";
      const licenseMatch = this.extractLicense(footerText);
      if (licenseMatch.found) {
        found = true;
        licenseNumber = licenseMatch.licenseNumber;
        issuingAuthority = licenseMatch.authority;
        jurisdiction = licenseMatch.jurisdiction;
        location = "footer";
        source = "Current page footer scan";
      }
    }
    if (!found) {
      const licenseLinks = Array.from(doc.querySelectorAll("a")).filter(
        (a) => /license|regulation|authority|gaming\s*commission/i.test(a.textContent || "")
      );
      if (licenseLinks.length > 0) {
        for (const link of licenseLinks) {
          const linkText = link.textContent || "";
          const licenseMatch = this.extractLicense(linkText);
          if (licenseMatch.found) {
            found = true;
            licenseNumber = licenseMatch.licenseNumber;
            issuingAuthority = licenseMatch.authority;
            jurisdiction = licenseMatch.jurisdiction;
            location = "license-page";
            source = "Current page license-link scan";
            break;
          }
        }
      }
    }
    if (!found) {
      const aboutLinks = Array.from(doc.querySelectorAll("a")).filter(
        (a) => /about|terms|legal|responsible/i.test(a.textContent || "")
      );
      if (aboutLinks.length > 0) {
        warnings.push("License info may be on About/Terms page - not verified automatically");
        source = "Current page legal-link scan";
      }
    }
    const bodyText = doc.body.textContent || "";
    for (const redFlag of RED_FLAGS) {
      if (redFlag.pattern.test(bodyText)) {
        warnings.push(redFlag.label);
      }
    }
    return {
      found,
      licenseNumber,
      issuingAuthority,
      jurisdiction,
      location,
      verified: found && issuingAuthority !== void 0,
      source,
      lastVerifiedAt,
      warnings
    };
  }
  /**
   * Extract license from text
   */
  extractLicense(text) {
    for (const auth of LEGITIMATE_AUTHORITIES) {
      if (auth.pattern.test(text)) {
        const licenseMatch = text.match(/\b([A-Z0-9]{4,}\/[A-Z0-9]+\/\d{4,}|\d{4,})\b/);
        return {
          found: true,
          licenseNumber: licenseMatch?.[1],
          authority: auth.name,
          jurisdiction: auth.jurisdiction
        };
      }
    }
    return { found: false };
  }
  /**
   * Verify casino legitimacy
   */
  verifyCasino(doc = document) {
    const licenseInfo = this.findLicenseInfo(doc);
    let verdict;
    let shouldAnalyze;
    let warningMessage;
    if (licenseInfo.verified) {
      verdict = "legitimate";
      shouldAnalyze = true;
    } else if (licenseInfo.found && licenseInfo.warnings.length === 0) {
      verdict = "unknown";
      shouldAnalyze = true;
      warningMessage = "License found but could not be verified automatically. Proceeding with caution.";
    } else if (licenseInfo.warnings.length > 0) {
      verdict = "suspicious";
      shouldAnalyze = true;
      warningMessage = `Suspicious licensing signals detected: ${licenseInfo.warnings.join(", ")}. Analysis is active with elevated risk indicators.`;
    } else {
      verdict = "unlicensed";
      shouldAnalyze = false;
      warningMessage = "No valid gambling license found yet. Normal TiltCheck analysis is disabled on this site.";
    }
    return {
      isLegitimate: verdict === "legitimate",
      licenseInfo,
      verdict,
      shouldAnalyze,
      warningMessage
    };
  }
  /**
   * Get user-friendly message about casino legitimacy
   */
  getVerificationMessage(verification) {
    if (verification.verdict === "legitimate") {
      return `Licensed by ${verification.licenseInfo.issuingAuthority} (${verification.licenseInfo.jurisdiction})${verification.licenseInfo.licenseNumber ? ` - License #${verification.licenseInfo.licenseNumber}` : ""}`;
    } else if (verification.verdict === "unknown") {
      return verification.warningMessage || "License status unknown";
    } else if (verification.verdict === "suspicious") {
      return verification.warningMessage || "Suspicious licensing";
    } else {
      return verification.warningMessage || "No license found";
    }
  }
};
function formatLicenseAuthority(licenseInfo) {
  return licenseInfo.issuingAuthority || "Unknown authority";
}
function formatLicenseDetails(licenseInfo) {
  const authority = formatLicenseAuthority(licenseInfo);
  const jurisdiction = licenseInfo.jurisdiction ? ` (${licenseInfo.jurisdiction})` : "";
  const licenseNumber = licenseInfo.licenseNumber ? ` #${licenseInfo.licenseNumber}` : "";
  const location = licenseInfo.location ? ` via ${licenseInfo.location}` : "";
  return `${authority}${jurisdiction}${licenseNumber}${location}`;
}
function formatVerificationDate(value) {
  if (!value) {
    return "pending";
  }
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) {
    return "unknown";
  }
  return new Date(parsed).toLocaleDateString();
}
function isStaleVerification(value) {
  if (!value) {
    return false;
  }
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) {
    return false;
  }
  return Date.now() - parsed > LICENSE_STALE_WINDOW_MS;
}
function buildLicenseDetails(licenseInfo) {
  const details = [
    `Source: ${licenseInfo.source || EXTENSION_LICENSE_SOURCE}`,
    `Last verified: ${formatVerificationDate(licenseInfo.lastVerifiedAt)}`,
    "Not legal advice. No regulator endorsement implied."
  ];
  if (isStaleVerification(licenseInfo.lastVerifiedAt)) {
    details.splice(2, 0, "Stale warning: license scan is older than 7 days.");
  }
  if (licenseInfo.warnings.length > 0) {
    details.push(`Warnings: ${licenseInfo.warnings.join(", ")}`);
  }
  return details;
}
function buildLicensePresentation(verification) {
  if (!verification) {
    return {
      tone: "pending",
      summary: "License: scanning current site...",
      details: [
        `Source: ${EXTENSION_LICENSE_SOURCE}`,
        "Last verified: pending",
        "Not legal advice. No regulator endorsement implied."
      ]
    };
  }
  const details = buildLicenseDetails(verification.licenseInfo);
  if (verification.verdict === "legitimate") {
    return {
      tone: "verified",
      summary: `License verified: ${formatLicenseDetails(verification.licenseInfo)}`,
      details
    };
  }
  if (verification.verdict === "unknown") {
    return {
      tone: "warning",
      summary: verification.warningMessage || `License found but not fully verified: ${formatLicenseDetails(verification.licenseInfo)}`,
      details
    };
  }
  return {
    tone: "risk",
    summary: verification.warningMessage || "License verification failed. Normal TiltCheck analysis is disabled on this site.",
    details
  };
}
function getAnalysisBlockMessage(verification) {
  if (!verification || verification.shouldAnalyze) {
    return null;
  }
  return verification.warningMessage || "Normal TiltCheck analysis is disabled on this site until a valid license is verified.";
}

// src/mobile-license-hud.ts
var MOBILE_LICENSE_HUD_ID = "tiltcheck-mobile-license-hud";
var MOBILE_LICENSE_HUD_STYLE_ID = "tiltcheck-mobile-license-hud-style";
var BRAND_FOOTER = "Made for Degens. By Degens.";
var TONE_STYLES = {
  verified: {
    background: "rgba(6, 78, 59, 0.92)",
    border: "rgba(110, 231, 183, 0.55)",
    color: "#d1fae5"
  },
  warning: {
    background: "rgba(113, 63, 18, 0.94)",
    border: "rgba(252, 211, 77, 0.58)",
    color: "#fef3c7"
  },
  risk: {
    background: "rgba(127, 29, 29, 0.94)",
    border: "rgba(252, 165, 165, 0.62)",
    color: "#fee2e2"
  },
  pending: {
    background: "rgba(12, 74, 110, 0.92)",
    border: "rgba(125, 211, 252, 0.55)",
    color: "#e0f2fe"
  }
};
function ensureMobileLicenseHudStyle(doc) {
  if (doc.getElementById(MOBILE_LICENSE_HUD_STYLE_ID)) {
    return;
  }
  const style = doc.createElement("style");
  style.id = MOBILE_LICENSE_HUD_STYLE_ID;
  style.textContent = `
    #${MOBILE_LICENSE_HUD_ID} {
      position: fixed;
      top: calc(env(safe-area-inset-top, 0px) + 8px);
      left: 10px;
      right: 10px;
      z-index: 2147483646;
      display: none;
      min-height: 38px;
      padding: 9px 12px;
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 12px;
      box-sizing: border-box;
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.42);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 12px;
      font-weight: 800;
      line-height: 1.3;
      letter-spacing: 0.01em;
      text-align: center;
      pointer-events: none;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    @media (max-width: 768px), (pointer: coarse) {
      #${MOBILE_LICENSE_HUD_ID} {
        display: block;
      }
    }
  `;
  doc.head.appendChild(style);
}
function ensureMobileLicenseHud(doc) {
  ensureMobileLicenseHudStyle(doc);
  const existing = doc.getElementById(MOBILE_LICENSE_HUD_ID);
  if (existing) {
    return existing;
  }
  const hud = doc.createElement("div");
  hud.id = MOBILE_LICENSE_HUD_ID;
  hud.setAttribute("role", "status");
  hud.setAttribute("aria-live", "polite");
  hud.dataset.status = "pending";
  doc.body.appendChild(hud);
  return hud;
}
function updateMobileLicenseHud(verification, doc = document) {
  if (!doc.body || !doc.head) {
    return null;
  }
  const presentation = buildLicensePresentation(verification);
  const hud = ensureMobileLicenseHud(doc);
  const toneStyle = TONE_STYLES[presentation.tone];
  hud.textContent = `${presentation.summary} | ${BRAND_FOOTER}`;
  hud.className = `tiltcheck-mobile-license-hud ${presentation.tone}`;
  hud.dataset.status = presentation.tone;
  hud.style.background = toneStyle.background;
  hud.style.borderColor = toneStyle.border;
  hud.style.color = toneStyle.color;
  return hud;
}

// src/FairnessService.ts
var FairnessService = class {
  /**
   * Generates a provably fair HMAC-SHA256 hash (The 4-Key Lock).
   * 
   * Formula: R = HMAC_SHA256(Solana_Block_Hash, Discord_ID + Client_Seed + Nonce)
   *
   * @param solanaBlockHash - The Solana Block Hash (Platform Entropy / The Salt)
   * @param discordId - The User's Discord ID (Identity Entropy)
   * @param clientSeed - The user-controlled client seed (User Entropy)
   * @param nonce - Sequential counter ensuring uniqueness (Incremental Entropy)
   * @returns The resulting hex string of the HMAC
   */
  async generateHash(solanaBlockHash, discordId, clientSeed, nonce = 0) {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(solanaBlockHash);
    const messageData = encoder.encode(`${discordId}${clientSeed}:${nonce}`);
    const subtle = crypto.subtle || crypto.webcrypto?.subtle;
    const key = await subtle.importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await subtle.sign(
      "HMAC",
      key,
      messageData
    );
    return this.bufferToHex(signature);
  }
  /**
   * Converts a hex hash into a normalized float (0.0 to 1.0).
   * Useful for determining game outcomes (e.g. dice rolls, win/loss).
   * 
   * Standard implementation: Takes the first 4 bytes (32 bits) of the hash.
   */
  hashToFloat(hexHash) {
    const subHash = hexHash.substring(0, 8);
    const intValue = parseInt(subHash, 16);
    return intValue / 4294967295;
  }
  /**
   * Calculates a standard Dice result (0.00 to 100.00).
   * Used by Stake, BC.Game, etc.
   * 
   * Logic: Float * 10001 / 100
   */
  getDiceResult(float) {
    return Math.floor(float * 10001) / 100;
  }
  /**
   * Calculates a Limbo/Crash multiplier.
   * 
   * Logic: 0.99 / (1 - float)
   * This creates the exponential distribution required for crash games.
   * 
   * @param float - The normalized float (0.0 to 1.0)
   * @param houseEdge - The house edge (default 0.01 / 1%)
   */
  getLimboResult(float, houseEdge = 0.01) {
    if (float === 1) return 1e6;
    const multiplier = (1 - houseEdge) / (1 - float);
    return Math.floor(multiplier * 100) / 100;
  }
  /**
   * Calculates Plinko path directions.
   * Plinko requires multiple random decisions (one per row).
   * 
   * @param hexHash - The full HMAC hash
   * @param rows - Number of rows (8-16 usually)
   * @returns Array of 0 (Left) and 1 (Right)
   */
  getPlinkoPath(hexHash, rows) {
    const directions = [];
    for (let i = 0; i < rows * 2; i += 2) {
      const byte = parseInt(hexHash.substring(i, i + 2), 16);
      directions.push(byte % 2);
    }
    return directions;
  }
  /**
   * Verifies if a reported result matches the "Double Provably Fair" inputs.
   * Used by the Browser Extension to detect fraud.
   * 
   * @param reportedHash - The hash reported by the casino/house
   * @param solanaBlockHash - The Solana Block Hash used for the bet
   * @param discordId - The User's Discord ID
   * @param clientSeed - The User's Client Seed
   * @param nonce - Sequential counter
   */
  async verify(reportedHash, solanaBlockHash, discordId, clientSeed, nonce = 0) {
    const calculatedHash = await this.generateHash(solanaBlockHash, discordId, clientSeed, nonce);
    return calculatedHash === reportedHash;
  }
  /**
   * Verifies standard casino game fairness using server seed, client seed, and nonce.
   */
  async verifyCasinoResult(serverSeed, clientSeed, nonce) {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(serverSeed);
    const messageData = encoder.encode(`${clientSeed}:${nonce}`);
    const key = await (crypto.subtle || crypto.webcrypto.subtle).importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await (crypto.subtle || crypto.webcrypto.subtle).sign(
      "HMAC",
      key,
      messageData
    );
    return this.bufferToHex(signature);
  }
  bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
};

// src/analyzer.ts
var Analyzer = class {
  fairness;
  constructor() {
    this.fairness = new FairnessService();
  }
  /**
   * Watches the DOM for a specific element to appear that contains the game result.
   * Useful for SPAs where the result appears dynamically after the bet.
   * 
   * @param selector - CSS selector for the result element
   * @param parser - Function to extract the GameResult from the DOM element
   * @param timeoutMs - Max time to wait for result
   */
  async waitForResult(selector, parser, timeoutMs = 1e4) {
    return new Promise((resolve, reject) => {
      const existingEl = document.querySelector(selector);
      if (existingEl) {
        resolve(parser(existingEl));
        return;
      }
      const observer = new MutationObserver((mutations, obs) => {
        const element = document.querySelector(selector);
        if (element) {
          obs.disconnect();
          resolve(parser(element));
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true
        // Some casinos update data attributes
      });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error("Timeout waiting for game result"));
      }, timeoutMs);
    });
  }
  /**
   * Verifies if the scraped result matches the commitment.
   */
  async verify(result, commitment) {
    const expectedHash = await this.fairness.generateHash(
      commitment.blockHash,
      commitment.discordId,
      commitment.clientSeed,
      commitment.nonce
    );
    if (result.rawHash) {
      return { isValid: result.rawHash === expectedHash, expectedHash };
    }
    const expectedFloat = this.fairness.hashToFloat(expectedHash);
    const epsilon = 1e-5;
    const isValid = Math.abs(expectedFloat - result.value) < epsilon;
    return { isValid, expectedHash };
  }
};

// src/config.ts
var EXT_CONFIG = {
  API_BASE_URL: "https://api.tiltcheck.me",
  HUB_URL: "https://api.tiltcheck.me",
  DASHBOARD_URL: "https://tiltcheck.me/dashboard",
  AI_GATEWAY_URL: "https://api.tiltcheck.me/ai",
  WEB_APP_URL: "https://tiltcheck.me",
  DISCORD_CLIENT_ID: "1445916179163250860",
  // Operations & Revenue (GCP Bill Fund)
  OPERATIONS_WALLET: "BvzEqVRUicmW8Y6HFncLYrGXESpMbSNDkWUNTQj5GGGi",
  PROTOCOL_FEE_BPS: 250
  // 2.5% service fee
};
var TELEMETRY_BASE_PATH = "/v1/telemetry";
var TELEMETRY_PATH = `${TELEMETRY_BASE_PATH}/round`;
var WIN_SECURE_PATH = `${TELEMETRY_BASE_PATH}/win-secure`;
var TELEMETRY_REQUEST_HEADERS = Object.freeze({
  "Content-Type": "application/json",
  "X-Requested-With": "TiltCheckExtension"
});
function normalizeBaseUrl(url) {
  return url.replace(/\/+$/, "");
}
function getHubEndpoint(path) {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${normalizeBaseUrl(EXT_CONFIG.HUB_URL)}${normalizedPath}`;
}

// src/telemetry-client.ts
function postTelemetry(path, payload) {
  return fetch(getHubEndpoint(path), {
    method: "POST",
    headers: TELEMETRY_REQUEST_HEADERS,
    body: JSON.stringify(payload)
  });
}
function postRoundTelemetry(payload) {
  return postTelemetry(TELEMETRY_PATH, payload);
}
function postWinSecureTelemetry(payload) {
  return postTelemetry(WIN_SECURE_PATH, payload);
}

// ../../packages/types/src/index.ts
var GAME_EXCLUSION_CATEGORIES = [
  "chicken_mines",
  "bonus_buy",
  "live_dealer",
  "slots",
  "crash",
  "table_games"
];

// src/exclusion-taxonomy.ts
var CATEGORY_KEYWORDS = {
  chicken_mines: ["chicken", "mines", "minefield", "chicken-road", "chickenroad"],
  bonus_buy: ["bonus-buy", "bonusbuy", "feature-buy", "featurebuy"],
  live_dealer: ["live-dealer", "live-casino", "live_dealer", "livecasino"],
  slots: ["slot", "slots"],
  crash: ["crash", "aviator", "jetx", "spaceman"],
  table_games: ["blackjack", "roulette", "baccarat", "poker", "table"]
};
function matchExclusion(haystack, slugs, categories) {
  const lower = haystack.toLowerCase();
  if (!lower.trim()) return null;
  for (const category of categories) {
    const keywords = CATEGORY_KEYWORDS[category] ?? [];
    if (keywords.some((keyword) => lower.includes(keyword))) {
      return { kind: "category", value: category };
    }
  }
  for (const slug of slugs) {
    const needle = slug.trim().toLowerCase();
    if (needle.length >= 2 && lower.includes(needle)) {
      return { kind: "slug", value: slug };
    }
  }
  return null;
}
function haystackFromLocation(loc) {
  return `${loc.pathname}${loc.search}${loc.href ?? ""}`.toLowerCase();
}
function haystackFromElement(el) {
  const card = el.closest('a, button, [role="button"], [data-game-id], [data-game-name], [data-game], article, li');
  const node = card ?? el;
  return [
    node.getAttribute("href"),
    node.getAttribute("src"),
    node.getAttribute("data-game-id"),
    node.getAttribute("data-game-name"),
    node.getAttribute("data-game"),
    node.getAttribute("data-testid"),
    node.textContent
  ].filter(Boolean).join(" ").toLowerCase();
}

// src/game-blocker.ts
var OVERLAY_ID = "tiltcheck-game-block-overlay";
var POLL_INTERVAL_MS = 3e3;
var CACHE_TTL_MS = 5 * 60 * 1e3;
var CATEGORY_SLUGS = CATEGORY_KEYWORDS;
var GameBlocker = class {
  profile = null;
  profileFetchedAt = 0;
  discordId;
  authToken;
  observer = null;
  pollTimer = null;
  dismissStorageKey = `tiltcheck_game_block_dismissed:${window.location.hostname.toLowerCase()}`;
  handleWindowFocus = () => {
    void this.refreshAndScan(true);
  };
  handlePageShow = () => {
    void this.refreshAndScan(true);
  };
  handleVisibilityChange = () => {
    if (document.visibilityState === "visible") {
      void this.refreshAndScan(true);
    }
  };
  constructor(discordId, authToken) {
    this.discordId = discordId;
    this.authToken = authToken;
  }
  async init() {
    await this.refreshProfile();
    this.scan();
    this.startObserver();
    this.startPoller();
    this.attachReturnListeners();
  }
  resume(_source = "navigation") {
    void this.refreshAndScan(true);
  }
  destroy() {
    this.observer?.disconnect();
    if (this.pollTimer) clearInterval(this.pollTimer);
    this.detachReturnListeners();
    this.removeOverlay();
  }
  // ─── Profile management ────────────────────────────────────────────────────
  async refreshProfile(force = false) {
    const now = Date.now();
    if (!force && this.profile && now - this.profileFetchedAt < CACHE_TTL_MS) return;
    try {
      const resp = await fetch(
        `${EXT_CONFIG.API_BASE_URL}/user/${encodeURIComponent(this.discordId)}/exclusions`,
        {
          credentials: "include",
          headers: {
            Authorization: `Bearer ${this.authToken}`
          }
        }
      );
      if (!resp.ok) return;
      const body = await resp.json();
      if (body.success && body.data) {
        this.profile = body.data;
        this.profileFetchedAt = now;
      }
    } catch {
    }
  }
  async refreshAndScan(force = false) {
    await this.refreshProfile(force);
    this.scan();
  }
  // ─── Matching helpers ──────────────────────────────────────────────────────
  normalizeLookupValue(value) {
    if (!value) return null;
    const normalized = value.trim().toLowerCase();
    return normalized.length > 0 ? normalized : null;
  }
  normalizeSlugValue(value) {
    if (!value) return null;
    const normalized = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return normalized.length > 0 ? normalized : null;
  }
  tokenMatches(blockedValue, candidateValue) {
    return candidateValue === blockedValue || candidateValue.startsWith(`${blockedValue}-`) || blockedValue.startsWith(`${candidateValue}-`);
  }
  matchGameId(slug) {
    if (!this.profile) return null;
    const lower = this.normalizeLookupValue(slug);
    if (!lower) return null;
    for (const id of this.profile.blockedGameIds) {
      const blockedId = this.normalizeLookupValue(id);
      if (blockedId && lower.includes(blockedId)) {
        const entry = this.profile.exclusions.find((e) => e.gameId === id) ?? null;
        return { gameId: id, category: null, provider: null, casino: null, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  matchCategory(slug) {
    if (!this.profile) return null;
    const lower = slug.toLowerCase();
    for (const cat of this.profile.blockedCategories) {
      const keywords = CATEGORY_SLUGS[cat] ?? [];
      if (keywords.some((kw) => lower.includes(kw))) {
        const entry = this.profile.exclusions.find((e) => e.category === cat) ?? null;
        return { gameId: null, category: cat, provider: null, casino: null, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  collectProviderCandidates() {
    const candidates = /* @__PURE__ */ new Set();
    const addCandidate = (value) => {
      const normalized = this.normalizeSlugValue(value);
      if (normalized) {
        candidates.add(normalized);
      }
    };
    addCandidate(document.title);
    addCandidate(window.location.pathname);
    addCandidate(window.location.search);
    const metaProvider = document.querySelector('meta[name="provider"], meta[property="og:provider"]');
    addCandidate(metaProvider?.content);
    for (const element of Array.from(document.querySelectorAll("[data-provider], [data-provider-name], [data-game-provider], [data-game-provider-name]"))) {
      addCandidate(element.dataset["provider"]);
      addCandidate(element.dataset["providerName"]);
      addCandidate(element.dataset["gameProvider"]);
      addCandidate(element.dataset["gameProviderName"]);
      addCandidate(element.getAttribute("data-provider"));
      addCandidate(element.getAttribute("data-provider-name"));
      addCandidate(element.getAttribute("data-game-provider"));
      addCandidate(element.getAttribute("data-game-provider-name"));
    }
    return [...candidates];
  }
  collectCasinoCandidates() {
    const hostname2 = window.location.hostname.toLowerCase();
    const candidates = /* @__PURE__ */ new Set();
    const addCandidate = (value) => {
      const normalized = this.normalizeSlugValue(value);
      if (normalized) {
        candidates.add(normalized);
      }
    };
    addCandidate(hostname2);
    for (const segment of hostname2.split(".")) {
      addCandidate(segment);
    }
    addCandidate(hostname2.split(".")[0] ?? "");
    return [...candidates];
  }
  matchProvider() {
    if (!this.profile) return null;
    const candidates = this.collectProviderCandidates();
    for (const provider of this.profile.blockedProviders) {
      const blockedProvider = this.normalizeSlugValue(provider);
      if (!blockedProvider) continue;
      const matched = candidates.some((candidate) => this.tokenMatches(blockedProvider, candidate));
      if (matched) {
        const entry = this.profile.exclusions.find((e) => e.provider === provider) ?? null;
        return { gameId: null, category: null, provider, casino: null, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  matchCasino() {
    if (!this.profile) return null;
    const candidates = this.collectCasinoCandidates();
    for (const casino of this.profile.blockedCasinos) {
      const blockedCasino = this.normalizeSlugValue(casino);
      if (!blockedCasino) continue;
      const matched = candidates.some((candidate) => this.tokenMatches(blockedCasino, candidate));
      if (matched) {
        const entry = this.profile.exclusions.find((e) => e.casino === casino) ?? null;
        return { gameId: null, category: null, provider: null, casino, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  isBlocked(slug) {
    return this.matchGameId(slug) ?? this.matchCategory(slug) ?? this.matchProvider() ?? this.matchCasino();
  }
  // ─── DOM scan ─────────────────────────────────────────────────────────────
  scan() {
    if (this.isDismissedForSession()) {
      this.removeOverlay();
      return;
    }
    if (!this.profile) return;
    const urlSlug = window.location.pathname + window.location.search;
    const urlMatch = this.isBlocked(urlSlug);
    if (urlMatch) {
      this.injectOverlay(urlMatch);
      return;
    }
    for (const iframe of Array.from(document.querySelectorAll("iframe[src]"))) {
      const match = this.isBlocked(iframe.src);
      if (match) {
        this.injectOverlay(match);
        return;
      }
    }
    for (const btn of Array.from(document.querySelectorAll("[data-game-id]"))) {
      const gameId = btn.dataset["gameId"] ?? "";
      const match = this.isBlocked(gameId);
      if (match) {
        this.injectOverlay(match);
        return;
      }
    }
    this.removeOverlay();
  }
  // ─── DOM observer ─────────────────────────────────────────────────────────
  startObserver() {
    this.observer = new MutationObserver(() => this.scan());
    this.observer.observe(document.body, { childList: true, subtree: true, attributes: true });
  }
  attachReturnListeners() {
    window.addEventListener("focus", this.handleWindowFocus);
    window.addEventListener("pageshow", this.handlePageShow);
    document.addEventListener("visibilitychange", this.handleVisibilityChange);
  }
  detachReturnListeners() {
    window.removeEventListener("focus", this.handleWindowFocus);
    window.removeEventListener("pageshow", this.handlePageShow);
    document.removeEventListener("visibilitychange", this.handleVisibilityChange);
  }
  // ─── Profile refresh poller ───────────────────────────────────────────────
  startPoller() {
    this.pollTimer = setInterval(async () => {
      await this.refreshAndScan();
    }, POLL_INTERVAL_MS);
  }
  // ─── Overlay ──────────────────────────────────────────────────────────────
  injectOverlay(match) {
    if (document.getElementById(OVERLAY_ID)) return;
    const label = match.gameId ? `game ID: ${match.gameId}` : match.category ? `category: ${(match.category ?? "").replace(/_/g, " ")}` : match.provider ? `provider: ${match.provider.replace(/[-_]/g, " ")}` : `casino: ${(match.casino ?? "").replace(/[-_]/g, " ")}`;
    const reasonHtml = match.reason ? `<p class="tc-block-reason">"${match.reason}"</p>` : "";
    const safetyUrl = `${EXT_CONFIG.DASHBOARD_URL}?tab=safety`;
    const overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.innerHTML = `
      <div class="tc-block-inner">
        <div class="tc-block-badge">BLOCKED BY YOU</div>
        <h2 class="tc-block-title">Not today.</h2>
        <p class="tc-block-body">
          You told TiltCheck to block ${label}.<br>
          Past-you was looking out for present-you. Respect the call.<br>
          The dashboard owns the filter. This page just enforces it.
        </p>
        ${reasonHtml}
        <div class="tc-block-actions">
          <a class="tc-block-btn tc-block-btn--primary" href="${safetyUrl}" target="_blank">
            Open Safety Controls
          </a>
          <button class="tc-block-btn tc-block-btn--ghost" id="tc-block-dismiss">
            Dismiss for this session
          </button>
        </div>
        <footer class="tc-block-footer">Made for Degens. By Degens.</footer>
      </div>
    `;
    this.applyStyles(overlay);
    document.body.appendChild(overlay);
    document.getElementById("tc-block-dismiss")?.addEventListener("click", () => {
      this.setDismissedForSession(true);
      this.removeOverlay();
    });
  }
  isDismissedForSession() {
    try {
      return window.sessionStorage.getItem(this.dismissStorageKey) === "1";
    } catch {
      return false;
    }
  }
  setDismissedForSession(dismissed) {
    try {
      if (dismissed) {
        window.sessionStorage.setItem(this.dismissStorageKey, "1");
      } else {
        window.sessionStorage.removeItem(this.dismissStorageKey);
      }
    } catch {
    }
  }
  removeOverlay() {
    document.getElementById(OVERLAY_ID)?.remove();
  }
  applyStyles(overlay) {
    Object.assign(overlay.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483647",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.92)",
      fontFamily: "system-ui, sans-serif"
    });
    const style = document.createElement("style");
    style.textContent = `
      #${OVERLAY_ID} .tc-block-inner {
        max-width: 480px;
        width: 90%;
        background: #111;
        border: 1px solid #333;
        border-radius: 12px;
        padding: 40px 32px 28px;
        text-align: center;
        color: #f0f0f0;
      }
      #${OVERLAY_ID} .tc-block-badge {
        display: inline-block;
        background: #dc2626;
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.12em;
        padding: 4px 10px;
        border-radius: 4px;
        margin-bottom: 16px;
        text-transform: uppercase;
      }
      #${OVERLAY_ID} .tc-block-title {
        font-size: 28px;
        font-weight: 800;
        margin: 0 0 12px;
        color: #fff;
      }
      #${OVERLAY_ID} .tc-block-body {
        font-size: 15px;
        line-height: 1.6;
        color: #aaa;
        margin: 0 0 12px;
      }
      #${OVERLAY_ID} .tc-block-reason {
        font-style: italic;
        color: #888;
        font-size: 13px;
        margin-bottom: 24px;
      }
      #${OVERLAY_ID} .tc-block-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 28px;
      }
      #${OVERLAY_ID} .tc-block-btn {
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        border: none;
      }
      #${OVERLAY_ID} .tc-block-btn--primary {
        background: #7c3aed;
        color: #fff;
      }
      #${OVERLAY_ID} .tc-block-btn--ghost {
        background: transparent;
        color: #666;
        font-size: 12px;
      }
      #${OVERLAY_ID} .tc-block-btn--ghost:hover { color: #999; }
      #${OVERLAY_ID} .tc-block-footer {
        font-size: 11px;
        color: #444;
        letter-spacing: 0.05em;
      }
    `;
    document.head.appendChild(style);
  }
};

// src/pro/blocked-games-options.ts
var TILTCHECK_BLOCKED_GAMES_KEY = "tiltcheck_blocked_games";
var TILTCHECK_BLOCKED_CATEGORIES_KEY = "tiltcheck_blocked_categories";
var TILTCHECK_GAME_BLOCK_OPT_IN_KEY = "tiltcheck_game_block_opt_in";
var MAX_BLOCKED_ENTRIES = 64;
var MAX_SLUG_LENGTH = 48;
function normalizeBlockedGameSlug(value) {
  if (typeof value !== "string") return null;
  const slug = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  if (!slug || slug.length > MAX_SLUG_LENGTH) return null;
  return slug;
}
function normalizeBlockedGamesList(raw) {
  if (!Array.isArray(raw)) return [];
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const item of raw) {
    const slug = normalizeBlockedGameSlug(item);
    if (!slug || seen.has(slug)) continue;
    seen.add(slug);
    out.push(slug);
    if (out.length >= MAX_BLOCKED_ENTRIES) break;
  }
  return out;
}
async function loadBlockedGameSlugs() {
  try {
    const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_GAMES_KEY);
    return normalizeBlockedGamesList(stored[TILTCHECK_BLOCKED_GAMES_KEY]);
  } catch {
    return [];
  }
}
function normalizeBlockedCategories(raw) {
  if (!Array.isArray(raw)) return [];
  const allowed = new Set(GAME_EXCLUSION_CATEGORIES);
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const item of raw) {
    if (typeof item !== "string" || !allowed.has(item) || seen.has(item)) continue;
    seen.add(item);
    out.push(item);
  }
  return out;
}
async function loadBlockedCategories() {
  try {
    const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_CATEGORIES_KEY);
    return normalizeBlockedCategories(stored[TILTCHECK_BLOCKED_CATEGORIES_KEY]);
  } catch {
    return [];
  }
}
async function loadGameBlockOptIn() {
  try {
    const stored = await chrome.storage.local.get(TILTCHECK_GAME_BLOCK_OPT_IN_KEY);
    return stored[TILTCHECK_GAME_BLOCK_OPT_IN_KEY] === true;
  } catch {
    return false;
  }
}

// src/pro/containment.ts
var TILTCHECK_SAFETY_ROOT_IDS = [
  "tiltcheck-lockdown-root",
  "tiltcheck-local-game-block-overlay",
  "tiltcheck-cooldown-overlay",
  "tiltcheck-game-block-overlay",
  "tiltcheck-redeem-nudge",
  "tiltcheck-sidebar",
  "tiltcheck-mobile-license-hud",
  "tiltcheck-cooldown-hud"
];
function isInsideTiltcheckSafetyRoot(node) {
  if (!node || typeof Element === "undefined" || !(node instanceof Element)) {
    return false;
  }
  for (const id of TILTCHECK_SAFETY_ROOT_IDS) {
    if (node.closest(`#${id}`)) {
      return true;
    }
  }
  return false;
}
function mutationsOnlyTouchSafetyRoots(mutations) {
  const nodes = [];
  for (const m of mutations) {
    for (const n of m.addedNodes) {
      nodes.push(n);
    }
    if (m.target) {
      nodes.push(m.target);
    }
  }
  if (nodes.length === 0) {
    return false;
  }
  return nodes.every((n) => {
    if (typeof Element === "undefined" || !(n instanceof Element)) {
      return true;
    }
    return isInsideTiltcheckSafetyRoot(n);
  });
}

// src/pro/local-game-blocker.ts
var LOCAL_OVERLAY_ID = "tiltcheck-local-game-block-overlay";
var SANITIZED_ATTR = "data-tiltcheck-local-blocked";
var PLACEHOLDER_LABEL = "[ GAME EXCLUDED ]";
var installed = null;
function installLocalGameBlocker(doc = document) {
  if (installed) return installed;
  installed = new LocalGameBlocker(doc);
  void installed.init();
  return installed;
}
var LocalGameBlocker = class {
  blockedSlugs = [];
  blockedCategories = [];
  enforcementEnabled = false;
  observer = null;
  scanScheduled = false;
  storageListenerAttached = false;
  clickBound = false;
  doc;
  constructor(doc = document) {
    this.doc = doc;
  }
  onBlockedPointer = (event) => {
    if (!this.enforcementEnabled) return;
    if (this.blockedSlugs.length === 0 && this.blockedCategories.length === 0) return;
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (isInsideTiltcheckSafetyRoot(target)) return;
    const hit = matchExclusion(haystackFromElement(target), this.blockedSlugs, this.blockedCategories);
    if (!hit) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    const card = target.closest('a, button, [role="button"], article, li, div');
    if (card instanceof HTMLElement) {
      this.sanitizeNode(card, hit.value);
    }
  };
  handleStorageChange = (changes, area) => {
    if (area !== "local") return;
    if (changes[TILTCHECK_BLOCKED_GAMES_KEY] || changes[TILTCHECK_BLOCKED_CATEGORIES_KEY] || changes[TILTCHECK_GAME_BLOCK_OPT_IN_KEY]) {
      void this.reloadAndScan();
    }
  };
  async init() {
    await this.reloadAndScan();
    this.startObserver();
    this.attachStorageListener();
    this.attachClickGuard();
  }
  resume(_source = "navigation") {
    void this.reloadAndScan();
  }
  destroy() {
    this.observer?.disconnect();
    this.observer = null;
    if (this.storageListenerAttached) {
      try {
        chrome.storage.onChanged.removeListener(this.handleStorageChange);
      } catch {
      }
      this.storageListenerAttached = false;
    }
    this.removeUrlOverlay();
    this.detachClickGuard();
    if (installed === this) installed = null;
  }
  attachStorageListener() {
    if (this.storageListenerAttached) return;
    try {
      chrome.storage.onChanged.addListener(this.handleStorageChange);
      this.storageListenerAttached = true;
    } catch {
    }
  }
  async reloadAndScan() {
    this.enforcementEnabled = await loadGameBlockOptIn();
    this.blockedSlugs = this.enforcementEnabled ? await loadBlockedGameSlugs() : [];
    this.blockedCategories = this.enforcementEnabled ? await loadBlockedCategories() : [];
    this.scan();
  }
  scheduleScan() {
    if (this.scanScheduled) return;
    this.scanScheduled = true;
    const run = () => {
      this.scanScheduled = false;
      this.scan();
    };
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(run);
    } else {
      setTimeout(run, 0);
    }
  }
  scan() {
    if (this.blockedSlugs.length === 0 && this.blockedCategories.length === 0) {
      this.removeUrlOverlay();
      return;
    }
    const urlHit = this.matchHref(window.location.href);
    if (urlHit) {
      this.injectUrlOverlay(urlHit.value);
      return;
    }
    this.removeUrlOverlay();
    this.redactDomMatches();
  }
  /** Returns matched slug/category when URL path/search references a blocked game. */
  matchUrl(href, slugs = this.blockedSlugs, categories = this.blockedCategories) {
    return this.matchHref(href, slugs, categories)?.value ?? null;
  }
  matchHref(href, slugs = this.blockedSlugs, categories = this.blockedCategories) {
    let loc = { pathname: href, search: "", href };
    try {
      const parsed = new URL(href, window.location.origin);
      loc = { pathname: parsed.pathname, search: parsed.search, href: parsed.href };
    } catch {
    }
    return matchExclusion(haystackFromLocation(loc), slugs, categories);
  }
  redactDomMatches() {
    const nodesByKey = this.collectBlockedNodes();
    for (const [key, nodes] of nodesByKey) {
      for (const node of nodes) {
        this.sanitizeNode(node, key);
      }
    }
  }
  /** Single-pass DOM scan: map each blocked slug/category to nodes that reference it. */
  collectBlockedNodes() {
    const buckets = /* @__PURE__ */ new Map();
    const tryAdd = (el, key) => {
      if (!el || !(el instanceof HTMLElement)) return;
      if (isInsideTiltcheckSafetyRoot(el)) return;
      if (el.closest(`#${LOCAL_OVERLAY_ID}`)) return;
      const card = el.closest('a, button, [role="button"], article, li, div');
      if (!buckets.has(key)) buckets.set(key, /* @__PURE__ */ new Set());
      buckets.get(key)?.add(card ?? el);
    };
    const consider = (el) => {
      const hit = matchExclusion(haystackFromElement(el), this.blockedSlugs, this.blockedCategories);
      if (hit) tryAdd(el, hit.value);
    };
    for (const anchor of this.doc.querySelectorAll("a[href]")) {
      consider(anchor);
    }
    for (const el of this.doc.querySelectorAll(
      'button, [role="button"], [data-game-name], [data-game-id], [data-game], [data-testid*="game"]'
    )) {
      consider(el);
    }
    const result = /* @__PURE__ */ new Map();
    for (const [key, set] of buckets) {
      if (set.size > 0) {
        result.set(key, [...set]);
      }
    }
    return result;
  }
  attachClickGuard() {
    if (this.clickBound) return;
    this.doc.addEventListener("click", this.onBlockedPointer, true);
    this.doc.addEventListener("pointerdown", this.onBlockedPointer, true);
    this.clickBound = true;
  }
  detachClickGuard() {
    if (!this.clickBound) return;
    this.doc.removeEventListener("click", this.onBlockedPointer, true);
    this.doc.removeEventListener("pointerdown", this.onBlockedPointer, true);
    this.clickBound = false;
  }
  disableInteractiveTarget(target) {
    target.style.pointerEvents = "none";
    if (target instanceof HTMLButtonElement) {
      target.disabled = true;
    }
    if (target.getAttribute("role") === "button") {
      target.setAttribute("aria-disabled", "true");
      target.tabIndex = -1;
    }
  }
  sanitizeNode(target, slug) {
    if (target.getAttribute(SANITIZED_ATTR) === slug) return;
    const placeholder = document.createElement("div");
    placeholder.setAttribute(SANITIZED_ATTR, slug);
    placeholder.setAttribute("aria-label", `Game excluded: ${slug}`);
    placeholder.style.cssText = `
      background: #1a1d24;
      color: #ff4a4a;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 72px;
      height: 100%;
      width: 100%;
      font-family: ui-monospace, monospace;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      border: 1px dashed #ff4a4a;
      border-radius: 4px;
      box-sizing: border-box;
      pointer-events: none;
      user-select: none;
    `;
    placeholder.textContent = PLACEHOLDER_LABEL;
    if (target.tagName === "A") {
      const wrap = document.createElement("div");
      wrap.setAttribute(SANITIZED_ATTR, slug);
      wrap.style.pointerEvents = "none";
      wrap.appendChild(placeholder);
      target.replaceChildren(wrap);
      target.removeAttribute("href");
      this.disableInteractiveTarget(target);
      target.setAttribute(SANITIZED_ATTR, slug);
      return;
    }
    target.replaceChildren(placeholder);
    this.disableInteractiveTarget(target);
    target.setAttribute(SANITIZED_ATTR, slug);
  }
  injectUrlOverlay(slug) {
    if (document.getElementById(LOCAL_OVERLAY_ID)) return;
    const overlay = document.createElement("div");
    overlay.id = LOCAL_OVERLAY_ID;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", `Access denied: ${slug} is on your exclusion list`);
    Object.assign(overlay.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483646",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(10, 12, 16, 0.97)",
      fontFamily: "ui-monospace, monospace",
      color: "#f5f5f5",
      padding: "24px",
      boxSizing: "border-box"
    });
    overlay.innerHTML = `
      <div style="max-width: 420px; text-align: center; border: 1px solid #333; border-radius: 12px; padding: 32px 24px; background: #111;">
        <div style="color: #ff4a4a; font-size: 11px; font-weight: 800; letter-spacing: 0.2em; margin-bottom: 12px;">STRATEGIC FILTER</div>
        <h2 style="margin: 0 0 12px; font-size: 22px; font-weight: 900; color: #fff;">Access denied.</h2>
        <p style="margin: 0 0 8px; font-size: 14px; line-height: 1.5; color: #aaa;">
          <strong style="color: #ff4a4a;">${slug}</strong> is on your local exclusion list.
        </p>
        <p style="margin: 0 0 20px; font-size: 12px; line-height: 1.45; color: #666;">
          You put this on your list. It does not click. Edit the list in the extension Guards tab.
        </p>
        <button type="button" id="tiltcheck-local-block-back" style="
          background: transparent;
          border: 1px solid #444;
          color: #ccc;
          padding: 10px 18px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          text-transform: uppercase;
          letter-spacing: 0.06em;
        ">Go back</button>
        <footer style="margin-top: 20px; font-size: 10px; color: #444;">Made for Degens. By Degens.</footer>
      </div>
    `;
    document.body.appendChild(overlay);
    document.getElementById("tiltcheck-local-block-back")?.addEventListener("click", () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.assign("/");
      }
    });
  }
  removeUrlOverlay() {
    document.getElementById(LOCAL_OVERLAY_ID)?.remove();
  }
  startObserver() {
    if (!this.doc.body) return;
    this.observer = new MutationObserver((mutations) => {
      if (mutationsOnlyTouchSafetyRoots(mutations)) {
        return;
      }
      this.scheduleScan();
    });
    this.observer.observe(this.doc.body, { childList: true, subtree: true });
  }
};

// src/audio-alerts.ts
var DEFAULT_AUDIO_ALERTS_CONFIG = {
  enabled: true,
  volume: 0.25
};
var cachedConfig = { ...DEFAULT_AUDIO_ALERTS_CONFIG };
var globalAudioCtx = null;
function getOrCreateAudioContext(audioContextOverride) {
  if (audioContextOverride !== void 0) {
    return audioContextOverride;
  }
  if (typeof window === "undefined") return null;
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return null;
  try {
    if (!globalAudioCtx || globalAudioCtx.state === "closed") {
      globalAudioCtx = new AudioContextClass();
    }
    if (globalAudioCtx.state === "suspended") {
      globalAudioCtx.resume().catch(() => {
      });
    }
    return globalAudioCtx;
  } catch {
    return null;
  }
}
function playAudioCue(cue, customVolume, audioContextOverride) {
  if (!cachedConfig.enabled) {
    return false;
  }
  const ctx = getOrCreateAudioContext(audioContextOverride);
  if (!ctx) {
    return false;
  }
  const baseVolume = typeof customVolume === "number" ? customVolume : cachedConfig.volume;
  const clampedVol = Math.max(0, Math.min(1, baseVolume));
  if (clampedVol <= 0) {
    return false;
  }
  try {
    const now = ctx.currentTime;
    switch (cue) {
      case "spin_brake": {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(330, now + 0.08);
        gain.gain.setValueAtTime(1e-3, now);
        gain.gain.linearRampToValueAtTime(clampedVol * 0.7, now + 0.01);
        gain.gain.exponentialRampToValueAtTime(1e-3, now + 0.08);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.08);
        return true;
      }
      case "cold_warn": {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(520, now);
        gain.gain.setValueAtTime(1e-3, now);
        gain.gain.linearRampToValueAtTime(clampedVol * 0.8, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(1e-3, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.12);
        return true;
      }
      case "due_trap": {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(660, now);
        osc.frequency.setValueAtTime(440, now + 0.05);
        osc.frequency.setValueAtTime(310, now + 0.1);
        gain.gain.setValueAtTime(1e-3, now);
        gain.gain.linearRampToValueAtTime(clampedVol * 0.5, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(1e-3, now + 0.18);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.18);
        return true;
      }
      case "heater_alert": {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(587, now);
        osc.frequency.setValueAtTime(880, now + 0.06);
        gain.gain.setValueAtTime(1e-3, now);
        gain.gain.linearRampToValueAtTime(clampedVol * 0.8, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(1e-3, now + 0.14);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.14);
        return true;
      }
      case "cooldown_chime": {
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();
        osc1.type = "sine";
        osc1.frequency.setValueAtTime(528, now);
        osc2.type = "sine";
        osc2.frequency.setValueAtTime(792, now);
        gain.gain.setValueAtTime(1e-3, now);
        gain.gain.linearRampToValueAtTime(clampedVol * 0.6, now + 0.05);
        gain.gain.exponentialRampToValueAtTime(1e-3, now + 0.35);
        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);
        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 0.35);
        osc2.stop(now + 0.35);
        return true;
      }
      case "click": {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(800, now);
        gain.gain.setValueAtTime(clampedVol * 0.5, now);
        gain.gain.exponentialRampToValueAtTime(1e-3, now + 0.015);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.015);
        return true;
      }
      default:
        return false;
    }
  } catch {
    return false;
  }
}

// src/touch-grass-timeout.ts
var TOUCH_GRASS_DURATION_MS = 12e4;
var TOUCH_GRASS_HUB_ORIGIN = "https://tiltcheck.me";
var TOUCH_GRASS_HUB_PAUSE_PATH = "/touch-grass?mode=pause";
var TOUCH_GRASS_HUB_READY_SOURCE = "TILTCHECK_TOUCH_GRASS";
var HUB_IFRAME_ID = "tiltcheck-lockdown-hub";
var HUB_IFRAME_LOAD_TIMEOUT_MS = 4e3;
var CSP_FALLBACK_PROMPTS = [
  "Stand up. Two minutes of legs, not clicking reels.",
  "Get water. The house edge will still be there.",
  "Text a friend who does not have a referral code."
];
function resolveTouchGrassHubUrl(origin = TOUCH_GRASS_HUB_ORIGIN) {
  return `${origin}${TOUCH_GRASS_HUB_PAUSE_PATH}`;
}
function resolveTouchGrassHubOrigin() {
  const hostname2 = globalThis.location?.hostname;
  if (hostname2 === "localhost" || hostname2 === "127.0.0.1") {
    return globalThis.location.origin;
  }
  return TOUCH_GRASS_HUB_ORIGIN;
}
function isTouchGrassHubReadyPing(event, expectedOrigin) {
  if (event.origin !== expectedOrigin) {
    return false;
  }
  const data = event.data;
  if (data == null || typeof data !== "object") {
    return false;
  }
  const payload = data;
  return payload.source === TOUCH_GRASS_HUB_READY_SOURCE && payload.ready === true;
}
var MESSAGE_ROTATE_MS = 2e4;
var MESSAGE_FADE_SWAP_MS = 450;
var BREAK_MESSAGES = [
  "You are down 60% in 9 minutes. You are not on a heater, you're chasing. Close the tab.",
  "Ed Craven doesn't need your rent money. Close the browser.",
  "That's 14 dead spins on Hacksaw. You already know how this movie ends.",
  "You're playing a 94.5% downgraded RTP tier on an offshore mirror thinking it's 96.5%.",
  "The bonus buy will not make you whole. Step back and breathe.",
  "Turbo spinning through dead rolls only speeds up the house edge. Walk away for two minutes.",
  "House telemetry loves rage clicking. Take your hand off the mouse.",
  "Unclench your jaw, put the phone down, and drink some water. The reel can wait."
];
var LOCKDOWN_ROOT_ID = "tiltcheck-lockdown-root";
var MESSAGE_EL_ID = "tiltcheck-lockdown-message";
var TIMER_ID = "lockdown-timer";
var overlayActive = false;
var overlayHubMessageListener = null;
function blockBettingUI(block) {
  const betButtons = document.querySelectorAll(
    'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
  );
  betButtons.forEach((btn) => {
    if (block) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = true;
      }
      btn.style.opacity = "0.5";
      btn.style.cursor = "not-allowed";
      btn.dataset.tiltguardBlocked = "true";
    } else if (btn.dataset.tiltguardBlocked) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = false;
      }
      btn.style.opacity = "";
      btn.style.cursor = "";
      delete btn.dataset.tiltguardBlocked;
    }
  });
}
function injectLockdownStyles(root) {
  const style = document.createElement("style");
  style.textContent = `
    #${LOCKDOWN_ROOT_ID} {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: #0f1115 !important;
      z-index: 2147483647 !important;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace;
      color: #ff4a4a;
      box-sizing: border-box;
      padding: 1.5rem;
      overflow-y: auto;
      user-select: none;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-inner {
      width: 100%;
      max-width: 32rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-eyebrow {
      font-size: 0.6875rem;
      font-weight: 800;
      letter-spacing: 0.28em;
      text-transform: uppercase;
      color: #ff4a4a;
      margin-bottom: 0.75rem;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-headline {
      font-size: 1.625rem;
      font-weight: 900;
      letter-spacing: -0.02em;
      color: #ffffff;
      margin: 0 0 0.75rem;
      line-height: 1.15;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-reason {
      font-size: 0.875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.82);
      margin: 0 0 1.25rem;
      max-width: 28rem;
    }

    /* Center stage: pacer ring + timer digits */
    .tiltcheck-pacer-stage {
      position: relative;
      width: 250px;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 2rem 0;
    }

    .tiltcheck-breath-pacer {
      position: absolute;
      width: 200px;
      height: 200px;
      border: 4px solid #ff4a4a;
      border-radius: 50%;
      box-shadow: 0 0 15px rgba(255, 74, 74, 0.2);
      animation: tiltcheck-breath-pacer 8s ease-in-out infinite;
      pointer-events: none;
    }

    #${TIMER_ID} {
      font-size: 3.5rem;
      font-weight: bold;
      color: #ffffff;
      z-index: 10;
      font-variant-numeric: tabular-nums;
      line-height: 1;
      text-shadow: 0 2px 20px rgba(0, 0, 0, 0.5);
    }

    @keyframes tiltcheck-breath-pacer {
      0%, 100% {
        transform: scale(0.6);
        opacity: 0.3;
        box-shadow: 0 0 10px rgba(255, 74, 74, 0.1);
      }
      50% {
        transform: scale(1.1);
        opacity: 0.9;
        border-color: #4affb4;
        box-shadow: 0 0 30px rgba(74, 255, 180, 0.4);
      }
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-breath-hint {
      position: absolute;
      bottom: -2.25rem;
      left: 50%;
      transform: translateX(-50%);
      width: 18rem;
      font-size: 0.625rem;
      opacity: 0.55;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: rgba(255, 255, 255, 0.55);
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-signal-label {
      font-size: 0.625rem;
      font-weight: 800;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: rgba(255, 74, 74, 0.65);
      margin-bottom: 0.5rem;
      align-self: stretch;
      text-align: left;
    }

    #${MESSAGE_EL_ID} {
      font-size: 0.875rem;
      line-height: 1.5;
      margin: 0;
      text-align: left;
      min-height: 4.5em;
      align-self: stretch;
      color: rgba(245, 245, 245, 0.94);
      transition: opacity 0.45s ease;
    }

    #${HUB_IFRAME_ID} {
      width: 100%;
      max-width: 32rem;
      height: 18rem;
      margin: 0.75rem 0 1rem;
      border: 1px solid rgba(255, 255, 255, 0.12);
      background: #111318;
      pointer-events: auto;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-csp-fallback {
      align-self: stretch;
      text-align: left;
      margin: 0 0 1rem;
      padding: 0 0 0 1.1rem;
      color: rgba(245, 245, 245, 0.94);
      font-size: 0.875rem;
      line-height: 1.5;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-foot {
      font-size: 0.6875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.45);
      margin: 1.25rem 0 0;
      max-width: 26rem;
    }
  `;
  root.insertBefore(style, root.firstChild);
}
function triggerTouchGrassTimeout(reason, durationMs = TOUCH_GRASS_DURATION_MS) {
  if (overlayActive) {
    return;
  }
  overlayActive = true;
  playAudioCue("cooldown_chime");
  blockBettingUI(true);
  const existing = document.getElementById(LOCKDOWN_ROOT_ID);
  if (existing) {
    existing.remove();
  }
  const root = document.createElement("div");
  root.id = LOCKDOWN_ROOT_ID;
  root.setAttribute("role", "dialog");
  root.setAttribute("aria-modal", "true");
  root.setAttribute(
    "aria-label",
    "Touch Grass timeout \u2014 session pause with breathing pacer and rotating guidance"
  );
  injectLockdownStyles(root);
  const inner = document.createElement("div");
  inner.className = "tiltcheck-lockdown-inner";
  const eyebrow = document.createElement("div");
  eyebrow.className = "tiltcheck-eyebrow";
  eyebrow.textContent = "Touch Grass Timeout";
  const headline = document.createElement("h1");
  headline.className = "tiltcheck-lockdown-headline";
  headline.textContent = "Hold up. Recalibrate.";
  const reasonEl = document.createElement("p");
  reasonEl.className = "tiltcheck-lockdown-reason";
  reasonEl.textContent = reason;
  const stage = document.createElement("div");
  stage.className = "tiltcheck-pacer-stage";
  const breathRing = document.createElement("div");
  breathRing.className = "tiltcheck-breath-pacer";
  breathRing.setAttribute("aria-hidden", "true");
  const timerWrap = document.createElement("div");
  timerWrap.id = TIMER_ID;
  timerWrap.setAttribute("aria-live", "polite");
  timerWrap.setAttribute("aria-atomic", "true");
  const breathHint = document.createElement("div");
  breathHint.className = "tiltcheck-breath-hint";
  breathHint.textContent = "Inhale as the ring expands \u2014 exhale as it releases.";
  const signalLabel = document.createElement("div");
  signalLabel.className = "tiltcheck-signal-label";
  signalLabel.textContent = "Spotter Signal";
  const messageRegion = document.createElement("div");
  messageRegion.className = "tiltcheck-signal-region";
  messageRegion.setAttribute("role", "region");
  messageRegion.setAttribute("aria-label", "System message updates every 20 seconds");
  const messageEl = document.createElement("p");
  messageEl.id = MESSAGE_EL_ID;
  messageEl.setAttribute("aria-live", "off");
  messageEl.textContent = BREAK_MESSAGES[0] ?? "";
  const foot = document.createElement("p");
  foot.className = "tiltcheck-lockdown-foot";
  foot.textContent = "This tab stays locked until the countdown hits zero. No dismiss. Spotter protocol active.";
  const hubOrigin = resolveTouchGrassHubOrigin();
  const iframe = document.createElement("iframe");
  iframe.id = HUB_IFRAME_ID;
  iframe.title = "Touch Grass games hub";
  iframe.src = resolveTouchGrassHubUrl(hubOrigin);
  iframe.referrerPolicy = "no-referrer";
  const fallbackList = document.createElement("ul");
  fallbackList.className = "tiltcheck-csp-fallback";
  fallbackList.hidden = true;
  fallbackList.setAttribute("aria-label", "Local pause prompts");
  for (const prompt of CSP_FALLBACK_PROMPTS) {
    const item = document.createElement("li");
    item.textContent = prompt;
    fallbackList.appendChild(item);
  }
  stage.appendChild(breathRing);
  stage.appendChild(timerWrap);
  stage.appendChild(breathHint);
  inner.appendChild(eyebrow);
  inner.appendChild(headline);
  inner.appendChild(reasonEl);
  inner.appendChild(stage);
  inner.appendChild(iframe);
  inner.appendChild(fallbackList);
  messageRegion.appendChild(messageEl);
  inner.appendChild(signalLabel);
  inner.appendChild(messageRegion);
  inner.appendChild(foot);
  root.appendChild(inner);
  document.body.appendChild(root);
  const stopBlocking = (e) => {
    if (e.target === iframe) {
      return;
    }
    e.preventDefault();
    e.stopPropagation();
  };
  const captureOpts = { capture: true };
  root.addEventListener("click", stopBlocking, captureOpts);
  root.addEventListener("mousedown", stopBlocking, captureOpts);
  root.addEventListener("mouseup", stopBlocking, captureOpts);
  root.addEventListener("keydown", stopBlocking, captureOpts);
  root.addEventListener("touchstart", stopBlocking, captureOpts);
  document.addEventListener("keydown", stopBlocking, captureOpts);
  let hubSettled = false;
  let hubLoadTimeoutId = null;
  const showCspFallback = (force = false) => {
    if (hubSettled && !force) {
      return;
    }
    hubSettled = true;
    if (hubLoadTimeoutId !== null) {
      clearTimeout(hubLoadTimeoutId);
      hubLoadTimeoutId = null;
    }
    iframe.hidden = true;
    iframe.setAttribute("aria-hidden", "true");
    fallbackList.hidden = false;
  };
  const onHubMessage = (event) => {
    if (hubSettled) {
      return;
    }
    if (!isTouchGrassHubReadyPing(event, hubOrigin)) {
      return;
    }
    hubSettled = true;
    if (hubLoadTimeoutId !== null) {
      clearTimeout(hubLoadTimeoutId);
      hubLoadTimeoutId = null;
    }
  };
  overlayHubMessageListener = onHubMessage;
  window.addEventListener("message", onHubMessage);
  iframe.addEventListener("error", () => {
    showCspFallback(true);
  });
  hubLoadTimeoutId = window.setTimeout(() => {
    hubLoadTimeoutId = null;
    if (!hubSettled) {
      showCspFallback();
    }
  }, HUB_IFRAME_LOAD_TIMEOUT_MS);
  let messageIndex = 0;
  let pendingFadeTimeout = null;
  const clearPendingFade = () => {
    if (pendingFadeTimeout !== null) {
      clearTimeout(pendingFadeTimeout);
      pendingFadeTimeout = null;
    }
  };
  const messageRotateIntervalId = window.setInterval(() => {
    if (!document.getElementById(LOCKDOWN_ROOT_ID) || !messageEl.isConnected) {
      clearInterval(messageRotateIntervalId);
      return;
    }
    messageIndex = (messageIndex + 1) % BREAK_MESSAGES.length;
    messageEl.style.opacity = "0";
    clearPendingFade();
    pendingFadeTimeout = window.setTimeout(() => {
      pendingFadeTimeout = null;
      if (!messageEl.isConnected) return;
      messageEl.textContent = BREAK_MESSAGES[messageIndex] ?? "";
      messageEl.style.opacity = "1";
    }, MESSAGE_FADE_SWAP_MS);
  }, MESSAGE_ROTATE_MS);
  let countdownIntervalId = null;
  const started = Date.now();
  const finish = () => {
    if (countdownIntervalId !== null) {
      clearInterval(countdownIntervalId);
      countdownIntervalId = null;
    }
    if (hubLoadTimeoutId !== null) {
      clearTimeout(hubLoadTimeoutId);
      hubLoadTimeoutId = null;
    }
    window.removeEventListener("message", onHubMessage);
    overlayHubMessageListener = null;
    clearInterval(messageRotateIntervalId);
    clearPendingFade();
    root.remove();
    document.removeEventListener("keydown", stopBlocking, captureOpts);
    blockBettingUI(false);
    overlayActive = false;
  };
  const tick = () => {
    const left = Math.max(0, durationMs - (Date.now() - started));
    const sec = Math.ceil(left / 1e3);
    timerWrap.textContent = `${sec}`;
    if (left <= 0) {
      finish();
    }
  };
  tick();
  countdownIntervalId = window.setInterval(tick, 250);
}

// src/spin-pace-lock.ts
var SPIN_CONTROL_SELECTOR = [
  'button[data-test*="bet"]',
  'button[data-test*="play"]',
  'button[data-test*="spin"]',
  '[data-test="bet-button"]',
  '[data-test="play-button"]',
  '[data-test="spin-button"]',
  '[data-testid*="bet"]',
  '[data-testid*="spin"]',
  '[data-testid*="play"]',
  'button[class*="bet" i]',
  'button[class*="spin" i]',
  'button[class*="play" i]',
  '[data-action="bet"]',
  '[data-action="spin"]',
  'button[aria-label*="spin" i]',
  'button[aria-label*="bet" i]',
  'button[aria-label*="play" i]',
  ".game-controls button",
  "#spin-button",
  ".play-btn",
  ".spin-btn"
].join(", ");

// src/bonus-tracker.ts
var TILTCHECK_BONUS_TRACKER_CONFIG_KEY = "tiltcheck_bonus_tracker_config";
var DEFAULT_BONUS_TRACKER_CONFIG = {
  active: false,
  bonusName: "Deposit Bonus",
  targetWager: 1e3,
  currentWagered: 0,
  maxBetLimit: 5,
  blockExceededBets: true
};
function sanitizeBonusConfig(raw) {
  if (typeof raw !== "object" || raw === null) {
    return { ...DEFAULT_BONUS_TRACKER_CONFIG };
  }
  const obj = raw;
  const active = typeof obj["active"] === "boolean" ? obj["active"] : DEFAULT_BONUS_TRACKER_CONFIG.active;
  const bonusName = typeof obj["bonusName"] === "string" && obj["bonusName"].trim() ? obj["bonusName"].trim() : DEFAULT_BONUS_TRACKER_CONFIG.bonusName;
  const targetWager = typeof obj["targetWager"] === "number" && Number.isFinite(obj["targetWager"]) ? Math.max(0, obj["targetWager"]) : DEFAULT_BONUS_TRACKER_CONFIG.targetWager;
  const currentWagered = typeof obj["currentWagered"] === "number" && Number.isFinite(obj["currentWagered"]) ? Math.max(0, obj["currentWagered"]) : 0;
  const maxBetLimit = typeof obj["maxBetLimit"] === "number" && Number.isFinite(obj["maxBetLimit"]) ? Math.max(0, obj["maxBetLimit"]) : DEFAULT_BONUS_TRACKER_CONFIG.maxBetLimit;
  const blockExceededBets = typeof obj["blockExceededBets"] === "boolean" ? obj["blockExceededBets"] : true;
  return { active, bonusName, targetWager, currentWagered, maxBetLimit, blockExceededBets };
}

// src/casino-vault-adapters.ts
var StakeVaultAdapter = class {
  name = "stake";
  domains = ["stake.com", "stake.us"];
  canDetectBalance() {
    return true;
  }
  getGraphQLEndpoint(hostname2) {
    const host = (hostname2 ?? (typeof window !== "undefined" ? window.location?.hostname || "" : "")).toLowerCase();
    if (host === "stake.us" || host.endsWith(".stake.us")) {
      return "https://stake.us/_api/graphql";
    }
    return "https://api.stake.com/graphql";
  }
  async getBalance() {
    try {
      const endpoint = this.getGraphQLEndpoint();
      const res = await fetch(endpoint, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: `query { user { balances { available { amount currency { name } } } } }`
        })
      });
      if (!res.ok) {
        return null;
      }
      const json = await res.json();
      const balances = json?.data?.user?.balances ?? [];
      return balances[0]?.available?.amount ?? null;
    } catch {
      return null;
    }
  }
  async getLastWinAmount() {
    return null;
  }
  async vaultAmount(amount, _currency = "usd") {
    try {
      const endpoint = this.getGraphQLEndpoint();
      const res = await fetch(endpoint, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: `mutation createVaultDeposit($amount: Float!) {
            createVaultDeposit(amount: $amount) { id amount }
          }`,
          variables: { amount }
        })
      });
      if (!res.ok) {
        return false;
      }
      const json = await res.json();
      return !!json?.data?.createVaultDeposit?.id;
    } catch {
      return false;
    }
  }
};
var GenericDOMVaultAdapter = class {
  name;
  domains;
  constructor(name, domains) {
    this.name = name;
    this.domains = domains;
  }
  canDetectBalance() {
    return false;
  }
  async getBalance() {
    return null;
  }
  async getLastWinAmount() {
    return null;
  }
  async vaultAmount(_amount, _currency) {
    const keywords = ["vault", "safe", "save funds", "lock", "stash"];
    const buttons = Array.from(document.querySelectorAll('button, [role="button"]'));
    for (const btn of buttons) {
      const text = (btn.textContent ?? "").trim().toLowerCase();
      if (keywords.some((k) => text.includes(k))) {
        btn.click();
        return true;
      }
    }
    return false;
  }
};
var ADAPTERS = [
  new StakeVaultAdapter(),
  new GenericDOMVaultAdapter("roobet", ["roobet.com"]),
  new GenericDOMVaultAdapter("bcgame", ["bc.game"]),
  new GenericDOMVaultAdapter("rollbit", ["rollbit.com"]),
  new GenericDOMVaultAdapter("gamdom", ["gamdom.com"]),
  new GenericDOMVaultAdapter("shuffle", ["shuffle.com"])
];

// src/profit-lock.ts
var DEFAULT_CASHOUT_GOALS = [
  {
    id: "dinner",
    name: "Dinner with Friends",
    targetAmount: 40,
    linkUrl: "",
    metric: "balance",
    enabled: true
  },
  {
    id: "gas_tank",
    name: "Full Tank of Gas",
    targetAmount: 50,
    linkUrl: "",
    metric: "balance",
    enabled: true
  },
  {
    id: "groceries",
    name: "Groceries & Essentials",
    targetAmount: 100,
    linkUrl: "",
    metric: "balance",
    enabled: true
  },
  {
    id: "power_bill",
    name: "Utility / Power Bill",
    targetAmount: 200,
    linkUrl: "",
    metric: "balance",
    enabled: true
  },
  {
    id: "rent_car",
    name: "Rent / Major Bill",
    targetAmount: 600,
    linkUrl: "",
    metric: "profit",
    enabled: true
  }
];
function sanitizeCashoutGoals(raw) {
  if (!Array.isArray(raw)) {
    return [...DEFAULT_CASHOUT_GOALS];
  }
  const result = [];
  for (const item of raw) {
    if (typeof item !== "object" || item === null) continue;
    const obj = item;
    const id = typeof obj["id"] === "string" && obj["id"].trim() ? obj["id"].trim() : `goal_${Date.now()}_${Math.random()}`;
    const name = typeof obj["name"] === "string" && obj["name"].trim() ? obj["name"].trim() : "Unnamed Goal";
    const targetAmount = typeof obj["targetAmount"] === "number" && Number.isFinite(obj["targetAmount"]) ? Math.max(1, obj["targetAmount"]) : 10;
    const linkUrl = typeof obj["linkUrl"] === "string" ? obj["linkUrl"].trim() : "";
    const metric = obj["metric"] === "profit" ? "profit" : "balance";
    const enabled = typeof obj["enabled"] === "boolean" ? obj["enabled"] : true;
    result.push({ id, name, targetAmount, linkUrl, metric, enabled });
  }
  return result.length > 0 ? result : [...DEFAULT_CASHOUT_GOALS];
}

// src/core-options.ts
var TILTCHECK_RISK_THRESHOLD_KEY = "tiltcheck_risk_threshold";
var TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY = "tiltcheck_touch_grass_duration_ms";
var TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY = "tiltcheck_touch_grass_cooldown_ms";
var TILTCHECK_TOUCH_GRASS_OPT_IN_KEY = "tiltcheck_touch_grass_opt_in";
var TILTCHECK_RISK_PROFILE_KEY = "tiltcheck_risk_profile";
var TILTCHECK_HOURLY_WAGE_KEY = "tiltcheck_hourly_wage";
var TILTCHECK_REALITY_HUD_ENABLED_KEY = "tiltcheck_reality_hud_enabled";
var TILTCHECK_REALITY_THRESHOLD_HOURS_KEY = "tiltcheck_reality_threshold_hours";
var TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY = "tiltcheck_deposit_barrier_enabled";
var TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY = "tiltcheck_reverse_withdrawal_shield_enabled";
var TILTCHECK_PROFIT_LOCK_ENABLED_KEY = "tiltcheck_profit_lock_enabled";
var TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY = "tiltcheck_profit_lock_trailing_percent";
var TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY = "tiltcheck_profit_lock_min_profit";
var TILTCHECK_CASHOUT_GOALS_ENABLED_KEY = "tiltcheck_cashout_goals_enabled";
var TILTCHECK_CASHOUT_GOALS_KEY = "tiltcheck_cashout_goals";
var TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY = "tiltcheck_cooldown_active_until";
var TILTCHECK_COOLDOWN_WALLET_KEY = "tiltcheck_cooldown_wallet";
var TILTCHECK_COOLDOWN_SOURCE_KEY = "tiltcheck_cooldown_source";
var TILTCHECK_AUTO_LOCK_ON_TILT_KEY = "tiltcheck_auto_lock_on_tilt";
var TILTCHECK_AUTO_LOCK_THRESHOLD_KEY = "tiltcheck_auto_lock_threshold";
var TILTCHECK_AUTO_LOCK_DURATION_KEY = "tiltcheck_auto_lock_duration";
var TILTCHECK_AUDIO_ALERTS_ENABLED_KEY = "tiltcheck_audio_alerts_enabled";
var TILTCHECK_AUDIO_ALERTS_VOLUME_KEY = "tiltcheck_audio_alerts_volume";
var DEFAULT_RISK_PROFILE = "moderate";
function normalizeRiskProfile(value, legacyRiskLevel) {
  if (value === "conservative" || value === "moderate" || value === "degen") {
    return value;
  }
  if (legacyRiskLevel === "conservative" || legacyRiskLevel === "moderate" || legacyRiskLevel === "degen") {
    return legacyRiskLevel;
  }
  return DEFAULT_RISK_PROFILE;
}
var DEFAULT_RISK_THRESHOLD = 85;
var DEFAULT_TOUCH_GRASS_DURATION_MS = TOUCH_GRASS_DURATION_MS;
var DEFAULT_TOUCH_GRASS_COOLDOWN_MS = DEFAULT_TOUCH_GRASS_DURATION_MS + 5e3;
var DEFAULT_HOURLY_WAGE = 25;
var MIN_HOURLY_WAGE = 5;
var MAX_HOURLY_WAGE = 2e3;
var DEFAULT_REALITY_HUD_ENABLED = true;
var DEFAULT_REALITY_THRESHOLD_HOURS = 2;
var MIN_REALITY_THRESHOLD_HOURS = 0.5;
var MAX_REALITY_THRESHOLD_HOURS = 24;
var DEFAULT_DEPOSIT_BARRIER_ENABLED = true;
var DEFAULT_REVERSE_WITHDRAWAL_SHIELD_ENABLED = true;
var DEFAULT_PROFIT_LOCK_ENABLED = true;
var DEFAULT_TRAILING_PERCENT = 50;
var DEFAULT_MIN_PROFIT = 50;
var DEFAULT_CASHOUT_GOALS_ENABLED = true;
var DEFAULT_AUDIO_ALERTS_ENABLED = true;
var DEFAULT_AUDIO_ALERTS_VOLUME = 0.25;
var DEFAULT_AUTO_LOCK_ON_TILT = true;
var DEFAULT_AUTO_LOCK_THRESHOLD = 75;
var DEFAULT_AUTO_LOCK_DURATION = 86400;
var MIN_AUTO_LOCK_THRESHOLD = 50;
var MAX_AUTO_LOCK_THRESHOLD = 95;
var MIN_AUTO_LOCK_DURATION = 3600;
var MAX_AUTO_LOCK_DURATION = 2592e3;
var MIN_RISK_THRESHOLD = 50;
var MAX_RISK_THRESHOLD = 100;
var MIN_DURATION_MS = 3e4;
var MAX_DURATION_MS = 6e5;
var MIN_COOLDOWN_MS = 3e4;
var MAX_COOLDOWN_MS = 9e5;
function clampInt(value, min, max, fallback) {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}
function clampFloat(value, min, max, fallback) {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || n <= 0) return fallback;
  return Math.min(max, Math.max(min, n));
}
async function loadCoreCircuitBreakerOptions() {
  try {
    const stored = await chrome.storage.local.get([
      TILTCHECK_RISK_THRESHOLD_KEY,
      TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
      TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
      TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
      TILTCHECK_RISK_PROFILE_KEY,
      TILTCHECK_HOURLY_WAGE_KEY,
      TILTCHECK_REALITY_HUD_ENABLED_KEY,
      TILTCHECK_REALITY_THRESHOLD_HOURS_KEY,
      TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY,
      TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY,
      TILTCHECK_PROFIT_LOCK_ENABLED_KEY,
      TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY,
      TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY,
      TILTCHECK_CASHOUT_GOALS_ENABLED_KEY,
      TILTCHECK_CASHOUT_GOALS_KEY,
      TILTCHECK_BONUS_TRACKER_CONFIG_KEY,
      TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY,
      TILTCHECK_COOLDOWN_WALLET_KEY,
      TILTCHECK_COOLDOWN_SOURCE_KEY,
      TILTCHECK_AUTO_LOCK_ON_TILT_KEY,
      TILTCHECK_AUTO_LOCK_THRESHOLD_KEY,
      TILTCHECK_AUTO_LOCK_DURATION_KEY,
      TILTCHECK_AUDIO_ALERTS_ENABLED_KEY,
      TILTCHECK_AUDIO_ALERTS_VOLUME_KEY,
      "riskLevel"
    ]);
    const durationMs = clampInt(
      stored[TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY],
      MIN_DURATION_MS,
      MAX_DURATION_MS,
      DEFAULT_TOUCH_GRASS_DURATION_MS
    );
    const cooldownDefault = durationMs + 5e3;
    const cooldownMs = clampInt(
      stored[TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY],
      MIN_COOLDOWN_MS,
      MAX_COOLDOWN_MS,
      cooldownDefault
    );
    const optIn = stored[TILTCHECK_TOUCH_GRASS_OPT_IN_KEY];
    const enforcementEnabled = optIn === void 0 ? true : optIn === true;
    const hourlyWage = clampInt(
      stored[TILTCHECK_HOURLY_WAGE_KEY],
      MIN_HOURLY_WAGE,
      MAX_HOURLY_WAGE,
      DEFAULT_HOURLY_WAGE
    );
    const realityHudOpt = stored[TILTCHECK_REALITY_HUD_ENABLED_KEY];
    const realityHudEnabled = realityHudOpt === void 0 ? DEFAULT_REALITY_HUD_ENABLED : realityHudOpt === true;
    const realityThresholdHours = clampFloat(
      stored[TILTCHECK_REALITY_THRESHOLD_HOURS_KEY],
      MIN_REALITY_THRESHOLD_HOURS,
      MAX_REALITY_THRESHOLD_HOURS,
      DEFAULT_REALITY_THRESHOLD_HOURS
    );
    const depositBarrierOpt = stored[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY];
    const depositBarrierEnabled = depositBarrierOpt === void 0 ? DEFAULT_DEPOSIT_BARRIER_ENABLED : depositBarrierOpt === true;
    const reverseWithdrawalShieldOpt = stored[TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY];
    const reverseWithdrawalShieldEnabled = reverseWithdrawalShieldOpt === void 0 ? DEFAULT_REVERSE_WITHDRAWAL_SHIELD_ENABLED : reverseWithdrawalShieldOpt === true;
    const profitLockOpt = stored[TILTCHECK_PROFIT_LOCK_ENABLED_KEY];
    const profitLockEnabled = profitLockOpt === void 0 ? DEFAULT_PROFIT_LOCK_ENABLED : profitLockOpt === true;
    const trailingPercent = clampInt(
      stored[TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY],
      10,
      90,
      DEFAULT_TRAILING_PERCENT
    );
    const minProfit = clampInt(
      stored[TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY],
      10,
      1e4,
      DEFAULT_MIN_PROFIT
    );
    const goalsOpt = stored[TILTCHECK_CASHOUT_GOALS_ENABLED_KEY];
    const goalsEnabled = goalsOpt === void 0 ? DEFAULT_CASHOUT_GOALS_ENABLED : goalsOpt === true;
    const goals = sanitizeCashoutGoals(stored[TILTCHECK_CASHOUT_GOALS_KEY]);
    const bonusConfig = sanitizeBonusConfig(stored[TILTCHECK_BONUS_TRACKER_CONFIG_KEY]);
    const cooldownActiveUntil = typeof stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY] === "number" && Number.isFinite(stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]) ? Math.max(0, stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]) : 0;
    const rawWallet = stored[TILTCHECK_COOLDOWN_WALLET_KEY];
    const cooldownWallet = typeof rawWallet === "string" && rawWallet.trim().length >= 32 && rawWallet.trim().length <= 44 ? rawWallet.trim() : null;
    const rawSource = stored[TILTCHECK_COOLDOWN_SOURCE_KEY];
    const cooldownSource = typeof rawSource === "string" && rawSource.trim().length > 0 ? rawSource.trim() : null;
    const autoLockOnTiltOpt = stored[TILTCHECK_AUTO_LOCK_ON_TILT_KEY];
    const autoLockOnTilt = autoLockOnTiltOpt === void 0 ? DEFAULT_AUTO_LOCK_ON_TILT : autoLockOnTiltOpt === true;
    const autoLockThreshold = clampInt(
      stored[TILTCHECK_AUTO_LOCK_THRESHOLD_KEY],
      MIN_AUTO_LOCK_THRESHOLD,
      MAX_AUTO_LOCK_THRESHOLD,
      DEFAULT_AUTO_LOCK_THRESHOLD
    );
    const autoLockDuration = clampInt(
      stored[TILTCHECK_AUTO_LOCK_DURATION_KEY],
      MIN_AUTO_LOCK_DURATION,
      MAX_AUTO_LOCK_DURATION,
      DEFAULT_AUTO_LOCK_DURATION
    );
    const audioAlertsEnabled = typeof stored[TILTCHECK_AUDIO_ALERTS_ENABLED_KEY] === "boolean" ? stored[TILTCHECK_AUDIO_ALERTS_ENABLED_KEY] : DEFAULT_AUDIO_ALERTS_ENABLED;
    const rawAudioVol = stored[TILTCHECK_AUDIO_ALERTS_VOLUME_KEY];
    const audioAlertsVolume = typeof rawAudioVol === "number" && Number.isFinite(rawAudioVol) ? Math.max(0, Math.min(1, rawAudioVol)) : DEFAULT_AUDIO_ALERTS_VOLUME;
    return {
      riskThreshold: clampInt(
        stored[TILTCHECK_RISK_THRESHOLD_KEY],
        MIN_RISK_THRESHOLD,
        MAX_RISK_THRESHOLD,
        DEFAULT_RISK_THRESHOLD
      ),
      touchGrassDurationMs: durationMs,
      touchGrassCooldownMs: Math.max(cooldownMs, durationMs + 1e3),
      riskProfile: normalizeRiskProfile(
        stored[TILTCHECK_RISK_PROFILE_KEY],
        stored["riskLevel"]
      ),
      enforcementEnabled,
      hourlyWage,
      realityHudEnabled,
      realityThresholdHours,
      depositBarrierEnabled,
      reverseWithdrawalShieldEnabled,
      profitLockEnabled,
      trailingPercent,
      minProfit,
      goalsEnabled,
      goals,
      bonusConfig,
      cooldownActiveUntil,
      cooldownWallet,
      cooldownSource,
      autoLockOnTilt,
      autoLockThreshold,
      autoLockDuration,
      audioAlertsEnabled,
      audioAlertsVolume
    };
  } catch {
    return {
      riskThreshold: DEFAULT_RISK_THRESHOLD,
      touchGrassDurationMs: DEFAULT_TOUCH_GRASS_DURATION_MS,
      touchGrassCooldownMs: DEFAULT_TOUCH_GRASS_COOLDOWN_MS,
      riskProfile: DEFAULT_RISK_PROFILE,
      enforcementEnabled: true,
      hourlyWage: DEFAULT_HOURLY_WAGE,
      realityHudEnabled: DEFAULT_REALITY_HUD_ENABLED,
      realityThresholdHours: DEFAULT_REALITY_THRESHOLD_HOURS,
      depositBarrierEnabled: DEFAULT_DEPOSIT_BARRIER_ENABLED,
      reverseWithdrawalShieldEnabled: DEFAULT_REVERSE_WITHDRAWAL_SHIELD_ENABLED,
      profitLockEnabled: DEFAULT_PROFIT_LOCK_ENABLED,
      trailingPercent: DEFAULT_TRAILING_PERCENT,
      minProfit: DEFAULT_MIN_PROFIT,
      goalsEnabled: DEFAULT_CASHOUT_GOALS_ENABLED,
      goals: [...DEFAULT_CASHOUT_GOALS],
      bonusConfig: { ...DEFAULT_BONUS_TRACKER_CONFIG },
      cooldownActiveUntil: 0,
      cooldownWallet: null,
      cooldownSource: null,
      autoLockOnTilt: DEFAULT_AUTO_LOCK_ON_TILT,
      autoLockThreshold: DEFAULT_AUTO_LOCK_THRESHOLD,
      autoLockDuration: DEFAULT_AUTO_LOCK_DURATION,
      audioAlertsEnabled: DEFAULT_AUDIO_ALERTS_ENABLED,
      audioAlertsVolume: DEFAULT_AUDIO_ALERTS_VOLUME
    };
  }
}

// src/tilt-auto-lock.ts
function buildAutoLockVaultUrl(options) {
  const params = new URLSearchParams();
  if (options.wallet) {
    params.set("wallet", options.wallet);
  }
  params.set("scope", options.scope ?? "all");
  params.set("duration", String(options.duration ?? DEFAULT_AUTO_LOCK_DURATION));
  params.set("source", options.source ?? "auto_tilt");
  return `https://tiltcheck.me/cooldown?${params.toString()}`;
}
function shouldTriggerAutoLock(params) {
  const enabled = params.autoLockEnabled ?? DEFAULT_AUTO_LOCK_ON_TILT;
  if (!enabled) {
    return false;
  }
  const threshold = params.threshold ?? DEFAULT_AUTO_LOCK_THRESHOLD;
  if (params.tiltRisk < threshold) {
    return false;
  }
  const now = params.now ?? Date.now();
  const cooldownUntil = params.cooldownActiveUntil ?? 0;
  if (cooldownUntil > now) {
    return false;
  }
  return true;
}
async function executeTiltAutoLock(options) {
  const now = options.now ?? Date.now();
  const duration = options.duration ?? DEFAULT_AUTO_LOCK_DURATION;
  const activeUntil = now + duration * 1e3;
  const source = options.source ?? "auto_tilt";
  const wallet = options.wallet ?? null;
  const targetUrl = buildAutoLockVaultUrl({
    wallet,
    duration,
    source,
    scope: "all"
  });
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    try {
      const updates = {
        [TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]: activeUntil,
        [TILTCHECK_COOLDOWN_SOURCE_KEY]: source,
        tiltcheck_last_auto_lock: {
          timestamp: now,
          tiltRisk: options.tiltRisk,
          indicators: options.indicators ?? [],
          duration
        }
      };
      if (wallet) {
        updates[TILTCHECK_COOLDOWN_WALLET_KEY] = wallet;
      }
      await chrome.storage.local.set(updates);
    } catch {
    }
  }
  try {
    playAudioCue("cooldown_chime");
  } catch {
  }
  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(
        new CustomEvent("TILTCHECK_COOLDOWN_LOCK_UPDATED", {
          detail: {
            wallet,
            endTime: Math.floor(activeUntil / 1e3),
            source,
            tiltRisk: options.tiltRisk
          }
        })
      );
    } catch {
    }
    try {
      window.postMessage(
        {
          source: "TILTCHECK_CONTENT_SCRIPT",
          type: "COOLDOWN_AUTO_LOCK_TRIGGERED",
          wallet,
          endTime: Math.floor(activeUntil / 1e3),
          tiltRisk: options.tiltRisk
        },
        "*"
      );
    } catch {
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
    try {
      chrome.runtime.sendMessage({
        type: "trigger_tilt_auto_lock",
        wallet,
        duration,
        tiltRisk: options.tiltRisk,
        indicators: options.indicators ?? [],
        openPrompt: options.openPrompt ?? false
      });
    } catch {
    }
  }
  return {
    triggered: true,
    activeUntil,
    duration,
    targetUrl,
    wallet
  };
}
async function checkAndTriggerAutoLock(params) {
  const opts = await loadCoreCircuitBreakerOptions();
  const shouldTrigger = shouldTriggerAutoLock({
    tiltRisk: params.tiltRisk,
    threshold: opts.autoLockThreshold,
    autoLockEnabled: opts.autoLockOnTilt,
    cooldownActiveUntil: opts.cooldownActiveUntil,
    now: params.now
  });
  if (!shouldTrigger) {
    return null;
  }
  return executeTiltAutoLock({
    tiltRisk: params.tiltRisk,
    wallet: opts.cooldownWallet,
    indicators: params.indicators,
    duration: opts.autoLockDuration,
    openPrompt: params.openPrompt ?? Boolean(opts.cooldownWallet),
    now: params.now
  });
}

// src/web-app-session-sync.ts
var WEB_TOKEN_STORAGE_KEY = "tc_token";
function marketingSiteHosts() {
  try {
    const host = new URL(EXT_CONFIG.WEB_APP_URL).hostname.toLowerCase();
    const hosts = [host];
    if (!host.startsWith("www.")) {
      hosts.push(`www.${host}`);
    }
    return hosts;
  } catch {
    return ["tiltcheck.me", "www.tiltcheck.me"];
  }
}
function isTiltCheckMarketingSite(hostname2) {
  return marketingSiteHosts().includes(hostname2.toLowerCase());
}
function injectLocalStorageSet(key, value) {
  const keyLit = JSON.stringify(key);
  const valLit = value === null ? "null" : JSON.stringify(value);
  const script = document.createElement("script");
  script.textContent = `(function(){try{var k=${keyLit};var v=${valLit};if(v===null){localStorage.removeItem(k);}else{localStorage.setItem(k,v);}window.dispatchEvent(new CustomEvent("tiltcheck-ext-session-sync"));}catch(_){}})();`;
  (document.documentElement || document.head).appendChild(script);
  script.remove();
}
function syncMarketingSiteTokenFromExtensionStorage() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) return;
  if (!isTiltCheckMarketingSite(window.location.hostname)) return;
  chrome.storage.local.get(["authToken"], (data) => {
    const token = typeof data.authToken === "string" && data.authToken ? data.authToken : null;
    injectLocalStorageSet(WEB_TOKEN_STORAGE_KEY, token);
  });
}
function attachMarketingSiteStorageListener() {
  if (typeof chrome === "undefined" || !chrome.storage?.onChanged) return;
  if (!isTiltCheckMarketingSite(window.location.hostname)) return;
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.authToken) return;
    const raw = changes.authToken.newValue;
    const token = typeof raw === "string" && raw ? raw : null;
    injectLocalStorageSet(WEB_TOKEN_STORAGE_KEY, token);
  });
}

// src/decoupled-sidebar.ts
function initSidebar(_onDisable) {
  const existing = document.getElementById("tiltcheck-sidebar");
  if (existing) existing.remove();
  const sidebarEl = document.createElement("div");
  sidebarEl.id = "tiltcheck-sidebar";
  sidebarEl.style.cssText = "position:fixed;top:0;right:0;width:340px;height:100vh;background:#0f1115;color:#fff;z-index:2147483640;display:none;font-family:ui-monospace,monospace;border-left:1px solid #2a3140;padding:1rem;box-sizing:border-box;overflow-y:auto;";
  sidebarEl.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #2a3140;padding-bottom:0.75rem;margin-bottom:1rem;">
      <span style="font-weight:800;color:#17c3b2;font-size:0.875rem;letter-spacing:0.05em;">TiltCheck Spotter</span>
      <button id="tg-hide" type="button" style="background:transparent;border:0;color:#9aa3b2;cursor:pointer;font:inherit;">Close</button>
    </div>
    <div id="tg-sidebar-status" style="font-size:0.75rem;color:#9aa3b2;margin-bottom:1rem;">Spotter active. Zero custody. Non-custodial guardrails.</div>
    <div id="tg-sidebar-feed" style="font-size:0.75rem;color:#e2e8f0;display:flex;flex-direction:column;gap:0.5rem;"></div>
  `;
  document.body.appendChild(sidebarEl);
  sidebarEl.querySelector("#tg-hide")?.addEventListener("click", () => {
    sidebarEl.style.display = "none";
  });
  return {
    syncAccountUi: () => {
    },
    showMainContent: () => {
    },
    addFeedMessage: (msg) => {
      const feed = sidebarEl.querySelector("#tg-sidebar-feed");
      if (feed) {
        const item = document.createElement("div");
        item.style.cssText = "padding:0.5rem;background:#1a1f29;border-radius:4px;border-left:3px solid #17c3b2;";
        item.textContent = msg;
        feed.prepend(item);
      }
    },
    getStorage: async (keys) => {
      return chrome.storage.local.get(keys);
    },
    setStorage: async (data) => {
      return chrome.storage.local.set(data);
    },
    updateStatus: (msg, type) => {
      const el = sidebarEl.querySelector("#tg-sidebar-status");
      if (el) {
        el.textContent = msg;
        el.setAttribute("data-status-type", type);
      }
    },
    updateRealityCheck: () => {
    },
    updateLicense: (data) => {
      const el = sidebarEl.querySelector("#tg-sidebar-status");
      if (el && data?.warningMessage) {
        el.textContent = data.warningMessage;
      }
    },
    updateTilt: () => {
    },
    updateStats: () => {
    },
    notifyBuddy: () => {
    },
    openPremium: async () => {
    }
  };
}

// src/pro-monolith-bootstrap.ts
function isDomain(hostname2, domain) {
  return hostname2 === domain || hostname2.endsWith("." + domain);
}
var hostname = window.location.hostname.toLowerCase();
var pathname = window.location.pathname.toLowerCase();
var isDiscordAuthRoute = pathname.startsWith("/auth/discord");
var isExcludedDomain = isDomain(hostname, "discord.com") || hostname === "localhost" && window.location.port === "3333" || hostname === "localhost" && window.location.port === "3001" && isDiscordAuthRoute || isDomain(hostname, "api.tiltcheck.me") && isDiscordAuthRoute;
if (isExcludedDomain) {
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] Skipping - excluded domain:", hostname);
}
var INJECTION_DISABLED_KEY = "tiltcheck_injection_disabled";
var ANALYZER_WS_URL = "wss://api.tiltcheck.me/analyzer";
var extractor = null;
var tiltDetector = null;
var licenseVerifier = null;
var client = null;
var sessionId = null;
var stopObserving = null;
var isMonitoring = false;
var casinoVerification = null;
var analyzer = null;
var fairness = null;
var tiltMonitoringInterval = null;
var sidebar = null;
var gameBlocker = null;
var localGameBlocker = null;
var analysisRuntimeReady = false;
var initializationComplete = false;
var runtimeBootPromise = null;
var runtimeListenersAttached = false;
var spaResumeWatchInstalled = false;
var fairnessPlayObserver = null;
var proMonolithActive = false;
var injectionDisabled = false;
var lastAnalysisBlockMessage = null;
var SIDEBAR_VISIBILITY_KEY = "tiltcheck_sidebar_visible";
var SITE_REDEEM_THRESHOLDS_KEY = "tiltcheck_site_thresholds";
var SUPPORT_INTERVENTION_COOLDOWN_MS = 10 * 60 * 1e3;
var cooldownEndTime = null;
var lastRedeemNudgeBalance = null;
var lastRedeemNudgeThreshold = 0;
var lastSupportInterventionByType = {};
function normalizeInterventionData(data) {
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    return {};
  }
  return data;
}
function isFairnessCommitment(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }
  const record = value;
  return typeof record.discordId === "string" && typeof record.clientSeed === "string" && typeof record.timestamp === "number";
}
function normalizeSiteHost(value) {
  return value.replace(/^www\./, "").toLowerCase();
}
function getStoredSiteRedeemThresholds(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }
  const thresholds = {};
  for (const [host, rawValue] of Object.entries(value)) {
    const threshold = Number(rawValue);
    if (Number.isFinite(threshold) && threshold > 0) {
      thresholds[normalizeSiteHost(host)] = threshold;
    }
  }
  return thresholds;
}
function shouldShowRedeemNudge(data) {
  if (document.getElementById("tiltcheck-redeem-nudge")) return false;
  const threshold = Number(data.threshold) || 0;
  if (threshold <= 0) return false;
  const amount = Number(data.amount) || 0;
  const thresholdChanged = threshold !== lastRedeemNudgeThreshold;
  const meaningfulGain = lastRedeemNudgeBalance !== null && amount >= lastRedeemNudgeBalance + Math.max(5, threshold * 0.1);
  if (thresholdChanged || lastRedeemNudgeBalance === null || meaningfulGain) {
    lastRedeemNudgeThreshold = threshold;
    lastRedeemNudgeBalance = amount;
    return true;
  }
  return false;
}
function refreshLicenseVerification() {
  if (!licenseVerifier) {
    licenseVerifier = new CasinoLicenseVerifier();
  }
  casinoVerification = licenseVerifier.verifyCasino();
  sidebar?.updateLicense(casinoVerification);
  updateMobileLicenseHud(casinoVerification);
  if (initializationComplete) {
    applyAnalysisGate(casinoVerification);
  }
  return casinoVerification;
}
function ensureAnalysisRuntime() {
  if (analysisRuntimeReady) {
    return;
  }
  analyzer = new Analyzer();
  fairness = new FairnessService();
  setupFairnessListeners();
  analysisRuntimeReady = true;
}
function applyAnalysisGate(verification) {
  const blockMessage = getAnalysisBlockMessage(verification);
  if (!blockMessage) {
    lastAnalysisBlockMessage = null;
    if (!analysisRuntimeReady) {
      ensureAnalysisRuntime();
    }
    if (!isMonitoring) {
      void startMonitoring().catch((err) => {
        console.warn("[TiltCheck] Auto-start monitoring failed:", err);
      });
    }
    return;
  }
  if (isMonitoring) {
    _stopMonitoring();
  } else {
    sidebar?.updateRealityCheck(false);
  }
  const statusType = verification.verdict === "suspicious" ? "danger" : "warning";
  sidebar?.updateStatus(blockMessage, statusType);
  if (lastAnalysisBlockMessage !== blockMessage) {
    sidebar?.addFeedMessage(blockMessage);
    lastAnalysisBlockMessage = blockMessage;
  }
}
function notifySupportIntervention(type, data) {
  const lastSentAt = lastSupportInterventionByType[type] || 0;
  if (Date.now() - lastSentAt < SUPPORT_INTERVENTION_COOLDOWN_MS) {
    return false;
  }
  lastSupportInterventionByType[type] = Date.now();
  sidebar?.notifyBuddy("intervention", { type, data });
  return true;
}
function setSidebarVisibility(visible) {
  const sidebar2 = document.getElementById("tiltcheck-sidebar");
  if (!sidebar2) return false;
  sidebar2.style.display = visible ? "block" : "none";
  return visible;
}
function persistSidebarVisibility(visible) {
  try {
    chrome.storage.local.set({ [SIDEBAR_VISIBILITY_KEY]: visible });
  } catch {
  }
}
async function restoreSidebarVisibility(defaultVisible) {
  try {
    const stored = await chrome.storage.local.get([SIDEBAR_VISIBILITY_KEY]);
    if (typeof stored[SIDEBAR_VISIBILITY_KEY] === "boolean") {
      setSidebarVisibility(stored[SIDEBAR_VISIBILITY_KEY]);
      return;
    }
  } catch {
  }
  setSidebarVisibility(defaultVisible);
}
function toggleSidebarVisibility() {
  const sidebarEl = document.getElementById("tiltcheck-sidebar");
  if (!sidebarEl) {
    sidebar = initSidebar(disableInjectionFromHud);
    persistSidebarVisibility(true);
    return true;
  }
  const currentlyVisible = sidebarEl.style.display !== "none";
  const visible = setSidebarVisibility(!currentlyVisible);
  persistSidebarVisibility(visible);
  return visible;
}
function getSidebarState() {
  const sidebar2 = document.getElementById("tiltcheck-sidebar");
  return {
    exists: !!sidebar2,
    visible: !!sidebar2 && sidebar2.style.display !== "none",
    injectionDisabled
  };
}
async function getStoredInjectionDisabled() {
  try {
    const stored = await chrome.storage.local.get([INJECTION_DISABLED_KEY]);
    return stored[INJECTION_DISABLED_KEY] === true;
  } catch {
    return false;
  }
}
async function setInjectionDisabled(disabled) {
  injectionDisabled = disabled;
  try {
    await chrome.storage.local.set({ [INJECTION_DISABLED_KEY]: disabled });
  } catch {
  }
}
function waitForDocumentEnd() {
  if (document.readyState !== "loading" && document.body) {
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    const resolveWhenReady = () => {
      if (document.body) {
        document.removeEventListener("DOMContentLoaded", resolveWhenReady);
        resolve();
      }
    };
    document.addEventListener("DOMContentLoaded", resolveWhenReady, { once: true });
    setTimeout(resolveWhenReady, 0);
  });
}
var PRO_UI_ROOT_IDS = [
  "tiltcheck-sidebar",
  "tiltcheck-sidebar-root",
  "tiltcheck-sidebar-container",
  "tiltcheck-game-block-overlay",
  "tiltcheck-local-game-block-overlay",
  "tiltcheck-cooldown-overlay",
  "tiltcheck-redeem-nudge",
  "tiltcheck-mobile-license-hud"
];
function removeProUiSurfaces() {
  for (const id of PRO_UI_ROOT_IDS) {
    document.getElementById(id)?.remove();
  }
}
function teardownInjectedRuntime() {
  if (isMonitoring) {
    _stopMonitoring();
  }
  if (fairnessPlayObserver) {
    fairnessPlayObserver.disconnect();
    fairnessPlayObserver = null;
  }
  gameBlocker?.destroy();
  gameBlocker = null;
  localGameBlocker?.destroy();
  localGameBlocker = null;
  extractor = null;
  tiltDetector = null;
  casinoVerification = null;
  sessionId = null;
  initializationComplete = false;
  lastAnalysisBlockMessage = null;
  analysisRuntimeReady = false;
  analyzer = null;
  fairness = null;
  removeProUiSurfaces();
  sidebar = null;
}
async function disableInjectionFromHud() {
  await setInjectionDisabled(true);
  teardownInjectedRuntime();
}
async function resumeRuntimeAfterNavigation(source) {
  if (isExcludedDomain || injectionDisabled) {
    return;
  }
  if (!initializationComplete) {
    await startRuntimeAtDocumentEnd();
    return;
  }
  if (!document.getElementById("tiltcheck-sidebar")) {
    sidebar = initSidebar(disableInjectionFromHud);
    const defaultVisible = !isDomain(hostname, "tiltcheck.me");
    void restoreSidebarVisibility(defaultVisible);
  }
  syncMarketingSiteTokenFromExtensionStorage();
  attachMarketingSiteStorageListener();
  const verification = refreshLicenseVerification();
  applyAnalysisGate(verification);
  gameBlocker?.resume(source);
  localGameBlocker?.resume(source);
}
function installSpaResumeWatch() {
  if (spaResumeWatchInstalled) {
    return;
  }
  spaResumeWatchInstalled = true;
  let lastUrl = window.location.href;
  let pending = false;
  const queueResume = (source) => {
    if (pending) {
      return;
    }
    pending = true;
    queueMicrotask(() => {
      pending = false;
      const currentUrl = window.location.href;
      if (currentUrl === lastUrl && source !== "pageshow") {
        return;
      }
      lastUrl = currentUrl;
      void resumeRuntimeAfterNavigation(source);
    });
  };
  const patchHistoryMethod = (method) => {
    const original = window.history[method];
    if (original.__tiltcheckPatched) {
      return;
    }
    const patched = function patchedHistoryMethod(...args) {
      const result = original.apply(this, args);
      queueResume(method);
      return result;
    };
    Object.defineProperty(patched, "__tiltcheckPatched", { value: true });
    window.history[method] = patched;
  };
  patchHistoryMethod("pushState");
  patchHistoryMethod("replaceState");
  window.addEventListener("popstate", () => queueResume("popstate"));
  window.addEventListener("hashchange", () => queueResume("hashchange"));
  window.addEventListener("pageshow", () => queueResume("pageshow"));
}
async function startRuntimeAtDocumentEnd(options = {}) {
  if (isExcludedDomain) {
    return;
  }
  if (runtimeBootPromise) {
    await runtimeBootPromise;
    return;
  }
  runtimeBootPromise = (async () => {
    await waitForDocumentEnd();
    installSpaResumeWatch();
    if (options.forceEnable) {
      await setInjectionDisabled(false);
    } else {
      injectionDisabled = await getStoredInjectionDisabled();
    }
    if (injectionDisabled) {
      teardownInjectedRuntime();
      return;
    }
    initialize();
  })().finally(() => {
    runtimeBootPromise = null;
  });
  await runtimeBootPromise;
}
async function openRuntimeFromToolbar() {
  if (injectionDisabled || await getStoredInjectionDisabled()) {
    await startRuntimeAtDocumentEnd({ forceEnable: true });
    const sidebarEl = document.getElementById("tiltcheck-sidebar");
    if (!sidebarEl) {
      sidebar = initSidebar(disableInjectionFromHud);
    }
    const visible2 = setSidebarVisibility(true);
    persistSidebarVisibility(true);
    return { success: true, visible: visible2, injectionDisabled: false };
  }
  const visible = toggleSidebarVisibility();
  return { success: true, visible, injectionDisabled: false };
}
var VisualPicker = class {
  overlay = null;
  active = false;
  callback = null;
  start(callback) {
    if (this.active) return;
    this.active = true;
    this.callback = callback;
    this.overlay = document.createElement("div");
    this.overlay.style.cssText = `
      position: fixed;
      pointer-events: none;
      background: rgba(0, 255, 136, 0.2);
      border: 2px solid #00ff88;
      z-index: 2147483647;
      transition: all 0.1s;
      display: none;
      border-radius: 4px;
    `;
    document.body.appendChild(this.overlay);
    document.addEventListener("mousemove", this.onHover, true);
    document.addEventListener("click", this.onClick, true);
    document.body.style.cursor = "crosshair";
  }
  stop() {
    this.active = false;
    this.callback = null;
    if (this.overlay) this.overlay.remove();
    document.removeEventListener("mousemove", this.onHover, true);
    document.removeEventListener("click", this.onClick, true);
    document.body.style.cursor = "";
  }
  onHover = (e) => {
    if (!this.overlay) return;
    const target = e.target;
    if (target === this.overlay || target.closest("#tiltcheck-sidebar")) return;
    const rect = target.getBoundingClientRect();
    this.overlay.style.display = "block";
    this.overlay.style.top = rect.top + "px";
    this.overlay.style.left = rect.left + "px";
    this.overlay.style.width = rect.width + "px";
    this.overlay.style.height = rect.height + "px";
  };
  onClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const target = e.target;
    if (target.closest("#tiltcheck-sidebar")) return;
    const selector = this.generateSelector(target);
    if (this.callback) this.callback(selector);
    this.stop();
  };
  generateSelector(el) {
    if (el.id && /^[a-z][a-z0-9_-]*$/i.test(el.id) && document.querySelectorAll(`#${el.id}`).length === 1) {
      return `#${el.id}`;
    }
    const dataAttrs = ["data-test", "data-testid", "data-qa", "data-automation-id"];
    for (const attr of dataAttrs) {
      if (el.hasAttribute(attr)) {
        return `[${attr}="${el.getAttribute(attr)}"]`;
      }
    }
    if (el.className && typeof el.className === "string") {
      const classes = el.className.trim().split(/\s+/).filter((c) => c && !c.includes(":"));
      if (classes.length > 0) {
        for (const cls of classes) {
          if (document.querySelectorAll(`.${cls}`).length === 1) return `.${cls}`;
        }
      }
    }
    const path = [];
    let current = el;
    while (current && current !== document.body && current !== document.documentElement) {
      let selector = current.tagName.toLowerCase();
      if (current.id && /^[a-z][a-z0-9_-]*$/i.test(current.id)) {
        selector = `#${current.id}`;
        path.unshift(selector);
        break;
      } else {
        let sibling = current;
        let nth = 1;
        while (sibling.previousElementSibling) {
          sibling = sibling.previousElementSibling;
          if (sibling.tagName === current.tagName) nth++;
        }
        if (nth > 1) selector += `:nth-of-type(${nth})`;
      }
      path.unshift(selector);
      current = current.parentElement;
    }
    return path.join(" > ");
  }
};
var Highlighter = class {
  overlay = null;
  highlight(selector) {
    this.clear();
    try {
      const el = document.querySelector(selector);
      if (!el) {
        console.warn("[TiltCheck] Element not found for highlighting");
        return;
      }
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      const rect = el.getBoundingClientRect();
      this.overlay = document.createElement("div");
      this.overlay.style.cssText = `
        position: fixed;
        top: ${rect.top}px;
        left: ${rect.left}px;
        width: ${rect.width}px;
        height: ${rect.height}px;
        background: rgba(0, 255, 136, 0.2);
        border: 2px solid #00ff88;
        z-index: 2147483647;
        pointer-events: none;
        transition: all 0.3s;
        border-radius: 4px;
        box-shadow: 0 0 15px rgba(0, 255, 136, 0.4);
      `;
      document.body.appendChild(this.overlay);
      setTimeout(() => this.clear(), 2e3);
    } catch (e) {
      console.error("Invalid selector", e);
    }
  }
  clear() {
    if (this.overlay) {
      this.overlay.remove();
      this.overlay = null;
    }
  }
};
function initialize() {
  if (initializationComplete) {
    return;
  }
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] Initializing on:", window.location.hostname);
  syncMarketingSiteTokenFromExtensionStorage();
  attachMarketingSiteStorageListener();
  sidebar = initSidebar(disableInjectionFromHud);
  const defaultVisible = !isDomain(hostname, "tiltcheck.me");
  void restoreSidebarVisibility(defaultVisible);
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] Sidebar created:", !!sidebar);
  updateMobileLicenseHud(null);
  const initialLicenseStatus = refreshLicenseVerification();
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] License verification:", initialLicenseStatus);
  setTimeout(() => refreshLicenseVerification(), 3e3);
  setTimeout(() => refreshLicenseVerification(), 8e3);
  if (!runtimeListenersAttached) {
    runtimeListenersAttached = true;
    const picker = new VisualPicker();
    window.addEventListener("tg-start-picker", ((e) => {
      picker.start((selector) => {
        window.dispatchEvent(new CustomEvent("tg-picker-result", { detail: { field: e.detail.field, selector } }));
      });
    }));
    const highlighter = new Highlighter();
    window.addEventListener("tg-test-selector", ((e) => {
      highlighter.highlight(e.detail.selector);
    }));
    window.addEventListener("tg-redeem-threshold-updated", ((e) => {
      if (!tiltDetector) return;
      const updatedHost = normalizeSiteHost(e.detail?.hostname || "");
      if (updatedHost && updatedHost !== normalizeSiteHost(window.location.hostname)) {
        return;
      }
      const threshold = Number(e.detail?.threshold) || 0;
      tiltDetector.setRedeemThreshold(threshold > 0 ? threshold : null);
      lastRedeemNudgeBalance = 0;
      lastRedeemNudgeThreshold = 0;
    }));
    window.addEventListener("tg-calc-fairness", (async (e) => {
      if (!fairness) return;
      const { serverSeed, clientSeed, nonce } = e.detail;
      try {
        const hash = await fairness.verifyCasinoResult(serverSeed, clientSeed, parseInt(nonce));
        const float = fairness.hashToFloat(hash);
        window.dispatchEvent(new CustomEvent("tg-fairness-result", {
          detail: {
            hash,
            float,
            dice: fairness.getDiceResult(float),
            limbo: fairness.getLimboResult(float)
          }
        }));
      } catch (err) {
        console.error("Fairness calc error", err);
      }
    }));
  }
  initializationComplete = true;
  applyAnalysisGate(initialLicenseStatus);
  if (!localGameBlocker) {
    localGameBlocker = installLocalGameBlocker();
  }
  setTimeout(() => {
    Promise.all([
      getLinkedDiscordId(),
      chrome.storage.local.get(["authToken"])
    ]).then(([discordId, authState]) => {
      const authToken = typeof authState.authToken === "string" ? authState.authToken : "";
      if (!discordId || !authToken) {
        return;
      }
      gameBlocker = new GameBlocker(discordId, authToken);
      gameBlocker.init().catch((err) => {
        console.warn("[TiltCheck] Game blocker init failed:", err);
      });
    }).catch(() => {
    });
  }, 500);
}
async function startMonitoring() {
  if (isMonitoring) return;
  console.log("[TiltCheck] Starting monitoring...");
  const verification = casinoVerification ?? refreshLicenseVerification();
  const blockMessage = getAnalysisBlockMessage(verification);
  if (blockMessage) {
    sidebar?.updateRealityCheck(false);
    sidebar?.updateStatus(blockMessage, verification?.verdict === "suspicious" ? "danger" : "warning");
    return;
  }
  sidebar?.updateRealityCheck(true);
  isMonitoring = true;
  extractor = new CasinoDataExtractor();
  await extractor.initialize();
  const initialBalance = extractor.extractBalance();
  peakBalance = typeof initialBalance === "number" ? initialBalance : 0;
  zeroTriggered = false;
  fumbleStrikes = 0;
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Initial balance:", initialBalance);
  const storageResult = await chrome.storage.local.get(["riskLevel", "redeemThreshold", "authToken", SITE_REDEEM_THRESHOLDS_KEY]);
  const riskLevel = storageResult.riskLevel || "moderate";
  const siteThresholds = getStoredSiteRedeemThresholds(storageResult[SITE_REDEEM_THRESHOLDS_KEY]);
  const siteHost = normalizeSiteHost(window.location.hostname);
  const redeemThreshold = siteThresholds[siteHost] ?? (Number(storageResult.redeemThreshold) || 0);
  const authToken = storageResult.authToken;
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Using profile:", { riskLevel, redeemThreshold, hasToken: !!authToken });
  tiltDetector = new TiltDetector(initialBalance, riskLevel, redeemThreshold);
  if (authToken) {
    const wsUrlWithAuth = `${ANALYZER_WS_URL}?token=${authToken}`;
    client = new AnalyzerClient(wsUrlWithAuth, (error) => {
      console.warn("[TiltGuard] Analyzer connection issue:", error);
      sidebar?.updateRealityCheck(false);
      window.dispatchEvent(
        new CustomEvent("tg-status-update", {
          detail: { message: "Analyzer connection dropped. Reconnecting...", type: "warning" }
        })
      );
    });
    try {
      await client.connect();
      if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Connected to analyzer server");
      sidebar?.updateRealityCheck(true);
    } catch {
      if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Analyzer backend offline - tilt monitoring only");
    }
  } else {
    if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Analyzer disabled until Discord auth is connected");
    sidebar?.updateRealityCheck(false);
  }
  const randomBytes = new Uint32Array(1);
  crypto.getRandomValues(randomBytes);
  sessionId = `session_${Date.now()}_${randomBytes[0].toString(36)}`;
  const userId = await getUserId();
  const casinoId = detectCasinoId();
  const gameId = detectGameId();
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Session started:", { sessionId, userId, casinoId, gameId });
  startTiltMonitoring();
  stopObserving = extractor.startObserving((spinData) => {
    if (!spinData) return;
    if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Spin detected:", spinData);
    if (!sessionId) {
      console.warn("[TiltGuard] Session not started, cannot record spin");
      return;
    }
    handleSpinEvent(spinData, { sessionId, userId, casinoId, gameId });
  });
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Monitoring started successfully");
}
function _stopMonitoring() {
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Stopping monitoring...");
  if (stopObserving) {
    stopObserving();
    stopObserving = null;
  }
  if (client) {
    client.disconnect();
    client = null;
  }
  if (tiltMonitoringInterval) {
    clearInterval(tiltMonitoringInterval);
    tiltMonitoringInterval = null;
  }
  isMonitoring = false;
  sidebar?.updateRealityCheck(false);
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Monitoring stopped");
}
function handleSpinEvent(spinData, session) {
  if (casinoVerification != null && !casinoVerification.shouldAnalyze) {
    return;
  }
  const bet = spinData.bet || 0;
  const payout = spinData.win || 0;
  if (tiltDetector) {
    tiltDetector.recordBet(bet, payout);
    window.dispatchEvent(
      new CustomEvent("tiltcheck-core-record-bet", { detail: { bet, payout } })
    );
    if (typeof spinData.balance === "number") {
      tiltDetector.updateBalance(spinData.balance);
    }
    const sessionSummary = tiltDetector.getSessionSummary();
    const stats = {
      startTime: sessionSummary.startTime || Date.now(),
      totalBets: sessionSummary.totalBets || 0,
      totalWagered: sessionSummary.totalWagered || 0,
      totalWon: sessionSummary.totalWon || 0
    };
    window.TiltCheckSidebar?.updateStats?.(stats);
    const redeemOpportunity = tiltDetector.detectRedeemOpportunity();
    if (redeemOpportunity) {
      if (shouldShowRedeemNudge(redeemOpportunity)) {
        showRedeemNudge(redeemOpportunity);
      }
    } else {
      lastRedeemNudgeBalance = null;
      lastRedeemNudgeThreshold = 0;
    }
    const tiltSigns = tiltDetector.detectAllTiltSigns();
    const tiltRisk = tiltDetector.getTiltRiskScore();
    const indicators = tiltSigns.map((sign) => sign.description);
    sidebar?.updateTilt(tiltRisk, indicators);
  }
  if (client && sessionId) {
    client.sendSpin({
      sessionId: session.sessionId,
      casinoId: session.casinoId,
      gameId: session.gameId,
      userId: session.userId,
      bet,
      payout,
      gameResult: spinData.gameResult,
      symbols: spinData.symbols,
      bonusRound: spinData.bonusActive,
      freeSpins: (spinData.freeSpins || 0) > 0
    });
  }
  postRoundTelemetry({
    userId: session.userId,
    bet,
    win: payout,
    sessionId: session.sessionId,
    casinoId: session.casinoId,
    gameId: session.gameId,
    timestamp: spinData.timestamp
  }).catch((err) => console.warn("[TiltCheck] Hub relay failed:", err));
  if (tiltDetector) {
    checkBagFumble(spinData.balance, tiltDetector.getSessionSummary().initialBalance);
  }
  const currentNonce = parseInt(localStorage.getItem("tiltcheck_nonce") || "0");
  const nextNonce = currentNonce + 1;
  localStorage.setItem("tiltcheck_nonce", nextNonce.toString());
  window.dispatchEvent(new CustomEvent("tg-nonce-update", { detail: { nonce: nextNonce, source: "spin" } }));
  window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: "Analyzing spin...", type: "thinking" } }));
  verifySpinFairness(spinData, session.gameId);
}
var peakBalance = 0;
var zeroTriggered = false;
var fumbleStrikes = 0;
function checkBagFumble(balance, initialBalance) {
  if (balance === null || initialBalance <= 0) return;
  if (balance > peakBalance) {
    peakBalance = balance;
  }
  const hadBigBag = peakBalance >= initialBalance * 1.5;
  const isBlowingIt = hadBigBag && balance <= initialBalance * 1.1 && balance < peakBalance * 0.5;
  const isZero = balance < 0.05;
  if ((isBlowingIt || isZero) && !zeroTriggered) {
    zeroTriggered = true;
    fumbleStrikes++;
    if (fumbleStrikes === 1) {
      showInteractiveNotification(
        isZero ? "0 BALANCE DETECTED. Hey, stop it. You're gonna be mad if you deposit again. Close the tab and go touch grass." : "BAG FUMBLE DETECTED. You were up and now you're giving it all back. Stop spinning before you ruin your week. Go touch grass.",
        [
          { text: "Close Tab", action: () => {
            window.close();
          } },
          { text: "I Won't Deposit (Lie)", action: () => {
          } }
        ]
      );
    } else {
      showInteractiveNotification(
        "REPEATED FUMBLES. You obviously aren't going to stop yourself, so I just pinged the Discord. Get in the 'degen-accountability' VC for a lifeline before you do something stupid.",
        [
          { text: "Get Yelled At (Join VC)", action: () => {
            window.open("https://discord.gg/gdBsEJfCar", "_blank");
          } },
          { text: "Ignore Me", action: () => {
          } }
        ]
      );
      notifySupportIntervention("phone_friend_discord", {
        message: "Repeated fumble detected. Get them into the accountability voice room.",
        supportActions: ["tell them to stop depositing", "tell them to cash out", "pull them into voice"],
        balance,
        initialBalance,
        peakBalance,
        strikeCount: fumbleStrikes
      });
    }
  } else if (balance >= initialBalance * 1.2 && !isBlowingIt) {
    zeroTriggered = false;
  }
}
function startTiltMonitoring() {
  if (tiltMonitoringInterval) {
    clearInterval(tiltMonitoringInterval);
  }
  tiltMonitoringInterval = setInterval(() => {
    if (!tiltDetector || !isMonitoring) return;
    const tiltSigns = tiltDetector.detectAllTiltSigns();
    const tiltRisk = tiltDetector.getTiltRiskScore();
    const indicators = tiltSigns.map((sign) => sign.description);
    sidebar?.updateTilt(tiltRisk, indicators);
    const coreOwnsTouchGrass = window.__tiltcheckCoreShieldActive === true;
    if (tiltRisk >= 80 && !coreOwnsTouchGrass) {
      triggerTouchGrassTimeout("Critical tilt detected.");
      notifySupportIntervention("critical_tilt", {
        message: "Critical tilt detected from live extension telemetry.",
        risk: tiltRisk,
        indicators
      });
    }
    void checkAndTriggerAutoLock({
      tiltRisk,
      indicators
    }).then((result) => {
      if (result?.triggered) {
        triggerTouchGrassTimeout(`High Tilt Auto-Lock Engaged: Score ${tiltRisk}/100. 24h deposit barrier active.`);
        notifySupportIntervention("tilt_auto_lock", {
          message: `High tilt auto-lock engaged at score ${tiltRisk}/100.`,
          risk: tiltRisk,
          indicators,
          duration: result.duration,
          wallet: result.wallet
        });
      }
    });
    const generated = tiltDetector.generateInterventions();
    if (generated.length > 0) {
      handleInterventions(generated);
    }
  }, 5e3);
}
function handleInterventions(interventions) {
  for (const intervention of interventions) {
    if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Intervention:", intervention);
    switch (intervention.type) {
      case "cooldown":
        startCooldown(intervention.data.duration);
        break;
      case "vault_balance":
        showVaultPrompt(intervention.data);
        break;
      case "spending_reminder":
        showSpendingReminder(intervention.data.realWorldComparison);
        break;
      case "stop_loss_triggered":
        triggerStopLoss(intervention.data);
        break;
      case "phone_friend":
        showPhoneFriendPrompt();
        break;
      case "session_break":
        showBreakPrompt();
        break;
      case "redeem_nudge":
        showRedeemNudge(intervention.data);
        break;
    }
    notifySupportIntervention(intervention.type, normalizeInterventionData(intervention.data));
  }
}
function startCooldown(duration) {
  cooldownEndTime = Date.now() + duration;
  blockBettingUI2(true);
  showCooldownOverlay(duration);
  const countdown = setInterval(() => {
    if (!cooldownEndTime) {
      clearInterval(countdown);
      return;
    }
    const remaining = cooldownEndTime - Date.now();
    if (remaining <= 0) {
      clearInterval(countdown);
      endCooldown();
    } else {
      updateCooldownOverlay(remaining);
    }
  }, 1e3);
}
function endCooldown() {
  cooldownEndTime = null;
  blockBettingUI2(false);
  removeCooldownOverlay();
  showNotification("Cooldown complete. Play responsibly.", "success");
}
function blockBettingUI2(block) {
  const betButtons = document.querySelectorAll(
    'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
  );
  betButtons.forEach((btn) => {
    if (block) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = true;
      }
      btn.style.opacity = "0.5";
      btn.style.cursor = "not-allowed";
      btn.dataset.tiltguardBlocked = "true";
    } else if (btn.dataset.tiltguardBlocked) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = false;
      }
      btn.style.opacity = "";
      btn.style.cursor = "";
      delete btn.dataset.tiltguardBlocked;
    }
  });
}
function showCooldownOverlay(duration) {
  const overlay = document.createElement("div");
  overlay.id = "tiltcheck-cooldown-overlay";
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: white;
    font-family: Arial, sans-serif;
  `;
  overlay.innerHTML = `
    <div style="text-align: center;">
      <h1 style="font-size: 48px; margin-bottom: 20px;">HOLD UP</h1>
      <h2 style="font-size: 32px; margin-bottom: 10px;">Spotter Lockdown</h2>
      <p style="font-size: 18px; color: #ff4a4a; margin-bottom: 30px;">
        Tilt detected. You're chasing, not recovering. Step back.
      </p>
      <div id="cooldown-timer" style="font-size: 72px; font-weight: bold; color: #17c3b2;">
        ${Math.ceil(duration / 1e3)}
      </div>
      <p style="font-size: 14px; margin-top: 20px; color: rgba(255, 255, 255, 0.7);">
        Reel stays locked until countdown reaches zero. Spotter protocol active.
      </p>
    </div>
  `;
  document.body.appendChild(overlay);
}
function updateCooldownOverlay(remaining) {
  const timer = document.getElementById("cooldown-timer");
  if (timer) {
    timer.textContent = Math.ceil(remaining / 1e3).toString();
  }
}
function removeCooldownOverlay() {
  const overlay = document.getElementById("tiltcheck-cooldown-overlay");
  if (overlay) overlay.remove();
}
function showVaultPrompt(vaultData) {
  const message = `Your balance is ${vaultData.suggestedAmount.toFixed(2)}. Consider vaulting to protect your winnings.`;
  showInteractiveNotification(message, [
    { text: "Vault Now", action: () => openVaultInterface(vaultData.suggestedAmount) },
    { text: "Later", action: () => {
    } }
  ]);
}
function showSpendingReminder(comparison) {
  showInteractiveNotification(comparison.message, [
    { text: "Vault & Buy", action: () => openVaultInterface(comparison.cost) },
    { text: "Remind Me Later", action: () => {
    } }
  ]);
}
function triggerStopLoss(data) {
  triggerTouchGrassTimeout(data.reason);
}
function showPhoneFriendPrompt() {
  showInteractiveNotification(
    "Multiple tilt signs detected. Consider calling someone before continuing.",
    [
      { text: "Take Break", action: () => startCooldown(5 * 60 * 1e3) },
      { text: "Continue", action: () => {
      } }
    ]
  );
}
function showBreakPrompt() {
  showInteractiveNotification(
    "You have been playing for a while. How about a quick break?",
    [
      { text: "5 Min Break", action: () => startCooldown(5 * 60 * 1e3) },
      { text: "Keep Playing", action: () => {
      } }
    ]
  );
}
function openVaultInterface(amount) {
  chrome.runtime.sendMessage({
    type: "open_vault",
    data: { suggestedAmount: amount }
  }, (response) => {
    if (response?.success) {
      showNotification("[OK] Vault interface opened", "success");
    } else if (response?.error) {
      showNotification(`[ERROR] Vault error: ${response.error}`, "error");
    }
  });
}
function showInteractiveNotification(message, actions) {
  const notification = document.createElement("div");
  notification.className = "tiltguard-notification";
  notification.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    background: rgba(0, 0, 0, 0.95);
    color: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 255, 136, 0.3);
    z-index: 999999;
    max-width: 350px;
    font-family: Arial, sans-serif;
    border: 2px solid #00ff88;
  `;
  const messageEl = document.createElement("p");
  messageEl.style.cssText = "margin-bottom: 15px; font-size: 14px; line-height: 1.4;";
  messageEl.textContent = message;
  notification.appendChild(messageEl);
  const actionsContainer = document.createElement("div");
  actionsContainer.style.cssText = "display: flex; gap: 10px;";
  for (const actionDef of actions) {
    const button = document.createElement("button");
    button.textContent = actionDef.text;
    button.style.cssText = `
      flex: 1;
      padding: 10px;
      border: none;
      border-radius: 6px;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      background: linear-gradient(135deg, #00ff88 0%, #00ccff 100%);
      color: black;
    `;
    button.addEventListener("click", () => {
      actionDef.action();
      notification.remove();
    });
    actionsContainer.appendChild(button);
  }
  notification.appendChild(actionsContainer);
  document.body.appendChild(notification);
  setTimeout(() => notification.remove(), 3e4);
}
function showNotification(message, type = "success") {
  const notification = document.createElement("div");
  const bgColors = {
    success: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
    warning: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
    error: "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)"
  };
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${bgColors[type]};
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    z-index: 999999;
    max-width: 350px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    animation: slideIn 0.3s ease;
  `;
  notification.textContent = message;
  document.body.appendChild(notification);
  setTimeout(() => {
    notification.style.animation = "slideOut 0.3s ease";
    setTimeout(() => notification.remove(), 300);
  }, 5e3);
}
function detectCasinoId() {
  const hostname2 = window.location.hostname.toLowerCase();
  if (isDomain(hostname2, "stake.com") || isDomain(hostname2, "stake.us")) return "stake";
  if (isDomain(hostname2, "roobet.com")) return "roobet";
  if (isDomain(hostname2, "bc.game")) return "bc-game";
  if (isDomain(hostname2, "duelbits.com")) return "duelbits";
  if (isDomain(hostname2, "rollbit.com")) return "rollbit";
  if (isDomain(hostname2, "shuffle.com")) return "shuffle";
  if (isDomain(hostname2, "gamdom.com")) return "gamdom";
  if (isDomain(hostname2, "csgoempire.com")) return "csgoempire";
  const parts = hostname2.replace("www.", "").split(".");
  return parts[0] || "unknown";
}
function detectGameId() {
  const pathname2 = window.location.pathname.toLowerCase();
  const href = window.location.href.toLowerCase();
  const patterns = [
    /\/casino\/slots\/([a-z0-9-]+)/,
    /\/games?\/([a-z0-9-]+)/,
    /\/slots?\/([a-z0-9-]+)/,
    /\/play\/([a-z0-9-]+)/
  ];
  for (const pattern of patterns) {
    const match = pathname2.match(pattern) || href.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }
  const pageTitle = document.title.toLowerCase();
  if (pageTitle.includes("sweet bonanza")) return "sweet-bonanza";
  if (pageTitle.includes("gates of olympus")) return "gates-of-olympus";
  if (pageTitle.includes("sugar rush")) return "sugar-rush";
  if (pageTitle.includes("starlight princess")) return "starlight-princess";
  if (pageTitle.includes("wild west gold")) return "wild-west-gold";
  if (pageTitle.includes("dog house")) return "dog-house";
  if (pageTitle.includes("book of dead")) return "book-of-dead";
  if (pageTitle.includes("fire joker")) return "fire-joker";
  return "unknown-game";
}
async function getUserId() {
  const createUserId = () => {
    const rand = crypto.getRandomValues(new Uint32Array(1))[0].toString(36);
    return `user_${Date.now()}_${rand}`;
  };
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(["userData", "tiltguard_user_id"], (result) => {
        if (result.userData?.id) {
          resolve(result.userData.id);
        } else if (result.tiltguard_user_id) {
          resolve(result.tiltguard_user_id);
        } else {
          const newId = createUserId();
          chrome.storage.local.set({ tiltguard_user_id: newId });
          resolve(newId);
        }
      });
    } catch {
      const storedUserData = localStorage.getItem("userData");
      if (storedUserData) {
        try {
          const user = JSON.parse(storedUserData);
          if (user.id) return resolve(user.id);
        } catch {
        }
      }
      let userId = localStorage.getItem("tiltguard_user_id");
      if (!userId) {
        userId = createUserId();
        localStorage.setItem("tiltguard_user_id", userId);
      }
      resolve(userId);
    }
  });
}
async function getLinkedDiscordId() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(["userData"], (result) => {
        resolve(typeof result.userData?.discordId === "string" ? result.userData.discordId : null);
      });
    } catch {
      resolve(null);
    }
  });
}
function setupFairnessListeners() {
  if (fairnessPlayObserver) {
    fairnessPlayObserver.disconnect();
  }
  fairnessPlayObserver = new MutationObserver((mutations) => {
    if (typeof document === "undefined" || !document.body) {
      return;
    }
    if (mutationsOnlyTouchSafetyRoots(mutations)) {
      return;
    }
    const playBtns = document.querySelectorAll('[data-testid="bet-button"], .bet-button, button[class*="bet"]');
    playBtns.forEach((btn) => {
      if (!(btn instanceof HTMLElement) || isInsideTiltcheckSafetyRoot(btn)) {
        return;
      }
      if (!btn.dataset.tiltCheckAttached) {
        btn.dataset.tiltCheckAttached = "true";
        btn.addEventListener("click", async () => {
          try {
            const discordId = await getUserId();
            const clientSeed = localStorage.getItem("tiltcheck_client_seed") || "default-seed";
            sessionStorage.setItem("tiltcheck_pending_commitment", JSON.stringify({
              discordId,
              clientSeed,
              timestamp: Date.now()
            }));
          } catch (err) {
            console.error("[TiltCheck] Commitment Error:", err);
          }
        });
      }
    });
  });
  fairnessPlayObserver.observe(document.body, { childList: true, subtree: true });
}
async function verifySpinFairness(spinData, gameId) {
  if (casinoVerification != null && !casinoVerification.shouldAnalyze) {
    return;
  }
  if (!fairness || !analyzer) return;
  const storedCommitment = sessionStorage.getItem("tiltcheck_pending_commitment");
  if (!storedCommitment) return;
  try {
    const parsedCommitment = JSON.parse(storedCommitment);
    if (!isFairnessCommitment(parsedCommitment)) {
      return;
    }
    const commitment = parsedCommitment;
    sessionStorage.removeItem("tiltcheck_pending_commitment");
    if (typeof commitment.blockHash !== "string" || commitment.blockHash.trim() === "") {
      console.warn("[TiltCheck] Missing block hash for fairness verification");
      return;
    }
    const expectedHash = await fairness.generateHash(
      commitment.blockHash,
      commitment.discordId,
      commitment.clientSeed
    );
    const expectedFloat = fairness.hashToFloat(expectedHash);
    let expectedResult = expectedFloat;
    let gameType = "standard";
    if (gameId.includes("dice")) {
      gameType = "dice";
      expectedResult = fairness.getDiceResult(expectedFloat);
    } else if (gameId.includes("limbo") || gameId.includes("crash")) {
      gameType = "limbo";
      expectedResult = fairness.getLimboResult(expectedFloat);
    } else if (gameId.includes("plinko")) {
      gameType = "plinko";
      const rows = spinData.rows || 16;
      expectedResult = fairness.getPlinkoPath(expectedHash, rows).join(",");
    }
    if (define_process_default.env.NODE_ENV !== "production") {
      console.log(`[TiltCheck] Fair Result Calculated (${gameType}):`, expectedResult);
      console.log(`[TiltCheck] Server Hash:`, expectedHash);
    }
    if (spinData.hash) {
      const isHashValid = spinData.hash === expectedHash;
      if (isHashValid) {
        window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: "Fairness Verified (Hash Match)", type: "success" } }));
        showNotification("Fair Game Verified (Hash Match)", "success");
      } else {
        showNotification("Fairness Hash Mismatch!", "error");
        console.warn(`[TiltCheck] Hash Mismatch! Expected: ${expectedHash}, Got: ${spinData.hash}`);
      }
    } else if (spinData.gameResult !== null && spinData.gameResult !== void 0) {
      const resultVal = Number(spinData.gameResult);
      if (typeof expectedResult === "number") {
        if (Math.abs(resultVal - expectedResult) < 0.05) {
          window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: `Fairness Verified (Result: ${resultVal})`, type: "success" } }));
          showNotification(`Fair Game Verified (Result: ${resultVal})`, "success");
          if (define_process_default.env.NODE_ENV !== "production") {
            console.log(`[TiltCheck] Scraped result ${resultVal} matches expected ${expectedResult}`);
          }
        } else {
          console.warn(`[TiltCheck] Result Mismatch! Expected: ${expectedResult}, Scraped: ${resultVal}`);
        }
      }
    } else {
      if (define_process_default.env.NODE_ENV !== "production") {
        console.log(`[TiltCheck] Visual Verify: Does the screen show ${expectedResult}?`);
      }
      window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: `Visual Check: Expecting ${expectedResult}`, type: "info" } }));
    }
  } catch (err) {
    console.error("[TiltCheck] Verification Error:", err);
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Message received:", message.type);
  if (isExcludedDomain && message.type !== "get_sidebar_state") {
    sendResponse({ error: "Feature disabled on this domain" });
    return true;
  }
  switch (message.type) {
    case "toggle_sidebar": {
      void openRuntimeFromToolbar().then(sendResponse).catch((err) => {
        sendResponse({ success: false, error: err instanceof Error ? err.message : "Runtime toggle failed" });
      });
      return true;
    }
    case "open_sidebar": {
      void startRuntimeAtDocumentEnd({ forceEnable: true }).then(() => {
        const sidebarEl = document.getElementById("tiltcheck-sidebar");
        if (!sidebarEl) {
          sidebar = initSidebar(disableInjectionFromHud);
        }
        const visible = setSidebarVisibility(true);
        persistSidebarVisibility(true);
        sendResponse({ success: true, visible, injectionDisabled: false });
      }).catch((err) => {
        sendResponse({ success: false, error: err instanceof Error ? err.message : "Runtime open failed" });
      });
      return true;
    }
    case "get_sidebar_state":
      sendResponse(getSidebarState());
      return true;
    default:
      return false;
  }
});
function showRedeemNudge(data) {
  const existing = document.getElementById("tiltcheck-redeem-nudge");
  if (existing) {
    existing.remove();
  }
  const overlay = document.createElement("div");
  overlay.id = "tiltcheck-redeem-nudge";
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.95);
    z-index: 1000000;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: white;
    font-family: 'Inter', sans-serif;
    text-align: center;
  `;
  overlay.innerHTML = `
    <div style="max-width: 500px; padding: 40px; border: 2px solid #00ff88; border-radius: 20px; background: rgba(0, 255, 136, 0.05); box-shadow: 0 0 50px rgba(0, 255, 136, 0.2);">
      <h1 style="font-size: 64px; margin-bottom: 10px;">WIN</h1>
      <h2 style="font-size: 28px; color: #00ff88; text-transform: uppercase; letter-spacing: 2px;">WIN SECURED</h2>
      <p style="font-size: 20px; margin: 20px 0; line-height: 1.5;">${data.message}</p>
      <div style="font-size: 48px; font-weight: 800; margin-bottom: 30px;">$${Number(data.amount).toFixed(2)}</div>
      
      <div style="display: flex; gap: 15px; justify-content: center;">
        <button id="redeem-btn" style="background: #00ff88; color: black; border: none; padding: 15px 30px; border-radius: 10px; font-weight: 900; cursor: pointer; font-size: 18px; text-transform: uppercase;">
          Redeem Now & Quit
        </button>
        <button id="later-btn" style="background: transparent; color: white; border: 1px solid rgba(255,255,255,0.2); padding: 15px 30px; border-radius: 10px; font-weight: 600; cursor: pointer; font-size: 14px;">
          Maybe Later (Risk It)
        </button>
      </div>
      
      <div style="margin-top: 30px; font-size: 11px; opacity: 0.5; text-transform: uppercase; letter-spacing: 1px;">
        Made for Degens. By Degens.
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById("redeem-btn")?.addEventListener("click", (evt) => {
    const btn = evt.currentTarget;
    btn.disabled = true;
    btn.textContent = "Securing win...";
    relayWinSecure(data.amount).then(() => {
      overlay.remove();
      window.close();
    }).catch(() => {
      btn.disabled = false;
      btn.textContent = "Redeem Now & Quit";
      const errEl = document.createElement("p");
      errEl.style.cssText = "margin-top: 12px; color: #ff4444; font-size: 13px; font-weight: 600;";
      errEl.textContent = "Win relay failed. Screenshot this and contact support.";
      btn.parentElement?.insertAdjacentElement("afterend", errEl);
    });
  });
  document.getElementById("later-btn")?.addEventListener("click", () => {
    overlay.remove();
  });
}
async function relayWinSecure(amount) {
  const userId = await getUserId();
  const response = await postWinSecureTelemetry({ amount, userId });
  if (!response.ok) {
    console.error("[TiltCheck] Win secure relay returned non-OK status:", response.status);
    throw new Error(`Win secure relay failed with status ${response.status}`);
  }
}
function deactivateProMonolith() {
  teardownInjectedRuntime();
  proMonolithActive = false;
  if (define_process_default.env.NODE_ENV !== "production") {
    console.log("[TiltCheck Pro] Monolith surface safely defused. Core shield remains active.");
  }
}
async function startProMonolith() {
  if (proMonolithActive) {
    await startRuntimeAtDocumentEnd();
    return;
  }
  await startRuntimeAtDocumentEnd();
  proMonolithActive = true;
}
if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Pro monolith bootstrap module loaded");
export {
  INJECTION_DISABLED_KEY,
  deactivateProMonolith,
  initSidebar,
  startProMonolith
};
//# sourceMappingURL=pro-monolith-bootstrap.js.map
