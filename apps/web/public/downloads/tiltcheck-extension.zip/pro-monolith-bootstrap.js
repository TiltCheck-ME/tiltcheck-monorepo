// <define:process>
var define_process_default = { env: {} };

// src/extractor.ts
var CASINO_SELECTORS = [
  {
    casinoId: "stake",
    domain: "stake.com",
    selectors: {
      betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
      winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
      balance: '[data-test="balance"], .balance, [class*="balance-value"]',
      symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
      bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
      freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
      gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
      gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
    }
  },
  {
    casinoId: "stake-us",
    domain: "stake.us",
    selectors: {
      betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
      winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
      balance: '[data-test="balance"], .balance, [class*="balance-value"]',
      symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
      bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
      freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
      gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
      gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
    }
  },
  // Stake mirror domains - same selectors as stake.com
  ...["stake.bet", "stake.games", "staketr.com", "staketr2.com", "staketr3.com", "staketr4.com", "stake.bz", "stake.pet"].map((domain) => ({
    casinoId: "stake",
    domain,
    selectors: {
      betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
      winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
      balance: '[data-test="balance"], .balance, [class*="balance-value"]',
      symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
      bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
      freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
      gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
      gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
    }
  })),
  {
    casinoId: "roobet",
    domain: "roobet.com",
    selectors: {
      betAmount: '.bet-input input, [name="bet"], [class*="betInput"]',
      winAmount: '.win-display, .payout-amount, [class*="winAmount"]',
      balance: '.user-balance, [class*="userBalance"], [class*="balance"]',
      symbols: '.slot-symbol, [class*="reelSymbol"]',
      bonusIndicator: '.bonus-round-active, [class*="bonusActive"]',
      gameResult: ".crash-payout, .multiplier-display"
    },
    extractors: {
      extractResult: (doc) => {
        const el = doc.querySelector(".crash-payout, .multiplier-display");
        if (!el || !el.textContent) return null;
        return parseFloat(el.textContent.replace(/x/i, "").trim());
      }
    }
  },
  {
    casinoId: "bc-game",
    domain: "bc.game",
    selectors: {
      betAmount: '[class*="betAmount"], [class*="bet-amount"], input[type="number"]',
      winAmount: '[class*="winAmount"], [class*="win-amount"], [class*="payout"]',
      balance: '[class*="balance"], [class*="userBalance"]',
      symbols: '[class*="symbol"], [class*="reel"]'
    }
  },
  {
    casinoId: "duelbits",
    domain: "duelbits.com",
    selectors: {
      betAmount: '.bet-value, [class*="betValue"], [class*="bet-amount"]',
      winAmount: '.win-value, [class*="winValue"], [class*="win-amount"]',
      balance: '[class*="balance"], .user-balance',
      symbols: '[data-reel] img, .reel-symbol, [class*="symbol"]'
    }
  },
  {
    casinoId: "rollbit",
    domain: "rollbit.com",
    selectors: {
      betAmount: '[class*="betInput"], [class*="bet-amount"], input[name="bet"]',
      winAmount: '[class*="winAmount"], [class*="payout"]',
      balance: '[class*="balance"], [class*="wallet"]',
      symbols: '[class*="symbol"], [class*="reel"]'
    }
  },
  {
    casinoId: "shuffle",
    domain: "shuffle.com",
    selectors: {
      betAmount: '[class*="bet"], input[type="number"]',
      winAmount: '[class*="win"], [class*="payout"]',
      balance: '[class*="balance"], [class*="wallet"]',
      symbols: '[class*="symbol"]'
    }
  },
  {
    casinoId: "gamdom",
    domain: "gamdom.com",
    selectors: {
      betAmount: '[class*="bet-amount"], [class*="betValue"]',
      winAmount: '[class*="win-amount"], [class*="winValue"]',
      balance: '[class*="balance"]',
      symbols: '[class*="symbol"]'
    }
  },
  {
    casinoId: "generic",
    domain: "*",
    selectors: {
      betAmount: '[data-bet], .bet, .bet-amount, input[name="bet"], [class*="betAmount"], [class*="bet-input"]',
      winAmount: '[data-win], .win, .win-amount, .payout, [class*="winAmount"], [class*="payout"]',
      balance: '[data-balance], .balance, .user-balance, [class*="balance"], [class*="wallet"]',
      symbols: '[data-symbol], .symbol, .reel-symbol, [class*="symbol"], [class*="reel"]',
      gameResult: "[data-result], .game-result, .result-value, .outcome"
    }
  }
];
var CasinoDataExtractor = class {
  casinoConfig = null;
  previousBalance = null;
  lastSpinTime = 0;
  spinDebounceMs = 1e3;
  // Don't capture spins faster than 1/sec
  constructor(casinoDomain) {
    this.detectCasino(casinoDomain);
  }
  /**
   * Initialize with custom user configurations
   */
  async initialize() {
    return new Promise((resolve) => {
      try {
        const storage = chrome.storage.sync || chrome.storage.local;
        storage.get(["tiltcheck_custom_casinos"], (result) => {
          const custom = result.tiltcheck_custom_casinos || [];
          this.detectCasino(void 0, custom);
          resolve();
        });
      } catch (e) {
        console.warn("[TiltCheck] Failed to load custom casinos:", e);
        resolve();
      }
    });
  }
  /**
   * Detect which casino we're on, prioritizing custom user configs
   */
  detectCasino(domain, customSelectors = []) {
    const currentDomain = domain || window.location.hostname;
    const allSelectors = [...customSelectors, ...CASINO_SELECTORS];
    this.casinoConfig = allSelectors.find(
      (config) => currentDomain.includes(config.domain) || config.domain === "*"
    ) || CASINO_SELECTORS.find((c) => c.casinoId === "generic");
    console.log("[TiltCheck] Detected casino:", this.casinoConfig.casinoId);
  }
  /**
   * Extract text content from element
   */
  extractText(selector, doc = document) {
    const element = doc.querySelector(selector);
    if (!element) return null;
    const value = element.getAttribute("data-value") || element.getAttribute("value") || element.textContent;
    return value?.trim() || null;
  }
  /**
   * Parse numeric value from text (handles $, commas, etc.)
   */
  parseNumeric(text) {
    if (!text) return null;
    const cleaned = text.replace(/[$,\s]/g, "");
    const num = parseFloat(cleaned);
    return isNaN(num) ? null : num;
  }
  /**
   * Extract bet amount
   */
  extractBet(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractBet) {
      return this.casinoConfig.extractors.extractBet(doc);
    }
    const selector = this.casinoConfig.selectors.betAmount;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract win amount
   */
  extractWin(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractWin) {
      return this.casinoConfig.extractors.extractWin(doc);
    }
    const selector = this.casinoConfig.selectors.winAmount;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract balance
   */
  extractBalance(doc = document) {
    if (!this.casinoConfig) return null;
    const selector = this.casinoConfig.selectors.balance;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract symbols from reels
   */
  extractSymbols(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractSymbols) {
      return this.casinoConfig.extractors.extractSymbols(doc);
    }
    const selector = this.casinoConfig.selectors.symbols;
    if (!selector) return null;
    const elements = Array.from(doc.querySelectorAll(selector));
    if (elements.length === 0) return null;
    return elements.map((el) => {
      const dataSymbol = el.getAttribute("data-symbol");
      if (dataSymbol) return dataSymbol;
      const alt = el.getAttribute("alt");
      if (alt) return alt;
      const src = el.getAttribute("src");
      if (src) {
        const filename = src.split("/").pop()?.split(".")[0];
        if (filename) return filename;
      }
      return el.textContent?.trim() || "unknown";
    });
  }
  /**
   * Check if bonus round is active
   */
  isBonusActive(doc = document) {
    if (!this.casinoConfig) return false;
    const selector = this.casinoConfig.selectors.bonusIndicator;
    if (!selector) return false;
    return doc.querySelector(selector) !== null;
  }
  /**
   * Extract free spins count
   */
  extractFreeSpinsCount(doc = document) {
    if (!this.casinoConfig) return null;
    const selector = this.casinoConfig.selectors.freeSpinsCounter;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Extract game title
   */
  extractGameTitle(doc = document) {
    if (!this.casinoConfig) return null;
    const selector = this.casinoConfig.selectors.gameTitle;
    if (!selector) return null;
    return this.extractText(selector, doc);
  }
  /**
   * Extract game result (e.g. dice roll)
   */
  extractGameResult(doc = document) {
    if (!this.casinoConfig) return null;
    if (this.casinoConfig.extractors?.extractResult) {
      return this.casinoConfig.extractors.extractResult(doc);
    }
    const selector = this.casinoConfig.selectors.gameResult;
    if (!selector) return null;
    const text = this.extractText(selector, doc);
    return this.parseNumeric(text);
  }
  /**
   * Attempt to extract a complete spin event
   */
  extractSpinEvent(doc = document) {
    const now = Date.now();
    if (now - this.lastSpinTime < this.spinDebounceMs) {
      return null;
    }
    const bet = this.extractBet(doc);
    const win = this.extractWin(doc);
    const balance = this.extractBalance(doc);
    if (bet === null && win === null) {
      return null;
    }
    const symbols = this.extractSymbols(doc);
    const bonusActive = this.isBonusActive(doc);
    const freeSpins = this.extractFreeSpinsCount(doc);
    const gameTitle = this.extractGameTitle(doc);
    const gameResult = this.extractGameResult(doc);
    if (balance !== null && this.previousBalance !== null) {
      const balanceChange = balance - this.previousBalance;
      if (Math.abs(balanceChange) > 0.01) {
        this.lastSpinTime = now;
        this.previousBalance = balance;
        return {
          bet: bet !== null ? bet : Math.abs(balanceChange) - (win || 0),
          win: win !== null ? win : 0,
          balance,
          gameResult,
          symbols,
          bonusActive,
          freeSpins,
          gameTitle,
          timestamp: now
        };
      }
    } else if (balance !== null) {
      this.previousBalance = balance;
    }
    return null;
  }
  /**
   * Start observing the DOM for gameplay
   */
  startObserving(callback) {
    console.log("[TiltCheck] Starting DOM observation...");
    const pollInterval = setInterval(() => {
      const spinData = this.extractSpinEvent();
      if (spinData) {
        callback(spinData);
      }
    }, 500);
    const observer = new MutationObserver(() => {
      const spinData = this.extractSpinEvent();
      if (spinData) {
        callback(spinData);
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["data-value", "value", "class"]
    });
    return () => {
      clearInterval(pollInterval);
      observer.disconnect();
      console.log("[TiltCheck] Stopped DOM observation");
    };
  }
};
var AnalyzerClient = class {
  ws = null;
  reconnectAttempts = 0;
  maxReconnectAttempts = 5;
  baseReconnectDelay = 2e3;
  maxReconnectDelay = 3e4;
  reconnectTimer = null;
  shouldReconnect = true;
  isConnecting = false;
  heartbeatTimer = null;
  heartbeatIntervalMs = 25e3;
  onConnectionIssue;
  constructor(wsUrl, onConnectionIssue) {
    this.wsUrl = wsUrl;
    this.onConnectionIssue = onConnectionIssue;
  }
  wsUrl;
  getReadyStateLabel(state) {
    switch (state) {
      case WebSocket.CONNECTING:
        return "CONNECTING";
      case WebSocket.OPEN:
        return "OPEN";
      case WebSocket.CLOSING:
        return "CLOSING";
      case WebSocket.CLOSED:
        return "CLOSED";
      default:
        return "UNKNOWN";
    }
  }
  logSocketEvent(prefix, event) {
    const maybeClose = event;
    const maybeTarget = event?.target;
    const targetState = maybeTarget ? this.getReadyStateLabel(maybeTarget.readyState) : "UNKNOWN";
    if (maybeClose && typeof maybeClose.code === "number") {
      console.error(`${prefix} (close event)`, {
        code: maybeClose.code,
        reason: maybeClose.reason || "(no reason)",
        wasClean: maybeClose.wasClean,
        url: this.wsUrl,
        readyState: targetState
      });
      return;
    }
    console.error(`${prefix} (event)`, {
      type: event?.type || typeof event,
      url: this.wsUrl,
      readyState: targetState
    });
  }
  toConnectionError(event, fallbackMessage) {
    if (event instanceof Error) {
      return event;
    }
    const closeEvent = event;
    if (closeEvent && typeof closeEvent.code === "number") {
      return new Error(
        `${fallbackMessage} (code=${closeEvent.code}, reason=${closeEvent.reason || "none"}, clean=${closeEvent.wasClean})`
      );
    }
    return new Error(fallbackMessage);
  }
  stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }
  startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      try {
        this.ws.send(JSON.stringify({ type: "ping", ts: Date.now() }));
      } catch (error) {
        this.logSocketEvent("[TiltCheck] Heartbeat send failed", error);
      }
    }, this.heartbeatIntervalMs);
  }
  /**
   * Connect to analyzer backend
   */
  connect() {
    if (this.isConnecting) {
      return Promise.resolve();
    }
    this.shouldReconnect = true;
    return new Promise((resolve, reject) => {
      console.log("[TiltCheck] Connecting to analyzer...", this.wsUrl);
      this.isConnecting = true;
      let settled = false;
      this.ws = new WebSocket(this.wsUrl);
      this.ws.onopen = () => {
        console.log("[TiltCheck] Connected to analyzer");
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
        this.startHeartbeat();
        settled = true;
        resolve();
      };
      this.ws.onerror = (error) => {
        this.isConnecting = false;
        this.logSocketEvent("[TiltCheck] WebSocket error", error);
        if (!settled) {
          settled = true;
          reject(error);
        }
      };
      this.ws.onclose = (event) => {
        this.isConnecting = false;
        this.stopHeartbeat();
        this.ws = null;
        console.log("[TiltCheck] Disconnected from analyzer");
        this.logSocketEvent("[TiltCheck] WebSocket closed", event);
        if (!settled) {
          settled = true;
          reject(event);
        } else {
          this.onConnectionIssue?.(
            this.toConnectionError(event, "Analyzer connection closed after opening")
          );
        }
        if (this.shouldReconnect) {
          this.attemptReconnect(event);
        }
      };
    });
  }
  /**
   * Attempt to reconnect
   */
  attemptReconnect(lastEvent) {
    if (!this.shouldReconnect) return;
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error("[TiltCheck] Max reconnect attempts reached", {
        attempts: this.reconnectAttempts,
        maxAttempts: this.maxReconnectAttempts,
        url: this.wsUrl
      });
      if (lastEvent) {
        this.logSocketEvent("[TiltCheck] Final reconnect failure context", lastEvent);
      }
      return;
    }
    this.reconnectAttempts++;
    const baseDelay = Math.min(
      this.baseReconnectDelay * Math.pow(2, this.reconnectAttempts - 1),
      this.maxReconnectDelay
    );
    const jitteredDelay = Math.round(baseDelay * (1 + Math.random() * 0.25));
    console.log(`[TiltCheck] Reconnecting in ${jitteredDelay}ms... (attempt ${this.reconnectAttempts})`);
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    this.reconnectTimer = setTimeout(() => {
      this.connect().catch((err) => {
        this.logSocketEvent("[TiltCheck] Reconnect failed", err);
        this.onConnectionIssue?.(this.toConnectionError(err, "Analyzer reconnect attempt failed"));
      });
    }, jitteredDelay);
  }
  /**
   * Send spin data to analyzer
   */
  sendSpin(data) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn("[TiltCheck] WebSocket not connected, buffering spin data");
      return;
    }
    this.ws.send(JSON.stringify({
      type: "spin",
      data
    }));
  }
  /**
   * Request fairness report
   */
  requestReport(sessionId2) {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        reject(new Error("WebSocket not connected"));
        return;
      }
      const messageHandler = (event) => {
        const message = JSON.parse(event.data);
        if (message.type === "report" && message.sessionId === sessionId2) {
          this.ws.removeEventListener("message", messageHandler);
          resolve(message.data);
        }
      };
      this.ws.addEventListener("message", messageHandler);
      this.ws.send(JSON.stringify({
        type: "request_report",
        sessionId: sessionId2
      }));
      setTimeout(() => {
        this.ws.removeEventListener("message", messageHandler);
        reject(new Error("Report request timeout"));
      }, 5e3);
    });
  }
  /**
   * Close connection
   */
  disconnect() {
    this.shouldReconnect = false;
    this.stopHeartbeat();
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close(1e3, "Client disconnect");
      this.ws = null;
    }
  }
};

// src/tilt-detector.ts
var PROFILE_MULTIPLIERS = {
  conservative: 1.2,
  moderate: 1,
  degen: 0.8
};
var ANIMATION_LOOP_MS = 500;
var MICRO_PACING_RETENTION_MS = 6e4;
var TiltDetector = class {
  bets = [];
  clicks = [];
  // Timestamps of clicks
  sessionStartTime = Date.now();
  baselineAvgBet = 0;
  consecutiveLosses = 0;
  totalWagered = 0;
  totalWon = 0;
  currentBalance = null;
  initialBalance = null;
  redeemThreshold = null;
  riskProfile = "moderate";
  // Configuration
  config = {
    // Rage betting thresholds
    fastBetThreshold: 2e3,
    // ms between bets
    rageBetCount: 5,
    // consecutive fast bets
    // Chasing losses
    betIncreaseMultiplier: 2.5,
    // 2.5x increase after loss
    chasingPattern: 3,
    // consecutive increasing bets after losses
    // Fast clicks — "Auto-Pilot Trance" detection.
    // Triggers when bet events arrive faster than 300ms apart (sub-human pacing = autopilot state).
    clickThreshold: 5,
    // clicks in window
    clickWindow: 300,
    // ms — reduced from 3000ms to detect Auto-Pilot Trance pattern
    // Session duration
    warningDuration: 60 * 60 * 1e3,
    // 1 hour
    criticalDuration: 2 * 60 * 60 * 1e3,
    // 2 hours
    // Vault recommendations
    vaultThreshold: 5,
    // 5x initial balance
    profitVaultPercent: 0.5,
    // Vault 50% of profits
    // Stop loss
    stopLossPercent: 0.5,
    // Stop at 50% loss
    // Real-world comparisons (common items people forget to buy)
    realWorldItems: [
      { item: "trash bags", avgCost: 15 },
      { item: "toilet paper", avgCost: 20 },
      { item: "groceries", avgCost: 100 },
      { item: "gas", avgCost: 50 },
      { item: "phone bill", avgCost: 80 },
      { item: "utilities", avgCost: 150 },
      { item: "rent", avgCost: 1500 }
    ]
  };
  constructor(initialBalance, riskLevel = "moderate", redeemThreshold) {
    this.currentBalance = initialBalance;
    this.initialBalance = initialBalance;
    this.redeemThreshold = redeemThreshold || null;
    this.setRiskProfile(riskLevel);
  }
  setRiskProfile(level) {
    this.riskProfile = level;
    this.applyRiskProfile(level);
  }
  getRiskProfile() {
    return this.riskProfile;
  }
  classifyBetResult(bet, payout) {
    if (bet <= 0) {
      return payout > 0 ? "win" : "push";
    }
    if (payout <= 0 || payout < bet) {
      return "loss";
    }
    if (payout === bet) {
      return "push";
    }
    return "win";
  }
  /**
   * Apply risk profile configuration
   */
  applyRiskProfile(level) {
    if (level === "conservative") {
      this.config.fastBetThreshold = 3e3;
      this.config.betIncreaseMultiplier = 1.5;
      this.config.warningDuration = 30 * 60 * 1e3;
      this.config.criticalDuration = 1 * 60 * 1e3;
      this.config.stopLossPercent = 0.3;
    } else if (level === "degen") {
      this.config.fastBetThreshold = 1e3;
      this.config.betIncreaseMultiplier = 5;
      this.config.warningDuration = 4 * 60 * 60 * 1e3;
      this.config.criticalDuration = 8 * 60 * 60 * 1e3;
      this.config.stopLossPercent = 0.8;
    }
  }
  /**
   * Record a bet event
   */
  recordBet(bet, payout) {
    const now = Date.now();
    const result = this.classifyBetResult(bet, payout);
    this.bets.push({
      amount: bet,
      timestamp: now,
      result,
      payout
    });
    this.totalWagered += bet;
    this.totalWon += payout;
    if (this.currentBalance !== null) {
      this.currentBalance = this.currentBalance - bet + payout;
    }
    if (result === "loss") {
      this.consecutiveLosses++;
    } else {
      this.consecutiveLosses = 0;
    }
    const baselineBets = this.bets.filter((entry) => entry.amount > 0).slice(0, 10);
    if (baselineBets.length > 0) {
      this.baselineAvgBet = baselineBets.reduce((sum, entry) => sum + entry.amount, 0) / baselineBets.length;
    }
  }
  /**
   * Update the current balance from an external source.
   */
  updateBalance(newBalance) {
    if (newBalance !== this.currentBalance) {
      this.currentBalance = newBalance;
    }
  }
  setRedeemThreshold(redeemThreshold) {
    this.redeemThreshold = redeemThreshold && redeemThreshold > 0 ? redeemThreshold : null;
  }
  /**
   * Record a click event (for erratic clicking detection)
   */
  recordClick() {
    const now = Date.now();
    this.clicks.push(now);
    this.clicks = this.clicks.filter((t) => now - t < MICRO_PACING_RETENTION_MS);
  }
  /** Recent inter-click deltas (ms), oldest first. */
  computeRecentClickDeltas(maxDeltas = 8) {
    const sorted = [...this.clicks].sort((a, b) => a - b);
    const deltas = [];
    for (let i = 1; i < sorted.length && deltas.length < maxDeltas; i++) {
      deltas.push(sorted[i] - sorted[i - 1]);
    }
    return deltas;
  }
  getLastClickDeltaMs() {
    const deltas = this.computeRecentClickDeltas();
    return deltas.length > 0 ? deltas[deltas.length - 1] : null;
  }
  /**
   * Continuous velocity contribution (0–45) from compressing click pacing.
   */
  getMicroPacingComponent() {
    const deltas = this.computeRecentClickDeltas();
    if (deltas.length < 2) return 0;
    const lastDelta = deltas[deltas.length - 1];
    const recent = deltas.slice(-4);
    const avgDelta = recent.reduce((sum, d) => sum + d, 0) / recent.length;
    let velocity = 0;
    if (lastDelta < ANIMATION_LOOP_MS) {
      velocity += (ANIMATION_LOOP_MS - lastDelta) / ANIMATION_LOOP_MS * 28;
    }
    if (avgDelta < ANIMATION_LOOP_MS) {
      velocity += (ANIMATION_LOOP_MS - avgDelta) / ANIMATION_LOOP_MS * 12;
    }
    let compressingSteps = 0;
    for (let i = 1; i < recent.length; i++) {
      if (recent[i] < recent[i - 1] * 0.92) {
        compressingSteps++;
      }
    }
    if (compressingSteps >= 2 && lastDelta < ANIMATION_LOOP_MS + 100) {
      velocity += compressingSteps * 6;
    }
    return Math.min(45, velocity);
  }
  /**
   * Exponential loss-streak weight when pacing is hot (co-occurrence required).
   */
  getLossStreakCompoundComponent() {
    if (this.consecutiveLosses <= 3) return 0;
    const pacingHot = this.getMicroPacingComponent() >= 10 || this.getLastClickDeltaMs() !== null && this.getLastClickDeltaMs() < ANIMATION_LOOP_MS;
    if (!pacingHot) return 0;
    const streakExcess = this.consecutiveLosses - 3;
    const exponential = Math.pow(1.35, streakExcess);
    const linear = streakExcess * 7;
    return Math.min(35, linear * Math.min(2.5, exponential / 1.8));
  }
  getIndicatorCompositeScore() {
    const tiltSigns = this.detectAllTiltSigns();
    const weights = {
      rage_betting: 22,
      chasing_losses: 26,
      fast_clicks: 12,
      bet_escalation: 18,
      duration_warning: 8,
      emotional_pattern: 16,
      fatigue: 12,
      martingale: 20
    };
    const severityMultipliers = {
      low: 0.5,
      medium: 1,
      high: 1.5,
      critical: 2
    };
    let score = 0;
    for (const sign of tiltSigns) {
      const weight = weights[sign.type] ?? 10;
      const multiplier = severityMultipliers[sign.severity];
      score += weight * multiplier * sign.confidence;
    }
    return Math.min(55, score);
  }
  /**
   * Detect rage betting (fast consecutive bets)
   */
  detectRageBetting() {
    if (this.bets.length < this.config.rageBetCount) return null;
    const recentBets = this.bets.slice(-this.config.rageBetCount);
    const intervals = [];
    for (let i = 1; i < recentBets.length; i++) {
      intervals.push(recentBets[i].timestamp - recentBets[i - 1].timestamp);
    }
    const avgInterval = intervals.reduce((sum, i) => sum + i, 0) / intervals.length;
    if (avgInterval < this.config.fastBetThreshold) {
      const severity = avgInterval < 1e3 ? "critical" : avgInterval < 1500 ? "high" : "medium";
      return {
        type: "rage_betting",
        severity,
        confidence: Math.min(1, this.config.fastBetThreshold / avgInterval - 1),
        description: `Betting very quickly (${(avgInterval / 1e3).toFixed(1)}s between bets)`,
        evidence: {
          avgInterval,
          recentBets: recentBets.length,
          threshold: this.config.fastBetThreshold
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect chasing losses (increasing bets after losses)
   */
  detectChasingLosses() {
    if (this.bets.length < this.config.chasingPattern + 1) return null;
    if (this.consecutiveLosses < this.config.chasingPattern) return null;
    const recentBets = this.bets.slice(-this.config.chasingPattern - 1);
    const isChasing = recentBets.every((bet, i) => {
      if (i === 0) return true;
      return bet.amount > recentBets[i - 1].amount * this.config.betIncreaseMultiplier;
    });
    if (isChasing) {
      const increase = recentBets[recentBets.length - 1].amount / recentBets[0].amount;
      const severity = increase > 10 ? "critical" : increase > 5 ? "high" : increase > 3 ? "medium" : "low";
      return {
        type: "chasing_losses",
        severity,
        confidence: Math.min(1, increase / 10),
        description: `Bet size increased ${increase.toFixed(1)}x after ${this.consecutiveLosses} losses`,
        evidence: {
          consecutiveLosses: this.consecutiveLosses,
          betIncrease: increase,
          startBet: recentBets[0].amount,
          currentBet: recentBets[recentBets.length - 1].amount
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect fast/erratic clicking (Auto-Pilot Trance detection).
   * At 300ms window, this fires when bet events arrive faster than humanly intentional.
   */
  detectFastClicks() {
    if (this.clicks.length < this.config.clickThreshold) return null;
    const recentClicks = this.clicks.filter(
      (t) => Date.now() - t < this.config.clickWindow
    );
    if (recentClicks.length >= this.config.clickThreshold) {
      const severity = recentClicks.length > 10 ? "high" : "medium";
      const sortedRecent = [...recentClicks].sort((a, b) => b - a);
      const lastClickDeltaMs = sortedRecent.length >= 2 ? sortedRecent[0] - sortedRecent[1] : 0;
      return {
        type: "fast_clicks",
        severity,
        confidence: Math.min(1, recentClicks.length / 10),
        description: `${recentClicks.length} clicks in ${this.config.clickWindow}ms \u2014 Auto-Pilot Trance detected`,
        evidence: {
          clickCount: recentClicks.length,
          window: this.config.clickWindow,
          last_click_delta_ms: lastClickDeltaMs
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect bet escalation (beyond baseline)
   */
  detectBetEscalation() {
    if (this.bets.filter((entry) => entry.amount > 0).length < 10 || this.baselineAvgBet <= 0) return null;
    const recentBet = this.bets[this.bets.length - 1];
    if (recentBet.amount <= 0) return null;
    const escalationFactor = recentBet.amount / this.baselineAvgBet;
    if (escalationFactor > 5) {
      const severity = escalationFactor > 20 ? "critical" : escalationFactor > 10 ? "high" : "medium";
      return {
        type: "bet_escalation",
        severity,
        confidence: Math.min(1, escalationFactor / 20),
        description: `Bet ${escalationFactor.toFixed(1)}x larger than your average`,
        evidence: {
          currentBet: recentBet.amount,
          baselineAvg: this.baselineAvgBet,
          escalationFactor
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect session duration warnings
   */
  detectDurationWarning() {
    const duration = Date.now() - this.sessionStartTime;
    if (duration > this.config.criticalDuration) {
      return {
        type: "duration_warning",
        severity: "critical",
        confidence: 1,
        description: `You've been playing for ${(duration / 36e5).toFixed(1)} hours`,
        evidence: {
          duration,
          hours: duration / 36e5
        },
        triggeredAt: Date.now()
      };
    } else if (duration > this.config.warningDuration) {
      return {
        type: "duration_warning",
        severity: "medium",
        confidence: 0.8,
        description: `Session duration: ${(duration / 6e4).toFixed(0)} minutes`,
        evidence: {
          duration,
          minutes: duration / 6e4
        },
        triggeredAt: Date.now()
      };
    }
    return null;
  }
  /**
   * Detect Martingale Desperation pattern.
   *
   * Pattern: loss -> bet * 1.7x-2.5x -> loss -> bet * 1.7x-2.5x -> ... (3+ consecutive steps).
   * Uses 1.7x floor — real-world players rarely double exactly.
   */
  detectMartingale() {
    if (this.bets.length < 4) return null;
    const window2 = this.bets.slice(-6);
    let consecutiveSteps = 0;
    for (let i = 1; i < window2.length; i++) {
      const prev = window2[i - 1];
      const curr = window2[i];
      const prevWasLoss = prev.result === "loss";
      const multiplier = prev.amount > 0 ? curr.amount / prev.amount : 0;
      const isMartingaleStep = prevWasLoss && multiplier >= 1.7 && multiplier <= 2.5;
      if (isMartingaleStep) {
        consecutiveSteps++;
      } else {
        consecutiveSteps = 0;
      }
      if (consecutiveSteps >= 3) {
        const increase = curr.amount / window2[i - consecutiveSteps].amount;
        const severity = increase > 8 ? "critical" : increase > 4 ? "high" : "medium";
        return {
          type: "emotional_pattern",
          severity,
          confidence: Math.min(1, consecutiveSteps / 4),
          description: `Martingale pattern: ${consecutiveSteps} consecutive loss-double cycles detected`,
          evidence: {
            consecutiveSteps,
            startAmount: window2[i - consecutiveSteps].amount,
            currentAmount: curr.amount,
            multiplierRange: "1.7x-2.5x"
          },
          triggeredAt: Date.now()
        };
      }
    }
    return null;
  }
  /**
   * Detect all tilt indicators
   */
  detectAllTiltSigns() {
    const indicators = [];
    const rageBetting = this.detectRageBetting();
    if (rageBetting) indicators.push(rageBetting);
    const chasing = this.detectChasingLosses();
    if (chasing) indicators.push(chasing);
    const fastClicks = this.detectFastClicks();
    if (fastClicks) indicators.push(fastClicks);
    const escalation = this.detectBetEscalation();
    if (escalation) indicators.push(escalation);
    const duration = this.detectDurationWarning();
    if (duration) indicators.push(duration);
    const martingale = this.detectMartingale();
    if (martingale) indicators.push(martingale);
    return indicators;
  }
  /**
   * Generate vault recommendation
   */
  generateVaultRecommendation() {
    if (this.currentBalance === null || this.initialBalance === null || this.initialBalance <= 0) {
      return null;
    }
    const profit = this.currentBalance - this.initialBalance;
    const profitMultiple = this.currentBalance / this.initialBalance;
    if (profitMultiple >= this.config.vaultThreshold) {
      const suggestedAmount = profit * this.config.profitVaultPercent;
      const comparison = this.findRealWorldComparison(suggestedAmount);
      return {
        reason: `Your balance is ${profitMultiple.toFixed(1)}x your starting amount`,
        suggestedAmount,
        urgency: profitMultiple > 10 ? "critical" : profitMultiple > 7 ? "high" : "medium",
        realWorldComparison: comparison
      };
    }
    const lossPercent = (this.initialBalance - this.currentBalance) / this.initialBalance;
    if (lossPercent >= this.config.stopLossPercent) {
      return {
        reason: `You've lost ${(lossPercent * 100).toFixed(0)}% of your starting balance`,
        suggestedAmount: this.currentBalance,
        // Vault everything
        urgency: "critical",
        realWorldComparison: void 0
      };
    }
    return null;
  }
  /**
   * Detect opportunity to redeem/cash out (Redeem-to-Win)
   */
  detectRedeemOpportunity() {
    if (!this.redeemThreshold || this.currentBalance === null || this.currentBalance < this.redeemThreshold) return null;
    const diff = this.currentBalance - this.redeemThreshold;
    const overshootPercent = diff / this.redeemThreshold * 100;
    let urgency = "medium";
    if (overshootPercent > 50) urgency = "critical";
    else if (overshootPercent > 20) urgency = "high";
    return {
      amount: this.currentBalance,
      threshold: this.redeemThreshold,
      urgency,
      message: `\u{1F3AF} PROFIT GOAL REACHED! You're at $${this.currentBalance.toFixed(2)}, which is above your $${this.redeemThreshold} goal. Secure the win and cash out now!`
    };
  }
  /**
   * Find real-world item comparison
   */
  findRealWorldComparison(amount) {
    const affordableItems = this.config.realWorldItems.filter(
      (item2) => amount >= item2.avgCost
    );
    if (affordableItems.length === 0) return void 0;
    const item = affordableItems[Math.floor(Math.random() * affordableItems.length)];
    const quantity = Math.floor(amount / item.avgCost);
    return {
      item: item.item,
      cost: item.avgCost,
      quantity,
      message: `Hey, you mentioned needing ${item.item}. Your balance is ${quantity}x what they cost - maybe pull $${item.avgCost} and grab them now?`
    };
  }
  /**
   * Generate intervention recommendations
   */
  generateInterventions() {
    const interventions = [];
    const tiltSigns = this.detectAllTiltSigns();
    const vaultRec = this.generateVaultRecommendation();
    const redeemRec = this.detectRedeemOpportunity();
    const criticalSigns = tiltSigns.filter((t) => t.severity === "critical");
    if (criticalSigns.length > 0) {
      interventions.push({
        type: "cooldown",
        message: `\u{1F6D1} TILT DETECTED: ${criticalSigns.map((t) => t.description).join(", ")}. Take a 5-minute break.`,
        actionRequired: true,
        data: { duration: 5 * 60 * 1e3, tiltSigns: criticalSigns }
      });
    }
    const highSigns = tiltSigns.filter((t) => t.severity === "high" || t.severity === "critical");
    if (highSigns.length >= 2) {
      interventions.push({
        type: "phone_friend",
        message: "\u{1F4DE} Multiple tilt indicators detected. Maybe call someone before continuing?",
        actionRequired: false,
        data: { tiltSigns: highSigns }
      });
    }
    if (vaultRec) {
      if (vaultRec.urgency === "critical") {
        interventions.push({
          type: "stop_loss_triggered",
          message: `\u26A0\uFE0F STOP LOSS: ${vaultRec.reason}. Strongly recommend vaulting your remaining balance.`,
          actionRequired: true,
          data: vaultRec
        });
      } else if (vaultRec.realWorldComparison) {
        interventions.push({
          type: "spending_reminder",
          message: vaultRec.realWorldComparison.message,
          actionRequired: false,
          data: vaultRec
        });
      } else {
        interventions.push({
          type: "vault_balance",
          message: `\u{1F4B0} ${vaultRec.reason}. Consider vaulting $${vaultRec.suggestedAmount.toFixed(2)}.`,
          actionRequired: false,
          data: vaultRec
        });
      }
    }
    if (redeemRec) {
      interventions.push({
        type: "redeem_nudge",
        message: redeemRec.message,
        actionRequired: true,
        data: redeemRec
      });
    }
    const durationWarning = tiltSigns.find((t) => t.type === "duration_warning");
    if (durationWarning && durationWarning.severity === "critical") {
      interventions.push({
        type: "session_break",
        message: `\u23F0 ${durationWarning.description}. Time for a break?`,
        actionRequired: false,
        data: durationWarning
      });
    }
    return interventions;
  }
  /**
   * Composite tilt risk (0–100): indicators + micro-pacing + loss-streak compound, scaled by profile.
   */
  getTiltRiskScore() {
    const indicatorScore = this.getIndicatorCompositeScore();
    const velocityScore = this.getMicroPacingComponent();
    const lossCompound = this.getLossStreakCompoundComponent();
    const raw = indicatorScore + velocityScore + lossCompound;
    const profileMu = PROFILE_MULTIPLIERS[this.riskProfile];
    return Math.min(100, Math.round(raw * profileMu));
  }
  /**
   * Get session summary
   */
  getSessionSummary() {
    const duration = Date.now() - this.sessionStartTime;
    const netProfit = this.currentBalance !== null && this.initialBalance !== null ? this.currentBalance - this.initialBalance : null;
    const roi = netProfit !== null && this.initialBalance !== null && this.initialBalance > 0 ? netProfit / this.initialBalance * 100 : null;
    return {
      duration,
      // ms
      startTime: this.sessionStartTime,
      totalBets: this.bets.length,
      totalWagered: this.totalWagered,
      totalWon: this.totalWon,
      netProfit,
      roi,
      currentBalance: this.currentBalance,
      initialBalance: this.initialBalance,
      avgBetSize: this.bets.length > 0 ? this.totalWagered / this.bets.length : 0,
      consecutiveLosses: this.consecutiveLosses,
      tiltRisk: this.getTiltRiskScore()
    };
  }
};

// src/license-verifier.ts
var EXTENSION_LICENSE_SOURCE = "Current page DOM scan";
var LICENSE_STALE_WINDOW_MS = 7 * 24 * 60 * 60 * 1e3;
var LEGITIMATE_AUTHORITIES = [
  // Tier 1 (Strictest)
  { name: "UK Gambling Commission", pattern: /UKGC|UK\s*Gambling|39\d{3}/i, jurisdiction: "United Kingdom" },
  { name: "Malta Gaming Authority", pattern: /MGA|Malta\s*Gaming|MGA\/\w+\/\d+/i, jurisdiction: "Malta" },
  { name: "Gibraltar Gambling Commission", pattern: /Gibraltar|RGL/i, jurisdiction: "Gibraltar" },
  // Tier 2 (Reputable)
  { name: "Curacao eGaming", pattern: /Cura[cç]ao|8048\/JAZ|1668\/JAZ/i, jurisdiction: "Curacao" },
  { name: "Kahnawake Gaming Commission", pattern: /Kahnawake/i, jurisdiction: "Canada" },
  { name: "Alderney Gambling Control", pattern: /Alderney/i, jurisdiction: "Alderney" },
  { name: "Isle of Man Gambling", pattern: /Isle\s*of\s*Man/i, jurisdiction: "Isle of Man" },
  // Tier 3 (Emerging)
  { name: "Anjouan Gaming", pattern: /Anjouan/i, jurisdiction: "Comoros" },
  { name: "Costa Rica Gaming", pattern: /Costa\s*Rica/i, jurisdiction: "Costa Rica" },
  // US State licenses
  { name: "Nevada Gaming Control", pattern: /Nevada\s*Gaming/i, jurisdiction: "Nevada, USA" },
  { name: "New Jersey DGE", pattern: /New\s*Jersey|DGE|Division\s*of\s*Gaming/i, jurisdiction: "New Jersey, USA" },
  { name: "Pennsylvania Gaming", pattern: /Pennsylvania\s*Gaming|PGCB/i, jurisdiction: "Pennsylvania, USA" }
];
var RED_FLAGS = [
  { pattern: /no\s*license/i, label: "site claims no license" },
  { pattern: /unlicensed/i, label: "site describes itself as unlicensed" },
  { pattern: /offshore\s+(unlicensed|unregulated)/i, label: "offshore unlicensed/unregulated language detected" },
  { pattern: /unregulated/i, label: "site describes itself as unregulated" },
  { pattern: /bitcoin\s*only/i, label: "bitcoin-only language detected" }
];
var CasinoLicenseVerifier = class {
  /**
   * Scan document for license information
   */
  findLicenseInfo(doc = document) {
    const warnings = [];
    let found = false;
    let licenseNumber;
    let issuingAuthority;
    let jurisdiction;
    let location;
    let source = EXTENSION_LICENSE_SOURCE;
    const lastVerifiedAt = (/* @__PURE__ */ new Date()).toISOString();
    const footer = doc.querySelector("footer") || doc.querySelector('[class*="footer"]') || doc.querySelector('[id*="footer"]');
    if (footer) {
      const footerText = footer.textContent || "";
      const licenseMatch = this.extractLicense(footerText);
      if (licenseMatch.found) {
        found = true;
        licenseNumber = licenseMatch.licenseNumber;
        issuingAuthority = licenseMatch.authority;
        jurisdiction = licenseMatch.jurisdiction;
        location = "footer";
        source = "Current page footer scan";
      }
    }
    if (!found) {
      const licenseLinks = Array.from(doc.querySelectorAll("a")).filter(
        (a) => /license|regulation|authority|gaming\s*commission/i.test(a.textContent || "")
      );
      if (licenseLinks.length > 0) {
        for (const link of licenseLinks) {
          const linkText = link.textContent || "";
          const licenseMatch = this.extractLicense(linkText);
          if (licenseMatch.found) {
            found = true;
            licenseNumber = licenseMatch.licenseNumber;
            issuingAuthority = licenseMatch.authority;
            jurisdiction = licenseMatch.jurisdiction;
            location = "license-page";
            source = "Current page license-link scan";
            break;
          }
        }
      }
    }
    if (!found) {
      const aboutLinks = Array.from(doc.querySelectorAll("a")).filter(
        (a) => /about|terms|legal|responsible/i.test(a.textContent || "")
      );
      if (aboutLinks.length > 0) {
        warnings.push("License info may be on About/Terms page - not verified automatically");
        source = "Current page legal-link scan";
      }
    }
    const bodyText = doc.body.textContent || "";
    for (const redFlag of RED_FLAGS) {
      if (redFlag.pattern.test(bodyText)) {
        warnings.push(redFlag.label);
      }
    }
    return {
      found,
      licenseNumber,
      issuingAuthority,
      jurisdiction,
      location,
      verified: found && issuingAuthority !== void 0,
      source,
      lastVerifiedAt,
      warnings
    };
  }
  /**
   * Extract license from text
   */
  extractLicense(text) {
    for (const auth of LEGITIMATE_AUTHORITIES) {
      if (auth.pattern.test(text)) {
        const licenseMatch = text.match(/\b([A-Z0-9]{4,}\/[A-Z0-9]+\/\d{4,}|\d{4,})\b/);
        return {
          found: true,
          licenseNumber: licenseMatch?.[1],
          authority: auth.name,
          jurisdiction: auth.jurisdiction
        };
      }
    }
    return { found: false };
  }
  /**
   * Verify casino legitimacy
   */
  verifyCasino(doc = document) {
    const licenseInfo = this.findLicenseInfo(doc);
    let verdict;
    let shouldAnalyze;
    let warningMessage;
    if (licenseInfo.verified) {
      verdict = "legitimate";
      shouldAnalyze = true;
    } else if (licenseInfo.found && licenseInfo.warnings.length === 0) {
      verdict = "unknown";
      shouldAnalyze = true;
      warningMessage = "License found but could not be verified automatically. Proceeding with caution.";
    } else if (licenseInfo.warnings.length > 0) {
      verdict = "suspicious";
      shouldAnalyze = true;
      warningMessage = `Suspicious licensing signals detected: ${licenseInfo.warnings.join(", ")}. Analysis is active with elevated risk indicators.`;
    } else {
      verdict = "unlicensed";
      shouldAnalyze = false;
      warningMessage = "No valid gambling license found yet. Normal TiltCheck analysis is disabled on this site.";
    }
    return {
      isLegitimate: verdict === "legitimate",
      licenseInfo,
      verdict,
      shouldAnalyze,
      warningMessage
    };
  }
  /**
   * Get user-friendly message about casino legitimacy
   */
  getVerificationMessage(verification) {
    if (verification.verdict === "legitimate") {
      return `Licensed by ${verification.licenseInfo.issuingAuthority} (${verification.licenseInfo.jurisdiction})${verification.licenseInfo.licenseNumber ? ` - License #${verification.licenseInfo.licenseNumber}` : ""}`;
    } else if (verification.verdict === "unknown") {
      return verification.warningMessage || "License status unknown";
    } else if (verification.verdict === "suspicious") {
      return verification.warningMessage || "Suspicious licensing";
    } else {
      return verification.warningMessage || "No license found";
    }
  }
};
function formatLicenseAuthority(licenseInfo) {
  return licenseInfo.issuingAuthority || "Unknown authority";
}
function formatLicenseDetails(licenseInfo) {
  const authority = formatLicenseAuthority(licenseInfo);
  const jurisdiction = licenseInfo.jurisdiction ? ` (${licenseInfo.jurisdiction})` : "";
  const licenseNumber = licenseInfo.licenseNumber ? ` #${licenseInfo.licenseNumber}` : "";
  const location = licenseInfo.location ? ` via ${licenseInfo.location}` : "";
  return `${authority}${jurisdiction}${licenseNumber}${location}`;
}
function formatVerificationDate(value) {
  if (!value) {
    return "pending";
  }
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) {
    return "unknown";
  }
  return new Date(parsed).toLocaleDateString();
}
function isStaleVerification(value) {
  if (!value) {
    return false;
  }
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) {
    return false;
  }
  return Date.now() - parsed > LICENSE_STALE_WINDOW_MS;
}
function buildLicenseDetails(licenseInfo) {
  const details = [
    `Source: ${licenseInfo.source || EXTENSION_LICENSE_SOURCE}`,
    `Last verified: ${formatVerificationDate(licenseInfo.lastVerifiedAt)}`,
    "Not legal advice. No regulator endorsement implied."
  ];
  if (isStaleVerification(licenseInfo.lastVerifiedAt)) {
    details.splice(2, 0, "Stale warning: license scan is older than 7 days.");
  }
  if (licenseInfo.warnings.length > 0) {
    details.push(`Warnings: ${licenseInfo.warnings.join(", ")}`);
  }
  return details;
}
function buildLicensePresentation(verification) {
  if (!verification) {
    return {
      tone: "pending",
      summary: "License: scanning current site...",
      details: [
        `Source: ${EXTENSION_LICENSE_SOURCE}`,
        "Last verified: pending",
        "Not legal advice. No regulator endorsement implied."
      ]
    };
  }
  const details = buildLicenseDetails(verification.licenseInfo);
  if (verification.verdict === "legitimate") {
    return {
      tone: "verified",
      summary: `License verified: ${formatLicenseDetails(verification.licenseInfo)}`,
      details
    };
  }
  if (verification.verdict === "unknown") {
    return {
      tone: "warning",
      summary: verification.warningMessage || `License found but not fully verified: ${formatLicenseDetails(verification.licenseInfo)}`,
      details
    };
  }
  return {
    tone: "risk",
    summary: verification.warningMessage || "License verification failed. Normal TiltCheck analysis is disabled on this site.",
    details
  };
}
function getAnalysisBlockMessage(verification) {
  if (!verification || verification.shouldAnalyze) {
    return null;
  }
  return verification.warningMessage || "Normal TiltCheck analysis is disabled on this site until a valid license is verified.";
}

// src/mobile-license-hud.ts
var MOBILE_LICENSE_HUD_ID = "tiltcheck-mobile-license-hud";
var MOBILE_LICENSE_HUD_STYLE_ID = "tiltcheck-mobile-license-hud-style";
var BRAND_FOOTER = "Made for Degens. By Degens.";
var TONE_STYLES = {
  verified: {
    background: "rgba(6, 78, 59, 0.92)",
    border: "rgba(110, 231, 183, 0.55)",
    color: "#d1fae5"
  },
  warning: {
    background: "rgba(113, 63, 18, 0.94)",
    border: "rgba(252, 211, 77, 0.58)",
    color: "#fef3c7"
  },
  risk: {
    background: "rgba(127, 29, 29, 0.94)",
    border: "rgba(252, 165, 165, 0.62)",
    color: "#fee2e2"
  },
  pending: {
    background: "rgba(12, 74, 110, 0.92)",
    border: "rgba(125, 211, 252, 0.55)",
    color: "#e0f2fe"
  }
};
function ensureMobileLicenseHudStyle(doc) {
  if (doc.getElementById(MOBILE_LICENSE_HUD_STYLE_ID)) {
    return;
  }
  const style = doc.createElement("style");
  style.id = MOBILE_LICENSE_HUD_STYLE_ID;
  style.textContent = `
    #${MOBILE_LICENSE_HUD_ID} {
      position: fixed;
      top: calc(env(safe-area-inset-top, 0px) + 8px);
      left: 10px;
      right: 10px;
      z-index: 2147483646;
      display: none;
      min-height: 38px;
      padding: 9px 12px;
      border: 1px solid rgba(255, 255, 255, 0.16);
      border-radius: 12px;
      box-sizing: border-box;
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.42);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 12px;
      font-weight: 800;
      line-height: 1.3;
      letter-spacing: 0.01em;
      text-align: center;
      pointer-events: none;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    @media (max-width: 768px), (pointer: coarse) {
      #${MOBILE_LICENSE_HUD_ID} {
        display: block;
      }
    }
  `;
  doc.head.appendChild(style);
}
function ensureMobileLicenseHud(doc) {
  ensureMobileLicenseHudStyle(doc);
  const existing = doc.getElementById(MOBILE_LICENSE_HUD_ID);
  if (existing) {
    return existing;
  }
  const hud = doc.createElement("div");
  hud.id = MOBILE_LICENSE_HUD_ID;
  hud.setAttribute("role", "status");
  hud.setAttribute("aria-live", "polite");
  hud.dataset.status = "pending";
  doc.body.appendChild(hud);
  return hud;
}
function updateMobileLicenseHud(verification, doc = document) {
  if (!doc.body || !doc.head) {
    return null;
  }
  const presentation = buildLicensePresentation(verification);
  const hud = ensureMobileLicenseHud(doc);
  const toneStyle = TONE_STYLES[presentation.tone];
  hud.textContent = `${presentation.summary} | ${BRAND_FOOTER}`;
  hud.className = `tiltcheck-mobile-license-hud ${presentation.tone}`;
  hud.dataset.status = presentation.tone;
  hud.style.background = toneStyle.background;
  hud.style.borderColor = toneStyle.border;
  hud.style.color = toneStyle.color;
  return hud;
}

// src/sidebar/template.ts
var SIDEBAR_TEMPLATE = `
    <div class="tg-header">
      <div class="tg-header-brand">
        <div class="tg-logo-icon"><span class="tg-logo-mark">T</span></div>
        <div class="tg-logo-copy">
          <span class="tg-logo-text">TILTCHECK</span>
          <span class="tg-logo-sub">The Degen Audit Layer</span>
        </div>
      </div>
      <div class="tg-header-actions">
        <button class="tg-header-btn tg-advanced-only" id="tg-settings" title="Settings">SET</button>
        <button class="tg-header-btn" id="tg-minimize" title="Minimize">\u2212</button>
        <button class="tg-header-btn" id="tg-hide" title="Close">\xD7</button>
      </div>
    </div>
    <div id="tg-license-strip" class="tg-license-strip pending">License: scanning current site...</div>
    <div id="tg-license-detail" class="tg-license-detail">Source: current page scan. Last verified: pending. Not legal advice.</div>
    <div id="tg-status-bar" class="tg-status-bar" style="display: none;"></div>
    
    <div class="tg-content" id="tg-content">
      <!-- Auth Section -->
      <div class="tg-section" id="tg-auth-section">
        <div class="tg-auth-prompt">
          <h3>TILTCHECK ACTIVE</h3>
          <p>Connect Discord to sync vault history, live session signals, and casino telemetry across the ecosystem. No lectures, just math.</p>
          <button class="tg-btn tg-btn-primary" id="tg-discord-login">Log in with Discord</button>
          <button class="tg-btn tg-btn-secondary" id="tg-guest-login" style="margin-top: 8px;">Continue as Guest</button>
        </div>
      </div>

      <!-- Main Content (hidden until auth) -->
      <div id="tg-main-content" style="display: none;">
        <!-- User Bar -->
        <div class="tg-user-bar">
          <div class="tg-user-info">
            <span id="tg-username">Guest</span>
            <span class="tg-tier" id="tg-user-tier">Verified User</span>
          </div>
          <button class="tg-btn-icon" id="tg-logout" title="Logout" aria-label="Logout">&#x00D7;</button>
        </div>
        <div class="tg-account-strip">
          <span id="tg-account-text">Demo mode is live</span>
          <button class="tg-btn tg-btn-primary tg-btn-inline" id="tg-connect-discord-inline">Log in with Discord</button>
        </div>
        <div class="tg-focus-note">Quick tip: keep this minimized while you play, then expand when you want a clean reality check.</div>

        <!-- Reality Check Bot -->
        <div class="tg-section tg-emergency">
          <div class="tg-emergency-header">
            <div style="flex: 1;">
              <div class="tg-emergency-title">TILTCHECK INTERVENTION</div>
              <div class="tg-emergency-sub">The house is farming you. Use the EMERGENCY BRAKE to lock your gains on-chain before you give it all back.</div>
            </div>
            <button class="tg-btn tg-btn-danger" id="tg-emergency-lock" style="width: auto; padding: 10px 16px;">EMERGENCY BRAKE</button>
          </div>
        </div>

        <div class="tg-section">
          <h4>Redeem-to-Win</h4>
          <div class="tg-input-group">
            <label>Cash-out line for <span id="tg-redeem-site-label">this site</span></label>
            <div style="display: flex; gap: 8px; align-items: center;">
              <input type="number" id="tg-redeem-threshold" min="0" step="0.01" placeholder="0.00" style="flex: 1;" />
              <button class="tg-btn tg-btn-primary tg-btn-inline" id="tg-save-redeem-threshold">Arm</button>
            </div>
            <div style="font-size: 11px; opacity: 0.65; margin-top: 6px;">
              Set 0 to disable the redeem nudge on this casino.
            </div>
          </div>
        </div>

        <!-- Settings Panel (toggleable) -->
        <div class="tg-settings-panel tg-advanced-only" id="tg-settings-panel" style="display: none;">
          <h4>Sidebar Settings</h4>
          <div class="tg-input-group" style="display: flex; align-items: center; gap: 8px; margin-top: 10px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
            <input type="checkbox" id="cfg-buddy-mirror" style="width: auto;" />
            <label for="cfg-buddy-mirror" style="margin: 0; font-size: 12px;">Mirror Buddy Alerts In Discord</label>
          </div>
          <div style="font-size: 10px; opacity: 0.65; margin-top: 8px;">
            Quick mirror only. Buddy roster and approvals stay dashboard-owned.
          </div>
          <button class="tg-btn tg-btn-secondary" id="tg-open-buddies" style="margin-top: 10px;">Open Buddy Controls</button>
          <button class="tg-btn tg-btn-secondary" id="close-settings">Close</button>
        </div>

        <!-- Reality Check Log -->
        <div class="tg-metrics-card">
          <div class="tg-metrics-header" style="margin-bottom: 24px;">
            <div style="flex: 1;">
              <h1 class="tg-hud-label">THE PROJECTED</h1>
              <h2 class="tg-hud-title" style="color: var(--tg-muted); opacity: 0.5;">HOUSE ALWAYS WINS</h2>
            </div>
            <div id="tg-status-indicator" class="tg-status-indicator"></div>
          </div>

          <div class="tg-metric-stack">
            <h1 class="tg-hud-label">THE REALITY</h1>
            <div class="tg-drift-main">
              <span class="tg-drift-value" id="tg-rtp">--</span>
              <span class="tg-drift-label">ACTUAL RTP</span>
            </div>
          </div>

          <div class="tg-metrics-grid" style="margin-top: 24px; border-top: 1px solid var(--tg-border); padding-top: 20px;">
            <div class="tg-metric">
              <span class="tg-metric-label">Volatility</span>
              <span class="tg-metric-value" id="tg-score-value">0</span>
            </div>
            <div class="tg-metric">
              <span class="tg-metric-label">Wagered</span>
              <span class="tg-metric-value" id="tg-wagered">$0</span>
            </div>
            <div class="tg-metric">
              <span class="tg-metric-label">Rounds</span>
              <span class="tg-metric-value" id="tg-bets">0</span>
            </div>
            <div class="tg-metric">
              <span class="tg-metric-label">Session P/L</span>
              <span class="tg-metric-value" id="tg-profit">$0</span>
            </div>
          </div>
          <div class="tg-session-site" id="tg-session-site" style="margin-top: 12px; text-align: center;">Scanning Casino Environment...</div>
        </div>

        <!-- P/L Graph -->
        <div class="tg-section">
          <h4>Profit/Loss</h4>
          <div class="tg-graph" id="tg-pnl-graph">
            <canvas id="pnl-canvas" width="300" height="120"></canvas>
          </div>
        </div>

        <!-- Reality Check Log (Formerly Message Feed) -->
        <div class="tg-section">
          <h4>Session History Log</h4>
          <div class="tg-feed" id="tg-message-feed">
            <div class="tg-feed-item">Monitoring active. No fluff.</div>
          </div>
        </div>

        <!-- Quick Actions -->
        <div class="tg-section">
          <h4>Quick Tools</h4>
          <button class="tg-btn tg-btn-secondary tg-advanced-toggle" id="tg-toggle-advanced" aria-pressed="false">Show Pro Tools</button>
          <div class="tg-action-grid">
            <button class="tg-action-btn" id="tg-open-predictor">DAILY BONUSES</button>
            <button class="tg-action-btn" id="tg-open-dashboard">THE DASHBOARD</button>
            <button class="tg-action-btn" id="tg-open-safety">SAFETY SETTINGS</button>
            <button class="tg-action-btn" id="tg-open-vault-rules">VAULT RULES</button>
            <button class="tg-action-btn" id="tg-open-buddy-controls">BUDDY CONTROLS</button>
          </div>
          <div class="tg-runtime-control">
            <button class="tg-btn tg-btn-danger" id="tg-disable-injection" type="button">Disable Runtime</button>
            <div class="tg-runtime-note">Hard off-switch for injection. The toolbar can wake it back up if you want the HUD again.</div>
          </div>
          <button class="tg-btn tg-btn-secondary tg-advanced-only" id="tg-open-report" style="margin-top: 8px;">Report Site Change</button>
        </div>
          <h4>THE TILT SIGNAL</h4>
          <div class="tg-input-group">
            <label>Signal Type</label>
            <select id="report-type" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 4px;">
              <option value="payout_change">Payout Schedule Change</option>
              <option value="bonus_nerf">Bonus Amount Reduced</option>
              <option value="rtp_change">RTP/Odds Change</option>
              <option value="scam_alert">Scam/Fraud Alert</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="tg-input-group">
            <label>Details</label>
            <textarea id="report-details" rows="3" style="width: 100%; padding: 8px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 4px;"></textarea>
          </div>
          <button class="tg-btn tg-btn-primary" id="submit-report">Send Signal</button>
          <button class="tg-btn tg-btn-secondary" id="close-report">Close</button>
        </div>

        <!-- Vault Section -->
        <div class="tg-section">
          <h4>Vault Balance</h4>
          <div class="tg-vault-amount" id="tg-vault-balance">$0.00</div>
          
          <!-- Auto-Vault (API Backdoor) -->
          <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255,255,255,0.1);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <h4 style="font-size: 11px; margin: 0;">THE AUTO-BAG SECURE (API)</h4>
              <div class="tg-toggle-wrapper">
                <input type="checkbox" id="tg-autovault-toggle" class="tg-toggle-input" />
                <label for="tg-autovault-toggle" class="tg-toggle-label"></label>
              </div>
            </div>
            <div id="tg-autovault-controls" style="display: none; background: rgba(0,255,198,0.05); padding: 10px; border-radius: 8px; border: 1px solid rgba(0,255,198,0.1);">
              <div class="tg-input-group" style="margin-bottom: 8px;">
                <label style="font-size: 10px; opacity: 0.7;">Quick-save % of profit</label>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <input type="range" id="tg-autovault-pct" min="5" max="50" step="5" value="10" style="flex: 1;" />
                  <span id="tg-autovault-pct-val" style="font-size: 12px; font-weight: bold; width: 30px;">10%</span>
                </div>
              </div>
              <div style="font-size: 9px; opacity: 0.6; line-height: 1.4;">
                Session quick-save only. Durable vault rules and wallet safety settings stay dashboard-owned.
              </div>
              <div id="tg-autovault-stats" style="margin-top: 8px; font-size: 10px; border-top: 1px solid rgba(0,255,198,0.1); padding-top: 6px; display: flex; justify-content: space-between;">
                <span>Session Secured:</span>
                <span id="tg-autovault-secured" style="color: #00FFC6;">0.00 --</span>
              </div>
              <button class="tg-btn tg-btn-secondary" id="tg-open-vault" style="margin-top: 10px;">Open Vault Controls</button>
            </div>
          </div>

          <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(255,255,255,0.1);">
            <h4 style="font-size: 11px; margin-bottom: 6px;">Vault Timeline</h4>
            <div id="tg-vault-timeline" class="tg-vault-timeline">
              <div class="tg-vault-timeline-empty">No vault activity yet. Your wins will show up here.</div>
            </div>
          </div>
        </div>

        <!-- Daily Bonuses Section -->
        <div class="tg-section tg-bonuses-section">
          <div class="tg-bonuses-header">
            <h4 style="margin:0;">DAILY BONUSES</h4>
            <div class="tg-bonuses-controls">
              <button class="tg-btn-link" id="tg-bonuses-refresh">[REFRESH]</button>
              <button class="tg-btn-link" id="tg-bonuses-toggle">[EXPAND]</button>
            </div>
          </div>
          <div id="tg-bonuses-body" style="display:none;">
            <div id="tg-bonuses-list">
              <div class="tg-bonus-empty">Loading bonuses...</div>
            </div>
            <div class="tg-bonuses-footer">
              <a href="https://tiltcheck.me/bonuses" target="_blank" rel="noopener noreferrer" class="tg-bonuses-viewall">View all at tiltcheck.me/bonuses</a>
            </div>
          </div>
        </div>
        <div class="tg-brand-footer">Made for Degens. By Degens. \u2022 \xA9 2026 TiltCheck</div>
      </div>
    </div>

    <div class="tg-toast" id="tg-toast" style="display:none;"></div>

    <!-- Vibe Check Overlay -->
    <div id="tg-vibe-check-overlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); z-index: 2147483647; flex-direction: column; align-items: center; justify-content: center; padding: 20px; text-align: center; color: #fff; font-family: 'JetBrains Mono', monospace;">
      <div style="font-size: 32px; margin-bottom: 20px; letter-spacing: 0.2em;">ALERT</div>
      <h2 style="font-size: 32px; color: #ff3366; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 10px;">SESSION PAUSE</h2>
      <p style="font-size: 18px; margin-bottom: 30px; max-width: 500px;">The Reality Check Bot just caught you rage-betting. You're about to fumble the bag. Either lock your profits now or go touch grass.</p>
      
      <div id="vibe-check-gif" style="width: 300px; height: 300px; background: #222; margin-bottom: 30px; border: 2px solid #ff3366; display: flex; align-items: center; justify-content: center; overflow: hidden; border-radius: 12px;">
        <!-- GIF will be injected here -->
        <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMThqOHF4YTh2eGgxNzhxZnx8fGVufDB8fHw%3D/v1.gif" alt="Wake up" style="width: 100%; height: 100%; object-fit: cover;">
      </div>

      <div style="display: flex; gap: 15px; flex-wrap: wrap; justify-content: center;">
        <button class="tg-btn tg-btn-danger" id="vibe-lock-bag" style="padding: 15px 30px; font-size: 18px;">SECURE THE BAG</button>
        <button class="tg-btn tg-btn-secondary" id="vibe-discord" style="padding: 15px 30px; font-size: 18px;">GET YELLED AT (DISCORD)</button>
        <button class="tg-btn tg-btn-outline" id="vibe-ignore" style="padding: 15px 30px; font-size: 14px; opacity: 0.5;">IGNORE (FUMBLE IT)</button>
      </div>
    </div>

    <!-- Onboarding Overlay -->
    <div id="onboarding-overlay">
      <div class="onboarding-tooltip">
        <div class="tooltip-title">Welcome</div>
        <div class="tooltip-body">Let's walk through the Reality Check Pro tools.</div>
        <div class="tooltip-footer">
          <div class="tooltip-progress">1 / 4</div>
          <div class="tooltip-actions">
            <button class="tooltip-btn" id="ob-skip">Skip</button>
            <button class="tooltip-btn primary" id="ob-next">Next</button>
          </div>
        </div>
      </div>
    </div>
`;

// src/config.ts
var EXT_CONFIG = {
  API_BASE_URL: "https://api.tiltcheck.me",
  HUB_URL: "https://api.tiltcheck.me",
  DASHBOARD_URL: "https://dashboard.tiltcheck.me/dashboard",
  AI_GATEWAY_URL: "https://api.tiltcheck.me/ai",
  WEB_APP_URL: "https://tiltcheck.me",
  DISCORD_CLIENT_ID: "1445916179163250860",
  // Operations & Revenue (GCP Bill Fund)
  OPERATIONS_WALLET: "BvzEqVRUicmW8Y6HFncLYrGXESpMbSNDkWUNTQj5GGGi",
  PROTOCOL_FEE_BPS: 250
  // 2.5% service fee
};
var TELEMETRY_BASE_PATH = "/v1/telemetry";
var TELEMETRY_PATH = `${TELEMETRY_BASE_PATH}/round`;
var WIN_SECURE_PATH = `${TELEMETRY_BASE_PATH}/win-secure`;
var TELEMETRY_REQUEST_HEADERS = Object.freeze({
  "Content-Type": "application/json",
  "X-Requested-With": "TiltCheckExtension"
});
function normalizeBaseUrl(url) {
  return url.replace(/\/+$/, "");
}
function getHubEndpoint(path) {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${normalizeBaseUrl(EXT_CONFIG.HUB_URL)}${normalizedPath}`;
}
function getExtensionId() {
  return typeof chrome !== "undefined" ? chrome.runtime?.id : void 0;
}
function getDiscordLoginUrl(source = "extension") {
  const url = new URL(`${EXT_CONFIG.API_BASE_URL}/auth/discord/login`);
  url.searchParams.set("source", source);
  if (source === "extension") {
    const runtimeId = getExtensionId();
    if (runtimeId) {
      url.searchParams.set("opener_origin", `chrome-extension://${runtimeId}`);
      url.searchParams.set("ext_id", runtimeId);
    }
  }
  if (source && source !== "extension") {
    url.searchParams.set("source_detail", source);
  }
  return url.toString();
}

// src/sidebar/constants.ts
var API_BASE = EXT_CONFIG.API_BASE_URL;
var AI_GATEWAY_URL = EXT_CONFIG.AI_GATEWAY_URL;
var API_ORIGIN = (() => {
  try {
    return new URL(API_BASE).origin;
  } catch {
    return "https://api.tiltcheck.me";
  }
})();
var SIDEBAR_WIDTH = 340;
var MINIMIZED_WIDTH = 40;
var INJECTION_DISABLED_KEY = "tiltcheck_injection_disabled";
var SIDEBAR_VISIBILITY_KEY = "tiltcheck_sidebar_visible";
var SIDEBAR_PREFS_KEY = "sidebarUiPrefs";

// src/sidebar/styles.ts
var getSidebarStyles = () => `
    html.tiltcheck-sidebar-reserved,
    body.tiltcheck-sidebar-reserved {
      width: calc(100vw - var(--tiltcheck-sidebar-offset, 0px)) !important;
      max-width: calc(100vw - var(--tiltcheck-sidebar-offset, 0px)) !important;
      margin-right: var(--tiltcheck-sidebar-offset, 0px) !important;
      box-sizing: border-box !important;
      overflow-x: hidden !important;
      transition: width 0.25s ease, max-width 0.25s ease, margin-right 0.25s ease !important;
    }

    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=JetBrains+Mono:wght@400;700&family=Inter:wght@400;500;600;700&display=swap');

    #tiltcheck-sidebar {
      --tg-bg: rgba(8, 10, 14, 0.85); 
      --tg-surface: rgba(255, 255, 255, 0.04);
      --tg-surface-strong: rgba(255, 255, 255, 0.08);
      --tg-border: rgba(255, 255, 255, 0.1);
      --tg-text: #ffffff;
      --tg-muted: rgba(160, 175, 190, 0.6);
      --tg-primary: #17c3b2; /* Radiant Teal */
      --tg-primary-glow: rgba(23, 195, 178, 0.4);
      --tg-danger: #ff003c; /* Neon Red Rebuttal */
      --tg-danger-glow: rgba(255, 0, 60, 0.4);
      --tg-warning: #fbbf24;
      
      position: fixed !important;
      top: 0 !important;
      right: 0 !important;
      width: ${SIDEBAR_WIDTH}px;
      height: 100vh;
      background: var(--tg-bg); 
      backdrop-filter: blur(24px);
      color: var(--tg-text);
      z-index: 2147483647 !important;
      font-family: 'Space Grotesk', -apple-system, sans-serif;
      box-shadow: -10px 0 60px rgba(0, 0, 0, 0.9);
      overflow-y: auto;
      transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
      border-left: 1px solid var(--tg-border);
    }
    #tiltcheck-sidebar.minimized { transform: translateX(${SIDEBAR_WIDTH - MINIMIZED_WIDTH}px); width: ${MINIMIZED_WIDTH}px; }
    #tiltcheck-sidebar::-webkit-scrollbar { width: 6px; }
    #tiltcheck-sidebar::-webkit-scrollbar-track { background: transparent; }
    #tiltcheck-sidebar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.2); border-radius: 3px; }
    
    .tg-header {
      padding: 0.75rem 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
      min-height: 56px;
      border-bottom: 1px solid transparent;
      position: sticky;
      top: 0;
      background: rgba(6, 8, 11, 0.97);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      box-shadow: 0 1px 24px rgba(0, 0, 0, 0.5), 0 0 1px rgba(23, 195, 178, 0.08);
      border-bottom-color: rgba(23, 195, 178, 0.12);
      z-index: 100;
    }
    .tg-header-brand {
      display: flex;
      align-items: center;
      gap: 0.625rem;
      min-width: 0;
    }
    .tg-logo-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border: 1px solid rgba(23, 195, 178, 0.25);
      background: rgba(23, 195, 178, 0.06);
      border-radius: 4px;
      flex: 0 0 auto;
    }
    .tg-logo-mark {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100%;
      font-weight: 900;
      font-size: 12px;
      color: #fff;
    }
    .tg-logo-copy {
      display: flex;
      flex-direction: column;
      min-width: 0;
    }
    .tg-logo-text {
      color: #fff;
      font-family: 'JetBrains Mono', monospace;
      font-size: 0.8rem;
      font-weight: 900;
      letter-spacing: 0.12em;
      line-height: 1;
    }
    .tg-logo-sub {
      margin-top: 0.15rem;
      color: rgba(160, 175, 190, 0.78);
      font-size: 0.62rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      white-space: nowrap;
    }
    .tg-header-actions { display: flex; gap: 6px; align-items: center; }
    .tg-header-btn {
      background: none;
      border: 1px solid rgba(23, 195, 178, 0.2);
      color: var(--tg-primary);
      width: 32px;
      height: 32px;
      border-radius: 4px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      transition: all 0.2s cubic-bezier(0.23, 1, 0.32, 1);
      line-height: 1;
    }
    .tg-header-btn:hover { 
      background: rgba(23, 195, 178, 0.08);
      border-color: rgba(23, 195, 178, 0.4);
    }
    #tiltcheck-sidebar:not(.tg-show-advanced) .tg-advanced-only { display: none !important; }
    
    .tg-content { padding: 12px; }
    .tg-section { 
      margin-bottom: 16px; 
      padding: 16px; 
      background: var(--tg-surface); 
      border-radius: 16px; 
      border: 1px solid var(--tg-border); 
      transition: border-color 0.2s;
    }
    .tg-section:hover { border-color: rgba(255, 255, 255, 0.15); }
    .tg-section h4 { 
      margin: 0 0 12px 0; 
      font-family: 'Space Grotesk', sans-serif;
      font-size: 11px; 
      font-weight: 700; 
      color: var(--tg-muted); 
      text-transform: uppercase; 
      letter-spacing: 0.1em; 
    }
    .tg-emergency { border: 1px solid rgba(239, 68, 68, 0.35); background: rgba(239, 68, 68, 0.08); }
    .tg-emergency-header { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .tg-emergency-title { font-weight: 700; font-size: 13px; }
    .tg-emergency-sub { font-size: 11px; opacity: 0.7; margin-top: 2px; }
    
    .tg-auth-prompt { text-align: center; padding: 40px 20px; }
    .tg-auth-prompt h3 { font-size: 18px; margin-bottom: 8px; font-weight: 600; }
    .tg-auth-prompt p { font-size: 13px; opacity: 0.8; margin-bottom: 16px; line-height: 1.45; }
    .tg-auth-divider { margin: 14px 0; text-align: center; opacity: 0.4; font-size: 12px; }
    
    .tg-user-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 16px;
      background: rgba(255, 255, 255, 0.03);
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      margin-bottom: 12px;
    }
    .tg-account-strip {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin: -6px 0 12px;
      padding: 8px 10px;
      background: rgba(0, 168, 255, 0.1);
      border: 1px solid rgba(0, 168, 255, 0.3);
      border-radius: 10px;
      font-size: 11px;
      line-height: 1.35;
    }
    .tg-focus-note {
      margin: -4px 0 12px;
      padding: 8px 10px;
      font-size: 11px;
      opacity: 0.78;
      border-left: 2px solid rgba(0, 212, 170, 0.6);
      background: rgba(0, 212, 170, 0.08);
      border-radius: 0 8px 8px 0;
    }
    .tg-user-info { display: flex; gap: 8px; align-items: center; font-size: 13px; }
    .tg-tier { padding: 2px 8px; background: rgba(168, 85, 247, 0.2); border-radius: 3px; font-size: 11px; color: #c4b5fd; }
    .tg-btn-icon {
      background: transparent;
      border: none;
      color: rgba(255, 255, 255, 0.5);
      font-size: 20px;
      cursor: pointer;
      width: 24px;
      height: 24px;
      padding: 0;
      line-height: 1;
    }
    .tg-btn-icon:hover { color: rgba(255, 255, 255, 0.8); }
    
    .tg-settings-panel {
      background: rgba(255, 255, 255, 0.03);
      backdrop-filter: blur(10px);
      padding: 16px;
      margin-bottom: 12px;
      border-radius: 12px;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .tg-settings-panel h4 { margin: 0 0 12px 0; font-size: 13px; }
    .tg-input-group { margin-bottom: 12px; }
    .tg-input-group label { display: block; font-size: 12px; margin-bottom: 4px; opacity: 0.7; }
    .tg-input-group input {
      width: 100%;
      padding: 8px;
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      color: #e1e8ed;
      font-size: 12px;
    }
    .tg-input-group input:focus { outline: none; border-color: var(--tg-primary); }
    
    .tg-metrics-card {
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid var(--tg-border);
      border-radius: 20px;
      padding: 24px;
      margin-bottom: 24px;
      position: relative;
      overflow: hidden;
    }
    @keyframes gradientBG {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    .tg-metrics-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }
    .tg-session-site { 
      font-size: 10px; 
      opacity: 0.5; 
      margin-top: 4px; 
      text-transform: uppercase; 
      letter-spacing: 0.05em;
    }
    .tg-metric-value {
      font-family: 'JetBrains Mono', monospace;
      font-size: 18px;
      font-weight: 700;
      font-variant-numeric: tabular-nums;
    }
    .tg-tilt-value { color: var(--tg-primary); }
    .tg-tilt-value.warning { color: var(--tg-warning); }
    .tg-tilt-value.critical { color: var(--tg-danger); }
    
    .tg-graph {
      background: rgba(0, 0, 0, 0.2);
      border-radius: 4px;
      padding: 10px;
      height: 130px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .tg-feed {
      max-height: 148px;
      overflow-y: auto;
      font-size: 12px;
    }
    .tg-feed-item {
      padding: 8px 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      opacity: 0.7;
    }
    .tg-feed-item:last-child { border-bottom: none; }
    
    .tg-action-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
    }
    .tg-advanced-toggle {
      margin-top: 0;
      margin-bottom: 8px;
      font-size: 11px;
      padding: 8px 10px;
    }
    .tg-action-btn {
      background: var(--tg-surface);
      border: 1px solid var(--tg-border);
      color: var(--tg-text);
      padding: 10px;
      border-radius: 10px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
      transition: all 0.15s;
      text-align: left;
    }
    .tg-action-btn:hover { background: var(--tg-surface-strong); border-color: var(--tg-primary); transform: translateY(-1px); }
    .tg-runtime-control {
      margin-top: 10px;
      padding-top: 10px;
      border-top: 1px solid var(--tg-border);
    }
    .tg-runtime-note {
      margin-top: 6px;
      color: var(--tg-muted);
      font-size: 10px;
      line-height: 1.4;
    }
    
    .tg-vault-amount {
      font-size: 24px;
      font-weight: 700;
      color: var(--tg-primary);
      margin-bottom: 12px;
      font-variant-numeric: tabular-nums;
    }
    .tg-goal-progress { margin-bottom: 10px; }
    .tg-goal-label { font-size: 11px; opacity: 0.7; margin-bottom: 6px; }
    .tg-goal-bar { height: 6px; background: rgba(255,255,255,0.08); border-radius: 999px; overflow: hidden; }
    .tg-goal-fill { height: 100%; background: linear-gradient(90deg, #22c55e, #10b981); width: 0%; transition: width 0.4s ease; }
    .tg-goal-meta { font-size: 10px; opacity: 0.6; margin-top: 4px; }
    .tg-vault-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    
    .tg-btn {
      width: 100%;
      padding: 10px;
      margin-top: 6px;
      border: none;
      border-radius: 10px;
      color: white;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.15s;
      font-size: 13px;
    }
    .tg-btn-inline {
      width: auto;
      margin-top: 0;
      padding: 6px 10px;
      font-size: 11px;
      white-space: nowrap;
    }
    .tg-btn-primary { background: var(--tg-primary); color: #000; }
    .tg-btn-primary:hover { background: #00b390; }
    .tg-btn-secondary { background: var(--tg-surface); border: 1px solid var(--tg-border); }
    .tg-btn-secondary:hover { background: var(--tg-surface-strong); border-color: var(--tg-secondary); }
    .tg-btn-vault { background: var(--tg-primary); color: #000; font-weight: 700; }
    .tg-btn-vault:hover { background: #00b390; }
    .tg-btn-danger { background: var(--tg-danger); }
    .tg-btn-danger:hover { background: #dc2626; }
    #tg-discord-login, #tg-connect-discord-inline { background: var(--tg-accent); border: 1px solid rgba(255,255,255,0.12); color: #fff;}
    #tg-discord-login:hover, #tg-connect-discord-inline:hover { background: #9333ea; }
    .tg-toast {
      position: fixed;
      right: 16px;
      bottom: 16px;
      background: rgba(255, 255, 255, 0.06);
      backdrop-filter: blur(10px);
      color: var(--tg-text);
      border: 1px solid rgba(255,255,255,0.12);
      border-left: 3px solid var(--tg-accent);
      padding: 10px 12px;
      border-radius: 10px;
      font-size: 12px;
      max-width: 260px;
      z-index: 2147483647;
      box-shadow: 0 6px 20px rgba(0,0,0,0.35);
      animation: toastIn 0.2s ease;
    }
    @keyframes toastIn {
      from { transform: translateY(6px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    #tiltcheck-sidebar.tilt-warn {
      box-shadow: -2px 0 12px rgba(245, 158, 11, 0.35);
      border-left-color: var(--tg-warning);
      animation: pulseBorder 2.2s ease-in-out infinite;
    }
    #tiltcheck-sidebar.tilt-critical {
      background: rgba(127, 29, 29, 0.85);
      box-shadow: -2px 0 16px rgba(239, 68, 68, 0.45);
      border-left-color: var(--tg-danger);
    }
    #tiltcheck-sidebar.tilt-critical .tg-emergency { border-color: var(--tg-danger); }
    #tiltcheck-sidebar.tilt-critical #tg-emergency-lock { animation: shake 0.6s ease-in-out infinite; }
    @keyframes pulseBorder {
      0% { border-left-color: rgba(245, 158, 11, 0.3); box-shadow: -2px 0 8px rgba(245, 158, 11, 0.15); }
      50% { border-left-color: rgba(245, 158, 11, 0.75); box-shadow: -2px 0 14px rgba(245, 158, 11, 0.35); }
      100% { border-left-color: rgba(245, 158, 11, 0.3); box-shadow: -2px 0 8px rgba(245, 158, 11, 0.15); }
    }
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-2px); }
      75% { transform: translateX(2px); }
    }
    .tg-tabs { display: flex; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 12px; }
    .tg-tab { flex: 1; background: none; border: none; color: rgba(255,255,255,0.5); padding: 8px; cursor: pointer; border-bottom: 2px solid transparent; font-size: 12px; font-weight: 600; }
    .tg-tab.active { color: #fff; border-bottom-color: var(--tg-secondary); }
    .tg-history-item { padding: 8px; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 11px; background: rgba(255,255,255,0.02); margin-bottom: 4px; border-radius: 4px; }
    .tg-history-header { display: flex; justify-content: space-between; margin-bottom: 4px; opacity: 0.7; }
    .tg-history-result { font-weight: bold; color: var(--tg-primary); }
    .tg-license-strip {
      padding: 8px 12px;
      font-size: 11px;
      font-weight: 600;
      text-align: center;
      border-bottom: 1px solid rgba(255,255,255,0.1);
      background: rgba(0, 168, 255, 0.1);
      color: #7dd3fc;
    }
    .tg-license-strip.verified { background: rgba(16, 185, 129, 0.18); color: #6ee7b7; }
    .tg-license-strip.warning { background: rgba(245, 158, 11, 0.18); color: #fcd34d; }
    .tg-license-strip.risk { background: rgba(239, 68, 68, 0.18); color: #fca5a5; }
    .tg-license-strip.pending { background: rgba(0, 168, 255, 0.1); color: #7dd3fc; }
    .tg-license-detail {
      padding: 7px 12px;
      border-bottom: 1px solid rgba(255,255,255,0.08);
      background: rgba(0,0,0,0.22);
      color: rgba(226,232,240,0.74);
      font-size: 10px;
      line-height: 1.4;
      text-align: center;
    }
    .tg-status-bar { padding: 8px 12px; font-size: 11px; font-weight: 600; text-align: center; animation: slideDown 0.3s ease; }
    .tg-status-bar.thinking { background: rgba(59, 130, 246, 0.2); color: #60a5fa; border-bottom: 1px solid rgba(59, 130, 246, 0.3); }
    .tg-status-bar.success { background: rgba(34, 211, 166, 0.2); color: #34d399; border-bottom: 1px solid rgba(34, 211, 166, 0.3); }
    .tg-status-bar.warning { background: rgba(245, 158, 11, 0.2); color: #fcd34d; border-bottom: 1px solid rgba(245, 158, 11, 0.3); }
    .tg-status-bar.danger { background: rgba(239, 68, 68, 0.2); color: #f87171; border-bottom: 1px solid rgba(239, 68, 68, 0.3); }
    .tg-status-bar.buddy { background: rgba(168, 85, 247, 0.2); color: #c084fc; border-bottom: 1px solid rgba(168, 85, 247, 0.3); }
    .tg-vault-timeline { max-height: 180px; overflow-y: auto; display: flex; flex-direction: column; gap: 6px; }
    .tg-vault-timeline-item {
      font-size: 11px;
      line-height: 1.35;
      padding: 8px;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.04);
      border: 1px solid rgba(255, 255, 255, 0.08);
    }
    .tg-vault-timeline-row { display: flex; justify-content: space-between; gap: 8px; }
    .tg-vault-timeline-action { font-weight: 600; color: #fbbf24; }
    .tg-vault-timeline-time { opacity: 0.7; font-size: 10px; white-space: nowrap; }
    .tg-vault-timeline-meta { opacity: 0.75; margin-top: 2px; font-size: 10px; }
    .tg-vault-timeline-empty { opacity: 0.6; font-size: 11px; padding: 8px; background: rgba(255,255,255,0.03); border-radius: 6px; }
    .tg-brand-footer {
      margin: 2px 0 16px;
      text-align: center;
      font-size: 10px;
      letter-spacing: 0.08em;
      color: var(--tg-muted);
      opacity: 0.75;
    }
    @keyframes slideDown { from { transform: translateY(-100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .nonce-flash { animation: flashGreen 1s ease; }
    @keyframes flashGreen {
      0% { background-color: rgba(16, 185, 129, 0.5); }
      100% { background-color: rgba(0, 0, 0, 0.3); }
    }

    /* Predictor Styles */
    .predictor-card {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      padding: 12px;
      margin-bottom: 10px;
      position: relative;
      overflow: hidden;
      transition: all 0.3s ease;
    }
    .predictor-card.critical {
      border-color: var(--tg-primary);
      background: rgba(0, 212, 170, 0.05);
    }
    .predictor-card .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .source-tag {
      font-size: 9px;
      font-weight: 800;
      padding: 2px 6px;
      border-radius: 4px;
      color: #fff;
    }
    .tag-instagram { background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); }
    .tag-x { background: #000; border: 1px solid rgba(255,255,255,0.2); }
    .tag-telegram { background: #0088cc; }
    .confidence-tag { font-size: 10px; opacity: 0.6; }
    .drop-label { font-size: 13px; font-weight: 600; margin-bottom: 4px; }
    .drop-timer { font-size: 18px; font-weight: 700; font-variant-numeric: tabular-nums; color: var(--tg-primary); }
    .critical-glow {
      position: absolute;
      top: 0; left: 0; width: 100%; height: 100%;
      background: radial-gradient(circle at center, rgba(0, 212, 170, 0.15) 0%, transparent 70%);
      animation: pulseGlow 2s infinite;
      pointer-events: none;
    }
    @keyframes pulseGlow {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 0.8; }
    }

    /* Onboarding Styles */
    #onboarding-overlay {
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      background: radial-gradient(circle var(--spot-r) at var(--spot-x) var(--spot-y), transparent 99%, rgba(0,0,0,0.85) 100%);
      z-index: 2147483647;
      display: none;
      pointer-events: none;
    }
    #onboarding-overlay.active { display: block; pointer-events: all; }
    .onboarding-tooltip {
      position: absolute;
      width: 240px;
      background: #1a1a1a;
      border: 1px solid var(--tg-primary);
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
      color: #fff;
      pointer-events: all;
      animation: tooltipPop 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    @keyframes tooltipPop {
      from { transform: scale(0.9) translateY(10px); opacity: 0; }
      to { transform: scale(1) translateY(0); opacity: 1; }
    }
    .tooltip-title { font-size: 14px; font-weight: 700; margin-bottom: 8px; color: var(--tg-primary); }
    .tooltip-body { font-size: 12px; line-height: 1.5; margin-bottom: 12px; opacity: 0.9; }
    .tooltip-footer { display: flex; justify-content: space-between; align-items: center; }
    .tooltip-progress { font-size: 11px; opacity: 0.5; }
    .tooltip-actions { display: flex; gap: 8px; }
    .tooltip-btn {
      background: var(--tg-surface);
      border: 1px solid rgba(255,255,255,0.1);
      color: #fff;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      cursor: pointer;
    }
    .tooltip-btn.primary { background: var(--tg-primary); color: #000; font-weight: 700; border: none; }

    /* Vibe Check Overlay */
    #tg-vibe-check-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.95);
      z-index: 2147483647;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px;
      text-align: center;
      color: #fff;
      font-family: 'JetBrains Mono', monospace;
      animation: fadeIn 0.4s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    
    #tg-vibe-check-overlay h2 {
      font-family: 'Space Grotesk', sans-serif;
      font-size: 32px;
      color: #ff3366;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 15px;
      text-shadow: 0 0 20px rgba(255, 51, 102, 0.4);
    }
    
    .vibe-check-gif-container {
      width: 280px;
      height: 280px;
      background: #111;
      margin-bottom: 30px;
      border: 3px solid #ff3366;
      box-shadow: 0 0 40px rgba(255, 51, 102, 0.2);
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      border-radius: 20px;
      transform: rotate(-2deg);
    }
    
    .tg-btn-outline {
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #fff;
    }
    .tg-btn-outline:hover {
      background: rgba(255, 255, 255, 0.05);
      border-color: #fff;
    }

    /* Toggle Switch Styles */
    .tg-toggle-wrapper {
      position: relative;
      width: 44px;
      height: 22px;
    }
    .tg-toggle-input {
      opacity: 0;
      width: 0;
      height: 0;
    }
    .tg-toggle-label {
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background-color: var(--tg-surface-strong);
      border: 1px solid var(--tg-border);
      border-radius: 22px;
      cursor: pointer;
      transition: .3s;
    }
    .tg-toggle-label:before {
      position: absolute;
      content: "";
      height: 14px;
      width: 14px;
      left: 3px;
      bottom: 3px;
      background-color: var(--tg-muted);
      border-radius: 50%;
      transition: .3s;
    }
    .tg-toggle-input:checked + .tg-toggle-label {
      background-color: var(--tg-primary);
      border-color: var(--tg-primary);
    }
    /* HUD Typography & Spacing */
    .tg-hud-label {
      font-size: 10px;
      font-weight: 700;
      color: var(--tg-primary);
      text-transform: uppercase;
      letter-spacing: 0.2em;
      margin: 0 0 4px 0;
    }
    .tg-hud-title {
      font-size: 1.4rem;
      font-weight: 800;
      line-height: 1.1;
      margin: 0;
      letter-spacing: -0.02em;
    }
    .tg-metric-stack {
      margin-top: 24px;
      padding: 0;
    }
    .tg-drift-main {
      display: flex;
      flex-direction: column;
      margin-top: 8px;
    }
    .tg-drift-value {
      font-size: 3.5rem;
      font-weight: 900;
      color: var(--tg-primary);
      line-height: 0.9;
      letter-spacing: -0.04em;
      font-family: 'Space Grotesk', sans-serif;
      /* Subtle surgical glow */
      text-shadow: 0 0 20px var(--tg-primary-glow);
    }
    .tg-drift-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--tg-primary);
      opacity: 0.8;
      margin-top: 4px;
      letter-spacing: 0.1em;
    }
    .tg-metric-label {
      font-size: 10px;
      font-weight: 600;
      color: var(--tg-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .tg-metric-value {
      font-family: 'JetBrains Mono', monospace;
      font-size: 14px;
      font-weight: 700;
      margin-top: 2px;
    }
    .tg-metrics-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    /* Daily Bonuses Section */
    .tg-bonuses-section { padding: 14px 16px; }
    .tg-bonuses-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0;
    }
    .tg-bonuses-controls { display: flex; gap: 6px; align-items: center; }
    .tg-btn-link {
      background: none;
      border: none;
      color: var(--tg-primary);
      font-size: 10px;
      font-weight: 700;
      cursor: pointer;
      padding: 0;
      font-family: 'JetBrains Mono', monospace;
      letter-spacing: 0.03em;
      opacity: 0.85;
      transition: opacity 0.15s;
    }
    .tg-btn-link:hover { opacity: 1; text-decoration: underline; }
    #tg-bonuses-body { margin-top: 12px; }
    .tg-bonus-item {
      padding: 10px 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
    }
    .tg-bonus-item:last-child { border-bottom: none; }
    .tg-bonus-brand {
      font-size: 12px;
      font-weight: 700;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 2px;
    }
    .tg-bonus-desc {
      font-size: 11px;
      color: var(--tg-muted);
      line-height: 1.4;
      margin-bottom: 4px;
    }
    .tg-bonus-code {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 700;
      color: var(--tg-warning);
      margin-bottom: 4px;
      letter-spacing: 0.04em;
    }
    .tg-bonus-claim {
      display: inline-block;
      font-size: 10px;
      font-weight: 700;
      color: var(--tg-primary);
      text-decoration: none;
      font-family: 'JetBrains Mono', monospace;
      letter-spacing: 0.03em;
      transition: opacity 0.15s;
    }
    .tg-bonus-claim:hover { opacity: 0.75; text-decoration: underline; }
    .tg-bonus-claim-blocked {
      color: var(--tg-warning);
      cursor: default;
      text-decoration: none;
      opacity: 0.75;
    }
    .tg-bonus-empty {
      font-size: 11px;
      color: var(--tg-muted);
      padding: 8px 0;
    }
    .tg-bonuses-footer {
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid rgba(255, 255, 255, 0.07);
      text-align: right;
    }
    .tg-bonuses-viewall {
      font-size: 10px;
      color: var(--tg-muted);
      text-decoration: none;
      letter-spacing: 0.03em;
      transition: color 0.15s;
    }
    .tg-bonuses-viewall:hover { color: var(--tg-primary); }
`;

// src/sidebar/auth.ts
var AuthManager = class {
  ui;
  discordAuthPollIntervalId = null;
  authToken = null;
  userData = null;
  isAuthenticated = false;
  isConnecting = false;
  demoMode = false;
  constructor(ui) {
    this.ui = ui;
  }
  clearDiscordAuthPolling() {
    if (this.discordAuthPollIntervalId) {
      clearInterval(this.discordAuthPollIntervalId);
      this.discordAuthPollIntervalId = null;
    }
  }
  clearDiscordOauthErrorMarkers() {
    try {
      chrome.storage.local.remove(
        ["discord_oauth_error", "discord_oauth_error_code", "discord_oauth_error_ts"],
        () => {
        }
      );
    } catch {
    }
  }
  normalizeUserData(user) {
    const rawId = typeof user.id === "string" ? user.id : typeof user.userId === "string" ? user.userId : null;
    if (!rawId) {
      return null;
    }
    const email = typeof user.email === "string" ? user.email : null;
    const discordId = typeof user.discordId === "string" ? user.discordId : null;
    const discordUsername = typeof user.discordUsername === "string" ? user.discordUsername : null;
    const walletAddress = typeof user.walletAddress === "string" ? user.walletAddress : typeof user.wallet_address === "string" ? user.wallet_address : null;
    const usernameCandidate = typeof user.username === "string" ? user.username.trim() : "";
    const username = usernameCandidate || discordUsername || email || rawId.slice(0, 10);
    return {
      id: rawId,
      username,
      email,
      discordId,
      discordUsername,
      walletAddress
    };
  }
  async persistAuthState(token, user) {
    await this.ui.setStorage({
      authToken: token,
      userData: user,
      tiltguard_user_id: user.id
    });
  }
  async clearStoredAuthState() {
    await this.ui.setStorage({
      authToken: null,
      userData: null,
      tiltguard_user_id: null
    });
  }
  resetToGuestMode() {
    this.clearDiscordAuthPolling();
    this.authToken = null;
    this.userData = null;
    this.isAuthenticated = false;
    this.isConnecting = false;
    this.demoMode = true;
  }
  stopConnecting(message) {
    this.clearDiscordAuthPolling();
    this.isConnecting = false;
    this.ui.syncAccountUi();
    this.ui.addFeedMessage(message);
  }
  async fetchCurrentSession(token) {
    try {
      const response = await fetch(`${API_BASE}/auth/me`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`
        },
        credentials: "include"
      });
      if (!response.ok) {
        return null;
      }
      const data = await response.json();
      return this.normalizeUserData(data);
    } catch (error) {
      console.warn("[TiltCheck] Failed to verify stored auth session:", error);
      return null;
    }
  }
  async applyDiscordAuthSuccess(token, user) {
    const normalizedUser = this.normalizeUserData(user);
    if (!normalizedUser) {
      throw new Error("Discord auth payload missing user id");
    }
    this.clearDiscordAuthPolling();
    this.clearDiscordOauthErrorMarkers();
    this.isConnecting = false;
    await this.persistAuthState(token, normalizedUser);
    await this.syncSafetyPreferences(token);
    this.demoMode = false;
    this.authToken = token;
    this.userData = { ...normalizedUser, isDemo: false };
    this.isAuthenticated = true;
    this.ui.showMainContent();
    this.ui.syncAccountUi();
    this.ui.addFeedMessage(`Connected: ${this.userData.username || "TiltCheck user"}`);
  }
  handleDiscordAuthMessage(_event) {
  }
  startDiscordLoginFlow() {
    const authUrl = getDiscordLoginUrl("extension");
    const maxPollMs = 5 * 60 * 1e3;
    const startedAt = Date.now();
    this.clearDiscordAuthPolling();
    this.clearDiscordOauthErrorMarkers();
    this.isConnecting = true;
    this.ui.syncAccountUi();
    const startStoragePolling = () => {
      this.discordAuthPollIntervalId = setInterval(async () => {
        try {
          const stored = await this.ui.getStorage(["authToken", "userData", "discord_oauth_error"]);
          if (typeof stored?.discord_oauth_error === "string" && stored.discord_oauth_error.trim()) {
            const msg = stored.discord_oauth_error.trim().slice(0, 500);
            this.clearDiscordOauthErrorMarkers();
            this.stopConnecting(msg);
            return;
          }
          if (stored?.authToken && stored?.userData) {
            await this.applyDiscordAuthSuccess(stored.authToken, stored.userData);
            return;
          }
          if (Date.now() - startedAt > maxPollMs) {
            this.stopConnecting("Discord connect timed out. Try again.");
          }
        } catch (error) {
          console.warn("[TiltCheck] Discord connect polling failed:", error);
          this.stopConnecting("Discord connect interrupted. Reload the tab and try again.");
        }
      }, 500);
    };
    try {
      chrome.runtime.sendMessage({ type: "open_auth_bridge", url: authUrl }, (response) => {
        if (chrome.runtime.lastError) {
          const msg = chrome.runtime.lastError.message || "Could not open Discord login tab.";
          this.stopConnecting(
            msg.includes("Extension context invalidated") ? "Extension refreshed mid-login. Reload this tab and retry Connect Discord." : "Could not open Discord login helper. Try again."
          );
          return;
        }
        if (response?.success) {
          this.ui.addFeedMessage(`Opened Discord login helper tab.`);
          startStoragePolling();
        } else {
          this.stopConnecting("Discord login tab could not be opened. Double check popup blockers.");
        }
      });
    } catch (err) {
      console.error("[TiltCheck] startDiscordLoginFlow error:", err);
      this.stopConnecting("Discord login flow failed. Reload and try again.");
    }
  }
  async logout() {
    let serverLogoutFailed = false;
    try {
      const response = await fetch(`${API_BASE}/auth/logout`, {
        method: "POST",
        credentials: "include",
        headers: this.authToken ? { Authorization: `Bearer ${this.authToken}` } : {}
      });
      if (!response.ok) {
        serverLogoutFailed = true;
        console.warn("[TiltCheck] Shared session logout failed:", response.status);
      }
    } catch (error) {
      serverLogoutFailed = true;
      console.warn("[TiltCheck] Shared session logout request failed:", error);
    }
    await this.clearStoredAuthState();
    this.resetToGuestMode();
    this.ui.syncAccountUi();
    this.ui.addFeedMessage(
      serverLogoutFailed ? "Logged out locally. Shared session may still be active." : "Logged out successfully."
    );
  }
  continueAsGuest() {
    this.demoMode = true;
    this.isAuthenticated = false;
    this.ui.showMainContent();
    this.ui.syncAccountUi();
    this.ui.addFeedMessage("Continuing in Guest mode. Discord features (Buddy Mirror, Global Leaderboard) disabled.");
  }
  async restoreAuth() {
    const stored = await this.ui.getStorage(["authToken", "userData"]);
    if (typeof stored?.authToken === "string" && stored.authToken) {
      const sessionUser = await this.fetchCurrentSession(stored.authToken);
      if (!sessionUser) {
        await this.clearStoredAuthState();
        this.resetToGuestMode();
        this.ui.syncAccountUi();
        this.ui.addFeedMessage("Saved sign-in could not be verified. Connect Discord again.");
        return false;
      }
      await this.persistAuthState(stored.authToken, sessionUser);
      await this.syncSafetyPreferences(stored.authToken);
      this.clearDiscordAuthPolling();
      this.authToken = stored.authToken;
      this.userData = { ...sessionUser, isDemo: false };
      this.isAuthenticated = true;
      this.demoMode = false;
      this.ui.showMainContent();
      this.ui.syncAccountUi();
      return true;
    }
    this.resetToGuestMode();
    this.ui.syncAccountUi();
    return false;
  }
  async syncSafetyPreferences(token) {
    try {
      const response = await fetch(`${API_BASE}/me/settings`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`
        },
        credentials: "include"
      });
      if (!response.ok) {
        return;
      }
      const data = await response.json();
      const nextStorage = {};
      const etagHeader = response.headers.get("etag");
      if (etagHeader) {
        nextStorage.settingsEtag = etagHeader;
      } else if (typeof data.etag === "string" && data.etag) {
        nextStorage.settingsEtag = data.etag;
      }
      if (typeof data.settings?.limits?.cooldownEnabled === "boolean") {
        nextStorage.cooldownEnabled = data.settings.limits.cooldownEnabled;
      }
      if (typeof data.settings?.limits?.redeemThresholdUsd === "number" && Number.isFinite(data.settings.limits.redeemThresholdUsd)) {
        nextStorage.redeemThreshold = data.settings.limits.redeemThresholdUsd;
      }
      if (Object.keys(nextStorage).length > 0) {
        await this.ui.setStorage(nextStorage);
      }
    } catch (error) {
      console.warn("[TiltCheck] Failed to sync settings:", error);
    }
  }
  async patchSettings(token, patch) {
    try {
      const stored = await this.ui.getStorage(["settingsEtag"]);
      const ifMatch = typeof stored?.settingsEtag === "string" ? stored.settingsEtag : void 0;
      const response = await fetch(`${API_BASE}/me/settings`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          ...ifMatch ? { "If-Match": ifMatch } : {}
        },
        body: JSON.stringify(patch),
        credentials: "include"
      });
      if (response.status === 412) {
        await this.syncSafetyPreferences(token);
        return false;
      }
      if (!response.ok) {
        return false;
      }
      const nextEtag = response.headers.get("etag");
      if (nextEtag) {
        await this.ui.setStorage({ settingsEtag: nextEtag });
      }
      return true;
    } catch (error) {
      console.warn("[TiltCheck] Failed to patch settings:", error);
      return false;
    }
  }
};

// src/sidebar/session.ts
var SessionManager = class {
  ui;
  sessionStats = {
    startTime: Date.now(),
    totalBets: 0,
    totalWagered: 0,
    totalWon: 0,
    currentBalance: 0
  };
  lastProfit = 0;
  constructor(ui) {
    this.ui = ui;
  }
  resetStats() {
    this.sessionStats = {
      startTime: Date.now(),
      totalBets: 0,
      totalWagered: 0,
      totalWon: 0,
      currentBalance: 0
    };
    this.lastProfit = 0;
    this.updateStatsUi();
  }
  updateStats(params) {
    Object.assign(this.sessionStats, params);
    this.updateStatsUi();
    this.drawPnlGraph();
  }
  updateStatsUi() {
    const betsEl = document.getElementById("tg-bets");
    const wageredEl = document.getElementById("tg-wagered");
    const profitEl = document.getElementById("tg-profit");
    const rtpEl = document.getElementById("tg-rtp");
    const profit = this.sessionStats.totalWon - this.sessionStats.totalWagered;
    const rtp = this.sessionStats.totalWagered > 0 ? this.sessionStats.totalWon / this.sessionStats.totalWagered * 100 : 0;
    if (betsEl) betsEl.textContent = this.sessionStats.totalBets.toString();
    if (wageredEl) wageredEl.textContent = `$${this.sessionStats.totalWagered.toFixed(2)}`;
    if (profitEl) {
      profitEl.textContent = `${profit >= 0 ? "+" : ""}$${profit.toFixed(2)}`;
      profitEl.style.color = profit >= 0 ? "#10b981" : "#ef4444";
    }
    if (rtpEl) rtpEl.textContent = `${rtp.toFixed(1)}%`;
    this.updateDuration();
  }
  updateDuration() {
    const durationEl = document.getElementById("tg-duration");
    if (!durationEl) return;
    const diff = Math.floor((Date.now() - this.sessionStats.startTime) / 1e3);
    const mins = Math.floor(diff / 60);
    const secs = diff % 60;
    durationEl.textContent = `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  }
  drawPnlGraph() {
    const canvas = document.getElementById("pnl-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
  }
};

// src/autovault.ts
var DEFAULT_CONFIG = {
  saveAmount: 0.1,
  bigWinThreshold: 5,
  bigWinMultiplier: 3,
  checkInterval: 90
};
var MIN_BALANCE_CHECKS = 2;
var CURRENCY_CACHE_TIMEOUT = 5e3;
var BALANCE_INIT_RETRIES = 5;
var RATE_LIMIT_MAX = 50;
var RATE_LIMIT_WINDOW = 60 * 60 * 1e3;
var DEFAULT_CURRENCY = "bnb";
var DEFAULT_US_CURRENCY = "sc";
var BALANCE_SELECTORS = [
  '[data-testid="coin-toggle"] .content span[data-ds-text="true"]',
  '[data-testid="balance-toggle"] .content span[data-ds-text="true"]',
  '[data-testid="coin-toggle"] .content span',
  '[data-testid="balance-toggle"] span.content span',
  '[data-testid="user-balance"] .numeric',
  ".numeric.variant-highlighted",
  '[data-testid="user-balance"]',
  ".balance-value"
];
var FLAVOR = {
  profit: ["Positive difference,", "Profit detected"],
  bigWin: ["Big win detected", "Large profit"],
  deposit: ["Deposit detected"],
  start: ["AutoVault started", "Monitoring active"],
  stop: ["AutoVault stopped", "Monitoring paused"],
  rateLimit: [
    "Rate limited, vaulting paused. Please wait until it resets",
    "Limit reached, vaulting paused. Please wait until it resets"
  ]
};
function isStakeUS(hostname2) {
  return (hostname2 || window.location.hostname).toLowerCase().endsWith(".us");
}
function pickFlavor(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function getCookie(name) {
  const m = document.cookie.match("(^|;)\\s*" + name + "\\s*=\\s*([^;]+)");
  return m ? m.pop().replace(/"/g, "") : "";
}
function parseStakeAmount(text) {
  if (!text) return NaN;
  const raw = String(text).replace(/\u00a0/g, " ").trim();
  if (!raw) return NaN;
  if (/[•*]+/.test(raw)) return NaN;
  const m = raw.match(/[-+]?\d[\d\s,.'']*(?:[.,]\d+)?[kmbt]?/i);
  if (!m) return NaN;
  let token = m[0].trim();
  const suffixMatch = token.match(/[kmbt]$/i);
  const suffix = suffixMatch ? suffixMatch[0].toLowerCase() : "";
  token = token.replace(/[kmbt]$/i, "").trim();
  token = token.replace(/[\s'']/g, "");
  const hasDot = token.includes(".");
  const hasComma = token.includes(",");
  if (hasDot && hasComma) {
    if (token.lastIndexOf(".") > token.lastIndexOf(",")) {
      token = token.replace(/,/g, "");
    } else {
      token = token.replace(/\./g, "").replace(/,/g, ".");
    }
  } else if (hasComma && !hasDot) {
    const parts = token.split(",");
    if (parts.length === 2 && parts[1].length <= 2) token = `${parts[0]}.${parts[1]}`;
    else token = token.replace(/,/g, "");
  } else {
    token = token.replace(/,/g, "");
  }
  const n = parseFloat(token);
  if (isNaN(n)) return NaN;
  const mult = suffix === "k" ? 1e3 : suffix === "m" ? 1e6 : suffix === "b" ? 1e9 : suffix === "t" ? 1e12 : 1;
  return n * mult;
}
var StakeApi = class {
  apiUrl;
  headers;
  constructor() {
    this.apiUrl = window.location.origin + "/_api/graphql";
    const accessToken = getCookie("session");
    this.headers = {
      "content-type": "application/json",
      "x-access-token": accessToken,
      "x-language": "en"
    };
  }
  async call(body, opName) {
    const headers = { ...this.headers };
    if (opName) headers["x-operation-name"] = opName;
    try {
      const res = await fetch(this.apiUrl, {
        credentials: "include",
        headers,
        referrer: window.location.origin,
        body,
        method: "POST",
        mode: "cors",
        cache: "no-cache"
      });
      if (!res.ok) {
        return { error: true, status: res.status, message: res.statusText };
      }
      return res.json();
    } catch (e) {
      return { error: true, message: e.message, type: "network" };
    }
  }
  async getBalances() {
    const q = {
      query: `query UserBalances {
        user { id balances {
          available { amount currency }
          vault { amount currency }
        }}}`,
      variables: {}
    };
    return this.call(JSON.stringify(q), "UserBalances");
  }
  async depositToVault(currency, amount) {
    const q = {
      query: `mutation CreateVaultDeposit($currency: CurrencyEnum!, $amount: Float!) {
        createVaultDeposit(currency: $currency, amount: $amount) {
          id amount currency user {
            id balances {
              available { amount currency }
              vault { amount currency }
            }
          }
          __typename
        }
      }`,
      variables: { currency, amount }
    };
    return this.call(JSON.stringify(q), "CreateVaultDeposit");
  }
};
var currencyCache = null;
function detectCurrencyFromBalanceBar() {
  const el = document.querySelector('[data-testid="coin-toggle"]') || document.querySelector('[data-testid="balance-toggle"]');
  if (!el) return null;
  const txt = (el.textContent || "").trim();
  const m = txt.match(/\b[A-Z]{2,5}\b/);
  return m ? m[0].toLowerCase() : null;
}
function getCurrency() {
  const now = Date.now();
  if (currencyCache && now - currencyCache.time < CURRENCY_CACHE_TIMEOUT) {
    return currencyCache.value;
  }
  const el = document.querySelector("[data-active-currency]");
  if (el) {
    const c = el.getAttribute("data-active-currency");
    if (c) {
      currencyCache = { value: c.toLowerCase(), time: now };
      return currencyCache.value;
    }
  }
  const fromBar = detectCurrencyFromBalanceBar();
  if (fromBar) {
    currencyCache = { value: fromBar, time: now };
    return fromBar;
  }
  const defaultCurr = isStakeUS() ? DEFAULT_US_CURRENCY : DEFAULT_CURRENCY;
  currencyCache = { value: defaultCurr, time: now };
  return defaultCurr;
}
var apiBalanceCache = {};
var workingSelector = null;
var lastKnownBalance = 0;
var balanceWarned = false;
function getCurrentBalance(activeCurrency) {
  const curCode = activeCurrency.toLowerCase();
  const uiCode = (detectCurrencyFromBalanceBar() || "").toLowerCase();
  if (curCode && uiCode && uiCode !== curCode) {
    const apiVal = apiBalanceCache[curCode];
    if (typeof apiVal === "number" && apiVal >= 0) return apiVal;
  }
  for (const selector of BALANCE_SELECTORS) {
    try {
      const el = document.querySelector(selector);
      if (el) {
        const val = parseStakeAmount(el.textContent);
        if (!isNaN(val) && val >= 0) {
          if (workingSelector !== selector) {
            workingSelector = selector;
          }
          lastKnownBalance = val;
          return val;
        }
      }
    } catch {
    }
  }
  if (curCode) {
    const apiVal = apiBalanceCache[curCode];
    if (typeof apiVal === "number" && apiVal >= 0) return apiVal;
  }
  if (!balanceWarned) {
    balanceWarned = true;
  }
  return lastKnownBalance || 0;
}
function loadRateLimitData() {
  const saved = sessionStorage.getItem("autovault-ratelimit");
  if (saved) {
    try {
      const data = JSON.parse(saved);
      return data.filter((ts) => Date.now() - ts < RATE_LIMIT_WINDOW);
    } catch {
    }
  }
  return [];
}
function saveRateLimitData(timestamps) {
  sessionStorage.setItem("autovault-ratelimit", JSON.stringify(timestamps));
}
var AutoVaultEngine = class {
  config;
  callbacks;
  running = false;
  stakeApi = null;
  activeCurrency = "";
  oldBalance = 0;
  lastBalance = 0;
  isProcessing = false;
  isInitialized = false;
  balanceChecks = 0;
  lastDepositDetected = 0;
  lastDepositAmount = 0;
  lastVaultedDeposit = 0;
  vaultInterval = null;
  apiBalanceInterval = null;
  vaultCountInterval = null;
  vaultActionTimestamps = [];
  sessionVaulted = 0;
  constructor(callbacks) {
    this.callbacks = callbacks;
    this.config = { ...DEFAULT_CONFIG };
    this.loadConfig();
  }
  // --- Config persistence ---
  loadConfig() {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.get(["autovault-config"], (result) => {
        if (result["autovault-config"]) {
          try {
            const saved = result["autovault-config"];
            if (saved && typeof saved === "object" && !Array.isArray(saved)) {
              this.config = { ...DEFAULT_CONFIG, ...saved };
            }
          } catch {
          }
        }
      });
    } else {
      const saved = localStorage.getItem("autovault-config");
      if (saved) {
        try {
          this.config = { ...DEFAULT_CONFIG, ...JSON.parse(saved) };
        } catch {
        }
      }
    }
  }
  saveConfig() {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.set({ "autovault-config": this.config });
    } else {
      localStorage.setItem("autovault-config", JSON.stringify(this.config));
    }
  }
  // --- Session vaulted tracking ---
  sessionStorageKey() {
    return `autovault-vaulted-session:${this.activeCurrency}`;
  }
  loadSessionVaulted() {
    try {
      const raw = sessionStorage.getItem(this.sessionStorageKey());
      const v = parseFloat(raw || "0");
      this.sessionVaulted = !isNaN(v) && v >= 0 ? v : 0;
    } catch {
      this.sessionVaulted = 0;
    }
  }
  saveSessionVaulted() {
    try {
      sessionStorage.setItem(this.sessionStorageKey(), String(this.sessionVaulted));
    } catch {
    }
  }
  // --- Logging ---
  log(message, type = "info") {
    const entry = { time: /* @__PURE__ */ new Date(), message, type };
    this.callbacks.onLogEntry(entry);
  }
  // --- API balance polling ---
  async refreshApiBalance() {
    try {
      if (!this.stakeApi) this.stakeApi = new StakeApi();
      const cur = this.activeCurrency.toLowerCase();
      if (!cur) return;
      const resp = await this.stakeApi.getBalances();
      const balances = resp?.data?.user?.balances;
      if (!Array.isArray(balances)) return;
      const bal = balances.find((x) => x?.available?.currency?.toLowerCase() === cur);
      const amt = bal?.available?.amount;
      const n = typeof amt === "number" ? amt : parseFloat(amt);
      if (!isNaN(n) && n >= 0) {
        apiBalanceCache[cur] = n;
      }
    } catch {
    }
  }
  startApiBalancePolling() {
    if (this.apiBalanceInterval) clearInterval(this.apiBalanceInterval);
    this.apiBalanceInterval = setInterval(() => this.refreshApiBalance(), 5e3);
    this.refreshApiBalance();
  }
  stopApiBalancePolling() {
    if (this.apiBalanceInterval) clearInterval(this.apiBalanceInterval);
    this.apiBalanceInterval = null;
  }
  // --- Rate limiting ---
  canVaultNow() {
    const now = Date.now();
    this.vaultActionTimestamps = this.vaultActionTimestamps.filter((ts) => now - ts < RATE_LIMIT_WINDOW);
    saveRateLimitData(this.vaultActionTimestamps);
    return this.vaultActionTimestamps.length < RATE_LIMIT_MAX;
  }
  getVaultCountLastHour() {
    const now = Date.now();
    this.vaultActionTimestamps = this.vaultActionTimestamps.filter((ts) => now - ts < RATE_LIMIT_WINDOW);
    return this.vaultActionTimestamps.length;
  }
  // --- Currency change detection ---
  checkCurrencyChange() {
    currencyCache = null;
    const newCurrency = getCurrency();
    if (newCurrency !== this.activeCurrency) {
      this.log(`Currency changed: ${this.activeCurrency} \u2192 ${newCurrency}`, "info");
      this.activeCurrency = newCurrency;
      this.startApiBalancePolling();
      this.loadSessionVaulted();
      this.sessionVaulted = 0;
      this.saveSessionVaulted();
      this.isInitialized = false;
      this.balanceChecks = 0;
      this.updateCurrentBalance();
      this.callbacks.onVaultedUpdate(this.sessionVaulted, this.activeCurrency);
      return true;
    }
    return false;
  }
  // --- Balance tracking ---
  updateCurrentBalance() {
    const cur = getCurrentBalance(this.activeCurrency);
    if (cur > 0) {
      this.oldBalance = cur;
      if (!this.isInitialized && this.balanceChecks++ >= MIN_BALANCE_CHECKS) {
        this.isInitialized = true;
        this.log(`Initial balance: ${this.oldBalance.toFixed(8)} ${this.activeCurrency.toUpperCase()}`, "info");
      }
    }
  }
  initializeBalance() {
    this.updateCurrentBalance();
    let tries = 0;
    const intv = setInterval(() => {
      if (!this.running) {
        clearInterval(intv);
        return;
      }
      this.updateCurrentBalance();
      if (++tries >= BALANCE_INIT_RETRIES) {
        clearInterval(intv);
        if (this.oldBalance > 0) {
          this.isInitialized = true;
          this.log(`Initialized with starting balance: ${this.oldBalance.toFixed(8)} ${this.activeCurrency}`, "info");
        } else {
          const cur = getCurrentBalance(this.activeCurrency);
          if (cur > 0) {
            this.oldBalance = cur;
            this.isInitialized = true;
            this.log(`Last attempt balance: ${this.oldBalance.toFixed(8)} ${this.activeCurrency}`, "info");
          } else {
            this.log("Unable to detect starting balance", "warning");
          }
        }
      }
    }, 1e3);
  }
  // --- Deposit detection ---
  detectDepositEvent() {
    const possibleSelectors = [
      '[data-testid*="notification"]',
      '[class*="notification"]',
      '[class*="transaction"]',
      '[class*="history"]',
      '[class*="activity"]'
    ];
    for (const sel of possibleSelectors) {
      const nodes = document.querySelectorAll(sel);
      for (const node of nodes) {
        const txt = node.textContent || "";
        const lower = txt.toLowerCase();
        if (lower.includes("deposit") && /\d/.test(lower)) {
          const amt = parseStakeAmount(txt);
          if (!isNaN(amt) && amt > 0) {
            this.lastDepositDetected = Date.now();
            this.lastDepositAmount = amt;
            return amt;
          }
        }
      }
    }
    return 0;
  }
  // --- Vault deposit execution ---
  async processDeposit(amount, isBigWin) {
    if (amount < 1e-8 || this.isProcessing) return;
    if (!this.canVaultNow()) {
      this.log(pickFlavor(FLAVOR.rateLimit), "warning");
      this.callbacks.onVaultCountUpdate(this.getVaultCountLastHour(), RATE_LIMIT_MAX);
      return;
    }
    this.isProcessing = true;
    const pct = (this.config.saveAmount * (isBigWin ? this.config.bigWinMultiplier : 1) * 100).toFixed(0);
    const flavor = pickFlavor(isBigWin ? FLAVOR.bigWin : FLAVOR.profit);
    this.log(`${flavor} Vaulting ${pct}%: ${amount.toFixed(6)} ${this.activeCurrency.toUpperCase()}`, isBigWin ? "bigwin" : "profit");
    try {
      if (!this.stakeApi) this.stakeApi = new StakeApi();
      const resp = await this.stakeApi.depositToVault(this.activeCurrency, amount);
      this.isProcessing = false;
      if (resp?.data?.createVaultDeposit) {
        this.sessionVaulted += amount;
        this.saveSessionVaulted();
        this.vaultActionTimestamps.push(Date.now());
        saveRateLimitData(this.vaultActionTimestamps);
        this.oldBalance = getCurrentBalance(this.activeCurrency);
        this.callbacks.onVaultCountUpdate(this.getVaultCountLastHour(), RATE_LIMIT_MAX);
        this.callbacks.onVaultedUpdate(this.sessionVaulted, this.activeCurrency);
        this.log(`Secured ${amount.toFixed(6)} ${this.activeCurrency.toUpperCase()}`, "success");
      } else {
        this.log("Vault failed - may be rate limited", "error");
      }
    } catch (e) {
      this.isProcessing = false;
      this.log("Vault error: " + (e.message || "unknown"), "error");
    }
  }
  // --- Main balance check loop ---
  checkBalanceChanges() {
    if (this.checkCurrencyChange()) return;
    const cur = getCurrentBalance(this.activeCurrency);
    if (!this.isInitialized) {
      this.updateCurrentBalance();
      return;
    }
    const depositAmt = this.detectDepositEvent();
    if (depositAmt > 0) {
      if (cur - this.lastBalance >= depositAmt * 0.95 && this.lastVaultedDeposit !== depositAmt) {
        const toVault = depositAmt * this.config.saveAmount;
        this.log(`${pickFlavor(FLAVOR.deposit)} +${depositAmt.toFixed(4)} ${this.activeCurrency.toUpperCase()}`, "info");
        this.processDeposit(toVault, false);
        this.lastVaultedDeposit = depositAmt;
        this.oldBalance = cur;
      }
    } else if (cur > this.oldBalance) {
      const profit = cur - this.oldBalance;
      const isBig = cur > this.oldBalance * this.config.bigWinThreshold;
      const depAmt = profit * this.config.saveAmount * (isBig ? this.config.bigWinMultiplier : 1);
      this.processDeposit(depAmt, isBig);
      this.oldBalance = cur;
    } else if (cur < this.oldBalance) {
      this.oldBalance = cur;
    }
    this.lastBalance = cur;
    this.callbacks.onVaultCountUpdate(this.getVaultCountLastHour(), RATE_LIMIT_MAX);
  }
  // --- Public API ---
  start() {
    if (this.running) return;
    this.running = true;
    this.stakeApi = new StakeApi();
    this.activeCurrency = getCurrency();
    this.startApiBalancePolling();
    this.loadSessionVaulted();
    this.sessionVaulted = 0;
    this.saveSessionVaulted();
    this.oldBalance = 0;
    this.isProcessing = false;
    this.isInitialized = false;
    this.balanceChecks = 0;
    this.lastDepositDetected = 0;
    this.lastDepositAmount = 0;
    this.lastBalance = getCurrentBalance(this.activeCurrency);
    this.lastVaultedDeposit = 0;
    this.vaultActionTimestamps = loadRateLimitData();
    this.initializeBalance();
    this.vaultInterval = setInterval(() => this.checkBalanceChanges(), this.config.checkInterval * 1e3);
    this.vaultCountInterval = setInterval(() => {
      this.callbacks.onVaultCountUpdate(this.getVaultCountLastHour(), RATE_LIMIT_MAX);
    }, 1e4);
    this.callbacks.onRunningChange(true);
    this.callbacks.onVaultedUpdate(this.sessionVaulted, this.activeCurrency);
    this.callbacks.onVaultCountUpdate(this.getVaultCountLastHour(), RATE_LIMIT_MAX);
    this.log(pickFlavor(FLAVOR.start), "success");
    this.log(`Watching ${this.activeCurrency.toUpperCase()} on ${isStakeUS() ? "Stake.us" : "Stake.com"}`, "info");
  }
  stop() {
    if (!this.running) return;
    this.running = false;
    if (this.vaultInterval) clearInterval(this.vaultInterval);
    this.vaultInterval = null;
    if (this.vaultCountInterval) clearInterval(this.vaultCountInterval);
    this.vaultCountInterval = null;
    this.stopApiBalancePolling();
    this.callbacks.onRunningChange(false);
    this.log(pickFlavor(FLAVOR.stop), "info");
  }
  isRunning() {
    return this.running;
  }
  getConfig() {
    return { ...this.config };
  }
  setConfig(partial) {
    this.config = { ...this.config, ...partial };
    this.saveConfig();
    if (this.running && partial.checkInterval !== void 0) {
      this.stop();
      this.start();
    }
  }
  getSessionVaulted() {
    return this.sessionVaulted;
  }
  getActiveCurrency() {
    return this.activeCurrency || getCurrency();
  }
};

// src/sidebar/vault.ts
var VaultManager = class {
  controller;
  lockTimerInterval = null;
  autoVault = null;
  userId = null;
  constructor(controller) {
    this.controller = controller;
  }
  init() {
    this.userId = this.controller.auth.userData?.id || null;
    this.initAutoVault();
  }
  initAutoVault() {
    this.autoVault = new AutoVaultEngine({
      onLogEntry: (entry) => {
        this.controller.addFeedMessage(`[Vault] ${entry.message}`);
        if (entry.type === "error" || entry.type === "warning") {
          this.controller.updateStatus(entry.message, entry.type === "error" ? "danger" : "warning");
        }
      },
      onVaultCountUpdate: (count, max) => {
        if (count >= max) {
          this.controller.updateStatus("Vault rate limit reached inside Stake.", "warning");
        }
      },
      onVaultedUpdate: (amount, currency) => {
        const el = document.getElementById("tg-autovault-secured");
        if (el) el.textContent = `${amount.toFixed(6)} ${currency.toUpperCase()}`;
      },
      onRunningChange: (running) => {
        const toggle = document.getElementById("tg-autovault-toggle");
        const controls = document.getElementById("tg-autovault-controls");
        if (toggle) toggle.checked = running;
        if (controls) controls.style.display = running ? "block" : "none";
      }
    });
    const pctInput = document.getElementById("tg-autovault-pct");
    if (pctInput) {
      this.autoVault.setConfig({ saveAmount: parseInt(pctInput.value) / 100 });
    }
  }
  toggleAutoVault(enabled) {
    if (!this.autoVault) return;
    if (enabled) {
      this.autoVault.start();
    } else {
      this.autoVault.stop();
    }
  }
  setAutoVaultPct(pct) {
    if (this.autoVault) {
      this.autoVault.setConfig({ saveAmount: pct / 100 });
    }
  }
  async lockTheBag(_amount) {
    const userId = this.controller.auth.userData?.id;
    if (!userId) {
      this.controller.updateStatus("Connect Discord to use the Vault.", "warning");
      return;
    }
    this.controller.updateStatus("Opening vault controls...", "thinking");
    this.controller.addFeedMessage("EMERGENCY BRAKE: Opening vault dashboard to secure your bag.");
    chrome.runtime.sendMessage({ type: "open_vault" });
    setTimeout(() => {
      this.controller.updateStatus("Vault controls opened. Go secure the bag.", "success");
    }, 1e3);
  }
  async depositToVault(amount, userId) {
    if (!userId || !amount) return;
    try {
      this.controller.addFeedMessage(`Vaulted $${amount.toFixed(2)}`);
    } catch (err) {
      console.error("[VaultManager] deposit error:", err);
    }
  }
  async loadVaultBalance(userId) {
    if (!userId) return;
  }
  renderVaultTimeline(_locks) {
    const container = document.getElementById("tg-vault-timeline");
    if (!container) return;
  }
  startLockCountdown(_unlockTime, _startTime) {
    if (this.lockTimerInterval) clearInterval(this.lockTimerInterval);
  }
};

// src/sidebar/api.ts
async function apiCall(endpoint, options = {}, auth) {
  if (auth?.demoMode) {
    return mockApiCall(endpoint, options);
  }
  const headers = { "Content-Type": "application/json" };
  if (auth?.authToken) headers["Authorization"] = `Bearer ${auth.authToken}`;
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers: { ...headers, ...options.headers }
    });
    return await response.json();
  } catch (error) {
    console.error("API Error:", error);
    return { error: "Network issue. Try again." };
  }
}
function mockApiCall(endpoint, _options = {}) {
  const now = Date.now();
  if (endpoint.startsWith("/security/scan-url")) {
    return {
      success: true,
      scan: {
        isSafe: true,
        trustScore: 92,
        details: "Mock demo result: no obvious risk indicators."
      }
    };
  }
  if (endpoint.startsWith("/safety/report")) {
    return { success: true, id: `demo-report-${now}` };
  }
  if (endpoint.startsWith("/safety/signals/recent")) {
    return {
      success: true,
      signals: [
        { type: "payout_change", casino: "stake.us", details: "Delayed payouts reported." },
        { type: "rtp_change", casino: "roobet.com", details: "RTP seems lower than usual." }
      ]
    };
  }
  if (endpoint.startsWith("/stats")) {
    return {
      ok: true,
      stats: {
        predictions: [
          { id: "m-1", source: "instagram", label: "IG Flash Code (Mock)", estimatedAt: now + 27e5, confidence: 0.85 },
          { id: "m-2", source: "telegram", label: "Telegram Rain (Mock)", estimatedAt: now + 3e5, confidence: 0.7 }
        ]
      }
    };
  }
  return { success: true };
}

// src/sidebar/reports.ts
var ReportManager = class {
  ui;
  auth;
  constructor(ui, auth) {
    this.ui = ui;
    this.auth = auth;
  }
  async submitReport(type, details, casino) {
    if (!details) {
      alert("Add a quick note first.");
      return;
    }
    this.ui.addFeedMessage("Sending signal...");
    try {
      const result = await apiCall("/safety/report", {
        method: "POST",
        body: JSON.stringify({ type, details, casino })
      }, this.auth);
      if (result.success) {
        this.ui.addFeedMessage(`Signal sent: ${type}`);
        const detailsEl = document.getElementById("report-details");
        if (detailsEl) detailsEl.value = "";
        const panel = document.getElementById("tg-report-panel");
        if (panel) panel.style.display = "none";
      } else {
        this.ui.addFeedMessage(`Signal failed: ${result.error || "Unknown error"}`);
      }
    } catch (err) {
      console.error("[ReportManager] submit error:", err);
      this.ui.addFeedMessage("Network issue. Try again later.");
    }
  }
  async fetchRecentSignals() {
    try {
      const result = await apiCall("/safety/signals/recent", {}, this.auth);
      if (result.success && Array.isArray(result.signals)) {
        result.signals.forEach((s) => {
          this.ui.addFeedMessage(`Signal: ${s.type} @ ${s.casino}`);
        });
      }
    } catch (err) {
      console.warn("[ReportManager] Could not fetch recent signals", err);
    }
  }
};

// src/sidebar/buddy.ts
var BuddyManager = class {
  ui;
  auth;
  mirrorEnabled = false;
  constructor(ui, auth) {
    this.ui = ui;
    this.auth = auth;
  }
  setMirrorEnabled(enabled) {
    this.mirrorEnabled = enabled;
    this.ui.setStorage({ buddyMirrorEnabled: enabled });
    if (enabled) {
      this.ui.addFeedMessage("Buddy Mirror active: Partners can see your risk state.");
    }
  }
  async notifyMonitor(indicator) {
    return this.notifyBuddy("alert", `Risk detected: ${indicator}`);
  }
  async notifyIntervention(type, payload) {
    try {
      const userId = await this.getUserId();
      const data = this.normalizePayload(payload);
      const result = await apiCall("/safety/notify-buddy", {
        method: "POST",
        body: JSON.stringify({
          userId,
          type,
          data
        })
      }, this.auth);
      if (result.success) {
        this.ui.updateStatus("Buddy notified via Discord", "info");
        console.log("[BuddyManager] Intervention signal sent to Discord.");
      }
    } catch (err) {
      console.warn("[BuddyManager] Failed to send intervention signal", err);
    }
  }
  async notifyBuddy(type, details) {
    if (!this.mirrorEnabled && !this.auth.demoMode) return;
    try {
      const userId = await this.getUserId();
      const result = await apiCall("/safety/notify-buddy", {
        method: "POST",
        body: JSON.stringify({
          userId,
          type: `buddy_mirror_${type}`,
          data: {
            message: details,
            casino: window.location.hostname,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      }, this.auth);
      if (result.success) {
        console.log("[BuddyManager] Notification sent to accountability partners.");
      }
    } catch (err) {
      console.warn("[BuddyManager] Failed to notify buddy", err);
    }
  }
  async restorePrefs() {
    const prefs = await this.ui.getStorage(["buddyMirrorEnabled"]);
    this.mirrorEnabled = !!prefs.buddyMirrorEnabled;
    const checkbox = document.getElementById("cfg-buddy-mirror");
    if (checkbox) checkbox.checked = this.mirrorEnabled;
  }
  async getUserId() {
    const stored = await this.ui.getStorage(["userData", "tiltguard_user_id"]);
    if (typeof stored.userData?.id === "string" && stored.userData.id.trim() !== "") {
      return stored.userData.id;
    }
    if (typeof stored.tiltguard_user_id === "string" && stored.tiltguard_user_id.trim() !== "") {
      return stored.tiltguard_user_id;
    }
    return void 0;
  }
  normalizePayload(payload) {
    const basePayload = typeof payload === "string" ? { message: payload } : { ...payload };
    return {
      casino: window.location.hostname,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ...basePayload,
      message: typeof basePayload.message === "string" && basePayload.message.trim() !== "" ? basePayload.message : "Intervention triggered"
    };
  }
};

// src/sidebar/onboarding.ts
var OnboardingManager = class {
  ui;
  currentStep = 0;
  steps = [
    {
      targetId: "site-mapper-btn",
      title: "SITE AUDIT SETUP",
      body: "Configure the tool on any house entry point to monitor for potential manipulation signals."
    },
    {
      targetId: "fairness-verifier-btn",
      title: "VERIFICATION ENGINE",
      body: "Verify real-time spin data against official RTPs. Log any discrepancies immediately."
    },
    {
      targetId: "vault-btn",
      title: "PROFIT LOCKER",
      body: "Force-lock the bag before paper hands take over. Stop the 3 AM recovery-farming before it starts."
    },
    {
      targetId: "buddy-mirror-btn",
      title: "SQUAD MIRROR",
      body: "Connect a trusted peer to monitor your floor and help prevent impulsive entries."
    }
  ];
  constructor(ui) {
    this.ui = ui;
  }
  async startIntro() {
    const hasCompleted = await this.checkOnboardingStatus();
    if (hasCompleted) return;
    this.currentStep = 0;
    this.showStep();
  }
  async checkOnboardingStatus() {
    const prefs = await this.ui.getStorage(["onboardingCompleted"]);
    return !!prefs.onboardingCompleted;
  }
  showStep() {
    const step = this.steps[this.currentStep];
    if (!step) {
      this.finish();
      return;
    }
    const target = document.getElementById(step.targetId);
    if (!target) {
      this.next();
      return;
    }
    this.renderOverlay(step, target);
  }
  renderOverlay(step, target) {
    const overlay = document.getElementById("onboarding-overlay");
    if (!overlay) return;
    overlay.classList.add("active");
    const rect = target.getBoundingClientRect();
    const tooltip = overlay.querySelector(".onboarding-tooltip");
    if (tooltip) {
      tooltip.style.top = `${rect.bottom + 10}px`;
      tooltip.style.left = `${Math.max(10, rect.left - 50)}px`;
      const title = tooltip.querySelector(".tooltip-title");
      const body = tooltip.querySelector(".tooltip-body");
      const progress = tooltip.querySelector(".tooltip-progress");
      if (title) title.textContent = step.title;
      if (body) body.textContent = step.body;
      if (progress) progress.textContent = `${this.currentStep + 1} / ${this.steps.length}`;
    }
    overlay.style.setProperty("--spot-x", `${rect.left + rect.width / 2}px`);
    overlay.style.setProperty("--spot-y", `${rect.top + rect.height / 2}px`);
    overlay.style.setProperty("--spot-r", `${Math.max(rect.width, rect.height) / 1.5 + 5}px`);
  }
  next() {
    this.currentStep++;
    this.showStep();
  }
  prev() {
    if (this.currentStep > 0) {
      this.currentStep--;
      this.showStep();
    }
  }
  async finish() {
    const overlay = document.getElementById("onboarding-overlay");
    if (overlay) overlay.classList.remove("active");
    await this.ui.setStorage({ onboardingCompleted: true });
    this.ui.addFeedMessage("Setup complete. Audit mode active \u2014 the math does not lie, and now neither does your session.");
  }
};

// src/sidebar/bonuses.ts
var BONUSES_CACHE_KEY = "tg_bonuses_cache";
var BONUSES_CACHE_TTL_MS = 60 * 60 * 1e3;
var BONUSES_PRIMARY_URL = "https://api.tiltcheck.me/bonuses";
var BONUSES_FALLBACK_URL = "https://raw.githubusercontent.com/TiltCheck-ME/CollectClock/main/bonus-data.json";
var BONUSES_DISPLAY_COUNT = 5;
var BONUS_CLAIM_ALLOWED_HOSTS = [
  "stake.com",
  "stake.us",
  "roobet.com",
  "bc.game",
  "duelbits.com",
  "rollbit.com",
  "shuffle.com",
  "gamdom.com",
  "csgoempire.com",
  "tiltcheck.me"
];
var BonusManager = class {
  ui;
  bonuses = [];
  loading = false;
  expanded = false;
  hiddenCount = 0;
  constructor(ui) {
    this.ui = ui;
  }
  async init() {
    this.setupListeners();
    await this.loadBonuses(false);
  }
  setupListeners() {
    document.getElementById("tg-bonuses-toggle")?.addEventListener("click", () => this.toggleSection());
    document.getElementById("tg-bonuses-refresh")?.addEventListener("click", () => this.loadBonuses(true));
  }
  toggleSection() {
    this.expanded = !this.expanded;
    const body = document.getElementById("tg-bonuses-body");
    const toggle = document.getElementById("tg-bonuses-toggle");
    if (body) body.style.display = this.expanded ? "block" : "none";
    if (toggle) toggle.textContent = this.expanded ? "[COLLAPSE]" : "[EXPAND]";
  }
  async loadBonuses(forceRefresh) {
    if (this.loading) return;
    this.loading = true;
    this.setStatus("Loading...");
    try {
      if (!forceRefresh) {
        const cached = await this.getCache();
        if (cached) {
          this.bonuses = cached.data;
          this.render();
          this.loading = false;
          return;
        }
      }
      const data = await this.fetchFromNetwork();
      if (data) {
        this.bonuses = data;
        if (data.length > 0) {
          await this.setCache(data);
        }
        this.render();
      } else {
        this.setStatus("No bonus data available.");
      }
    } catch (err) {
      console.warn("[BonusManager] Failed to load bonuses", err);
      this.setStatus("Failed to load bonuses.");
    } finally {
      this.loading = false;
    }
  }
  async fetchFromNetwork() {
    const authToken = await this.getAuthToken();
    const headers = authToken ? { Authorization: `Bearer ${authToken}` } : void 0;
    try {
      const resp = await fetch(BONUSES_PRIMARY_URL, { headers, signal: AbortSignal.timeout(6e3) });
      if (resp.ok) {
        const json = await resp.json();
        this.hiddenCount = Math.max(0, Number(json?.suppression?.hiddenCount ?? 0));
        const entries = this.normalizeResponse(json);
        if (entries.length > 0) return entries;
        if (this.hiddenCount > 0) return [];
      }
    } catch {
    }
    this.hiddenCount = 0;
    try {
      const resp = await fetch(BONUSES_FALLBACK_URL, { signal: AbortSignal.timeout(8e3) });
      if (resp.ok) {
        const json = await resp.json();
        return this.normalizeResponse(json);
      }
    } catch (err) {
      console.warn("[BonusManager] Fallback also failed", err);
    }
    return null;
  }
  /**
   * Normalize API responses to BonusEntry[]. Handles both shapes:
   *   - { data: [...] }
   *   - { bonuses: [...] }
   *   - [...]
   */
  normalizeResponse(json) {
    const raw = Array.isArray(json) ? json : json?.data ?? json?.bonuses ?? [];
    return raw.filter((item) => item && typeof item.brand === "string").map((item) => ({
      brand: String(item.brand ?? ""),
      description: String(item.description ?? item.desc ?? ""),
      code: item.code ? String(item.code) : void 0,
      claimUrl: typeof item.claimUrl === "string" ? item.claimUrl : typeof item.url === "string" ? item.url : void 0
    }));
  }
  render() {
    const list = document.getElementById("tg-bonuses-list");
    if (!list) return;
    if (this.bonuses.length === 0) {
      list.innerHTML = this.hiddenCount > 0 ? `<div class="tg-bonus-empty">All matching bonuses are hidden by your active filters. ${this.hiddenCount} suppressed.</div>` : '<div class="tg-bonus-empty">No bonuses found.</div>';
      return;
    }
    const top = this.bonuses.slice(0, BONUSES_DISPLAY_COUNT);
    list.innerHTML = top.map(
      (b) => `
        <div class="tg-bonus-item">
          <div class="tg-bonus-brand">${this.esc(b.brand)}</div>
          <div class="tg-bonus-desc">${this.esc(b.description)}</div>
          ${b.code ? `<div class="tg-bonus-code">[CODE: ${this.esc(b.code)}]</div>` : ""}
          ${this.renderClaimAction(b.claimUrl)}
        </div>
      `
    ).join("") + (this.hiddenCount > 0 ? `<div class="tg-bonus-empty">${this.hiddenCount} hidden by your active filters.</div>` : "");
  }
  renderClaimAction(claimUrl) {
    const safeClaimUrl = this.getSafeClaimUrl(claimUrl);
    if (safeClaimUrl) {
      return `<a class="tg-bonus-claim" href="${this.esc(safeClaimUrl)}" target="_blank" rel="noopener noreferrer">[CLAIM]</a>`;
    }
    if (typeof claimUrl === "string" && claimUrl.trim()) {
      return '<span class="tg-bonus-claim tg-bonus-claim-blocked" title="Blocked unsafe claim link">[LINK BLOCKED]</span>';
    }
    return "";
  }
  getSafeClaimUrl(rawClaimUrl) {
    if (typeof rawClaimUrl !== "string") {
      return null;
    }
    const trimmedClaimUrl = rawClaimUrl.trim();
    if (!trimmedClaimUrl) {
      return null;
    }
    try {
      const parsedClaimUrl = new URL(trimmedClaimUrl);
      if (parsedClaimUrl.protocol !== "https:") {
        return null;
      }
      if (parsedClaimUrl.username || parsedClaimUrl.password) {
        return null;
      }
      const hostname2 = parsedClaimUrl.hostname.replace(/^www\./, "").toLowerCase();
      if (!hostname2 || !this.isAllowedClaimHost(hostname2)) {
        return null;
      }
      parsedClaimUrl.hash = "";
      return parsedClaimUrl.toString();
    } catch {
      return null;
    }
  }
  isAllowedClaimHost(hostname2) {
    return BONUS_CLAIM_ALLOWED_HOSTS.some(
      (allowedHost) => hostname2 === allowedHost || hostname2.endsWith(`.${allowedHost}`)
    );
  }
  setStatus(msg) {
    const list = document.getElementById("tg-bonuses-list");
    if (list) list.innerHTML = `<div class="tg-bonus-empty">${this.esc(msg)}</div>`;
  }
  async getCache() {
    try {
      const result = await this.ui.getStorage([BONUSES_CACHE_KEY]);
      const cached = result[BONUSES_CACHE_KEY];
      if (!cached || !cached.fetchedAt) return null;
      if (Date.now() - cached.fetchedAt > BONUSES_CACHE_TTL_MS) return null;
      return cached;
    } catch {
      return null;
    }
  }
  async setCache(data) {
    const cache = { data, fetchedAt: Date.now() };
    await this.ui.setStorage({ [BONUSES_CACHE_KEY]: cache });
  }
  esc(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  async getAuthToken() {
    try {
      const result = await this.ui.getStorage(["authToken"]);
      const token = typeof result["authToken"] === "string" ? result["authToken"].trim() : "";
      return token || null;
    } catch {
      return null;
    }
  }
};

// src/sidebar/index.ts
var SITE_REDEEM_THRESHOLDS_KEY = "tiltcheck_site_thresholds";
var SIDEBAR_RESERVED_CLASS = "tiltcheck-sidebar-reserved";
var SidebarController = class {
  constructor(onDisableRuntime) {
    this.onDisableRuntime = onDisableRuntime;
    this.auth = new AuthManager(this);
    this.session = new SessionManager(this);
    this.vault = new VaultManager(this);
    this.reports = new ReportManager(this, this.auth);
    this.buddy = new BuddyManager(this, this.auth);
    this.onboarding = new OnboardingManager(this);
    this.bonuses = new BonusManager(this);
  }
  auth;
  session;
  vault;
  reports;
  buddy;
  onboarding;
  bonuses;
  layoutObserver = null;
  showAdvancedTools = false;
  init() {
    this.injectStyles();
    this.createDom();
    this.observeSidebarLayout();
    this.setupListeners();
    void this.restoreSidebarPreferences();
    void this.loadRedeemThresholdSettings();
    this.auth.restoreAuth();
    this.buddy.restorePrefs();
    this.vault.init();
    this.bonuses.init();
  }
  injectStyles() {
    const style = document.createElement("style");
    style.textContent = getSidebarStyles();
    document.head.appendChild(style);
  }
  createDom() {
    const existing = document.getElementById("tiltcheck-sidebar");
    if (existing) existing.remove();
    const sidebar2 = document.createElement("div");
    sidebar2.id = "tiltcheck-sidebar";
    sidebar2.innerHTML = SIDEBAR_TEMPLATE;
    document.body.appendChild(sidebar2);
    this.syncHostPageLayout();
  }
  setupListeners() {
    document.getElementById("tg-minimize")?.addEventListener("click", () => {
      const sidebar2 = this.getSidebarElement();
      const minimized = !!sidebar2?.classList.contains("minimized");
      this.setSidebarMinimized(!minimized);
    });
    document.getElementById("tg-hide")?.addEventListener("click", () => {
      this.setSidebarVisibility(false);
    });
    document.getElementById("tg-settings")?.addEventListener("click", () => {
      this.togglePanelVisibility("tg-settings-panel");
    });
    document.getElementById("close-settings")?.addEventListener("click", () => {
      this.setPanelVisibility("tg-settings-panel", false);
    });
    document.getElementById("tg-discord-login")?.addEventListener("click", () => this.auth.startDiscordLoginFlow());
    document.getElementById("tg-connect-discord-inline")?.addEventListener("click", () => this.auth.startDiscordLoginFlow());
    document.getElementById("tg-guest-login")?.addEventListener("click", () => this.auth.continueAsGuest());
    document.getElementById("tg-logout")?.addEventListener("click", () => this.auth.logout());
    document.getElementById("tg-open-dashboard")?.addEventListener("click", () => this.openDashboard());
    document.getElementById("tg-open-safety")?.addEventListener("click", () => this.openDashboard("safety"));
    document.getElementById("tg-open-vault-rules")?.addEventListener("click", () => this.openDashboard("vault"));
    document.getElementById("tg-open-buddy-controls")?.addEventListener("click", () => this.openDashboard("buddies"));
    document.getElementById("tg-open-buddies")?.addEventListener("click", () => this.openDashboard("buddies"));
    document.getElementById("tg-open-vault")?.addEventListener("click", () => this.openDashboard("vault"));
    document.getElementById("tg-disable-injection")?.addEventListener("click", () => {
      void this.disableRuntimeInjection();
    });
    document.getElementById("tg-open-report")?.addEventListener("click", () => {
      this.setPanelVisibility("tg-report-panel", true);
    });
    document.getElementById("close-report")?.addEventListener("click", () => {
      this.setPanelVisibility("tg-report-panel", false);
    });
    document.getElementById("submit-report")?.addEventListener("click", () => {
      const typeEl = document.getElementById("report-type");
      const detailsEl = document.getElementById("report-details");
      if (typeEl && detailsEl) {
        this.reports.submitReport(typeEl.value, detailsEl.value, window.location.hostname);
      }
    });
    document.getElementById("cfg-buddy-mirror")?.addEventListener("change", (e) => {
      const target = e.target;
      this.buddy.setMirrorEnabled(target.checked);
    });
    document.getElementById("tg-save-redeem-threshold")?.addEventListener("click", () => {
      void this.saveRedeemThresholdForSite();
    });
    document.getElementById("tg-redeem-threshold")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        void this.saveRedeemThresholdForSite();
      }
    });
    document.getElementById("tg-toggle-advanced")?.addEventListener("click", () => {
      this.setAdvancedToolsVisibility(!this.showAdvancedTools);
    });
    document.getElementById("tg-open-predictor")?.addEventListener("click", () => {
      const body = document.getElementById("tg-bonuses-body");
      if (body) body.style.display = body.style.display === "none" ? "block" : "none";
    });
    document.getElementById("ob-next")?.addEventListener("click", () => this.onboarding.next());
    document.getElementById("ob-skip")?.addEventListener("click", () => this.onboarding.finish());
    document.getElementById("tg-emergency-lock")?.addEventListener("click", () => {
      this.vault.lockTheBag(1);
    });
    document.getElementById("vibe-lock-bag")?.addEventListener("click", () => {
      this.vault.lockTheBag(1);
      this.dismissSessionPause();
    });
    document.getElementById("vibe-discord")?.addEventListener("click", () => {
      window.open("https://discord.gg/gdBsEJfCar", "_blank");
      this.dismissSessionPause();
    });
    document.getElementById("vibe-ignore")?.addEventListener("click", () => {
      this.addFeedMessage("TiltCheck warning suppressed. Good luck.");
      this.dismissSessionPause();
    });
    const avToggle = document.getElementById("tg-autovault-toggle");
    avToggle?.addEventListener("change", () => {
      this.vault.toggleAutoVault(avToggle.checked);
    });
    const avPct = document.getElementById("tg-autovault-pct");
    const avPctVal = document.getElementById("tg-autovault-pct-val");
    avPct?.addEventListener("input", () => {
      const val = parseInt(avPct.value);
      if (avPctVal) avPctVal.textContent = `${val}%`;
      this.vault.setAutoVaultPct(val);
    });
  }
  setPanelVisibility(panelId, visible) {
    const panel = document.getElementById(panelId);
    if (panel) {
      panel.style.display = visible ? "block" : "none";
    }
  }
  togglePanelVisibility(panelId) {
    const panel = document.getElementById(panelId);
    if (!panel) {
      return;
    }
    this.setPanelVisibility(panelId, panel.style.display === "none");
  }
  getSidebarElement() {
    return document.getElementById("tiltcheck-sidebar");
  }
  getReservedWidth() {
    const sidebar2 = this.getSidebarElement();
    if (!sidebar2 || sidebar2.style.display === "none") {
      return 0;
    }
    return sidebar2.classList.contains("minimized") ? MINIMIZED_WIDTH : SIDEBAR_WIDTH;
  }
  applyHostPageLayout(offset) {
    const value = `${Math.max(offset, 0)}px`;
    for (const element of [document.documentElement, document.body]) {
      element.classList.toggle(SIDEBAR_RESERVED_CLASS, offset > 0);
      element.style.setProperty("--tiltcheck-sidebar-offset", value);
    }
  }
  syncHostPageLayout() {
    this.applyHostPageLayout(this.getReservedWidth());
  }
  observeSidebarLayout() {
    this.layoutObserver?.disconnect();
    const sidebar2 = this.getSidebarElement();
    if (!sidebar2) {
      return;
    }
    this.layoutObserver = new MutationObserver(() => this.syncHostPageLayout());
    this.layoutObserver.observe(sidebar2, {
      attributes: true,
      attributeFilter: ["class", "style"]
    });
  }
  async updateSidebarPrefs(partial) {
    const stored = await this.getStorage([SIDEBAR_PREFS_KEY]);
    const existing = stored[SIDEBAR_PREFS_KEY];
    const prefs = existing && typeof existing === "object" && !Array.isArray(existing) ? existing : {};
    await this.setStorage({ [SIDEBAR_PREFS_KEY]: { ...prefs, ...partial } });
  }
  setSidebarMinimized(minimized, persist = true) {
    const sidebar2 = this.getSidebarElement();
    if (!sidebar2) {
      return;
    }
    sidebar2.classList.toggle("minimized", minimized);
    const button = document.getElementById("tg-minimize");
    if (button) {
      button.textContent = minimized ? "+" : "\u2212";
      button.setAttribute("title", minimized ? "Expand" : "Minimize");
      button.setAttribute("aria-label", minimized ? "Expand sidebar" : "Minimize sidebar");
    }
    this.syncHostPageLayout();
    if (persist) {
      void this.updateSidebarPrefs({ minimized });
    }
  }
  setSidebarVisibility(visible, persist = true) {
    const sidebar2 = this.getSidebarElement();
    if (!sidebar2) {
      return;
    }
    sidebar2.style.display = visible ? "block" : "none";
    this.syncHostPageLayout();
    if (persist) {
      void this.setStorage({ [SIDEBAR_VISIBILITY_KEY]: visible });
    }
  }
  setAdvancedToolsVisibility(show, persist = true) {
    this.showAdvancedTools = show;
    const sidebar2 = this.getSidebarElement();
    const toggleBtn = document.getElementById("tg-toggle-advanced");
    if (!sidebar2) {
      return;
    }
    sidebar2.classList.toggle("tg-show-advanced", show);
    if (toggleBtn) {
      toggleBtn.textContent = show ? "Hide Pro Tools" : "Show Pro Tools";
      toggleBtn.setAttribute("aria-pressed", show ? "true" : "false");
    }
    if (!show) {
      const advancedPanels = ["tg-settings-panel", "tg-report-panel"];
      advancedPanels.forEach((panelId) => {
        const panel = document.getElementById(panelId);
        if (panel) {
          panel.style.display = "none";
        }
      });
    }
    if (persist) {
      void this.updateSidebarPrefs({ showAdvanced: show });
    }
  }
  async restoreSidebarPreferences() {
    const stored = await this.getStorage([SIDEBAR_PREFS_KEY]);
    const prefs = stored[SIDEBAR_PREFS_KEY];
    if (prefs && typeof prefs === "object" && !Array.isArray(prefs)) {
      const sidebarPrefs = prefs;
      if (typeof sidebarPrefs.minimized === "boolean") {
        this.setSidebarMinimized(sidebarPrefs.minimized, false);
      } else {
        this.setSidebarMinimized(false, false);
      }
      if (typeof sidebarPrefs.showAdvanced === "boolean") {
        this.setAdvancedToolsVisibility(sidebarPrefs.showAdvanced, false);
      } else {
        this.setAdvancedToolsVisibility(false, false);
      }
    } else {
      this.setSidebarMinimized(false, false);
      this.setAdvancedToolsVisibility(false, false);
    }
    this.syncHostPageLayout();
  }
  getCurrentSiteHost() {
    return (window.location.hostname || "unknown").replace(/^www\./, "").toLowerCase();
  }
  getStoredRedeemThresholds(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return {};
    }
    const thresholds = {};
    for (const [host, rawValue] of Object.entries(value)) {
      const threshold = Number(rawValue);
      if (Number.isFinite(threshold) && threshold > 0) {
        thresholds[host] = threshold;
      }
    }
    return thresholds;
  }
  parseRedeemThresholdInput() {
    const input = document.getElementById("tg-redeem-threshold");
    if (!input) return null;
    const parsed = Number(input.value || "0");
    if (!Number.isFinite(parsed) || parsed < 0) {
      return null;
    }
    return Math.round(parsed * 100) / 100;
  }
  setRedeemThresholdInputValue(threshold) {
    const input = document.getElementById("tg-redeem-threshold");
    if (!input) return;
    input.value = threshold > 0 ? threshold.toFixed(2).replace(/\.00$/, "") : "";
  }
  updateRedeemSiteLabel() {
    const label = document.getElementById("tg-redeem-site-label");
    if (label) {
      label.textContent = this.getCurrentSiteHost();
    }
  }
  async loadRedeemThresholdSettings() {
    this.updateRedeemSiteLabel();
    const siteHost = this.getCurrentSiteHost();
    const stored = await this.getStorage([SITE_REDEEM_THRESHOLDS_KEY, "redeemThreshold"]);
    const thresholds = this.getStoredRedeemThresholds(stored[SITE_REDEEM_THRESHOLDS_KEY]);
    const fallbackThreshold = Number(stored.redeemThreshold) || 0;
    const activeThreshold = thresholds[siteHost] ?? fallbackThreshold;
    this.setRedeemThresholdInputValue(activeThreshold);
  }
  async saveRedeemThresholdForSite() {
    const threshold = this.parseRedeemThresholdInput();
    if (threshold === null) {
      this.updateStatus("Use a valid redeem line or 0 to disable it.", "warning");
      return;
    }
    const siteHost = this.getCurrentSiteHost();
    const stored = await this.getStorage([SITE_REDEEM_THRESHOLDS_KEY]);
    const thresholds = this.getStoredRedeemThresholds(stored[SITE_REDEEM_THRESHOLDS_KEY]);
    if (threshold === 0) {
      delete thresholds[siteHost];
    } else {
      thresholds[siteHost] = threshold;
    }
    await this.setStorage({
      [SITE_REDEEM_THRESHOLDS_KEY]: thresholds,
      redeemThreshold: threshold
    });
    if (this.auth.authToken) {
      const ok = await this.auth.patchSettings(this.auth.authToken, {
        limits: { redeemThresholdUsd: threshold === 0 ? null : threshold },
        surfaces: {
          extension: {
            siteRedeemThresholds: thresholds
          }
        }
      });
      if (!ok) {
        this.addFeedMessage("Saved locally. Cloud settings sync will retry next login.");
      }
    }
    this.setRedeemThresholdInputValue(threshold);
    window.dispatchEvent(new CustomEvent("tg-redeem-threshold-updated", {
      detail: { hostname: siteHost, threshold }
    }));
    if (threshold === 0) {
      this.updateStatus(`Redeem nudge disabled for ${siteHost}.`, "info");
      this.addFeedMessage(`Redeem nudge disabled for ${siteHost}.`);
      return;
    }
    this.updateStatus(`Redeem line armed at $${threshold.toFixed(2)} for ${siteHost}.`, "success");
    this.addFeedMessage(`Redeem line armed for ${siteHost} at $${threshold.toFixed(2)}.`);
  }
  // SidebarUI implementation
  syncAccountUi() {
    const accountText = document.getElementById("tg-account-text");
    const usernameEl = document.getElementById("tg-username");
    const connectBtn = document.getElementById("tg-connect-discord-inline");
    if (this.auth.isConnecting) {
      if (accountText) accountText.textContent = "Syncing...";
      if (connectBtn) {
        connectBtn.hidden = false;
        connectBtn.disabled = true;
        connectBtn.textContent = "Connecting...";
      }
      return;
    }
    if (this.auth.demoMode || !this.auth.authToken) {
      if (accountText) accountText.textContent = "Standard Mode.";
      if (usernameEl) usernameEl.textContent = "Guest";
      if (connectBtn) {
        connectBtn.hidden = false;
        connectBtn.disabled = false;
        connectBtn.textContent = "Log in with Discord";
      }
    } else {
      if (accountText) accountText.textContent = `Connected as ${this.auth.userData?.username}`;
      if (usernameEl) usernameEl.textContent = this.auth.userData?.username;
      if (connectBtn) {
        connectBtn.hidden = true;
        connectBtn.disabled = false;
        connectBtn.textContent = "Log in with Discord";
      }
    }
  }
  openDashboard(tab = "profile") {
    const dashboardUrl = new URL(EXT_CONFIG.DASHBOARD_URL);
    if (tab !== "profile") {
      dashboardUrl.searchParams.set("tab", tab);
    }
    chrome.tabs.create({ url: dashboardUrl.toString(), active: true });
    this.addFeedMessage(tab === "profile" ? "Opening dashboard." : `Opening dashboard ${tab} controls.`);
  }
  async disableRuntimeInjection() {
    await this.setStorage({ [INJECTION_DISABLED_KEY]: true });
    this.updateStatus("TiltCheck runtime disabled. Toolbar wake-up is still available.", "warning");
    this.addFeedMessage("Runtime disabled. No cap, the HUD is off until you wake it back up.");
    await this.onDisableRuntime?.();
  }
  showMainContent() {
    const authSection = document.getElementById("tg-auth-section");
    const mainContent = document.getElementById("tg-main-content");
    if (authSection) authSection.style.display = "none";
    if (mainContent) mainContent.style.display = "block";
    this.reports.fetchRecentSignals();
    this.onboarding.startIntro();
  }
  addFeedMessage(msg) {
    const feed = document.getElementById("tg-message-feed");
    if (!feed) return;
    const item = document.createElement("div");
    item.className = "tg-feed-item";
    item.textContent = `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] ${msg}`;
    feed.insertBefore(item, feed.firstChild);
  }
  async getStorage(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve);
    });
  }
  async setStorage(data) {
    return new Promise((resolve) => {
      chrome.storage.local.set(data, resolve);
    });
  }
  updateStatus(message, type) {
    const statusBar = document.getElementById("tg-status-bar");
    if (!statusBar) return;
    statusBar.textContent = message;
    statusBar.className = `tg-status-bar ${type}`;
    statusBar.style.display = "block";
    setTimeout(() => {
      if (statusBar.textContent === message) statusBar.style.display = "none";
    }, 4e3);
  }
  updateRealityCheck(active) {
    const indicator = document.getElementById("tg-status-indicator");
    if (indicator) {
      indicator.className = `tg-status-indicator ${active ? "active" : ""}`;
    }
  }
  updateLicense(data) {
    const strip = document.getElementById("tg-license-strip");
    const detail = document.getElementById("tg-license-detail");
    if (!strip) return;
    const presentation = buildLicensePresentation(data);
    strip.textContent = presentation.summary;
    strip.className = `tg-license-strip ${presentation.tone}`;
    if (detail) {
      detail.textContent = presentation.details.join(" | ");
    }
  }
  updateTilt(score, indicators) {
    const scoreVal = document.getElementById("tg-score-value");
    if (scoreVal) {
      scoreVal.textContent = score.toString();
      if (score > 80) scoreVal.style.color = "#ff4444";
      else if (score > 50) scoreVal.style.color = "#ff8800";
      else scoreVal.style.color = "#17c3b2";
    }
    if (indicators.length > 0 && score > 60) {
      this.addFeedMessage(`Risk Alert: ${indicators[0]}`);
      this.buddy.notifyMonitor(indicators[0]);
    }
    if (score >= 80) {
      this.triggerSessionPause();
    }
  }
  triggerSessionPause() {
    const overlay = document.getElementById("tg-vibe-check-overlay");
    if (overlay && overlay.style.display !== "flex") {
      overlay.style.display = "flex";
      this.addFeedMessage("SESSION PAUSE TRIGGERED: TILTCHECK INTERVENTION RECOMMENDED.");
    }
  }
  dismissSessionPause() {
    const overlay = document.getElementById("tg-vibe-check-overlay");
    if (overlay) overlay.style.display = "none";
  }
  updateStats(stats) {
    if (stats.totalBets !== void 0) {
      const el = document.getElementById("tg-bets");
      if (el) el.textContent = stats.totalBets.toString();
    }
    if (stats.totalWagered !== void 0) {
      const el = document.getElementById("tg-wagered");
      if (el) el.textContent = `$${stats.totalWagered.toFixed(2)}`;
    }
    if (stats.totalWon !== void 0) {
      const el = document.getElementById("tg-profit");
      if (el) {
        const pnl = stats.totalWon - (stats.totalWagered || 0);
        el.textContent = `${pnl >= 0 ? "+" : ""}$${pnl.toFixed(2)}`;
        el.style.color = pnl >= 0 ? "#17c3b2" : "#ff4444";
      }
    }
  }
  notifyBuddy(event, data) {
    if (this.buddy) {
      const interventionType = data?.type || event;
      const interventionPayload = data?.data ?? data ?? "Intervention triggered";
      this.buddy.notifyIntervention(interventionType, interventionPayload);
    }
  }
  async openPremium() {
    const premiumUrl = new URL(EXT_CONFIG.DASHBOARD_URL);
    premiumUrl.pathname = "/premium";
    premiumUrl.search = "";
    chrome.tabs.create({ url: premiumUrl.toString(), active: true });
    console.log("[SidebarController] Redirecting to premium upgrade page...");
  }
};
function initSidebar(onDisableRuntime) {
  const controller = new SidebarController(onDisableRuntime);
  controller.init();
  return controller;
}

// src/FairnessService.ts
var FairnessService = class {
  /**
   * Generates a provably fair HMAC-SHA256 hash (The 4-Key Lock).
   * 
   * Formula: R = HMAC_SHA256(Solana_Block_Hash, Discord_ID + Client_Seed + Nonce)
   *
   * @param solanaBlockHash - The Solana Block Hash (Platform Entropy / The Salt)
   * @param discordId - The User's Discord ID (Identity Entropy)
   * @param clientSeed - The user-controlled client seed (User Entropy)
   * @param nonce - Sequential counter ensuring uniqueness (Incremental Entropy)
   * @returns The resulting hex string of the HMAC
   */
  async generateHash(solanaBlockHash, discordId, clientSeed, nonce = 0) {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(solanaBlockHash);
    const messageData = encoder.encode(`${discordId}${clientSeed}:${nonce}`);
    const subtle = crypto.subtle || crypto.webcrypto?.subtle;
    const key = await subtle.importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await subtle.sign(
      "HMAC",
      key,
      messageData
    );
    return this.bufferToHex(signature);
  }
  /**
   * Converts a hex hash into a normalized float (0.0 to 1.0).
   * Useful for determining game outcomes (e.g. dice rolls, win/loss).
   * 
   * Standard implementation: Takes the first 4 bytes (32 bits) of the hash.
   */
  hashToFloat(hexHash) {
    const subHash = hexHash.substring(0, 8);
    const intValue = parseInt(subHash, 16);
    return intValue / 4294967295;
  }
  /**
   * Calculates a standard Dice result (0.00 to 100.00).
   * Used by Stake, BC.Game, etc.
   * 
   * Logic: Float * 10001 / 100
   */
  getDiceResult(float) {
    return Math.floor(float * 10001) / 100;
  }
  /**
   * Calculates a Limbo/Crash multiplier.
   * 
   * Logic: 0.99 / (1 - float)
   * This creates the exponential distribution required for crash games.
   * 
   * @param float - The normalized float (0.0 to 1.0)
   * @param houseEdge - The house edge (default 0.01 / 1%)
   */
  getLimboResult(float, houseEdge = 0.01) {
    if (float === 1) return 1e6;
    const multiplier = (1 - houseEdge) / (1 - float);
    return Math.floor(multiplier * 100) / 100;
  }
  /**
   * Calculates Plinko path directions.
   * Plinko requires multiple random decisions (one per row).
   * 
   * @param hexHash - The full HMAC hash
   * @param rows - Number of rows (8-16 usually)
   * @returns Array of 0 (Left) and 1 (Right)
   */
  getPlinkoPath(hexHash, rows) {
    const directions = [];
    for (let i = 0; i < rows * 2; i += 2) {
      const byte = parseInt(hexHash.substring(i, i + 2), 16);
      directions.push(byte % 2);
    }
    return directions;
  }
  /**
   * Verifies if a reported result matches the "Double Provably Fair" inputs.
   * Used by the Browser Extension to detect fraud.
   * 
   * @param reportedHash - The hash reported by the casino/house
   * @param solanaBlockHash - The Solana Block Hash used for the bet
   * @param discordId - The User's Discord ID
   * @param clientSeed - The User's Client Seed
   * @param nonce - Sequential counter
   */
  async verify(reportedHash, solanaBlockHash, discordId, clientSeed, nonce = 0) {
    const calculatedHash = await this.generateHash(solanaBlockHash, discordId, clientSeed, nonce);
    return calculatedHash === reportedHash;
  }
  /**
   * Verifies standard casino game fairness using server seed, client seed, and nonce.
   */
  async verifyCasinoResult(serverSeed, clientSeed, nonce) {
    const encoder = new TextEncoder();
    const keyData = encoder.encode(serverSeed);
    const messageData = encoder.encode(`${clientSeed}:${nonce}`);
    const key = await (crypto.subtle || crypto.webcrypto.subtle).importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await (crypto.subtle || crypto.webcrypto.subtle).sign(
      "HMAC",
      key,
      messageData
    );
    return this.bufferToHex(signature);
  }
  bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
};

// src/analyzer.ts
var Analyzer = class {
  fairness;
  constructor() {
    this.fairness = new FairnessService();
  }
  /**
   * Watches the DOM for a specific element to appear that contains the game result.
   * Useful for SPAs where the result appears dynamically after the bet.
   * 
   * @param selector - CSS selector for the result element
   * @param parser - Function to extract the GameResult from the DOM element
   * @param timeoutMs - Max time to wait for result
   */
  async waitForResult(selector, parser, timeoutMs = 1e4) {
    return new Promise((resolve, reject) => {
      const existingEl = document.querySelector(selector);
      if (existingEl) {
        resolve(parser(existingEl));
        return;
      }
      const observer = new MutationObserver((mutations, obs) => {
        const element = document.querySelector(selector);
        if (element) {
          obs.disconnect();
          resolve(parser(element));
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true
        // Some casinos update data attributes
      });
      setTimeout(() => {
        observer.disconnect();
        reject(new Error("Timeout waiting for game result"));
      }, timeoutMs);
    });
  }
  /**
   * Verifies if the scraped result matches the commitment.
   */
  async verify(result, commitment) {
    const expectedHash = await this.fairness.generateHash(
      commitment.blockHash,
      commitment.discordId,
      commitment.clientSeed,
      commitment.nonce
    );
    if (result.rawHash) {
      return { isValid: result.rawHash === expectedHash, expectedHash };
    }
    const expectedFloat = this.fairness.hashToFloat(expectedHash);
    const epsilon = 1e-5;
    const isValid = Math.abs(expectedFloat - result.value) < epsilon;
    return { isValid, expectedHash };
  }
};

// src/telemetry-client.ts
function postTelemetry(path, payload) {
  return fetch(getHubEndpoint(path), {
    method: "POST",
    headers: TELEMETRY_REQUEST_HEADERS,
    body: JSON.stringify(payload)
  });
}
function postRoundTelemetry(payload) {
  return postTelemetry(TELEMETRY_PATH, payload);
}
function postWinSecureTelemetry(payload) {
  return postTelemetry(WIN_SECURE_PATH, payload);
}

// src/game-blocker.ts
var OVERLAY_ID = "tiltcheck-game-block-overlay";
var POLL_INTERVAL_MS = 3e3;
var CACHE_TTL_MS = 5 * 60 * 1e3;
var CATEGORY_SLUGS = {
  chicken_mines: ["chicken", "mines", "minefield"],
  bonus_buy: ["bonus-buy", "bonusbuy", "feature-buy", "featurebuy"],
  live_dealer: ["live-dealer", "live-casino", "live_dealer", "livecasino"],
  slots: ["slot", "slots"],
  crash: ["crash", "aviator", "jetx", "spaceman"],
  table_games: ["blackjack", "roulette", "baccarat", "poker", "table"]
};
var GameBlocker = class {
  profile = null;
  profileFetchedAt = 0;
  discordId;
  authToken;
  observer = null;
  pollTimer = null;
  dismissStorageKey = `tiltcheck_game_block_dismissed:${window.location.hostname.toLowerCase()}`;
  handleWindowFocus = () => {
    void this.refreshAndScan(true);
  };
  handlePageShow = () => {
    void this.refreshAndScan(true);
  };
  handleVisibilityChange = () => {
    if (document.visibilityState === "visible") {
      void this.refreshAndScan(true);
    }
  };
  constructor(discordId, authToken) {
    this.discordId = discordId;
    this.authToken = authToken;
  }
  async init() {
    await this.refreshProfile();
    this.scan();
    this.startObserver();
    this.startPoller();
    this.attachReturnListeners();
  }
  resume(_source = "navigation") {
    void this.refreshAndScan(true);
  }
  destroy() {
    this.observer?.disconnect();
    if (this.pollTimer) clearInterval(this.pollTimer);
    this.detachReturnListeners();
    this.removeOverlay();
  }
  // ─── Profile management ────────────────────────────────────────────────────
  async refreshProfile(force = false) {
    const now = Date.now();
    if (!force && this.profile && now - this.profileFetchedAt < CACHE_TTL_MS) return;
    try {
      const resp = await fetch(
        `${EXT_CONFIG.API_BASE_URL}/user/${encodeURIComponent(this.discordId)}/exclusions`,
        {
          credentials: "include",
          headers: {
            Authorization: `Bearer ${this.authToken}`
          }
        }
      );
      if (!resp.ok) return;
      const body = await resp.json();
      if (body.success && body.data) {
        this.profile = body.data;
        this.profileFetchedAt = now;
      }
    } catch {
    }
  }
  async refreshAndScan(force = false) {
    await this.refreshProfile(force);
    this.scan();
  }
  // ─── Matching helpers ──────────────────────────────────────────────────────
  normalizeLookupValue(value) {
    if (!value) return null;
    const normalized = value.trim().toLowerCase();
    return normalized.length > 0 ? normalized : null;
  }
  normalizeSlugValue(value) {
    if (!value) return null;
    const normalized = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return normalized.length > 0 ? normalized : null;
  }
  tokenMatches(blockedValue, candidateValue) {
    return candidateValue === blockedValue || candidateValue.startsWith(`${blockedValue}-`) || blockedValue.startsWith(`${candidateValue}-`);
  }
  matchGameId(slug) {
    if (!this.profile) return null;
    const lower = this.normalizeLookupValue(slug);
    if (!lower) return null;
    for (const id of this.profile.blockedGameIds) {
      const blockedId = this.normalizeLookupValue(id);
      if (blockedId && lower.includes(blockedId)) {
        const entry = this.profile.exclusions.find((e) => e.gameId === id) ?? null;
        return { gameId: id, category: null, provider: null, casino: null, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  matchCategory(slug) {
    if (!this.profile) return null;
    const lower = slug.toLowerCase();
    for (const cat of this.profile.blockedCategories) {
      const keywords = CATEGORY_SLUGS[cat] ?? [];
      if (keywords.some((kw) => lower.includes(kw))) {
        const entry = this.profile.exclusions.find((e) => e.category === cat) ?? null;
        return { gameId: null, category: cat, provider: null, casino: null, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  collectProviderCandidates() {
    const candidates = /* @__PURE__ */ new Set();
    const addCandidate = (value) => {
      const normalized = this.normalizeSlugValue(value);
      if (normalized) {
        candidates.add(normalized);
      }
    };
    addCandidate(document.title);
    addCandidate(window.location.pathname);
    addCandidate(window.location.search);
    const metaProvider = document.querySelector('meta[name="provider"], meta[property="og:provider"]');
    addCandidate(metaProvider?.content);
    for (const element of Array.from(document.querySelectorAll("[data-provider], [data-provider-name], [data-game-provider], [data-game-provider-name]"))) {
      addCandidate(element.dataset["provider"]);
      addCandidate(element.dataset["providerName"]);
      addCandidate(element.dataset["gameProvider"]);
      addCandidate(element.dataset["gameProviderName"]);
      addCandidate(element.getAttribute("data-provider"));
      addCandidate(element.getAttribute("data-provider-name"));
      addCandidate(element.getAttribute("data-game-provider"));
      addCandidate(element.getAttribute("data-game-provider-name"));
    }
    return [...candidates];
  }
  collectCasinoCandidates() {
    const hostname2 = window.location.hostname.toLowerCase();
    const candidates = /* @__PURE__ */ new Set();
    const addCandidate = (value) => {
      const normalized = this.normalizeSlugValue(value);
      if (normalized) {
        candidates.add(normalized);
      }
    };
    addCandidate(hostname2);
    for (const segment of hostname2.split(".")) {
      addCandidate(segment);
    }
    addCandidate(hostname2.split(".")[0] ?? "");
    return [...candidates];
  }
  matchProvider() {
    if (!this.profile) return null;
    const candidates = this.collectProviderCandidates();
    for (const provider of this.profile.blockedProviders) {
      const blockedProvider = this.normalizeSlugValue(provider);
      if (!blockedProvider) continue;
      const matched = candidates.some((candidate) => this.tokenMatches(blockedProvider, candidate));
      if (matched) {
        const entry = this.profile.exclusions.find((e) => e.provider === provider) ?? null;
        return { gameId: null, category: null, provider, casino: null, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  matchCasino() {
    if (!this.profile) return null;
    const candidates = this.collectCasinoCandidates();
    for (const casino of this.profile.blockedCasinos) {
      const blockedCasino = this.normalizeSlugValue(casino);
      if (!blockedCasino) continue;
      const matched = candidates.some((candidate) => this.tokenMatches(blockedCasino, candidate));
      if (matched) {
        const entry = this.profile.exclusions.find((e) => e.casino === casino) ?? null;
        return { gameId: null, category: null, provider: null, casino, reason: entry?.reason ?? null };
      }
    }
    return null;
  }
  isBlocked(slug) {
    return this.matchGameId(slug) ?? this.matchCategory(slug) ?? this.matchProvider() ?? this.matchCasino();
  }
  // ─── DOM scan ─────────────────────────────────────────────────────────────
  scan() {
    if (this.isDismissedForSession()) {
      this.removeOverlay();
      return;
    }
    if (!this.profile) return;
    const urlSlug = window.location.pathname + window.location.search;
    const urlMatch = this.isBlocked(urlSlug);
    if (urlMatch) {
      this.injectOverlay(urlMatch);
      return;
    }
    for (const iframe of Array.from(document.querySelectorAll("iframe[src]"))) {
      const match = this.isBlocked(iframe.src);
      if (match) {
        this.injectOverlay(match);
        return;
      }
    }
    for (const btn of Array.from(document.querySelectorAll("[data-game-id]"))) {
      const gameId = btn.dataset["gameId"] ?? "";
      const match = this.isBlocked(gameId);
      if (match) {
        this.injectOverlay(match);
        return;
      }
    }
    this.removeOverlay();
  }
  // ─── DOM observer ─────────────────────────────────────────────────────────
  startObserver() {
    this.observer = new MutationObserver(() => this.scan());
    this.observer.observe(document.body, { childList: true, subtree: true, attributes: true });
  }
  attachReturnListeners() {
    window.addEventListener("focus", this.handleWindowFocus);
    window.addEventListener("pageshow", this.handlePageShow);
    document.addEventListener("visibilitychange", this.handleVisibilityChange);
  }
  detachReturnListeners() {
    window.removeEventListener("focus", this.handleWindowFocus);
    window.removeEventListener("pageshow", this.handlePageShow);
    document.removeEventListener("visibilitychange", this.handleVisibilityChange);
  }
  // ─── Profile refresh poller ───────────────────────────────────────────────
  startPoller() {
    this.pollTimer = setInterval(async () => {
      await this.refreshAndScan();
    }, POLL_INTERVAL_MS);
  }
  // ─── Overlay ──────────────────────────────────────────────────────────────
  injectOverlay(match) {
    if (document.getElementById(OVERLAY_ID)) return;
    const label = match.gameId ? `game ID: ${match.gameId}` : match.category ? `category: ${(match.category ?? "").replace(/_/g, " ")}` : match.provider ? `provider: ${match.provider.replace(/[-_]/g, " ")}` : `casino: ${(match.casino ?? "").replace(/[-_]/g, " ")}`;
    const reasonHtml = match.reason ? `<p class="tc-block-reason">"${match.reason}"</p>` : "";
    const safetyUrl = `${EXT_CONFIG.DASHBOARD_URL}?tab=safety`;
    const overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    overlay.innerHTML = `
      <div class="tc-block-inner">
        <div class="tc-block-badge">BLOCKED BY YOU</div>
        <h2 class="tc-block-title">Not today.</h2>
        <p class="tc-block-body">
          You told TiltCheck to block ${label}.<br>
          Past-you was looking out for present-you. Respect the call.<br>
          The dashboard owns the filter. This page just enforces it.
        </p>
        ${reasonHtml}
        <div class="tc-block-actions">
          <a class="tc-block-btn tc-block-btn--primary" href="${safetyUrl}" target="_blank">
            Open Safety Controls
          </a>
          <button class="tc-block-btn tc-block-btn--ghost" id="tc-block-dismiss">
            Dismiss for this session
          </button>
        </div>
        <footer class="tc-block-footer">Made for Degens. By Degens.</footer>
      </div>
    `;
    this.applyStyles(overlay);
    document.body.appendChild(overlay);
    document.getElementById("tc-block-dismiss")?.addEventListener("click", () => {
      this.setDismissedForSession(true);
      this.removeOverlay();
    });
  }
  isDismissedForSession() {
    try {
      return window.sessionStorage.getItem(this.dismissStorageKey) === "1";
    } catch {
      return false;
    }
  }
  setDismissedForSession(dismissed) {
    try {
      if (dismissed) {
        window.sessionStorage.setItem(this.dismissStorageKey, "1");
      } else {
        window.sessionStorage.removeItem(this.dismissStorageKey);
      }
    } catch {
    }
  }
  removeOverlay() {
    document.getElementById(OVERLAY_ID)?.remove();
  }
  applyStyles(overlay) {
    Object.assign(overlay.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483647",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.92)",
      fontFamily: "system-ui, sans-serif"
    });
    const style = document.createElement("style");
    style.textContent = `
      #${OVERLAY_ID} .tc-block-inner {
        max-width: 480px;
        width: 90%;
        background: #111;
        border: 1px solid #333;
        border-radius: 12px;
        padding: 40px 32px 28px;
        text-align: center;
        color: #f0f0f0;
      }
      #${OVERLAY_ID} .tc-block-badge {
        display: inline-block;
        background: #dc2626;
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.12em;
        padding: 4px 10px;
        border-radius: 4px;
        margin-bottom: 16px;
        text-transform: uppercase;
      }
      #${OVERLAY_ID} .tc-block-title {
        font-size: 28px;
        font-weight: 800;
        margin: 0 0 12px;
        color: #fff;
      }
      #${OVERLAY_ID} .tc-block-body {
        font-size: 15px;
        line-height: 1.6;
        color: #aaa;
        margin: 0 0 12px;
      }
      #${OVERLAY_ID} .tc-block-reason {
        font-style: italic;
        color: #888;
        font-size: 13px;
        margin-bottom: 24px;
      }
      #${OVERLAY_ID} .tc-block-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 28px;
      }
      #${OVERLAY_ID} .tc-block-btn {
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        border: none;
      }
      #${OVERLAY_ID} .tc-block-btn--primary {
        background: #7c3aed;
        color: #fff;
      }
      #${OVERLAY_ID} .tc-block-btn--ghost {
        background: transparent;
        color: #666;
        font-size: 12px;
      }
      #${OVERLAY_ID} .tc-block-btn--ghost:hover { color: #999; }
      #${OVERLAY_ID} .tc-block-footer {
        font-size: 11px;
        color: #444;
        letter-spacing: 0.05em;
      }
    `;
    document.head.appendChild(style);
  }
};

// src/pro/blocked-games-options.ts
var TILTCHECK_BLOCKED_GAMES_KEY = "tiltcheck_blocked_games";
var TILTCHECK_GAME_BLOCK_OPT_IN_KEY = "tiltcheck_game_block_opt_in";
var MAX_BLOCKED_ENTRIES = 64;
var MAX_SLUG_LENGTH = 48;
function normalizeBlockedGameSlug(value) {
  if (typeof value !== "string") return null;
  const slug = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  if (!slug || slug.length > MAX_SLUG_LENGTH) return null;
  return slug;
}
function normalizeBlockedGamesList(raw) {
  if (!Array.isArray(raw)) return [];
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const item of raw) {
    const slug = normalizeBlockedGameSlug(item);
    if (!slug || seen.has(slug)) continue;
    seen.add(slug);
    out.push(slug);
    if (out.length >= MAX_BLOCKED_ENTRIES) break;
  }
  return out;
}
async function loadBlockedGameSlugs() {
  try {
    const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_GAMES_KEY);
    return normalizeBlockedGamesList(stored[TILTCHECK_BLOCKED_GAMES_KEY]);
  } catch {
    return [];
  }
}
async function loadGameBlockOptIn() {
  try {
    const stored = await chrome.storage.local.get(TILTCHECK_GAME_BLOCK_OPT_IN_KEY);
    return stored[TILTCHECK_GAME_BLOCK_OPT_IN_KEY] === true;
  } catch {
    return false;
  }
}

// src/pro/containment.ts
var TILTCHECK_SAFETY_ROOT_IDS = [
  "tiltcheck-lockdown-root",
  "tiltcheck-local-game-block-overlay",
  "tiltcheck-cooldown-overlay",
  "tiltcheck-game-block-overlay",
  "tiltcheck-redeem-nudge",
  "tiltcheck-sidebar",
  "tiltcheck-mobile-license-hud"
];
function isInsideTiltcheckSafetyRoot(node) {
  if (!node || typeof Element === "undefined" || !(node instanceof Element)) {
    return false;
  }
  for (const id of TILTCHECK_SAFETY_ROOT_IDS) {
    if (node.closest(`#${id}`)) {
      return true;
    }
  }
  return false;
}
function mutationsOnlyTouchSafetyRoots(mutations) {
  const nodes = [];
  for (const m of mutations) {
    for (const n of m.addedNodes) {
      nodes.push(n);
    }
    if (m.target) {
      nodes.push(m.target);
    }
  }
  if (nodes.length === 0) {
    return false;
  }
  return nodes.every((n) => {
    if (typeof Element === "undefined" || !(n instanceof Element)) {
      return true;
    }
    return isInsideTiltcheckSafetyRoot(n);
  });
}

// src/pro/local-game-blocker.ts
var LOCAL_OVERLAY_ID = "tiltcheck-local-game-block-overlay";
var SANITIZED_ATTR = "data-tiltcheck-local-blocked";
var PLACEHOLDER_LABEL = "[ GAME EXCLUDED ]";
var LocalGameBlocker = class {
  blockedSlugs = [];
  enforcementEnabled = false;
  observer = null;
  scanScheduled = false;
  storageListenerAttached = false;
  handleStorageChange = (changes, area) => {
    if (area !== "local") return;
    if (changes[TILTCHECK_BLOCKED_GAMES_KEY] || changes[TILTCHECK_GAME_BLOCK_OPT_IN_KEY]) {
      void this.reloadAndScan();
    }
  };
  async init() {
    await this.reloadAndScan();
    this.startObserver();
    this.attachStorageListener();
  }
  resume(_source = "navigation") {
    void this.reloadAndScan();
  }
  destroy() {
    this.observer?.disconnect();
    this.observer = null;
    if (this.storageListenerAttached) {
      try {
        chrome.storage.onChanged.removeListener(this.handleStorageChange);
      } catch {
      }
      this.storageListenerAttached = false;
    }
    this.removeUrlOverlay();
  }
  attachStorageListener() {
    if (this.storageListenerAttached) return;
    try {
      chrome.storage.onChanged.addListener(this.handleStorageChange);
      this.storageListenerAttached = true;
    } catch {
    }
  }
  async reloadAndScan() {
    this.enforcementEnabled = await loadGameBlockOptIn();
    this.blockedSlugs = this.enforcementEnabled ? await loadBlockedGameSlugs() : [];
    this.scan();
  }
  scheduleScan() {
    if (this.scanScheduled) return;
    this.scanScheduled = true;
    const run = () => {
      this.scanScheduled = false;
      this.scan();
    };
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(run);
    } else {
      setTimeout(run, 0);
    }
  }
  scan() {
    if (this.blockedSlugs.length === 0) {
      this.removeUrlOverlay();
      return;
    }
    const urlHit = this.matchUrl(window.location.href, this.blockedSlugs);
    if (urlHit) {
      this.injectUrlOverlay(urlHit);
      return;
    }
    this.removeUrlOverlay();
    this.redactDomMatches();
  }
  /** Returns matched slug when URL path/search references a blocked game. */
  matchUrl(href, slugs = this.blockedSlugs) {
    let pathSearch = "";
    try {
      const u = new URL(href, window.location.origin);
      pathSearch = `${u.pathname}${u.search}`.toLowerCase();
    } catch {
      pathSearch = href.toLowerCase();
    }
    for (const slug of slugs) {
      if (this.pathContainsSlug(pathSearch, slug)) {
        return slug;
      }
    }
    return null;
  }
  pathContainsSlug(pathSearch, slug) {
    if (pathSearch.includes(`/${slug}/`) || pathSearch.includes(`/${slug}`)) {
      return true;
    }
    if (pathSearch.includes(`games/${slug}`) || pathSearch.includes(`game/${slug}`)) {
      return true;
    }
    const segmentMatch = pathSearch.split(/[/?#&=_-]+/).includes(slug);
    return segmentMatch;
  }
  redactDomMatches() {
    const nodesBySlug = this.collectBlockedNodes();
    for (const [slug, nodes] of nodesBySlug) {
      for (const node of nodes) {
        this.sanitizeNode(node, slug);
      }
    }
  }
  /** Single-pass DOM scan: map each blocked slug to nodes that reference it. */
  collectBlockedNodes() {
    const buckets = /* @__PURE__ */ new Map();
    for (const slug of this.blockedSlugs) {
      buckets.set(slug, /* @__PURE__ */ new Set());
    }
    const tryAdd = (el, slug) => {
      if (!el || !(el instanceof HTMLElement)) return;
      if (isInsideTiltcheckSafetyRoot(el)) return;
      if (el.closest(`#${LOCAL_OVERLAY_ID}`)) return;
      const card = el.closest('a, button, [role="button"], article, li, div');
      buckets.get(slug)?.add(card ?? el);
    };
    const slugLowers = this.blockedSlugs.map((s) => ({ slug: s, lower: s.toLowerCase() }));
    for (const anchor of document.querySelectorAll("a[href]")) {
      const href = (anchor.getAttribute("href") ?? "").toLowerCase();
      for (const { slug, lower } of slugLowers) {
        if (href.includes(lower)) {
          tryAdd(anchor, slug);
        }
      }
    }
    for (const el of document.querySelectorAll(
      '[data-game-name], [data-game-id], [data-game], [data-testid*="game"]'
    )) {
      const blob = [
        el.getAttribute("data-game-name"),
        el.getAttribute("data-game-id"),
        el.getAttribute("data-game"),
        el.getAttribute("data-testid"),
        el.textContent
      ].filter(Boolean).join(" ").toLowerCase();
      for (const { slug, lower } of slugLowers) {
        if (blob.includes(lower)) {
          tryAdd(el, slug);
        }
      }
    }
    const result = /* @__PURE__ */ new Map();
    for (const [slug, set] of buckets) {
      if (set.size > 0) {
        result.set(slug, [...set]);
      }
    }
    return result;
  }
  disableInteractiveTarget(target) {
    target.style.pointerEvents = "none";
    if (target instanceof HTMLButtonElement) {
      target.disabled = true;
    }
    if (target.getAttribute("role") === "button") {
      target.setAttribute("aria-disabled", "true");
      target.tabIndex = -1;
    }
  }
  sanitizeNode(target, slug) {
    if (target.getAttribute(SANITIZED_ATTR) === slug) return;
    const placeholder = document.createElement("div");
    placeholder.setAttribute(SANITIZED_ATTR, slug);
    placeholder.setAttribute("aria-label", `Game excluded: ${slug}`);
    placeholder.style.cssText = `
      background: #1a1d24;
      color: #ff4a4a;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 72px;
      height: 100%;
      width: 100%;
      font-family: ui-monospace, monospace;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      border: 1px dashed #ff4a4a;
      border-radius: 4px;
      box-sizing: border-box;
      pointer-events: none;
      user-select: none;
    `;
    placeholder.textContent = PLACEHOLDER_LABEL;
    if (target.tagName === "A") {
      const wrap = document.createElement("div");
      wrap.setAttribute(SANITIZED_ATTR, slug);
      wrap.style.pointerEvents = "none";
      wrap.appendChild(placeholder);
      target.replaceChildren(wrap);
      target.removeAttribute("href");
      this.disableInteractiveTarget(target);
      target.setAttribute(SANITIZED_ATTR, slug);
      return;
    }
    target.replaceChildren(placeholder);
    this.disableInteractiveTarget(target);
    target.setAttribute(SANITIZED_ATTR, slug);
  }
  injectUrlOverlay(slug) {
    if (document.getElementById(LOCAL_OVERLAY_ID)) return;
    const overlay = document.createElement("div");
    overlay.id = LOCAL_OVERLAY_ID;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-label", `Access denied: ${slug} is on your exclusion list`);
    Object.assign(overlay.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483646",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(10, 12, 16, 0.97)",
      fontFamily: "ui-monospace, monospace",
      color: "#f5f5f5",
      padding: "24px",
      boxSizing: "border-box"
    });
    overlay.innerHTML = `
      <div style="max-width: 420px; text-align: center; border: 1px solid #333; border-radius: 12px; padding: 32px 24px; background: #111;">
        <div style="color: #ff4a4a; font-size: 11px; font-weight: 800; letter-spacing: 0.2em; margin-bottom: 12px;">STRATEGIC FILTER</div>
        <h2 style="margin: 0 0 12px; font-size: 22px; font-weight: 900; color: #fff;">Access denied.</h2>
        <p style="margin: 0 0 8px; font-size: 14px; line-height: 1.5; color: #aaa;">
          <strong style="color: #ff4a4a;">${slug}</strong> is on your local exclusion list.
        </p>
        <p style="margin: 0 0 20px; font-size: 12px; line-height: 1.45; color: #666;">
          Past-you removed this game type from your interface. Edit the list in extension settings (Pro).
        </p>
        <button type="button" id="tiltcheck-local-block-back" style="
          background: transparent;
          border: 1px solid #444;
          color: #ccc;
          padding: 10px 18px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          text-transform: uppercase;
          letter-spacing: 0.06em;
        ">Go back</button>
        <footer style="margin-top: 20px; font-size: 10px; color: #444;">Made for Degens. By Degens.</footer>
      </div>
    `;
    document.body.appendChild(overlay);
    document.getElementById("tiltcheck-local-block-back")?.addEventListener("click", () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.assign("/");
      }
    });
  }
  removeUrlOverlay() {
    document.getElementById(LOCAL_OVERLAY_ID)?.remove();
  }
  startObserver() {
    if (!document.body) return;
    this.observer = new MutationObserver((mutations) => {
      if (mutationsOnlyTouchSafetyRoots(mutations)) {
        return;
      }
      this.scheduleScan();
    });
    this.observer.observe(document.body, { childList: true, subtree: true });
  }
};

// src/touch-grass-timeout.ts
var TOUCH_GRASS_DURATION_MS = 12e4;
var MESSAGE_ROTATE_MS = 2e4;
var MESSAGE_FADE_SWAP_MS = 450;
var BREAK_MESSAGES = [
  "Click velocity anomaly detected. Your brain is scrambling to patch a sudden dopamine drop, not a mathematical edge.",
  "Fact: Fast-clicking alters nothing but the speed at which the house edge resolves against your balance.",
  "House algorithms monitor pacing. When you accelerate play, you transition from choice to pure execution of the machine's loop.",
  "Drop your shoulders. Unclench your jaw. Exhale completely. Mechanically cut the physical adrenaline loop.",
  "The platform has a memory; house telemetry tracks your live click-velocity to categorize your risk and volatility tolerance in real time.",
  "Turbo spins and short-cycling cut off your brain's natural evaluation window. The house relies on your auto-pilot.",
  "Prefrontal cortex (rational limit) is offline. Amygdala (fight-or-flight) is driving. You cannot out-gamble a system while hijacked.",
  "Inhale for 4 seconds. Exhale for 4 seconds. Let the neural chemical spike clear before the layout unlocks."
];
var LOCKDOWN_ROOT_ID = "tiltcheck-lockdown-root";
var MESSAGE_EL_ID = "tiltcheck-lockdown-message";
var TIMER_ID = "lockdown-timer";
var overlayActive = false;
function blockBettingUI(block) {
  const betButtons = document.querySelectorAll(
    'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
  );
  betButtons.forEach((btn) => {
    if (block) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = true;
      }
      btn.style.opacity = "0.5";
      btn.style.cursor = "not-allowed";
      btn.dataset.tiltguardBlocked = "true";
    } else if (btn.dataset.tiltguardBlocked) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = false;
      }
      btn.style.opacity = "";
      btn.style.cursor = "";
      delete btn.dataset.tiltguardBlocked;
    }
  });
}
function injectLockdownStyles(root) {
  const style = document.createElement("style");
  style.textContent = `
    #${LOCKDOWN_ROOT_ID} {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: #0f1115 !important;
      z-index: 2147483647 !important;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace;
      color: #ff4a4a;
      box-sizing: border-box;
      padding: 1.5rem;
      overflow-y: auto;
      user-select: none;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-inner {
      width: 100%;
      max-width: 32rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-eyebrow {
      font-size: 0.6875rem;
      font-weight: 800;
      letter-spacing: 0.28em;
      text-transform: uppercase;
      color: #ff4a4a;
      margin-bottom: 0.75rem;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-headline {
      font-size: 1.625rem;
      font-weight: 900;
      letter-spacing: -0.02em;
      color: #ffffff;
      margin: 0 0 0.75rem;
      line-height: 1.15;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-reason {
      font-size: 0.875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.82);
      margin: 0 0 1.25rem;
      max-width: 28rem;
    }

    /* Center stage: pacer ring + timer digits */
    .tiltcheck-pacer-stage {
      position: relative;
      width: 250px;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 2rem 0;
    }

    .tiltcheck-breath-pacer {
      position: absolute;
      width: 200px;
      height: 200px;
      border: 4px solid #ff4a4a;
      border-radius: 50%;
      box-shadow: 0 0 15px rgba(255, 74, 74, 0.2);
      animation: tiltcheck-breath-pacer 8s ease-in-out infinite;
      pointer-events: none;
    }

    #${TIMER_ID} {
      font-size: 3.5rem;
      font-weight: bold;
      color: #ffffff;
      z-index: 10;
      font-variant-numeric: tabular-nums;
      line-height: 1;
      text-shadow: 0 2px 20px rgba(0, 0, 0, 0.5);
    }

    @keyframes tiltcheck-breath-pacer {
      0%, 100% {
        transform: scale(0.6);
        opacity: 0.3;
        box-shadow: 0 0 10px rgba(255, 74, 74, 0.1);
      }
      50% {
        transform: scale(1.1);
        opacity: 0.9;
        border-color: #4affb4;
        box-shadow: 0 0 30px rgba(74, 255, 180, 0.4);
      }
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-breath-hint {
      position: absolute;
      bottom: -2.25rem;
      left: 50%;
      transform: translateX(-50%);
      width: 18rem;
      font-size: 0.625rem;
      opacity: 0.55;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: rgba(255, 255, 255, 0.55);
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-signal-label {
      font-size: 0.625rem;
      font-weight: 800;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: rgba(255, 74, 74, 0.65);
      margin-bottom: 0.5rem;
      align-self: stretch;
      text-align: left;
    }

    #${MESSAGE_EL_ID} {
      font-size: 0.875rem;
      line-height: 1.5;
      margin: 0;
      text-align: left;
      min-height: 4.5em;
      align-self: stretch;
      color: rgba(245, 245, 245, 0.94);
      transition: opacity 0.45s ease;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-foot {
      font-size: 0.6875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.45);
      margin: 1.25rem 0 0;
      max-width: 26rem;
    }
  `;
  root.insertBefore(style, root.firstChild);
}
function triggerTouchGrassTimeout(reason, durationMs = TOUCH_GRASS_DURATION_MS) {
  if (overlayActive) {
    return;
  }
  overlayActive = true;
  blockBettingUI(true);
  const existing = document.getElementById(LOCKDOWN_ROOT_ID);
  if (existing) {
    existing.remove();
  }
  const root = document.createElement("div");
  root.id = LOCKDOWN_ROOT_ID;
  root.setAttribute("role", "dialog");
  root.setAttribute("aria-modal", "true");
  root.setAttribute(
    "aria-label",
    "Touch Grass timeout \u2014 session pause with breathing pacer and rotating guidance"
  );
  injectLockdownStyles(root);
  const inner = document.createElement("div");
  inner.className = "tiltcheck-lockdown-inner";
  const eyebrow = document.createElement("div");
  eyebrow.className = "tiltcheck-eyebrow";
  eyebrow.textContent = "Touch Grass Timeout";
  const headline = document.createElement("h1");
  headline.className = "tiltcheck-lockdown-headline";
  headline.textContent = "Hold the line. Recalibrate.";
  const reasonEl = document.createElement("p");
  reasonEl.className = "tiltcheck-lockdown-reason";
  reasonEl.textContent = reason;
  const stage = document.createElement("div");
  stage.className = "tiltcheck-pacer-stage";
  const breathRing = document.createElement("div");
  breathRing.className = "tiltcheck-breath-pacer";
  breathRing.setAttribute("aria-hidden", "true");
  const timerWrap = document.createElement("div");
  timerWrap.id = TIMER_ID;
  timerWrap.setAttribute("aria-live", "polite");
  timerWrap.setAttribute("aria-atomic", "true");
  const breathHint = document.createElement("div");
  breathHint.className = "tiltcheck-breath-hint";
  breathHint.textContent = "Inhale as the ring expands \u2014 exhale as it releases.";
  const signalLabel = document.createElement("div");
  signalLabel.className = "tiltcheck-signal-label";
  signalLabel.textContent = "Signal";
  const messageRegion = document.createElement("div");
  messageRegion.className = "tiltcheck-signal-region";
  messageRegion.setAttribute("role", "region");
  messageRegion.setAttribute("aria-label", "System message updates every 20 seconds");
  const messageEl = document.createElement("p");
  messageEl.id = MESSAGE_EL_ID;
  messageEl.setAttribute("aria-live", "off");
  messageEl.textContent = BREAK_MESSAGES[0] ?? "";
  const foot = document.createElement("p");
  foot.className = "tiltcheck-lockdown-foot";
  foot.textContent = "This tab stays locked until the counter hits zero. No dismiss. Future settings: explicit opt-in for duration and policy.";
  stage.appendChild(breathRing);
  stage.appendChild(timerWrap);
  stage.appendChild(breathHint);
  inner.appendChild(eyebrow);
  inner.appendChild(headline);
  inner.appendChild(reasonEl);
  inner.appendChild(stage);
  messageRegion.appendChild(messageEl);
  inner.appendChild(signalLabel);
  inner.appendChild(messageRegion);
  inner.appendChild(foot);
  root.appendChild(inner);
  document.body.appendChild(root);
  const stopBlocking = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const captureOpts = { capture: true };
  root.addEventListener("click", stopBlocking, captureOpts);
  root.addEventListener("mousedown", stopBlocking, captureOpts);
  root.addEventListener("mouseup", stopBlocking, captureOpts);
  root.addEventListener("keydown", stopBlocking, captureOpts);
  root.addEventListener("touchstart", stopBlocking, captureOpts);
  document.addEventListener("keydown", stopBlocking, captureOpts);
  let messageIndex = 0;
  let pendingFadeTimeout = null;
  const clearPendingFade = () => {
    if (pendingFadeTimeout !== null) {
      clearTimeout(pendingFadeTimeout);
      pendingFadeTimeout = null;
    }
  };
  const messageRotateIntervalId = window.setInterval(() => {
    if (!document.getElementById(LOCKDOWN_ROOT_ID) || !messageEl.isConnected) {
      clearInterval(messageRotateIntervalId);
      return;
    }
    messageIndex = (messageIndex + 1) % BREAK_MESSAGES.length;
    messageEl.style.opacity = "0";
    clearPendingFade();
    pendingFadeTimeout = window.setTimeout(() => {
      pendingFadeTimeout = null;
      if (!messageEl.isConnected) return;
      messageEl.textContent = BREAK_MESSAGES[messageIndex] ?? "";
      messageEl.style.opacity = "1";
    }, MESSAGE_FADE_SWAP_MS);
  }, MESSAGE_ROTATE_MS);
  let countdownIntervalId = null;
  const started = Date.now();
  const finish = () => {
    if (countdownIntervalId !== null) {
      clearInterval(countdownIntervalId);
      countdownIntervalId = null;
    }
    clearInterval(messageRotateIntervalId);
    clearPendingFade();
    root.remove();
    document.removeEventListener("keydown", stopBlocking, captureOpts);
    blockBettingUI(false);
    overlayActive = false;
  };
  const tick = () => {
    const left = Math.max(0, durationMs - (Date.now() - started));
    const sec = Math.ceil(left / 1e3);
    timerWrap.textContent = `${sec}`;
    if (left <= 0) {
      finish();
    }
  };
  tick();
  countdownIntervalId = window.setInterval(tick, 250);
}

// src/web-app-session-sync.ts
var WEB_TOKEN_STORAGE_KEY = "tc_token";
function marketingSiteHosts() {
  try {
    const host = new URL(EXT_CONFIG.WEB_APP_URL).hostname.toLowerCase();
    const hosts = [host];
    if (!host.startsWith("www.")) {
      hosts.push(`www.${host}`);
    }
    return hosts;
  } catch {
    return ["tiltcheck.me", "www.tiltcheck.me"];
  }
}
function isTiltCheckMarketingSite(hostname2) {
  return marketingSiteHosts().includes(hostname2.toLowerCase());
}
function injectLocalStorageSet(key, value) {
  const keyLit = JSON.stringify(key);
  const valLit = value === null ? "null" : JSON.stringify(value);
  const script = document.createElement("script");
  script.textContent = `(function(){try{var k=${keyLit};var v=${valLit};if(v===null){localStorage.removeItem(k);}else{localStorage.setItem(k,v);}window.dispatchEvent(new CustomEvent("tiltcheck-ext-session-sync"));}catch(_){}})();`;
  (document.documentElement || document.head).appendChild(script);
  script.remove();
}
function syncMarketingSiteTokenFromExtensionStorage() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) return;
  if (!isTiltCheckMarketingSite(window.location.hostname)) return;
  chrome.storage.local.get(["authToken"], (data) => {
    const token = typeof data.authToken === "string" && data.authToken ? data.authToken : null;
    injectLocalStorageSet(WEB_TOKEN_STORAGE_KEY, token);
  });
}
function attachMarketingSiteStorageListener() {
  if (typeof chrome === "undefined" || !chrome.storage?.onChanged) return;
  if (!isTiltCheckMarketingSite(window.location.hostname)) return;
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.authToken) return;
    const raw = changes.authToken.newValue;
    const token = typeof raw === "string" && raw ? raw : null;
    injectLocalStorageSet(WEB_TOKEN_STORAGE_KEY, token);
  });
}

// src/pro-monolith-bootstrap.ts
function isDomain(hostname2, domain) {
  return hostname2 === domain || hostname2.endsWith("." + domain);
}
var hostname = window.location.hostname.toLowerCase();
var pathname = window.location.pathname.toLowerCase();
var isDiscordAuthRoute = pathname.startsWith("/auth/discord");
var isExcludedDomain = isDomain(hostname, "discord.com") || hostname === "localhost" && window.location.port === "3333" || hostname === "localhost" && window.location.port === "3001" && isDiscordAuthRoute || isDomain(hostname, "api.tiltcheck.me") && isDiscordAuthRoute;
if (isExcludedDomain) {
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] Skipping - excluded domain:", hostname);
}
var ANALYZER_WS_URL = "wss://api.tiltcheck.me/analyzer";
var extractor = null;
var tiltDetector = null;
var licenseVerifier = null;
var client = null;
var sessionId = null;
var stopObserving = null;
var isMonitoring = false;
var casinoVerification = null;
var analyzer = null;
var fairness = null;
var tiltMonitoringInterval = null;
var sidebar = null;
var gameBlocker = null;
var localGameBlocker = null;
var analysisRuntimeReady = false;
var initializationComplete = false;
var runtimeBootPromise = null;
var runtimeListenersAttached = false;
var spaResumeWatchInstalled = false;
var fairnessPlayObserver = null;
var proMonolithActive = false;
var injectionDisabled = false;
var lastAnalysisBlockMessage = null;
var SIDEBAR_VISIBILITY_KEY2 = "tiltcheck_sidebar_visible";
var SITE_REDEEM_THRESHOLDS_KEY2 = "tiltcheck_site_thresholds";
var SUPPORT_INTERVENTION_COOLDOWN_MS = 10 * 60 * 1e3;
var cooldownEndTime = null;
var lastRedeemNudgeBalance = null;
var lastRedeemNudgeThreshold = 0;
var lastSupportInterventionByType = {};
function normalizeInterventionData(data) {
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    return {};
  }
  return data;
}
function isFairnessCommitment(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }
  const record = value;
  return typeof record.discordId === "string" && typeof record.clientSeed === "string" && typeof record.timestamp === "number";
}
function normalizeSiteHost(value) {
  return value.replace(/^www\./, "").toLowerCase();
}
function getStoredSiteRedeemThresholds(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }
  const thresholds = {};
  for (const [host, rawValue] of Object.entries(value)) {
    const threshold = Number(rawValue);
    if (Number.isFinite(threshold) && threshold > 0) {
      thresholds[normalizeSiteHost(host)] = threshold;
    }
  }
  return thresholds;
}
function shouldShowRedeemNudge(data) {
  if (document.getElementById("tiltcheck-redeem-nudge")) return false;
  const threshold = Number(data.threshold) || 0;
  if (threshold <= 0) return false;
  const amount = Number(data.amount) || 0;
  const thresholdChanged = threshold !== lastRedeemNudgeThreshold;
  const meaningfulGain = lastRedeemNudgeBalance !== null && amount >= lastRedeemNudgeBalance + Math.max(5, threshold * 0.1);
  if (thresholdChanged || lastRedeemNudgeBalance === null || meaningfulGain) {
    lastRedeemNudgeThreshold = threshold;
    lastRedeemNudgeBalance = amount;
    return true;
  }
  return false;
}
function refreshLicenseVerification() {
  if (!licenseVerifier) {
    licenseVerifier = new CasinoLicenseVerifier();
  }
  casinoVerification = licenseVerifier.verifyCasino();
  sidebar?.updateLicense(casinoVerification);
  updateMobileLicenseHud(casinoVerification);
  if (initializationComplete) {
    applyAnalysisGate(casinoVerification);
  }
  return casinoVerification;
}
function ensureAnalysisRuntime() {
  if (analysisRuntimeReady) {
    return;
  }
  analyzer = new Analyzer();
  fairness = new FairnessService();
  setupFairnessListeners();
  analysisRuntimeReady = true;
}
function applyAnalysisGate(verification) {
  const blockMessage = getAnalysisBlockMessage(verification);
  if (!blockMessage) {
    lastAnalysisBlockMessage = null;
    if (!analysisRuntimeReady) {
      ensureAnalysisRuntime();
    }
    if (!isMonitoring) {
      void startMonitoring().catch((err) => {
        console.warn("[TiltCheck] Auto-start monitoring failed:", err);
      });
    }
    return;
  }
  if (isMonitoring) {
    _stopMonitoring();
  } else {
    sidebar?.updateRealityCheck(false);
  }
  const statusType = verification.verdict === "suspicious" ? "danger" : "warning";
  sidebar?.updateStatus(blockMessage, statusType);
  if (lastAnalysisBlockMessage !== blockMessage) {
    sidebar?.addFeedMessage(blockMessage);
    lastAnalysisBlockMessage = blockMessage;
  }
}
function notifySupportIntervention(type, data) {
  const lastSentAt = lastSupportInterventionByType[type] || 0;
  if (Date.now() - lastSentAt < SUPPORT_INTERVENTION_COOLDOWN_MS) {
    return false;
  }
  lastSupportInterventionByType[type] = Date.now();
  sidebar?.notifyBuddy("intervention", { type, data });
  return true;
}
function setSidebarVisibility(visible) {
  const sidebar2 = document.getElementById("tiltcheck-sidebar");
  if (!sidebar2) return false;
  sidebar2.style.display = visible ? "block" : "none";
  return visible;
}
function persistSidebarVisibility(visible) {
  try {
    chrome.storage.local.set({ [SIDEBAR_VISIBILITY_KEY2]: visible });
  } catch {
  }
}
async function restoreSidebarVisibility(defaultVisible) {
  try {
    const stored = await chrome.storage.local.get([SIDEBAR_VISIBILITY_KEY2]);
    if (typeof stored[SIDEBAR_VISIBILITY_KEY2] === "boolean") {
      setSidebarVisibility(stored[SIDEBAR_VISIBILITY_KEY2]);
      return;
    }
  } catch {
  }
  setSidebarVisibility(defaultVisible);
}
function toggleSidebarVisibility() {
  const sidebarEl = document.getElementById("tiltcheck-sidebar");
  if (!sidebarEl) {
    sidebar = initSidebar(disableInjectionFromHud);
    persistSidebarVisibility(true);
    return true;
  }
  const currentlyVisible = sidebarEl.style.display !== "none";
  const visible = setSidebarVisibility(!currentlyVisible);
  persistSidebarVisibility(visible);
  return visible;
}
function getSidebarState() {
  const sidebar2 = document.getElementById("tiltcheck-sidebar");
  return {
    exists: !!sidebar2,
    visible: !!sidebar2 && sidebar2.style.display !== "none",
    injectionDisabled
  };
}
async function getStoredInjectionDisabled() {
  try {
    const stored = await chrome.storage.local.get([INJECTION_DISABLED_KEY]);
    return stored[INJECTION_DISABLED_KEY] === true;
  } catch {
    return false;
  }
}
async function setInjectionDisabled(disabled) {
  injectionDisabled = disabled;
  try {
    await chrome.storage.local.set({ [INJECTION_DISABLED_KEY]: disabled });
  } catch {
  }
}
function waitForDocumentEnd() {
  if (document.readyState !== "loading" && document.body) {
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    const resolveWhenReady = () => {
      if (document.body) {
        document.removeEventListener("DOMContentLoaded", resolveWhenReady);
        resolve();
      }
    };
    document.addEventListener("DOMContentLoaded", resolveWhenReady, { once: true });
    setTimeout(resolveWhenReady, 0);
  });
}
var PRO_UI_ROOT_IDS = [
  "tiltcheck-sidebar",
  "tiltcheck-sidebar-root",
  "tiltcheck-sidebar-container",
  "tiltcheck-game-block-overlay",
  "tiltcheck-local-game-block-overlay",
  "tiltcheck-cooldown-overlay",
  "tiltcheck-redeem-nudge",
  "tiltcheck-mobile-license-hud"
];
function removeProUiSurfaces() {
  for (const id of PRO_UI_ROOT_IDS) {
    document.getElementById(id)?.remove();
  }
}
function teardownInjectedRuntime() {
  if (isMonitoring) {
    _stopMonitoring();
  }
  if (fairnessPlayObserver) {
    fairnessPlayObserver.disconnect();
    fairnessPlayObserver = null;
  }
  gameBlocker?.destroy();
  gameBlocker = null;
  localGameBlocker?.destroy();
  localGameBlocker = null;
  extractor = null;
  tiltDetector = null;
  casinoVerification = null;
  sessionId = null;
  initializationComplete = false;
  lastAnalysisBlockMessage = null;
  analysisRuntimeReady = false;
  analyzer = null;
  fairness = null;
  removeProUiSurfaces();
  sidebar = null;
}
async function disableInjectionFromHud() {
  await setInjectionDisabled(true);
  teardownInjectedRuntime();
}
async function resumeRuntimeAfterNavigation(source) {
  if (isExcludedDomain || injectionDisabled) {
    return;
  }
  if (!initializationComplete) {
    await startRuntimeAtDocumentEnd();
    return;
  }
  if (!document.getElementById("tiltcheck-sidebar")) {
    sidebar = initSidebar(disableInjectionFromHud);
    const defaultVisible = !isDomain(hostname, "tiltcheck.me");
    void restoreSidebarVisibility(defaultVisible);
  }
  syncMarketingSiteTokenFromExtensionStorage();
  attachMarketingSiteStorageListener();
  const verification = refreshLicenseVerification();
  applyAnalysisGate(verification);
  gameBlocker?.resume(source);
  localGameBlocker?.resume(source);
}
function installSpaResumeWatch() {
  if (spaResumeWatchInstalled) {
    return;
  }
  spaResumeWatchInstalled = true;
  let lastUrl = window.location.href;
  let pending = false;
  const queueResume = (source) => {
    if (pending) {
      return;
    }
    pending = true;
    queueMicrotask(() => {
      pending = false;
      const currentUrl = window.location.href;
      if (currentUrl === lastUrl && source !== "pageshow") {
        return;
      }
      lastUrl = currentUrl;
      void resumeRuntimeAfterNavigation(source);
    });
  };
  const patchHistoryMethod = (method) => {
    const original = window.history[method];
    if (original.__tiltcheckPatched) {
      return;
    }
    const patched = function patchedHistoryMethod(...args) {
      const result = original.apply(this, args);
      queueResume(method);
      return result;
    };
    Object.defineProperty(patched, "__tiltcheckPatched", { value: true });
    window.history[method] = patched;
  };
  patchHistoryMethod("pushState");
  patchHistoryMethod("replaceState");
  window.addEventListener("popstate", () => queueResume("popstate"));
  window.addEventListener("hashchange", () => queueResume("hashchange"));
  window.addEventListener("pageshow", () => queueResume("pageshow"));
}
async function startRuntimeAtDocumentEnd(options = {}) {
  if (isExcludedDomain) {
    return;
  }
  if (runtimeBootPromise) {
    await runtimeBootPromise;
    return;
  }
  runtimeBootPromise = (async () => {
    await waitForDocumentEnd();
    installSpaResumeWatch();
    if (options.forceEnable) {
      await setInjectionDisabled(false);
    } else {
      injectionDisabled = await getStoredInjectionDisabled();
    }
    if (injectionDisabled) {
      teardownInjectedRuntime();
      return;
    }
    initialize();
  })().finally(() => {
    runtimeBootPromise = null;
  });
  await runtimeBootPromise;
}
async function openRuntimeFromToolbar() {
  if (injectionDisabled || await getStoredInjectionDisabled()) {
    await startRuntimeAtDocumentEnd({ forceEnable: true });
    const sidebarEl = document.getElementById("tiltcheck-sidebar");
    if (!sidebarEl) {
      sidebar = initSidebar(disableInjectionFromHud);
    }
    const visible2 = setSidebarVisibility(true);
    persistSidebarVisibility(true);
    return { success: true, visible: visible2, injectionDisabled: false };
  }
  const visible = toggleSidebarVisibility();
  return { success: true, visible, injectionDisabled: false };
}
var VisualPicker = class {
  overlay = null;
  active = false;
  callback = null;
  start(callback) {
    if (this.active) return;
    this.active = true;
    this.callback = callback;
    this.overlay = document.createElement("div");
    this.overlay.style.cssText = `
      position: fixed;
      pointer-events: none;
      background: rgba(0, 255, 136, 0.2);
      border: 2px solid #00ff88;
      z-index: 2147483647;
      transition: all 0.1s;
      display: none;
      border-radius: 4px;
    `;
    document.body.appendChild(this.overlay);
    document.addEventListener("mousemove", this.onHover, true);
    document.addEventListener("click", this.onClick, true);
    document.body.style.cursor = "crosshair";
  }
  stop() {
    this.active = false;
    this.callback = null;
    if (this.overlay) this.overlay.remove();
    document.removeEventListener("mousemove", this.onHover, true);
    document.removeEventListener("click", this.onClick, true);
    document.body.style.cursor = "";
  }
  onHover = (e) => {
    if (!this.overlay) return;
    const target = e.target;
    if (target === this.overlay || target.closest("#tiltcheck-sidebar")) return;
    const rect = target.getBoundingClientRect();
    this.overlay.style.display = "block";
    this.overlay.style.top = rect.top + "px";
    this.overlay.style.left = rect.left + "px";
    this.overlay.style.width = rect.width + "px";
    this.overlay.style.height = rect.height + "px";
  };
  onClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const target = e.target;
    if (target.closest("#tiltcheck-sidebar")) return;
    const selector = this.generateSelector(target);
    if (this.callback) this.callback(selector);
    this.stop();
  };
  generateSelector(el) {
    if (el.id && /^[a-z][a-z0-9_-]*$/i.test(el.id) && document.querySelectorAll(`#${el.id}`).length === 1) {
      return `#${el.id}`;
    }
    const dataAttrs = ["data-test", "data-testid", "data-qa", "data-automation-id"];
    for (const attr of dataAttrs) {
      if (el.hasAttribute(attr)) {
        return `[${attr}="${el.getAttribute(attr)}"]`;
      }
    }
    if (el.className && typeof el.className === "string") {
      const classes = el.className.trim().split(/\s+/).filter((c) => c && !c.includes(":"));
      if (classes.length > 0) {
        for (const cls of classes) {
          if (document.querySelectorAll(`.${cls}`).length === 1) return `.${cls}`;
        }
      }
    }
    const path = [];
    let current = el;
    while (current && current !== document.body && current !== document.documentElement) {
      let selector = current.tagName.toLowerCase();
      if (current.id && /^[a-z][a-z0-9_-]*$/i.test(current.id)) {
        selector = `#${current.id}`;
        path.unshift(selector);
        break;
      } else {
        let sibling = current;
        let nth = 1;
        while (sibling.previousElementSibling) {
          sibling = sibling.previousElementSibling;
          if (sibling.tagName === current.tagName) nth++;
        }
        if (nth > 1) selector += `:nth-of-type(${nth})`;
      }
      path.unshift(selector);
      current = current.parentElement;
    }
    return path.join(" > ");
  }
};
var Highlighter = class {
  overlay = null;
  highlight(selector) {
    this.clear();
    try {
      const el = document.querySelector(selector);
      if (!el) {
        console.warn("[TiltCheck] Element not found for highlighting");
        return;
      }
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      const rect = el.getBoundingClientRect();
      this.overlay = document.createElement("div");
      this.overlay.style.cssText = `
        position: fixed;
        top: ${rect.top}px;
        left: ${rect.left}px;
        width: ${rect.width}px;
        height: ${rect.height}px;
        background: rgba(0, 255, 136, 0.2);
        border: 2px solid #00ff88;
        z-index: 2147483647;
        pointer-events: none;
        transition: all 0.3s;
        border-radius: 4px;
        box-shadow: 0 0 15px rgba(0, 255, 136, 0.4);
      `;
      document.body.appendChild(this.overlay);
      setTimeout(() => this.clear(), 2e3);
    } catch (e) {
      console.error("Invalid selector", e);
    }
  }
  clear() {
    if (this.overlay) {
      this.overlay.remove();
      this.overlay = null;
    }
  }
};
function initialize() {
  if (initializationComplete) {
    return;
  }
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] Initializing on:", window.location.hostname);
  syncMarketingSiteTokenFromExtensionStorage();
  attachMarketingSiteStorageListener();
  sidebar = initSidebar(disableInjectionFromHud);
  const defaultVisible = !isDomain(hostname, "tiltcheck.me");
  void restoreSidebarVisibility(defaultVisible);
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] Sidebar created:", !!sidebar);
  updateMobileLicenseHud(null);
  const initialLicenseStatus = refreshLicenseVerification();
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltCheck] License verification:", initialLicenseStatus);
  setTimeout(() => refreshLicenseVerification(), 3e3);
  setTimeout(() => refreshLicenseVerification(), 8e3);
  if (!runtimeListenersAttached) {
    runtimeListenersAttached = true;
    const picker = new VisualPicker();
    window.addEventListener("tg-start-picker", ((e) => {
      picker.start((selector) => {
        window.dispatchEvent(new CustomEvent("tg-picker-result", { detail: { field: e.detail.field, selector } }));
      });
    }));
    const highlighter = new Highlighter();
    window.addEventListener("tg-test-selector", ((e) => {
      highlighter.highlight(e.detail.selector);
    }));
    window.addEventListener("tg-redeem-threshold-updated", ((e) => {
      if (!tiltDetector) return;
      const updatedHost = normalizeSiteHost(e.detail?.hostname || "");
      if (updatedHost && updatedHost !== normalizeSiteHost(window.location.hostname)) {
        return;
      }
      const threshold = Number(e.detail?.threshold) || 0;
      tiltDetector.setRedeemThreshold(threshold > 0 ? threshold : null);
      lastRedeemNudgeBalance = 0;
      lastRedeemNudgeThreshold = 0;
    }));
    window.addEventListener("tg-calc-fairness", (async (e) => {
      if (!fairness) return;
      const { serverSeed, clientSeed, nonce } = e.detail;
      try {
        const hash = await fairness.verifyCasinoResult(serverSeed, clientSeed, parseInt(nonce));
        const float = fairness.hashToFloat(hash);
        window.dispatchEvent(new CustomEvent("tg-fairness-result", {
          detail: {
            hash,
            float,
            dice: fairness.getDiceResult(float),
            limbo: fairness.getLimboResult(float)
          }
        }));
      } catch (err) {
        console.error("Fairness calc error", err);
      }
    }));
  }
  initializationComplete = true;
  applyAnalysisGate(initialLicenseStatus);
  if (!localGameBlocker) {
    localGameBlocker = new LocalGameBlocker();
    localGameBlocker.init().catch((err) => {
      console.warn("[TiltCheck] Local game blocker init failed:", err);
    });
  }
  setTimeout(() => {
    Promise.all([
      getLinkedDiscordId(),
      chrome.storage.local.get(["authToken"])
    ]).then(([discordId, authState]) => {
      const authToken = typeof authState.authToken === "string" ? authState.authToken : "";
      if (!discordId || !authToken) {
        return;
      }
      gameBlocker = new GameBlocker(discordId, authToken);
      gameBlocker.init().catch((err) => {
        console.warn("[TiltCheck] Game blocker init failed:", err);
      });
    }).catch(() => {
    });
  }, 500);
}
async function startMonitoring() {
  if (isMonitoring) return;
  console.log("[TiltCheck] Starting monitoring...");
  const verification = casinoVerification ?? refreshLicenseVerification();
  const blockMessage = getAnalysisBlockMessage(verification);
  if (blockMessage) {
    sidebar?.updateRealityCheck(false);
    sidebar?.updateStatus(blockMessage, verification?.verdict === "suspicious" ? "danger" : "warning");
    return;
  }
  sidebar?.updateRealityCheck(true);
  isMonitoring = true;
  extractor = new CasinoDataExtractor();
  await extractor.initialize();
  const initialBalance = extractor.extractBalance();
  peakBalance = typeof initialBalance === "number" ? initialBalance : 0;
  zeroTriggered = false;
  fumbleStrikes = 0;
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Initial balance:", initialBalance);
  const storageResult = await chrome.storage.local.get(["riskLevel", "redeemThreshold", "authToken", SITE_REDEEM_THRESHOLDS_KEY2]);
  const riskLevel = storageResult.riskLevel || "moderate";
  const siteThresholds = getStoredSiteRedeemThresholds(storageResult[SITE_REDEEM_THRESHOLDS_KEY2]);
  const siteHost = normalizeSiteHost(window.location.hostname);
  const redeemThreshold = siteThresholds[siteHost] ?? (Number(storageResult.redeemThreshold) || 0);
  const authToken = storageResult.authToken;
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Using profile:", { riskLevel, redeemThreshold, hasToken: !!authToken });
  tiltDetector = new TiltDetector(initialBalance, riskLevel, redeemThreshold);
  if (authToken) {
    const wsUrlWithAuth = `${ANALYZER_WS_URL}?token=${authToken}`;
    client = new AnalyzerClient(wsUrlWithAuth, (error) => {
      console.warn("[TiltGuard] Analyzer connection issue:", error);
      sidebar?.updateRealityCheck(false);
      window.dispatchEvent(
        new CustomEvent("tg-status-update", {
          detail: { message: "Analyzer connection dropped. Reconnecting...", type: "warning" }
        })
      );
    });
    try {
      await client.connect();
      if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Connected to analyzer server");
      sidebar?.updateRealityCheck(true);
    } catch {
      if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Analyzer backend offline - tilt monitoring only");
    }
  } else {
    if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Analyzer disabled until Discord auth is connected");
    sidebar?.updateRealityCheck(false);
  }
  const randomBytes = new Uint32Array(1);
  crypto.getRandomValues(randomBytes);
  sessionId = `session_${Date.now()}_${randomBytes[0].toString(36)}`;
  const userId = await getUserId();
  const casinoId = detectCasinoId();
  const gameId = detectGameId();
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Session started:", { sessionId, userId, casinoId, gameId });
  startTiltMonitoring();
  stopObserving = extractor.startObserving((spinData) => {
    if (!spinData) return;
    if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Spin detected:", spinData);
    if (!sessionId) {
      console.warn("[TiltGuard] Session not started, cannot record spin");
      return;
    }
    handleSpinEvent(spinData, { sessionId, userId, casinoId, gameId });
  });
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Monitoring started successfully");
}
function _stopMonitoring() {
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Stopping monitoring...");
  if (stopObserving) {
    stopObserving();
    stopObserving = null;
  }
  if (client) {
    client.disconnect();
    client = null;
  }
  if (tiltMonitoringInterval) {
    clearInterval(tiltMonitoringInterval);
    tiltMonitoringInterval = null;
  }
  isMonitoring = false;
  sidebar?.updateRealityCheck(false);
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Monitoring stopped");
}
function handleSpinEvent(spinData, session) {
  if (casinoVerification != null && !casinoVerification.shouldAnalyze) {
    return;
  }
  const bet = spinData.bet || 0;
  const payout = spinData.win || 0;
  if (tiltDetector) {
    tiltDetector.recordBet(bet, payout);
    window.dispatchEvent(
      new CustomEvent("tiltcheck-core-record-bet", { detail: { bet, payout } })
    );
    if (typeof spinData.balance === "number") {
      tiltDetector.updateBalance(spinData.balance);
    }
    const sessionSummary = tiltDetector.getSessionSummary();
    const stats = {
      startTime: sessionSummary.startTime || Date.now(),
      totalBets: sessionSummary.totalBets || 0,
      totalWagered: sessionSummary.totalWagered || 0,
      totalWon: sessionSummary.totalWon || 0
    };
    window.TiltCheckSidebar?.updateStats?.(stats);
    const redeemOpportunity = tiltDetector.detectRedeemOpportunity();
    if (redeemOpportunity) {
      if (shouldShowRedeemNudge(redeemOpportunity)) {
        showRedeemNudge(redeemOpportunity);
      }
    } else {
      lastRedeemNudgeBalance = null;
      lastRedeemNudgeThreshold = 0;
    }
    const tiltSigns = tiltDetector.detectAllTiltSigns();
    const tiltRisk = tiltDetector.getTiltRiskScore();
    const indicators = tiltSigns.map((sign) => sign.description);
    sidebar?.updateTilt(tiltRisk, indicators);
  }
  if (client && sessionId) {
    client.sendSpin({
      sessionId: session.sessionId,
      casinoId: session.casinoId,
      gameId: session.gameId,
      userId: session.userId,
      bet,
      payout,
      gameResult: spinData.gameResult,
      symbols: spinData.symbols,
      bonusRound: spinData.bonusActive,
      freeSpins: (spinData.freeSpins || 0) > 0
    });
  }
  postRoundTelemetry({
    userId: session.userId,
    bet,
    win: payout,
    sessionId: session.sessionId,
    casinoId: session.casinoId,
    gameId: session.gameId,
    timestamp: spinData.timestamp
  }).catch((err) => console.warn("[TiltCheck] Hub relay failed:", err));
  if (tiltDetector) {
    checkBagFumble(spinData.balance, tiltDetector.getSessionSummary().initialBalance);
  }
  const currentNonce = parseInt(localStorage.getItem("tiltcheck_nonce") || "0");
  const nextNonce = currentNonce + 1;
  localStorage.setItem("tiltcheck_nonce", nextNonce.toString());
  window.dispatchEvent(new CustomEvent("tg-nonce-update", { detail: { nonce: nextNonce, source: "spin" } }));
  window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: "Analyzing spin...", type: "thinking" } }));
  verifySpinFairness(spinData, session.gameId);
}
var peakBalance = 0;
var zeroTriggered = false;
var fumbleStrikes = 0;
function checkBagFumble(balance, initialBalance) {
  if (balance === null || initialBalance <= 0) return;
  if (balance > peakBalance) {
    peakBalance = balance;
  }
  const hadBigBag = peakBalance >= initialBalance * 1.5;
  const isBlowingIt = hadBigBag && balance <= initialBalance * 1.1 && balance < peakBalance * 0.5;
  const isZero = balance < 0.05;
  if ((isBlowingIt || isZero) && !zeroTriggered) {
    zeroTriggered = true;
    fumbleStrikes++;
    if (fumbleStrikes === 1) {
      showInteractiveNotification(
        isZero ? "0 BALANCE DETECTED. Hey, stop it. You're gonna be mad if you deposit again. Close the tab and go touch grass." : "BAG FUMBLE DETECTED. You were up and now you're giving it all back. Stop spinning before you ruin your week. Go touch grass.",
        [
          { text: "Close Tab", action: () => {
            window.close();
          } },
          { text: "I Won't Deposit (Lie)", action: () => {
          } }
        ]
      );
    } else {
      showInteractiveNotification(
        "REPEATED FUMBLES. You obviously aren't going to stop yourself, so I just pinged the Discord. Get in the 'degen-accountability' VC for a lifeline before you do something stupid.",
        [
          { text: "Get Yelled At (Join VC)", action: () => {
            window.open("https://discord.gg/gdBsEJfCar", "_blank");
          } },
          { text: "Ignore Me", action: () => {
          } }
        ]
      );
      notifySupportIntervention("phone_friend_discord", {
        message: "Repeated fumble detected. Get them into the accountability voice room.",
        supportActions: ["tell them to stop depositing", "tell them to cash out", "pull them into voice"],
        balance,
        initialBalance,
        peakBalance,
        strikeCount: fumbleStrikes
      });
    }
  } else if (balance >= initialBalance * 1.2 && !isBlowingIt) {
    zeroTriggered = false;
  }
}
function startTiltMonitoring() {
  if (tiltMonitoringInterval) {
    clearInterval(tiltMonitoringInterval);
  }
  tiltMonitoringInterval = setInterval(() => {
    if (!tiltDetector || !isMonitoring) return;
    const tiltSigns = tiltDetector.detectAllTiltSigns();
    const tiltRisk = tiltDetector.getTiltRiskScore();
    const indicators = tiltSigns.map((sign) => sign.description);
    sidebar?.updateTilt(tiltRisk, indicators);
    const coreOwnsTouchGrass = window.__tiltcheckCoreShieldActive === true;
    if (tiltRisk >= 80 && !coreOwnsTouchGrass) {
      triggerTouchGrassTimeout("Critical tilt detected.");
      notifySupportIntervention("critical_tilt", {
        message: "Critical tilt detected from live extension telemetry.",
        risk: tiltRisk,
        indicators
      });
    }
    const generated = tiltDetector.generateInterventions();
    if (generated.length > 0) {
      handleInterventions(generated);
    }
  }, 5e3);
}
function handleInterventions(interventions) {
  for (const intervention of interventions) {
    if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Intervention:", intervention);
    switch (intervention.type) {
      case "cooldown":
        startCooldown(intervention.data.duration);
        break;
      case "vault_balance":
        showVaultPrompt(intervention.data);
        break;
      case "spending_reminder":
        showSpendingReminder(intervention.data.realWorldComparison);
        break;
      case "stop_loss_triggered":
        triggerStopLoss(intervention.data);
        break;
      case "phone_friend":
        showPhoneFriendPrompt();
        break;
      case "session_break":
        showBreakPrompt();
        break;
      case "redeem_nudge":
        showRedeemNudge(intervention.data);
        break;
    }
    notifySupportIntervention(intervention.type, normalizeInterventionData(intervention.data));
  }
}
function startCooldown(duration) {
  cooldownEndTime = Date.now() + duration;
  blockBettingUI2(true);
  showCooldownOverlay(duration);
  const countdown = setInterval(() => {
    if (!cooldownEndTime) {
      clearInterval(countdown);
      return;
    }
    const remaining = cooldownEndTime - Date.now();
    if (remaining <= 0) {
      clearInterval(countdown);
      endCooldown();
    } else {
      updateCooldownOverlay(remaining);
    }
  }, 1e3);
}
function endCooldown() {
  cooldownEndTime = null;
  blockBettingUI2(false);
  removeCooldownOverlay();
  showNotification("Cooldown complete. Play responsibly.", "success");
}
function blockBettingUI2(block) {
  const betButtons = document.querySelectorAll(
    'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
  );
  betButtons.forEach((btn) => {
    if (block) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = true;
      }
      btn.style.opacity = "0.5";
      btn.style.cursor = "not-allowed";
      btn.dataset.tiltguardBlocked = "true";
    } else if (btn.dataset.tiltguardBlocked) {
      if (btn instanceof HTMLButtonElement) {
        btn.disabled = false;
      }
      btn.style.opacity = "";
      btn.style.cursor = "";
      delete btn.dataset.tiltguardBlocked;
    }
  });
}
function showCooldownOverlay(duration) {
  const overlay = document.createElement("div");
  overlay.id = "tiltcheck-cooldown-overlay";
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: white;
    font-family: Arial, sans-serif;
  `;
  overlay.innerHTML = `
    <div style="text-align: center;">
      <h1 style="font-size: 48px; margin-bottom: 20px;">STOP</h1>
      <h2 style="font-size: 32px; margin-bottom: 10px;">Cooldown Period</h2>
      <p style="font-size: 18px; color: #ffaa00; margin-bottom: 30px;">
        Tilt detected. Take a break.
      </p>
      <div id="cooldown-timer" style="font-size: 72px; font-weight: bold; color: #00ff88;">
        ${Math.ceil(duration / 1e3)}
      </div>
      <p style="font-size: 14px; margin-top: 20px; color: rgba(255, 255, 255, 0.7);">
        Betting will resume when the timer reaches zero.
      </p>
    </div>
  `;
  document.body.appendChild(overlay);
}
function updateCooldownOverlay(remaining) {
  const timer = document.getElementById("cooldown-timer");
  if (timer) {
    timer.textContent = Math.ceil(remaining / 1e3).toString();
  }
}
function removeCooldownOverlay() {
  const overlay = document.getElementById("tiltcheck-cooldown-overlay");
  if (overlay) overlay.remove();
}
function showVaultPrompt(vaultData) {
  const message = `Your balance is ${vaultData.suggestedAmount.toFixed(2)}. Consider vaulting to protect your winnings.`;
  showInteractiveNotification(message, [
    { text: "Vault Now", action: () => openVaultInterface(vaultData.suggestedAmount) },
    { text: "Later", action: () => {
    } }
  ]);
}
function showSpendingReminder(comparison) {
  showInteractiveNotification(comparison.message, [
    { text: "Vault & Buy", action: () => openVaultInterface(comparison.cost) },
    { text: "Remind Me Later", action: () => {
    } }
  ]);
}
function triggerStopLoss(data) {
  triggerTouchGrassTimeout(data.reason);
}
function showPhoneFriendPrompt() {
  showInteractiveNotification(
    "Multiple tilt signs detected. Consider calling someone before continuing.",
    [
      { text: "Take Break", action: () => startCooldown(5 * 60 * 1e3) },
      { text: "Continue", action: () => {
      } }
    ]
  );
}
function showBreakPrompt() {
  showInteractiveNotification(
    "You have been playing for a while. How about a quick break?",
    [
      { text: "5 Min Break", action: () => startCooldown(5 * 60 * 1e3) },
      { text: "Keep Playing", action: () => {
      } }
    ]
  );
}
function openVaultInterface(amount) {
  chrome.runtime.sendMessage({
    type: "open_vault",
    data: { suggestedAmount: amount }
  }, (response) => {
    if (response?.success) {
      showNotification("\u2713 Vault interface opened", "success");
    } else if (response?.error) {
      showNotification(`\u2717 Vault error: ${response.error}`, "error");
    }
  });
}
function showInteractiveNotification(message, actions) {
  const notification = document.createElement("div");
  notification.className = "tiltguard-notification";
  notification.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    background: rgba(0, 0, 0, 0.95);
    color: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 255, 136, 0.3);
    z-index: 999999;
    max-width: 350px;
    font-family: Arial, sans-serif;
    border: 2px solid #00ff88;
  `;
  const messageEl = document.createElement("p");
  messageEl.style.cssText = "margin-bottom: 15px; font-size: 14px; line-height: 1.4;";
  messageEl.textContent = message;
  notification.appendChild(messageEl);
  const actionsContainer = document.createElement("div");
  actionsContainer.style.cssText = "display: flex; gap: 10px;";
  for (const actionDef of actions) {
    const button = document.createElement("button");
    button.textContent = actionDef.text;
    button.style.cssText = `
      flex: 1;
      padding: 10px;
      border: none;
      border-radius: 6px;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      background: linear-gradient(135deg, #00ff88 0%, #00ccff 100%);
      color: black;
    `;
    button.addEventListener("click", () => {
      actionDef.action();
      notification.remove();
    });
    actionsContainer.appendChild(button);
  }
  notification.appendChild(actionsContainer);
  document.body.appendChild(notification);
  setTimeout(() => notification.remove(), 3e4);
}
function showNotification(message, type = "success") {
  const notification = document.createElement("div");
  const bgColors = {
    success: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
    warning: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)",
    error: "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)"
  };
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${bgColors[type]};
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    z-index: 999999;
    max-width: 350px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    animation: slideIn 0.3s ease;
  `;
  notification.textContent = message;
  document.body.appendChild(notification);
  setTimeout(() => {
    notification.style.animation = "slideOut 0.3s ease";
    setTimeout(() => notification.remove(), 300);
  }, 5e3);
}
function detectCasinoId() {
  const hostname2 = window.location.hostname.toLowerCase();
  if (isDomain(hostname2, "stake.com") || isDomain(hostname2, "stake.us")) return "stake";
  if (isDomain(hostname2, "roobet.com")) return "roobet";
  if (isDomain(hostname2, "bc.game")) return "bc-game";
  if (isDomain(hostname2, "duelbits.com")) return "duelbits";
  if (isDomain(hostname2, "rollbit.com")) return "rollbit";
  if (isDomain(hostname2, "shuffle.com")) return "shuffle";
  if (isDomain(hostname2, "gamdom.com")) return "gamdom";
  if (isDomain(hostname2, "csgoempire.com")) return "csgoempire";
  const parts = hostname2.replace("www.", "").split(".");
  return parts[0] || "unknown";
}
function detectGameId() {
  const pathname2 = window.location.pathname.toLowerCase();
  const href = window.location.href.toLowerCase();
  const patterns = [
    /\/casino\/slots\/([a-z0-9-]+)/,
    /\/games?\/([a-z0-9-]+)/,
    /\/slots?\/([a-z0-9-]+)/,
    /\/play\/([a-z0-9-]+)/
  ];
  for (const pattern of patterns) {
    const match = pathname2.match(pattern) || href.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }
  const pageTitle = document.title.toLowerCase();
  if (pageTitle.includes("sweet bonanza")) return "sweet-bonanza";
  if (pageTitle.includes("gates of olympus")) return "gates-of-olympus";
  if (pageTitle.includes("sugar rush")) return "sugar-rush";
  if (pageTitle.includes("starlight princess")) return "starlight-princess";
  if (pageTitle.includes("wild west gold")) return "wild-west-gold";
  if (pageTitle.includes("dog house")) return "dog-house";
  if (pageTitle.includes("book of dead")) return "book-of-dead";
  if (pageTitle.includes("fire joker")) return "fire-joker";
  return "unknown-game";
}
async function getUserId() {
  const createUserId = () => {
    const rand = crypto.getRandomValues(new Uint32Array(1))[0].toString(36);
    return `user_${Date.now()}_${rand}`;
  };
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(["userData", "tiltguard_user_id"], (result) => {
        if (result.userData?.id) {
          resolve(result.userData.id);
        } else if (result.tiltguard_user_id) {
          resolve(result.tiltguard_user_id);
        } else {
          const newId = createUserId();
          chrome.storage.local.set({ tiltguard_user_id: newId });
          resolve(newId);
        }
      });
    } catch {
      const storedUserData = localStorage.getItem("userData");
      if (storedUserData) {
        try {
          const user = JSON.parse(storedUserData);
          if (user.id) return resolve(user.id);
        } catch {
        }
      }
      let userId = localStorage.getItem("tiltguard_user_id");
      if (!userId) {
        userId = createUserId();
        localStorage.setItem("tiltguard_user_id", userId);
      }
      resolve(userId);
    }
  });
}
async function getLinkedDiscordId() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(["userData"], (result) => {
        resolve(typeof result.userData?.discordId === "string" ? result.userData.discordId : null);
      });
    } catch {
      resolve(null);
    }
  });
}
function setupFairnessListeners() {
  if (fairnessPlayObserver) {
    fairnessPlayObserver.disconnect();
  }
  fairnessPlayObserver = new MutationObserver((mutations) => {
    if (typeof document === "undefined" || !document.body) {
      return;
    }
    if (mutationsOnlyTouchSafetyRoots(mutations)) {
      return;
    }
    const playBtns = document.querySelectorAll('[data-testid="bet-button"], .bet-button, button[class*="bet"]');
    playBtns.forEach((btn) => {
      if (!(btn instanceof HTMLElement) || isInsideTiltcheckSafetyRoot(btn)) {
        return;
      }
      if (!btn.dataset.tiltCheckAttached) {
        btn.dataset.tiltCheckAttached = "true";
        btn.addEventListener("click", async () => {
          try {
            const discordId = await getUserId();
            const clientSeed = localStorage.getItem("tiltcheck_client_seed") || "default-seed";
            sessionStorage.setItem("tiltcheck_pending_commitment", JSON.stringify({
              discordId,
              clientSeed,
              timestamp: Date.now()
            }));
          } catch (err) {
            console.error("[TiltCheck] Commitment Error:", err);
          }
        });
      }
    });
  });
  fairnessPlayObserver.observe(document.body, { childList: true, subtree: true });
}
async function verifySpinFairness(spinData, gameId) {
  if (casinoVerification != null && !casinoVerification.shouldAnalyze) {
    return;
  }
  if (!fairness || !analyzer) return;
  const storedCommitment = sessionStorage.getItem("tiltcheck_pending_commitment");
  if (!storedCommitment) return;
  try {
    const parsedCommitment = JSON.parse(storedCommitment);
    if (!isFairnessCommitment(parsedCommitment)) {
      return;
    }
    const commitment = parsedCommitment;
    sessionStorage.removeItem("tiltcheck_pending_commitment");
    if (typeof commitment.blockHash !== "string" || commitment.blockHash.trim() === "") {
      console.warn("[TiltCheck] Missing block hash for fairness verification");
      return;
    }
    const expectedHash = await fairness.generateHash(
      commitment.blockHash,
      commitment.discordId,
      commitment.clientSeed
    );
    const expectedFloat = fairness.hashToFloat(expectedHash);
    let expectedResult = expectedFloat;
    let gameType = "standard";
    if (gameId.includes("dice")) {
      gameType = "dice";
      expectedResult = fairness.getDiceResult(expectedFloat);
    } else if (gameId.includes("limbo") || gameId.includes("crash")) {
      gameType = "limbo";
      expectedResult = fairness.getLimboResult(expectedFloat);
    } else if (gameId.includes("plinko")) {
      gameType = "plinko";
      const rows = spinData.rows || 16;
      expectedResult = fairness.getPlinkoPath(expectedHash, rows).join(",");
    }
    if (define_process_default.env.NODE_ENV !== "production") {
      console.log(`[TiltCheck] Fair Result Calculated (${gameType}):`, expectedResult);
      console.log(`[TiltCheck] Server Hash:`, expectedHash);
    }
    if (spinData.hash) {
      const isHashValid = spinData.hash === expectedHash;
      if (isHashValid) {
        window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: "Fairness Verified (Hash Match)", type: "success" } }));
        showNotification("Fair Game Verified (Hash Match)", "success");
      } else {
        showNotification("Fairness Hash Mismatch!", "error");
        console.warn(`[TiltCheck] Hash Mismatch! Expected: ${expectedHash}, Got: ${spinData.hash}`);
      }
    } else if (spinData.gameResult !== null && spinData.gameResult !== void 0) {
      const resultVal = Number(spinData.gameResult);
      if (typeof expectedResult === "number") {
        if (Math.abs(resultVal - expectedResult) < 0.05) {
          window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: `Fairness Verified (Result: ${resultVal})`, type: "success" } }));
          showNotification(`Fair Game Verified (Result: ${resultVal})`, "success");
          if (define_process_default.env.NODE_ENV !== "production") {
            console.log(`[TiltCheck] Scraped result ${resultVal} matches expected ${expectedResult}`);
          }
        } else {
          console.warn(`[TiltCheck] Result Mismatch! Expected: ${expectedResult}, Scraped: ${resultVal}`);
        }
      }
    } else {
      if (define_process_default.env.NODE_ENV !== "production") {
        console.log(`[TiltCheck] Visual Verify: Does the screen show ${expectedResult}?`);
      }
      window.dispatchEvent(new CustomEvent("tg-status-update", { detail: { message: `Visual Check: Expecting ${expectedResult}`, type: "info" } }));
    }
  } catch (err) {
    console.error("[TiltCheck] Verification Error:", err);
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Message received:", message.type);
  if (isExcludedDomain && message.type !== "get_sidebar_state") {
    sendResponse({ error: "Feature disabled on this domain" });
    return true;
  }
  switch (message.type) {
    case "toggle_sidebar": {
      void openRuntimeFromToolbar().then(sendResponse).catch((err) => {
        sendResponse({ success: false, error: err instanceof Error ? err.message : "Runtime toggle failed" });
      });
      return true;
    }
    case "open_sidebar": {
      void startRuntimeAtDocumentEnd({ forceEnable: true }).then(() => {
        const sidebarEl = document.getElementById("tiltcheck-sidebar");
        if (!sidebarEl) {
          sidebar = initSidebar(disableInjectionFromHud);
        }
        const visible = setSidebarVisibility(true);
        persistSidebarVisibility(true);
        sendResponse({ success: true, visible, injectionDisabled: false });
      }).catch((err) => {
        sendResponse({ success: false, error: err instanceof Error ? err.message : "Runtime open failed" });
      });
      return true;
    }
    case "get_sidebar_state":
      sendResponse(getSidebarState());
      return true;
    default:
      return false;
  }
});
function showRedeemNudge(data) {
  const existing = document.getElementById("tiltcheck-redeem-nudge");
  if (existing) {
    existing.remove();
  }
  const overlay = document.createElement("div");
  overlay.id = "tiltcheck-redeem-nudge";
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.95);
    z-index: 1000000;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: white;
    font-family: 'Inter', sans-serif;
    text-align: center;
  `;
  overlay.innerHTML = `
    <div style="max-width: 500px; padding: 40px; border: 2px solid #00ff88; border-radius: 20px; background: rgba(0, 255, 136, 0.05); box-shadow: 0 0 50px rgba(0, 255, 136, 0.2);">
      <h1 style="font-size: 64px; margin-bottom: 10px;">WIN</h1>
      <h2 style="font-size: 28px; color: #00ff88; text-transform: uppercase; letter-spacing: 2px;">WIN SECURED</h2>
      <p style="font-size: 20px; margin: 20px 0; line-height: 1.5;">${data.message}</p>
      <div style="font-size: 48px; font-weight: 800; margin-bottom: 30px;">$${Number(data.amount).toFixed(2)}</div>
      
      <div style="display: flex; gap: 15px; justify-content: center;">
        <button id="redeem-btn" style="background: #00ff88; color: black; border: none; padding: 15px 30px; border-radius: 10px; font-weight: 900; cursor: pointer; font-size: 18px; text-transform: uppercase;">
          Redeem Now & Quit
        </button>
        <button id="later-btn" style="background: transparent; color: white; border: 1px solid rgba(255,255,255,0.2); padding: 15px 30px; border-radius: 10px; font-weight: 600; cursor: pointer; font-size: 14px;">
          Maybe Later (Risk It)
        </button>
      </div>
      
      <div style="margin-top: 30px; font-size: 11px; opacity: 0.5; text-transform: uppercase; letter-spacing: 1px;">
        Made for Degens. By Degens.
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById("redeem-btn")?.addEventListener("click", (evt) => {
    const btn = evt.currentTarget;
    btn.disabled = true;
    btn.textContent = "Securing win...";
    relayWinSecure(data.amount).then(() => {
      overlay.remove();
      window.close();
    }).catch(() => {
      btn.disabled = false;
      btn.textContent = "Redeem Now & Quit";
      const errEl = document.createElement("p");
      errEl.style.cssText = "margin-top: 12px; color: #ff4444; font-size: 13px; font-weight: 600;";
      errEl.textContent = "Win relay failed. Screenshot this and contact support.";
      btn.parentElement?.insertAdjacentElement("afterend", errEl);
    });
  });
  document.getElementById("later-btn")?.addEventListener("click", () => {
    overlay.remove();
  });
}
async function relayWinSecure(amount) {
  const userId = await getUserId();
  const response = await postWinSecureTelemetry({ amount, userId });
  if (!response.ok) {
    console.error("[TiltCheck] Win secure relay returned non-OK status:", response.status);
    throw new Error(`Win secure relay failed with status ${response.status}`);
  }
}
function deactivateProMonolith() {
  teardownInjectedRuntime();
  proMonolithActive = false;
  if (define_process_default.env.NODE_ENV !== "production") {
    console.log("[TiltCheck Pro] Monolith surface safely defused. Core shield remains active.");
  }
}
async function startProMonolith() {
  if (proMonolithActive) {
    await startRuntimeAtDocumentEnd();
    return;
  }
  await startRuntimeAtDocumentEnd();
  proMonolithActive = true;
}
if (define_process_default.env.NODE_ENV !== "production") console.log("[TiltGuard] Pro monolith bootstrap module loaded");
export {
  deactivateProMonolith,
  startProMonolith
};
//# sourceMappingURL=pro-monolith-bootstrap.js.map
