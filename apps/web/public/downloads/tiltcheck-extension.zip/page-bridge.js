(() => {
  // src/native-web-bridge.ts
  var TILTCHECK_BRIDGE_VERSION = 1;
  var BRIDGE_SOURCE_NATIVE = "TILTCHECK_NATIVE";
  var BRIDGE_SOURCE_WEB = "TILTCHECK_WEB";
  function isRecord(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }
  function isBridgeConfig(value) {
    return value === void 0 || isRecord(value);
  }
  function isBridgeFeatureFlags(value) {
    if (value === void 0) return true;
    if (!isRecord(value)) return false;
    return Object.values(value).every((flag) => typeof flag === "boolean");
  }
  function hasValidRequestId(value) {
    return value === void 0 || typeof value === "string";
  }
  function isNativeToWebBridgeMessage(value) {
    if (!isRecord(value) || value.version !== TILTCHECK_BRIDGE_VERSION || typeof value.type !== "string") {
      return false;
    }
    if (!hasValidRequestId(value.requestId)) {
      return false;
    }
    switch (value.type) {
      case "init":
        return isBridgeFeatureFlags(value.features) && isBridgeConfig(value.config);
      case "module.start":
        return typeof value.module === "string" && value.module.length > 0 && isBridgeConfig(value.config);
      case "module.stop":
        return typeof value.module === "string" && value.module.length > 0;
      case "status.request":
        return true;
      default:
        return false;
    }
  }
  function cloneRecord(value) {
    return value ? { ...value } : {};
  }
  function messageFromError(error) {
    return error instanceof Error ? error.message : String(error);
  }
  var NativeWebBridgeRuntime = class {
    initialized = false;
    features = {};
    config = {};
    listening = false;
    moduleControllers = /* @__PURE__ */ new Map();
    moduleStates = /* @__PURE__ */ new Map();
    targetWindow;
    targetOrigin;
    handleWindowMessage = (event) => {
      if (event.source !== this.targetWindow) return;
      if (!isRecord(event.data) || event.data.source !== BRIDGE_SOURCE_NATIVE) return;
      this.handleNativeMessage(event.data);
    };
    constructor(options = {}) {
      this.targetWindow = options.targetWindow ?? window;
      this.targetOrigin = options.targetOrigin ?? "*";
    }
    registerModule(controller) {
      if (!controller.name) {
        throw new Error("Bridge module name is required");
      }
      this.moduleControllers.set(controller.name, controller);
      if (!this.moduleStates.has(controller.name)) {
        this.moduleStates.set(controller.name, {
          module: controller.name,
          state: "stopped",
          updatedAt: Date.now()
        });
      }
    }
    listen() {
      if (this.listening) return;
      this.targetWindow.addEventListener("message", this.handleWindowMessage);
      this.listening = true;
    }
    destroy() {
      if (!this.listening) return;
      this.targetWindow.removeEventListener("message", this.handleWindowMessage);
      this.listening = false;
    }
    handleNativeMessage(message) {
      if (!isNativeToWebBridgeMessage(message)) {
        this.emitError("INVALID_MESSAGE", "Native bridge message failed validation");
        return;
      }
      switch (message.type) {
        case "init":
          this.initialized = true;
          this.features = cloneRecord(message.features);
          this.config = cloneRecord(message.config);
          this.emitLog("info", "Bridge initialized", {
            featureCount: Object.keys(this.features).length,
            configKeys: Object.keys(this.config)
          });
          this.emitStatusResponse(message.requestId);
          break;
        case "module.start":
          void this.startModule(message);
          break;
        case "module.stop":
          void this.stopModule(message);
          break;
        case "status.request":
          this.emitStatusResponse(message.requestId);
          break;
      }
    }
    emitLog(level, message, context) {
      this.postWebMessage({
        version: TILTCHECK_BRIDGE_VERSION,
        type: "log",
        level,
        message,
        context
      });
    }
    emitError(code, message, context, requestId) {
      this.postWebMessage({
        version: TILTCHECK_BRIDGE_VERSION,
        type: "error",
        code,
        message,
        requestId,
        context
      });
    }
    emitModuleState(module, state, details, requestId) {
      this.setModuleState(module, state, details, requestId);
    }
    getStatus() {
      const modules = Array.from(this.moduleStates.values()).map((snapshot) => {
        const controller = this.moduleControllers.get(snapshot.module);
        const details = controller?.getStatus?.() ?? snapshot.details;
        return {
          ...snapshot,
          details
        };
      });
      return {
        initialized: this.initialized,
        features: { ...this.features },
        config: { ...this.config },
        modules
      };
    }
    getPublicApi() {
      return {
        version: TILTCHECK_BRIDGE_VERSION,
        log: (level, message, context) => this.emitLog(level, message, context),
        error: (code, message, context) => this.emitError(code, message, context),
        moduleState: (module, state, details) => this.emitModuleState(module, state, details),
        getStatus: () => this.getStatus()
      };
    }
    async startModule(message) {
      const controller = this.moduleControllers.get(message.module);
      if (!controller) {
        this.emitError("UNKNOWN_MODULE", `Bridge module is not registered: ${message.module}`, void 0, message.requestId);
        return;
      }
      try {
        await controller.start?.(message);
        this.setModuleState(message.module, "running", controller.getStatus?.(), message.requestId);
      } catch (error) {
        const reason = messageFromError(error);
        this.setModuleState(message.module, "error", { reason }, message.requestId);
        this.emitError("MODULE_START_FAILED", reason, { module: message.module }, message.requestId);
      }
    }
    async stopModule(message) {
      const controller = this.moduleControllers.get(message.module);
      if (!controller) {
        this.emitError("UNKNOWN_MODULE", `Bridge module is not registered: ${message.module}`, void 0, message.requestId);
        return;
      }
      try {
        await controller.stop?.(message);
        this.setModuleState(message.module, "stopped", controller.getStatus?.(), message.requestId);
      } catch (error) {
        const reason = messageFromError(error);
        this.setModuleState(message.module, "error", { reason }, message.requestId);
        this.emitError("MODULE_STOP_FAILED", reason, { module: message.module }, message.requestId);
      }
    }
    setModuleState(module, state, details, requestId) {
      const snapshot = {
        module,
        state,
        details,
        updatedAt: Date.now()
      };
      this.moduleStates.set(module, snapshot);
      this.postWebMessage({
        version: TILTCHECK_BRIDGE_VERSION,
        type: "module.state",
        module,
        state,
        details,
        requestId
      });
    }
    emitStatusResponse(requestId) {
      this.postWebMessage({
        version: TILTCHECK_BRIDGE_VERSION,
        type: "status.response",
        requestId,
        status: this.getStatus()
      });
    }
    postWebMessage(message) {
      this.targetWindow.postMessage({
        source: BRIDGE_SOURCE_WEB,
        timestamp: Date.now(),
        ...message
      }, this.targetOrigin);
    }
  };

  // src/page-bridge.ts
  window.__TiltCheckPageBridgeRuntime?.destroy();
  var nativeWebBridge = new NativeWebBridgeRuntime();
  var walletModuleEnabled = false;
  nativeWebBridge.registerModule({
    name: "wallet",
    start: () => {
      walletModuleEnabled = true;
      nativeWebBridge.emitLog("info", "Wallet bridge module started");
    },
    stop: () => {
      walletModuleEnabled = false;
      nativeWebBridge.emitLog("info", "Wallet bridge module stopped");
    },
    getStatus: () => ({
      enabled: walletModuleEnabled,
      hasProvider: Boolean(window.solana),
      hasWeb3: Boolean(window.solanaWeb3?.Transaction)
    })
  });
  nativeWebBridge.listen();
  window.TiltCheckBridge = nativeWebBridge.getPublicApi();
  function getErrorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }
  var handleWalletBridgeMessage = async (event) => {
    if (event.source !== window) return;
    if (event.data.source !== "TILTCHECK_EXT") return;
    if (event.data.type === "CONNECT") {
      if (window.solana) {
        try {
          nativeWebBridge.emitLog("info", "Wallet connect requested");
          const resp = await window.solana.connect();
          nativeWebBridge.emitModuleState("wallet", "running", {
            connected: true,
            enabled: walletModuleEnabled
          });
          window.postMessage({
            source: "TILTCHECK_PAGE",
            type: "CONNECTED",
            publicKey: resp.publicKey.toString()
          }, "*");
        } catch (err) {
          const message = getErrorMessage(err);
          nativeWebBridge.emitModuleState("wallet", "error", { reason: message });
          nativeWebBridge.emitError("WALLET_CONNECT_FAILED", message);
          console.error("TiltCheck Wallet Error:", err);
        }
      } else {
        nativeWebBridge.emitError("WALLET_UNAVAILABLE", "Wallet provider is unavailable");
      }
    }
    if (event.data.type === "SIGN_AND_SEND") {
      try {
        const { transactionBase64, requestId } = event.data;
        if (!window.solana || !window.solanaWeb3?.Transaction) {
          nativeWebBridge.emitError("WALLET_UNAVAILABLE", "Wallet signing dependencies are unavailable", { requestId }, requestId);
          return;
        }
        nativeWebBridge.emitLog("info", "Wallet transaction signing requested", { requestId });
        const buffer = Uint8Array.from(atob(transactionBase64), (c) => c.charCodeAt(0));
        const transaction = window.solanaWeb3.Transaction.from(buffer);
        const { signature } = await window.solana.signAndSendTransaction(transaction);
        nativeWebBridge.emitModuleState("wallet", "running", {
          connected: true,
          enabled: walletModuleEnabled,
          lastRequestId: requestId
        }, requestId);
        window.postMessage({
          source: "TILTCHECK_PAGE",
          type: "TX_SENT",
          signature,
          requestId
        }, "*");
      } catch (err) {
        const message = getErrorMessage(err);
        nativeWebBridge.emitModuleState("wallet", "error", { reason: message, requestId: event.data.requestId }, event.data.requestId);
        nativeWebBridge.emitError("WALLET_SIGN_FAILED", message, { requestId: event.data.requestId }, event.data.requestId);
        console.error("TiltCheck Sign Error:", err);
      }
    }
  };
  window.addEventListener("message", handleWalletBridgeMessage);
  window.__TiltCheckPageBridgeRuntime = {
    destroy: () => {
      nativeWebBridge.destroy();
      window.removeEventListener("message", handleWalletBridgeMessage);
    }
  };
})();
//# sourceMappingURL=page-bridge.js.map
