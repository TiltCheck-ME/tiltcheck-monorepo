(() => {
  // <define:process>
  var define_process_default = { env: {} };

  // src/touch-grass-timeout.ts
  var TOUCH_GRASS_DURATION_MS = 12e4;
  var TOUCH_GRASS_HUB_ORIGIN = "https://tiltcheck.me";
  var TOUCH_GRASS_HUB_PAUSE_PATH = "/touch-grass?mode=pause";
  var TOUCH_GRASS_HUB_READY_SOURCE = "TILTCHECK_TOUCH_GRASS";
  var HUB_IFRAME_ID = "tiltcheck-lockdown-hub";
  var HUB_IFRAME_LOAD_TIMEOUT_MS = 4e3;
  var CSP_FALLBACK_PROMPTS = [
    "Stand up. Two minutes of legs, not clicking reels.",
    "Get water. The house edge will still be there.",
    "Text a friend who does not have a referral code."
  ];
  function resolveTouchGrassHubUrl(origin = TOUCH_GRASS_HUB_ORIGIN) {
    return `${origin}${TOUCH_GRASS_HUB_PAUSE_PATH}`;
  }
  function resolveTouchGrassHubOrigin() {
    const hostname2 = globalThis.location?.hostname;
    if (hostname2 === "localhost" || hostname2 === "127.0.0.1") {
      return globalThis.location.origin;
    }
    return TOUCH_GRASS_HUB_ORIGIN;
  }
  function isTouchGrassHubReadyPing(event, expectedOrigin) {
    if (event.origin !== expectedOrigin) {
      return false;
    }
    const data = event.data;
    if (data == null || typeof data !== "object") {
      return false;
    }
    const payload = data;
    return payload.source === TOUCH_GRASS_HUB_READY_SOURCE && payload.ready === true;
  }
  var MESSAGE_ROTATE_MS = 2e4;
  var MESSAGE_FADE_SWAP_MS = 450;
  var BREAK_MESSAGES = [
    "You are down 60% in 9 minutes. You are not on a heater, you're chasing. Close the tab.",
    "Ed Craven doesn't need your rent money. Close the browser.",
    "That's 14 dead spins on Hacksaw. You already know how this movie ends.",
    "You're playing a 94.5% downgraded RTP tier on an offshore mirror thinking it's 96.5%.",
    "The bonus buy will not make you whole. Step back and breathe.",
    "Turbo spinning through dead rolls only speeds up the house edge. Walk away for two minutes.",
    "House telemetry loves rage clicking. Take your hand off the mouse.",
    "Unclench your jaw, put the phone down, and drink some water. The reel can wait."
  ];
  var LOCKDOWN_ROOT_ID = "tiltcheck-lockdown-root";
  var MESSAGE_EL_ID = "tiltcheck-lockdown-message";
  var TIMER_ID = "lockdown-timer";
  var overlayActive = false;
  var overlayHubMessageListener = null;
  function isTouchGrassActive() {
    return overlayActive;
  }
  function blockBettingUI(block) {
    const betButtons = document.querySelectorAll(
      'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
    );
    betButtons.forEach((btn) => {
      if (block) {
        if (btn instanceof HTMLButtonElement) {
          btn.disabled = true;
        }
        btn.style.opacity = "0.5";
        btn.style.cursor = "not-allowed";
        btn.dataset.tiltguardBlocked = "true";
      } else if (btn.dataset.tiltguardBlocked) {
        if (btn instanceof HTMLButtonElement) {
          btn.disabled = false;
        }
        btn.style.opacity = "";
        btn.style.cursor = "";
        delete btn.dataset.tiltguardBlocked;
      }
    });
  }
  function injectLockdownStyles(root) {
    const style = document.createElement("style");
    style.textContent = `
    #${LOCKDOWN_ROOT_ID} {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: #0f1115 !important;
      z-index: 2147483647 !important;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace;
      color: #ff4a4a;
      box-sizing: border-box;
      padding: 1.5rem;
      overflow-y: auto;
      user-select: none;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-inner {
      width: 100%;
      max-width: 32rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-eyebrow {
      font-size: 0.6875rem;
      font-weight: 800;
      letter-spacing: 0.28em;
      text-transform: uppercase;
      color: #ff4a4a;
      margin-bottom: 0.75rem;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-headline {
      font-size: 1.625rem;
      font-weight: 900;
      letter-spacing: -0.02em;
      color: #ffffff;
      margin: 0 0 0.75rem;
      line-height: 1.15;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-reason {
      font-size: 0.875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.82);
      margin: 0 0 1.25rem;
      max-width: 28rem;
    }

    /* Center stage: pacer ring + timer digits */
    .tiltcheck-pacer-stage {
      position: relative;
      width: 250px;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 2rem 0;
    }

    .tiltcheck-breath-pacer {
      position: absolute;
      width: 200px;
      height: 200px;
      border: 4px solid #ff4a4a;
      border-radius: 50%;
      box-shadow: 0 0 15px rgba(255, 74, 74, 0.2);
      animation: tiltcheck-breath-pacer 8s ease-in-out infinite;
      pointer-events: none;
    }

    #${TIMER_ID} {
      font-size: 3.5rem;
      font-weight: bold;
      color: #ffffff;
      z-index: 10;
      font-variant-numeric: tabular-nums;
      line-height: 1;
      text-shadow: 0 2px 20px rgba(0, 0, 0, 0.5);
    }

    @keyframes tiltcheck-breath-pacer {
      0%, 100% {
        transform: scale(0.6);
        opacity: 0.3;
        box-shadow: 0 0 10px rgba(255, 74, 74, 0.1);
      }
      50% {
        transform: scale(1.1);
        opacity: 0.9;
        border-color: #4affb4;
        box-shadow: 0 0 30px rgba(74, 255, 180, 0.4);
      }
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-breath-hint {
      position: absolute;
      bottom: -2.25rem;
      left: 50%;
      transform: translateX(-50%);
      width: 18rem;
      font-size: 0.625rem;
      opacity: 0.55;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: rgba(255, 255, 255, 0.55);
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-signal-label {
      font-size: 0.625rem;
      font-weight: 800;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: rgba(255, 74, 74, 0.65);
      margin-bottom: 0.5rem;
      align-self: stretch;
      text-align: left;
    }

    #${MESSAGE_EL_ID} {
      font-size: 0.875rem;
      line-height: 1.5;
      margin: 0;
      text-align: left;
      min-height: 4.5em;
      align-self: stretch;
      color: rgba(245, 245, 245, 0.94);
      transition: opacity 0.45s ease;
    }

    #${HUB_IFRAME_ID} {
      width: 100%;
      max-width: 32rem;
      height: 18rem;
      margin: 0.75rem 0 1rem;
      border: 1px solid rgba(255, 255, 255, 0.12);
      background: #111318;
      pointer-events: auto;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-csp-fallback {
      align-self: stretch;
      text-align: left;
      margin: 0 0 1rem;
      padding: 0 0 0 1.1rem;
      color: rgba(245, 245, 245, 0.94);
      font-size: 0.875rem;
      line-height: 1.5;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-foot {
      font-size: 0.6875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.45);
      margin: 1.25rem 0 0;
      max-width: 26rem;
    }
  `;
    root.insertBefore(style, root.firstChild);
  }
  function triggerTouchGrassTimeout(reason, durationMs = TOUCH_GRASS_DURATION_MS) {
    if (overlayActive) {
      return;
    }
    overlayActive = true;
    blockBettingUI(true);
    const existing = document.getElementById(LOCKDOWN_ROOT_ID);
    if (existing) {
      existing.remove();
    }
    const root = document.createElement("div");
    root.id = LOCKDOWN_ROOT_ID;
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.setAttribute(
      "aria-label",
      "Touch Grass timeout \u2014 session pause with breathing pacer and rotating guidance"
    );
    injectLockdownStyles(root);
    const inner = document.createElement("div");
    inner.className = "tiltcheck-lockdown-inner";
    const eyebrow = document.createElement("div");
    eyebrow.className = "tiltcheck-eyebrow";
    eyebrow.textContent = "Touch Grass Timeout";
    const headline = document.createElement("h1");
    headline.className = "tiltcheck-lockdown-headline";
    headline.textContent = "Hold up. Recalibrate.";
    const reasonEl = document.createElement("p");
    reasonEl.className = "tiltcheck-lockdown-reason";
    reasonEl.textContent = reason;
    const stage = document.createElement("div");
    stage.className = "tiltcheck-pacer-stage";
    const breathRing = document.createElement("div");
    breathRing.className = "tiltcheck-breath-pacer";
    breathRing.setAttribute("aria-hidden", "true");
    const timerWrap = document.createElement("div");
    timerWrap.id = TIMER_ID;
    timerWrap.setAttribute("aria-live", "polite");
    timerWrap.setAttribute("aria-atomic", "true");
    const breathHint = document.createElement("div");
    breathHint.className = "tiltcheck-breath-hint";
    breathHint.textContent = "Inhale as the ring expands \u2014 exhale as it releases.";
    const signalLabel = document.createElement("div");
    signalLabel.className = "tiltcheck-signal-label";
    signalLabel.textContent = "Spotter Signal";
    const messageRegion = document.createElement("div");
    messageRegion.className = "tiltcheck-signal-region";
    messageRegion.setAttribute("role", "region");
    messageRegion.setAttribute("aria-label", "System message updates every 20 seconds");
    const messageEl = document.createElement("p");
    messageEl.id = MESSAGE_EL_ID;
    messageEl.setAttribute("aria-live", "off");
    messageEl.textContent = BREAK_MESSAGES[0] ?? "";
    const foot = document.createElement("p");
    foot.className = "tiltcheck-lockdown-foot";
    foot.textContent = "This tab stays locked until the countdown hits zero. No dismiss. Spotter protocol active.";
    const hubOrigin = resolveTouchGrassHubOrigin();
    const iframe = document.createElement("iframe");
    iframe.id = HUB_IFRAME_ID;
    iframe.title = "Touch Grass games hub";
    iframe.src = resolveTouchGrassHubUrl(hubOrigin);
    iframe.referrerPolicy = "no-referrer";
    const fallbackList = document.createElement("ul");
    fallbackList.className = "tiltcheck-csp-fallback";
    fallbackList.hidden = true;
    fallbackList.setAttribute("aria-label", "Local pause prompts");
    for (const prompt of CSP_FALLBACK_PROMPTS) {
      const item = document.createElement("li");
      item.textContent = prompt;
      fallbackList.appendChild(item);
    }
    stage.appendChild(breathRing);
    stage.appendChild(timerWrap);
    stage.appendChild(breathHint);
    inner.appendChild(eyebrow);
    inner.appendChild(headline);
    inner.appendChild(reasonEl);
    inner.appendChild(stage);
    inner.appendChild(iframe);
    inner.appendChild(fallbackList);
    messageRegion.appendChild(messageEl);
    inner.appendChild(signalLabel);
    inner.appendChild(messageRegion);
    inner.appendChild(foot);
    root.appendChild(inner);
    document.body.appendChild(root);
    const stopBlocking = (e) => {
      if (e.target === iframe) {
        return;
      }
      e.preventDefault();
      e.stopPropagation();
    };
    const captureOpts = { capture: true };
    root.addEventListener("click", stopBlocking, captureOpts);
    root.addEventListener("mousedown", stopBlocking, captureOpts);
    root.addEventListener("mouseup", stopBlocking, captureOpts);
    root.addEventListener("keydown", stopBlocking, captureOpts);
    root.addEventListener("touchstart", stopBlocking, captureOpts);
    document.addEventListener("keydown", stopBlocking, captureOpts);
    let hubSettled = false;
    let hubLoadTimeoutId = null;
    const showCspFallback = (force = false) => {
      if (hubSettled && !force) {
        return;
      }
      hubSettled = true;
      if (hubLoadTimeoutId !== null) {
        clearTimeout(hubLoadTimeoutId);
        hubLoadTimeoutId = null;
      }
      iframe.hidden = true;
      iframe.setAttribute("aria-hidden", "true");
      fallbackList.hidden = false;
    };
    const onHubMessage = (event) => {
      if (hubSettled) {
        return;
      }
      if (!isTouchGrassHubReadyPing(event, hubOrigin)) {
        return;
      }
      hubSettled = true;
      if (hubLoadTimeoutId !== null) {
        clearTimeout(hubLoadTimeoutId);
        hubLoadTimeoutId = null;
      }
    };
    overlayHubMessageListener = onHubMessage;
    window.addEventListener("message", onHubMessage);
    iframe.addEventListener("error", () => {
      showCspFallback(true);
    });
    hubLoadTimeoutId = window.setTimeout(() => {
      hubLoadTimeoutId = null;
      if (!hubSettled) {
        showCspFallback();
      }
    }, HUB_IFRAME_LOAD_TIMEOUT_MS);
    let messageIndex = 0;
    let pendingFadeTimeout = null;
    const clearPendingFade = () => {
      if (pendingFadeTimeout !== null) {
        clearTimeout(pendingFadeTimeout);
        pendingFadeTimeout = null;
      }
    };
    const messageRotateIntervalId = window.setInterval(() => {
      if (!document.getElementById(LOCKDOWN_ROOT_ID) || !messageEl.isConnected) {
        clearInterval(messageRotateIntervalId);
        return;
      }
      messageIndex = (messageIndex + 1) % BREAK_MESSAGES.length;
      messageEl.style.opacity = "0";
      clearPendingFade();
      pendingFadeTimeout = window.setTimeout(() => {
        pendingFadeTimeout = null;
        if (!messageEl.isConnected) return;
        messageEl.textContent = BREAK_MESSAGES[messageIndex] ?? "";
        messageEl.style.opacity = "1";
      }, MESSAGE_FADE_SWAP_MS);
    }, MESSAGE_ROTATE_MS);
    let countdownIntervalId = null;
    const started = Date.now();
    const finish = () => {
      if (countdownIntervalId !== null) {
        clearInterval(countdownIntervalId);
        countdownIntervalId = null;
      }
      if (hubLoadTimeoutId !== null) {
        clearTimeout(hubLoadTimeoutId);
        hubLoadTimeoutId = null;
      }
      window.removeEventListener("message", onHubMessage);
      overlayHubMessageListener = null;
      clearInterval(messageRotateIntervalId);
      clearPendingFade();
      root.remove();
      document.removeEventListener("keydown", stopBlocking, captureOpts);
      blockBettingUI(false);
      overlayActive = false;
    };
    const tick = () => {
      const left = Math.max(0, durationMs - (Date.now() - started));
      const sec = Math.ceil(left / 1e3);
      timerWrap.textContent = `${sec}`;
      if (left <= 0) {
        finish();
      }
    };
    tick();
    countdownIntervalId = window.setInterval(tick, 250);
  }

  // src/extractor.ts
  var CASINO_SELECTORS = [
    {
      casinoId: "stake",
      domain: "stake.com",
      selectors: {
        betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
        winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
        balance: '[data-test="balance"], .balance, [class*="balance-value"]',
        symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
        bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
        freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
        gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
        gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
      }
    },
    {
      casinoId: "stake-us",
      domain: "stake.us",
      selectors: {
        betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
        winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
        balance: '[data-test="balance"], .balance, [class*="balance-value"]',
        symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
        bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
        freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
        gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
        gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
      }
    },
    // Stake mirror domains - same selectors as stake.com
    ...["stake.bet", "stake.games", "staketr.com", "staketr2.com", "staketr3.com", "staketr4.com", "stake.bz", "stake.pet"].map((domain) => ({
      casinoId: "stake",
      domain,
      selectors: {
        betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
        winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
        balance: '[data-test="balance"], .balance, [class*="balance-value"]',
        symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
        bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
        freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
        gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
        gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
      }
    })),
    {
      casinoId: "roobet",
      domain: "roobet.com",
      selectors: {
        betAmount: '.bet-input input, [name="bet"], [class*="betInput"]',
        winAmount: '.win-display, .payout-amount, [class*="winAmount"]',
        balance: '.user-balance, [class*="userBalance"], [class*="balance"]',
        symbols: '.slot-symbol, [class*="reelSymbol"]',
        bonusIndicator: '.bonus-round-active, [class*="bonusActive"]',
        gameResult: ".crash-payout, .multiplier-display"
      },
      extractors: {
        extractResult: (doc) => {
          const el = doc.querySelector(".crash-payout, .multiplier-display");
          if (!el || !el.textContent) return null;
          return parseFloat(el.textContent.replace(/x/i, "").trim());
        }
      }
    },
    {
      casinoId: "bc-game",
      domain: "bc.game",
      selectors: {
        betAmount: '[class*="betAmount"], [class*="bet-amount"], input[type="number"]',
        winAmount: '[class*="winAmount"], [class*="win-amount"], [class*="payout"]',
        balance: '[class*="balance"], [class*="userBalance"]',
        symbols: '[class*="symbol"], [class*="reel"]'
      }
    },
    {
      casinoId: "duelbits",
      domain: "duelbits.com",
      selectors: {
        betAmount: '.bet-value, [class*="betValue"], [class*="bet-amount"]',
        winAmount: '.win-value, [class*="winValue"], [class*="win-amount"]',
        balance: '[class*="balance"], .user-balance',
        symbols: '[data-reel] img, .reel-symbol, [class*="symbol"]'
      }
    },
    {
      casinoId: "rollbit",
      domain: "rollbit.com",
      selectors: {
        betAmount: '[class*="betInput"], [class*="bet-amount"], input[name="bet"]',
        winAmount: '[class*="winAmount"], [class*="payout"]',
        balance: '[class*="balance"], [class*="wallet"]',
        symbols: '[class*="symbol"], [class*="reel"]'
      }
    },
    {
      casinoId: "shuffle",
      domain: "shuffle.com",
      selectors: {
        betAmount: '[class*="bet"], input[type="number"]',
        winAmount: '[class*="win"], [class*="payout"]',
        balance: '[class*="balance"], [class*="wallet"]',
        symbols: '[class*="symbol"]'
      }
    },
    {
      casinoId: "gamdom",
      domain: "gamdom.com",
      selectors: {
        betAmount: '[class*="bet-amount"], [class*="betValue"]',
        winAmount: '[class*="win-amount"], [class*="winValue"]',
        balance: '[class*="balance"]',
        symbols: '[class*="symbol"]'
      }
    },
    {
      casinoId: "generic",
      domain: "*",
      selectors: {
        betAmount: '[data-bet], .bet, .bet-amount, input[name="bet"], [class*="betAmount"], [class*="bet-input"]',
        winAmount: '[data-win], .win, .win-amount, .payout, [class*="winAmount"], [class*="payout"]',
        balance: '[data-balance], .balance, .user-balance, [class*="balance"], [class*="wallet"]',
        symbols: '[data-symbol], .symbol, .reel-symbol, [class*="symbol"], [class*="reel"]',
        gameResult: "[data-result], .game-result, .result-value, .outcome"
      }
    }
  ];

  // src/spin-pace-lock.ts
  var PACE_LOCK_MS = 2e3;
  var PACE_TICK_MS = 250;
  var PACE_TOAST_TEXT = "Pacing lock active. Let the last spin settle before firing again.";
  var PACE_HOST_ID = "tiltcheck-pace-host";
  var SPIN_CONTROL_SELECTOR = [
    'button[class*="bet"]',
    'button[class*="spin"]',
    '[data-action="bet"]',
    '[data-action="spin"]'
  ].join(", ");
  function installSpinPaceLock(doc = document) {
    let lockUntil = 0;
    let anchor = null;
    let tickId = null;
    let stopped = false;
    const priorDisabled = /* @__PURE__ */ new Map();
    const host = doc.createElement("div");
    host.id = PACE_HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const style = doc.createElement("style");
    style.textContent = `
    :host { position: fixed; inset: 0; z-index: 2147483646; pointer-events: none; }
    .chip {
      position: fixed;
      display: none;
      align-items: center;
      justify-content: center;
      pointer-events: auto;
      background: rgba(15, 17, 21, 0.88);
      color: #ffffff;
      font: 700 1.25rem ui-monospace, monospace;
    }
    .toast {
      position: fixed;
      display: none;
      left: 50%;
      top: 1rem;
      transform: translateX(-50%);
      max-width: 22rem;
      padding: 0.75rem 1rem;
      pointer-events: none;
      background: #0f1115;
      color: #ffffff;
      font: 600 0.875rem ui-monospace, monospace;
    }
  `;
    const chip = doc.createElement("div");
    chip.className = "chip";
    const toast = doc.createElement("div");
    toast.className = "toast";
    toast.textContent = PACE_TOAST_TEXT;
    shadow.append(style, chip, toast);
    doc.body.append(host);
    const matches = () => Array.from(doc.querySelectorAll(SPIN_CONTROL_SELECTOR));
    const showToast = () => {
      toast.style.display = "block";
    };
    const hideToast = () => {
      toast.style.display = "none";
    };
    const placeChip = (target) => {
      const rect = target.getBoundingClientRect();
      chip.style.display = "flex";
      chip.style.left = `${rect.left}px`;
      chip.style.top = `${rect.top}px`;
      chip.style.width = `${Math.max(rect.width, 48)}px`;
      chip.style.height = `${Math.max(rect.height, 32)}px`;
    };
    const release = () => {
      if (tickId !== null) {
        clearInterval(tickId);
        tickId = null;
      }
      for (const [button, wasDisabled] of priorDisabled) {
        button.disabled = wasDisabled;
      }
      priorDisabled.clear();
      chip.style.display = "none";
      hideToast();
      anchor = null;
      lockUntil = 0;
    };
    const applyLockVisuals = () => {
      const left = lockUntil - Date.now();
      if (left <= 0) {
        release();
        return;
      }
      chip.textContent = String(Math.ceil(left / 1e3));
      const current = matches();
      for (const el of current) {
        if (el instanceof HTMLButtonElement) {
          if (!priorDisabled.has(el)) {
            priorDisabled.set(el, el.disabled);
          }
          el.disabled = true;
        }
      }
      const liveAnchor = anchor && anchor.isConnected ? anchor : current[0] ?? null;
      anchor = liveAnchor;
      if (liveAnchor) {
        placeChip(liveAnchor);
      } else {
        chip.style.display = "none";
      }
    };
    const startLock = (spin) => {
      lockUntil = Date.now() + PACE_LOCK_MS;
      const connected = matches();
      anchor = spin.isConnected ? spin : connected[0] ?? null;
      hideToast();
      applyLockVisuals();
      if (tickId !== null) {
        clearInterval(tickId);
      }
      tickId = setInterval(applyLockVisuals, PACE_TICK_MS);
    };
    const swallow = (event) => {
      event.preventDefault();
      event.stopPropagation();
      showToast();
    };
    const onDocumentClick = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const spin = target.closest(SPIN_CONTROL_SELECTOR);
      if (!spin) return;
      if (Date.now() < lockUntil) {
        swallow(event);
        return;
      }
      if (spin instanceof HTMLButtonElement && !priorDisabled.has(spin)) {
        priorDisabled.set(spin, spin.disabled);
      }
      setTimeout(() => {
        if (stopped) return;
        startLock(spin);
      }, 0);
    };
    const onChipClick = (event) => {
      if (Date.now() >= lockUntil) return;
      swallow(event);
    };
    chip.addEventListener("click", onChipClick);
    doc.addEventListener("click", onDocumentClick, true);
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onDocumentClick, true);
      release();
      host.remove();
    };
    return {
      stop,
      lockUntil: () => lockUntil
    };
  }

  // src/bonus-tracker.ts
  var TILTCHECK_BONUS_TRACKER_CONFIG_KEY = "tiltcheck_bonus_tracker_config";
  var BONUS_HUD_ID = "tiltcheck-bonus-hud";
  var BONUS_TRAP_ALARM_ID = "tiltcheck-bonus-trap-alarm";
  var BONUS_COMPLETE_MODAL_ID = "tiltcheck-bonus-complete-modal";
  var BONUS_STYLES_ID = "tiltcheck-bonus-tracker-styles";
  var DEFAULT_BONUS_TRACKER_CONFIG = {
    active: false,
    bonusName: "Deposit Bonus",
    targetWager: 1e3,
    currentWagered: 0,
    maxBetLimit: 5,
    blockExceededBets: true
  };
  function parseMoney(text) {
    if (text == null) return null;
    const tokens = text.split(/\s+/).map((token) => token.replace(/,/g, "").replace(/[^\d.-]/g, ""));
    const matches = tokens.filter((token) => /^-?\d+(\.\d+)?$/.test(token));
    if (matches.length !== 1) return null;
    const n = Number(matches[0]);
    return Number.isFinite(n) ? n : null;
  }
  function calculateBonusProgress(currentWagered, targetWager) {
    if (targetWager <= 0) {
      return { percent: 100, remaining: 0, isComplete: true };
    }
    const safeWagered = Math.max(0, currentWagered);
    const percent = Math.min(100, Math.round(safeWagered / targetWager * 1e3) / 10);
    const remaining = Math.max(0, Math.round((targetWager - safeWagered) * 100) / 100);
    const isComplete = safeWagered >= targetWager;
    return { percent, remaining, isComplete };
  }
  function isBetExceedingMax(bet, maxBet) {
    if (maxBet <= 0 || bet <= 0) return false;
    return bet > maxBet;
  }
  function sanitizeBonusConfig(raw) {
    if (typeof raw !== "object" || raw === null) {
      return { ...DEFAULT_BONUS_TRACKER_CONFIG };
    }
    const obj = raw;
    const active = typeof obj["active"] === "boolean" ? obj["active"] : DEFAULT_BONUS_TRACKER_CONFIG.active;
    const bonusName = typeof obj["bonusName"] === "string" && obj["bonusName"].trim() ? obj["bonusName"].trim() : DEFAULT_BONUS_TRACKER_CONFIG.bonusName;
    const targetWager = typeof obj["targetWager"] === "number" && Number.isFinite(obj["targetWager"]) ? Math.max(0, obj["targetWager"]) : DEFAULT_BONUS_TRACKER_CONFIG.targetWager;
    const currentWagered = typeof obj["currentWagered"] === "number" && Number.isFinite(obj["currentWagered"]) ? Math.max(0, obj["currentWagered"]) : 0;
    const maxBetLimit = typeof obj["maxBetLimit"] === "number" && Number.isFinite(obj["maxBetLimit"]) ? Math.max(0, obj["maxBetLimit"]) : DEFAULT_BONUS_TRACKER_CONFIG.maxBetLimit;
    const blockExceededBets = typeof obj["blockExceededBets"] === "boolean" ? obj["blockExceededBets"] : true;
    return { active, bonusName, targetWager, currentWagered, maxBetLimit, blockExceededBets };
  }
  async function saveBonusTrackerConfig(config) {
    try {
      await chrome.storage.local.set({
        [TILTCHECK_BONUS_TRACKER_CONFIG_KEY]: sanitizeBonusConfig(config)
      });
    } catch {
    }
  }
  function readBetAmount(doc) {
    const hostname2 = doc.location?.hostname ?? "";
    const entry = CASINO_SELECTORS.find(
      (item) => hostname2 && hostname2.includes(item.domain) || item.domain === "*"
    );
    const selector = entry?.selectors?.betAmount;
    if (selector) {
      const el = doc.querySelector(selector);
      if (el) {
        const val = el.value || el.getAttribute("data-value") || el.textContent;
        const parsed = parseMoney(val);
        if (parsed !== null && parsed > 0) return parsed;
      }
    }
    const genericSelectors = [
      '[data-test*="bet-amount"]',
      '[data-testid*="bet-amount"]',
      'input[name*="bet"]',
      'input[class*="bet"]',
      ".bet-amount",
      ".stake-amount",
      '[class*="betAmount"]',
      '[class*="stakeAmount"]'
    ];
    for (const sel of genericSelectors) {
      const el = doc.querySelector(sel);
      if (el) {
        const val = el.value || el.getAttribute("data-value") || el.textContent;
        const parsed = parseMoney(val);
        if (parsed !== null && parsed > 0) return parsed;
      }
    }
    return null;
  }
  function ensureStyles(doc) {
    if (doc.getElementById(BONUS_STYLES_ID)) return;
    const style = doc.createElement("style");
    style.id = BONUS_STYLES_ID;
    style.textContent = `
    #${BONUS_HUD_ID} {
      position: fixed;
      bottom: 24px;
      left: 24px;
      z-index: 2147483644;
      background: #080a0e;
      border: 1px solid #17c3b2;
      border-radius: 8px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
      padding: 10px 14px;
      color: #ffffff;
      font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      min-width: 250px;
      user-select: none;
    }
    .tiltcheck-bonus-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 6px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    .tiltcheck-bonus-name {
      color: #17c3b2;
    }
    .tiltcheck-bonus-pct {
      font-family: 'JetBrains Mono', monospace;
      color: #ffffff;
    }
    .tiltcheck-bonus-bar-bg {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      height: 6px;
      overflow: hidden;
      margin-bottom: 6px;
    }
    .tiltcheck-bonus-bar-fill {
      background: #17c3b2;
      height: 100%;
      transition: width 0.3s ease;
    }
    .tiltcheck-bonus-footer {
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: rgba(160, 175, 190, 0.85);
      font-family: 'JetBrains Mono', monospace;
    }
    .tiltcheck-bonus-maxbet {
      color: #fbbf24;
      font-weight: 700;
    }
    #${BONUS_TRAP_ALARM_ID} {
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2147483647;
      background: #140507;
      border: 2px solid #ff003c;
      border-radius: 8px;
      box-shadow: 0 12px 40px rgba(255, 0, 60, 0.4);
      padding: 14px 20px;
      color: #ffffff;
      font-family: 'Space Grotesk', sans-serif;
      max-width: 440px;
      text-align: center;
      animation: tiltcheck-trap-shake 0.3s ease-in-out;
    }
    @keyframes tiltcheck-trap-shake {
      0%, 100% { transform: translateX(-50%); }
      20%, 60% { transform: translateX(calc(-50% - 6px)); }
      40%, 80% { transform: translateX(calc(-50% + 6px)); }
    }
    .tiltcheck-trap-tag {
      color: #ff003c;
      font-size: 11px;
      font-weight: 900;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .tiltcheck-trap-title {
      font-size: 15px;
      font-weight: 800;
      margin-bottom: 6px;
    }
    .tiltcheck-trap-body {
      font-size: 12px;
      color: rgba(230, 230, 230, 0.9);
      line-height: 1.4;
      margin-bottom: 10px;
    }
    .tiltcheck-trap-btn {
      background: #ff003c;
      color: #ffffff;
      border: none;
      padding: 6px 14px;
      border-radius: 4px;
      font-weight: 700;
      font-size: 11px;
      cursor: pointer;
    }
    #${BONUS_COMPLETE_MODAL_ID} {
      position: fixed;
      inset: 0;
      background: rgba(8, 10, 14, 0.9);
      backdrop-filter: blur(8px);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Space Grotesk', sans-serif;
    }
    .tiltcheck-complete-card {
      background: #0d1117;
      border: 2px solid #17c3b2;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.9), 0 0 30px rgba(23, 195, 178, 0.3);
      padding: 28px;
      width: 90%;
      max-width: 440px;
      text-align: center;
      color: #ffffff;
    }
  `;
    (doc.head || doc.documentElement).appendChild(style);
  }
  function showMaxBetTrapAlarm(doc, bet, maxBet, intercepted) {
    ensureStyles(doc);
    doc.getElementById(BONUS_TRAP_ALARM_ID)?.remove();
    const alarm = doc.createElement("div");
    alarm.id = BONUS_TRAP_ALARM_ID;
    const interceptMsg = intercepted ? "Bet intercepted and blocked before firing." : "Warning: Exceeding max bet voids all bonus winnings.";
    alarm.innerHTML = `
    <div class="tiltcheck-trap-tag">Bonus Trap Alert</div>
    <div class="tiltcheck-trap-title">Stake Exceeds Max Bet Limit</div>
    <div class="tiltcheck-trap-body">
      Current bet: <strong>$${bet.toFixed(2)}</strong>. Promotional terms cap bets at <strong>$${maxBet.toFixed(2)}</strong>.<br/>
      ${interceptMsg}
    </div>
    <button type="button" class="tiltcheck-trap-btn" id="tiltcheck-trap-dismiss">Lower My Bet</button>
  `;
    alarm.querySelector("#tiltcheck-trap-dismiss")?.addEventListener("click", () => {
      alarm.remove();
    });
    (doc.body || doc.documentElement).appendChild(alarm);
    setTimeout(() => {
      alarm.remove();
    }, 6e3);
  }
  function showBonusCompleteModal(doc, totalWagered, onCashout) {
    ensureStyles(doc);
    if (doc.getElementById(BONUS_COMPLETE_MODAL_ID)) return;
    const modal = doc.createElement("div");
    modal.id = BONUS_COMPLETE_MODAL_ID;
    modal.innerHTML = `
    <div class="tiltcheck-complete-card">
      <div style="font-size:11px; font-weight:800; letter-spacing:0.1em; color:#17c3b2; text-transform:uppercase; margin-bottom:8px;">Rollover 100% Complete</div>
      <div style="font-size:22px; font-weight:800; margin-bottom:12px;">Bonus Cleared to Real Cash</div>
      <div style="font-size:13px; color:rgba(200, 210, 220, 0.9); line-height:1.5; margin-bottom:20px;">
        You have successfully completed <strong>$${totalWagered.toFixed(2)}</strong> in wagering. Your balance is now 100% withdrawable with zero rollover locks. Stop spinning and cash out.
      </div>
      <div style="display:flex; flex-direction:column; gap:10px;">
        <button type="button" id="tiltcheck-bonus-cashout-btn" style="background:#17c3b2; color:#000; font-weight:800; font-size:14px; padding:12px 20px; border-radius:6px; border:none; cursor:pointer; text-transform:uppercase;">Go to Cashier &rarr;</button>
        <button type="button" id="tiltcheck-bonus-dismiss-btn" style="background:transparent; color:rgba(160, 175, 190, 0.7); font-size:12px; border:none; cursor:pointer;">Dismiss (I'll cash out later)</button>
      </div>
    </div>
  `;
    modal.querySelector("#tiltcheck-bonus-cashout-btn")?.addEventListener("click", () => {
      modal.remove();
      onCashout();
      const cashier = doc.querySelector('a[href*="cashier"], a[href*="wallet"], button[data-test*="cashier"]');
      cashier?.click();
    });
    modal.querySelector("#tiltcheck-bonus-dismiss-btn")?.addEventListener("click", () => {
      modal.remove();
    });
    (doc.body || doc.documentElement).appendChild(modal);
  }
  function installBonusTracker(doc, initialConfig, onUpdate) {
    let config = {
      ...DEFAULT_BONUS_TRACKER_CONFIG,
      ...initialConfig
    };
    let stopped = false;
    let completionModalShown = false;
    function renderHud() {
      if (stopped || !config.active) {
        doc.getElementById(BONUS_HUD_ID)?.remove();
        return;
      }
      ensureStyles(doc);
      let hud = doc.getElementById(BONUS_HUD_ID);
      if (!hud) {
        hud = doc.createElement("div");
        hud.id = BONUS_HUD_ID;
        (doc.body || doc.documentElement).appendChild(hud);
      }
      const { percent, remaining, isComplete } = calculateBonusProgress(config.currentWagered, config.targetWager);
      const maxBetTag = config.maxBetLimit > 0 ? `<span class="tiltcheck-bonus-maxbet">Max: $${config.maxBetLimit.toFixed(2)}</span>` : "";
      hud.innerHTML = `
      <div class="tiltcheck-bonus-header">
        <span class="tiltcheck-bonus-name">${config.bonusName}</span>
        <span class="tiltcheck-bonus-pct">${percent.toFixed(1)}%</span>
      </div>
      <div class="tiltcheck-bonus-bar-bg">
        <div class="tiltcheck-bonus-bar-fill" style="width: ${percent}%;"></div>
      </div>
      <div class="tiltcheck-bonus-footer">
        <span>Wagered: $${config.currentWagered.toFixed(2)} / $${config.targetWager.toFixed(2)}</span>
        ${maxBetTag}
      </div>
    `;
    }
    function recordBet(betAmountOverride) {
      if (stopped || !config.active) return;
      const bet = betAmountOverride !== void 0 ? betAmountOverride : readBetAmount(doc);
      if (bet === null || bet <= 0) return;
      if (isBetExceedingMax(bet, config.maxBetLimit)) {
        showMaxBetTrapAlarm(doc, bet, config.maxBetLimit, false);
        return;
      }
      const prevWagered = config.currentWagered;
      config.currentWagered = Math.round((config.currentWagered + bet) * 100) / 100;
      renderHud();
      onUpdate?.({ ...config });
      void saveBonusTrackerConfig(config);
      if (config.currentWagered >= config.targetWager && prevWagered < config.targetWager && !completionModalShown) {
        completionModalShown = true;
        showBonusCompleteModal(doc, config.currentWagered, () => {
        });
      }
    }
    const onSpinClickCapture = (e) => {
      if (stopped || !config.active) return;
      const target = e.target;
      if (!target) return;
      const isSpinControl = target.closest(SPIN_CONTROL_SELECTOR) !== null || target.matches(SPIN_CONTROL_SELECTOR) || target.closest('button, [role="button"]') !== null;
      if (!isSpinControl) return;
      const bet = readBetAmount(doc);
      if (bet !== null && isBetExceedingMax(bet, config.maxBetLimit)) {
        if (config.blockExceededBets) {
          e.preventDefault();
          e.stopImmediatePropagation();
          showMaxBetTrapAlarm(doc, bet, config.maxBetLimit, true);
          return;
        }
      }
      setTimeout(() => {
        if (bet !== null && bet > 0) {
          recordBet(bet);
        }
      }, 50);
    };
    doc.addEventListener("click", onSpinClickCapture, true);
    if (config.active) {
      renderHud();
    }
    return {
      stop: () => {
        stopped = true;
        doc.removeEventListener("click", onSpinClickCapture, true);
        doc.getElementById(BONUS_HUD_ID)?.remove();
        doc.getElementById(BONUS_TRAP_ALARM_ID)?.remove();
        doc.getElementById(BONUS_COMPLETE_MODAL_ID)?.remove();
        doc.getElementById(BONUS_STYLES_ID)?.remove();
      },
      recordBet,
      getProgress: () => calculateBonusProgress(config.currentWagered, config.targetWager),
      getConfig: () => ({ ...config }),
      updateConfig: (newConfig) => {
        config = { ...config, ...newConfig };
        renderHud();
        onUpdate?.({ ...config });
        void saveBonusTrackerConfig(config);
      },
      resetProgress: () => {
        config.currentWagered = 0;
        completionModalShown = false;
        renderHud();
        onUpdate?.({ ...config });
        void saveBonusTrackerConfig(config);
      }
    };
  }

  // src/casino-vault-adapters.ts
  var StakeVaultAdapter = class {
    name = "stake";
    domains = ["stake.com", "stake.us"];
    canDetectBalance() {
      return true;
    }
    getGraphQLEndpoint(hostname2) {
      const host = (hostname2 ?? (typeof window !== "undefined" ? window.location?.hostname || "" : "")).toLowerCase();
      if (host === "stake.us" || host.endsWith(".stake.us")) {
        return "https://stake.us/_api/graphql";
      }
      return "https://api.stake.com/graphql";
    }
    async getBalance() {
      try {
        const endpoint = this.getGraphQLEndpoint();
        const res = await fetch(endpoint, {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query: `query { user { balances { available { amount currency { name } } } } }`
          })
        });
        if (!res.ok) {
          return null;
        }
        const json = await res.json();
        const balances = json?.data?.user?.balances ?? [];
        return balances[0]?.available?.amount ?? null;
      } catch {
        return null;
      }
    }
    async getLastWinAmount() {
      return null;
    }
    async vaultAmount(amount, _currency = "usd") {
      try {
        const endpoint = this.getGraphQLEndpoint();
        const res = await fetch(endpoint, {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            query: `mutation createVaultDeposit($amount: Float!) {
            createVaultDeposit(amount: $amount) { id amount }
          }`,
            variables: { amount }
          })
        });
        if (!res.ok) {
          return false;
        }
        const json = await res.json();
        return !!json?.data?.createVaultDeposit?.id;
      } catch {
        return false;
      }
    }
  };
  var GenericDOMVaultAdapter = class {
    name;
    domains;
    constructor(name, domains) {
      this.name = name;
      this.domains = domains;
    }
    canDetectBalance() {
      return false;
    }
    async getBalance() {
      return null;
    }
    async getLastWinAmount() {
      return null;
    }
    async vaultAmount(_amount, _currency) {
      const keywords = ["vault", "safe", "save funds", "lock", "stash"];
      const buttons = Array.from(document.querySelectorAll('button, [role="button"]'));
      for (const btn of buttons) {
        const text = (btn.textContent ?? "").trim().toLowerCase();
        if (keywords.some((k) => text.includes(k))) {
          btn.click();
          return true;
        }
      }
      return false;
    }
  };
  var ADAPTERS = [
    new StakeVaultAdapter(),
    new GenericDOMVaultAdapter("roobet", ["roobet.com"]),
    new GenericDOMVaultAdapter("bcgame", ["bc.game"]),
    new GenericDOMVaultAdapter("rollbit", ["rollbit.com"]),
    new GenericDOMVaultAdapter("gamdom", ["gamdom.com"]),
    new GenericDOMVaultAdapter("shuffle", ["shuffle.com"])
  ];
  function getAdapterForHost(hostname2) {
    for (const adapter of ADAPTERS) {
      if (adapter.domains.some((d) => hostname2.includes(d))) return adapter;
    }
    return null;
  }

  // src/cashout-router.ts
  var CASINO_CASHOUT_ROUTES = [
    {
      id: "stake",
      name: "Stake.com",
      domainMatches: ["stake.com"],
      cashierUrl: "https://stake.com/?tab=wallet&modal=withdraw",
      buttonLabel: "Cashier / Withdraw",
      isSweepstakes: false,
      domSelectors: [
        'a[href*="modal=withdraw"]',
        'button[data-test="wallet-button"]',
        'button[data-test="cashier-button"]',
        'a[href*="/wallet"]'
      ]
    },
    {
      id: "stake_us",
      name: "Stake.us",
      domainMatches: ["stake.us"],
      cashierUrl: "https://stake.us/?tab=wallet&modal=withdraw",
      buttonLabel: "Redeem Sweeps Cash",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="modal=withdraw"]',
        'button[data-test="wallet-button"]',
        'a[href*="redeem"]',
        'button[data-test="cashier-button"]'
      ]
    },
    {
      id: "roobet",
      name: "Roobet",
      domainMatches: ["roobet.com"],
      cashierUrl: "https://roobet.com/?modal=cashier&tab=withdraw",
      buttonLabel: "Cashier / Withdraw",
      isSweepstakes: false,
      domSelectors: [
        '[data-test="cashier-btn"]',
        'button[data-test="cashier"]',
        'a[href*="cashier"]',
        'button[data-test="wallet"]'
      ]
    },
    {
      id: "bcgame",
      name: "BC.Game",
      domainMatches: ["bc.game"],
      cashierUrl: "https://bc.game/wallet/withdraw",
      buttonLabel: "Cashier / Withdraw",
      isSweepstakes: false,
      domSelectors: [
        'button[data-test="wallet"]',
        'a[href*="/wallet/withdraw"]',
        'a[href*="/wallet"]'
      ]
    },
    {
      id: "rollbit",
      name: "Rollbit",
      domainMatches: ["rollbit.com"],
      cashierUrl: "https://rollbit.com/deposit",
      buttonLabel: "Wallet / Cashier",
      isSweepstakes: false,
      domSelectors: [
        'button[data-test="deposit-button"]',
        'a[href*="/deposit"]',
        'a[href*="wallet"]'
      ]
    },
    {
      id: "shuffle",
      name: "Shuffle",
      domainMatches: ["shuffle.com"],
      cashierUrl: "https://shuffle.com/wallet",
      buttonLabel: "Wallet / Cashier",
      isSweepstakes: false,
      domSelectors: [
        'button[data-testid="wallet-button"]',
        'a[href*="/wallet"]'
      ]
    },
    {
      id: "gamdom",
      name: "Gamdom",
      domainMatches: ["gamdom.com"],
      cashierUrl: "https://gamdom.com/cashier",
      buttonLabel: "Cashier / Withdraw",
      isSweepstakes: false,
      domSelectors: [
        'button[data-test="cashier"]',
        'a[href*="/cashier"]',
        'a[href*="wallet"]'
      ]
    },
    {
      id: "csgoempire",
      name: "CSGOEmpire",
      domainMatches: ["csgoempire.com"],
      cashierUrl: "https://csgoempire.com/withdraw",
      buttonLabel: "Withdrawal Portal",
      isSweepstakes: false,
      domSelectors: [
        'a[href*="/withdraw"]',
        'button[data-test="withdraw"]'
      ]
    },
    // Sweepstakes Operators
    {
      id: "chumba",
      name: "Chumba Casino",
      domainMatches: ["chumbacasino.com"],
      cashierUrl: "https://lobby.chumbacasino.com/redemption",
      buttonLabel: "Redeem Sweeps Coins",
      isSweepstakes: true,
      domSelectors: [
        'button[data-testid="redeem"]',
        'a[href*="redemption"]',
        'button[aria-label*="Redeem"]'
      ]
    },
    {
      id: "luckyland",
      name: "LuckyLand Slots",
      domainMatches: ["luckylandslots.com"],
      cashierUrl: "https://play.luckylandslots.com/redeem",
      buttonLabel: "Redeem Prize",
      isSweepstakes: true,
      domSelectors: [
        'button[data-testid="redeem"]',
        'a[href*="redeem"]',
        'button[aria-label*="Redeem"]'
      ]
    },
    {
      id: "globalpoker",
      name: "Global Poker",
      domainMatches: ["globalpoker.com"],
      cashierUrl: "https://play.globalpoker.com/redemption",
      buttonLabel: "Redeem Sweeps Coins",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "pulsz",
      name: "Pulsz",
      domainMatches: ["pulsz.com"],
      cashierUrl: "https://www.pulsz.com/redemption",
      buttonLabel: "Redeem Cash Prize",
      isSweepstakes: true,
      domSelectors: [
        'button[data-testid="redeem"]',
        'a[href*="redemption"]'
      ]
    },
    {
      id: "wowvegas",
      name: "WOW Vegas",
      domainMatches: ["wowvegas.com"],
      cashierUrl: "https://www.wowvegas.com/profile/redemption",
      buttonLabel: "Redeem Prize",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "high5casino",
      name: "High 5 Casino",
      domainMatches: ["high5casino.com"],
      cashierUrl: "https://club5.high5casino.com/redemption",
      buttonLabel: "Redemption Center",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "mcluck",
      name: "McLuck",
      domainMatches: ["mcluck.com"],
      cashierUrl: "https://www.mcluck.com/redemption",
      buttonLabel: "Redeem Prize",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "zulacasino",
      name: "Zula Casino",
      domainMatches: ["zulacasino.com", "zula.casino"],
      cashierUrl: "https://www.zulacasino.com/redemption",
      buttonLabel: "Redeem Sweeps Coins",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "funzpoints",
      name: "Funzpoints",
      domainMatches: ["funzpoints.com"],
      cashierUrl: "https://funzpoints.com/cashout",
      buttonLabel: "Cash Out Points",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="cashout"]',
        'button[data-testid="cashout"]'
      ]
    },
    {
      id: "funrize",
      name: "Funrize",
      domainMatches: ["funrize.com"],
      cashierUrl: "https://funrize.com/redemption",
      buttonLabel: "Redeem Winnings",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "realprize",
      name: "Real Prize",
      domainMatches: ["realprize.com"],
      cashierUrl: "https://realprize.com/redemption",
      buttonLabel: "Redeem Prize",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "jackpota",
      name: "Jackpota",
      domainMatches: ["jackpota.com"],
      cashierUrl: "https://jackpota.com/redemption",
      buttonLabel: "Redeem Prize",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    },
    {
      id: "nolimitcoins",
      name: "NoLimitCoins",
      domainMatches: ["nolimitcoins.com"],
      cashierUrl: "https://nolimitcoins.com/redemption",
      buttonLabel: "Redeem Super Coins",
      isSweepstakes: true,
      domSelectors: [
        'a[href*="redemption"]',
        'button[data-testid="redeem"]'
      ]
    }
  ];
  var GENERIC_CASHIER_SELECTORS = [
    'a[href*="withdraw"]',
    'a[href*="redemption"]',
    'a[href*="redeem"]',
    'a[href*="cashier"]',
    'a[href*="wallet"]',
    'button[data-test*="cashier"]',
    'button[data-test*="wallet"]',
    'button[data-test*="withdraw"]',
    'button[data-testid*="redeem"]',
    'button[data-testid*="cashier"]'
  ];
  function findRouteForHostname(hostname2) {
    if (!hostname2) return null;
    const host = hostname2.toLowerCase();
    for (const route of CASINO_CASHOUT_ROUTES) {
      if (route.domainMatches.some((d) => host.includes(d))) {
        return route;
      }
    }
    return null;
  }
  function detectCashoutTarget(doc, hostnameOverride) {
    const hostname2 = hostnameOverride ?? doc.location?.hostname ?? (typeof window !== "undefined" ? window.location?.hostname : "") ?? "";
    const route = findRouteForHostname(hostname2);
    let clickTarget = null;
    if (route) {
      for (const selector of route.domSelectors) {
        const el = doc.querySelector(selector);
        if (el) {
          clickTarget = el;
          break;
        }
      }
    }
    if (!clickTarget) {
      for (const selector of GENERIC_CASHIER_SELECTORS) {
        const el = doc.querySelector(selector);
        if (el) {
          clickTarget = el;
          break;
        }
      }
    }
    const cashierUrl = route?.cashierUrl || null;
    const buttonLabel = route?.buttonLabel || "Cashier / Withdraw";
    const isSweepstakes = route?.isSweepstakes || false;
    const casinoName = route?.name || (hostname2 ? hostname2.replace(/^www\./, "") : null);
    return {
      route,
      clickTarget,
      cashierUrl,
      buttonLabel,
      isSweepstakes,
      casinoName
    };
  }
  function triggerCashoutNavigation(doc, hostnameOverride) {
    const { clickTarget, cashierUrl } = detectCashoutTarget(doc, hostnameOverride);
    if (clickTarget) {
      try {
        clickTarget.click();
        return {
          navigated: true,
          method: "click",
          target: clickTarget.tagName.toLowerCase()
        };
      } catch {
      }
    }
    if (cashierUrl) {
      if (doc.location) {
        doc.location.href = cashierUrl;
      }
      return {
        navigated: true,
        method: "href",
        target: cashierUrl
      };
    }
    const host = hostnameOverride ?? doc.location?.hostname ?? (typeof window !== "undefined" ? window.location?.hostname : "") ?? "";
    if (host) {
      const fallbackUrl = `https://${host}/cashier`;
      if (doc.location) {
        doc.location.href = fallbackUrl;
      }
      return {
        navigated: true,
        method: "href",
        target: fallbackUrl
      };
    }
    return { navigated: false, method: "none", target: "" };
  }
  async function triggerAutoVault(amount, currency = "usd", doc = document, hostnameOverride) {
    const hostname2 = hostnameOverride ?? doc.location?.hostname ?? (typeof window !== "undefined" ? window.location?.hostname : "") ?? "";
    const adapter = getAdapterForHost(hostname2);
    if (!adapter) {
      return {
        vaulted: false,
        method: "none",
        amount,
        currency,
        casinoName: null,
        error: "No vault adapter available for this operator."
      };
    }
    try {
      const success = await adapter.vaultAmount(amount, currency);
      const method = adapter.name === "stake" ? "api" : "dom";
      return {
        vaulted: success,
        method: success ? method : "none",
        amount,
        currency,
        casinoName: adapter.name,
        error: success ? void 0 : "Vault transaction failed or button not found."
      };
    } catch (err) {
      return {
        vaulted: false,
        method: "none",
        amount,
        currency,
        casinoName: adapter.name,
        error: err instanceof Error ? err.message : "Unknown error during auto-vault."
      };
    }
  }

  // src/reality-hud.ts
  var DEFAULT_HOURLY_WAGE = 25;
  var MIN_HOURLY_WAGE = 5;
  var MAX_HOURLY_WAGE = 2e3;
  var DEFAULT_REALITY_HUD_ENABLED = true;
  var DEFAULT_REALITY_THRESHOLD_HOURS = 2;
  var MIN_REALITY_THRESHOLD_HOURS = 0.5;
  var MAX_REALITY_THRESHOLD_HOURS = 24;
  var REALITY_HUD_ID = "tiltcheck-reality-hud";
  var REALITY_HUD_POLL_MS = 1e3;
  function clampHourlyWage(val) {
    const n = typeof val === "number" ? val : Number(val);
    if (!Number.isFinite(n)) return DEFAULT_HOURLY_WAGE;
    return Math.min(MAX_HOURLY_WAGE, Math.max(MIN_HOURLY_WAGE, Math.round(n)));
  }
  function clampThresholdHours(val) {
    const n = typeof val === "number" ? val : Number(val);
    if (!Number.isFinite(n) || n <= 0) return DEFAULT_REALITY_THRESHOLD_HOURS;
    return Math.min(MAX_REALITY_THRESHOLD_HOURS, Math.max(MIN_REALITY_THRESHOLD_HOURS, n));
  }
  function computeWageEquivalence(drawdown, hourlyWage) {
    if (drawdown <= 0 || hourlyWage <= 0) {
      return 0;
    }
    return drawdown / hourlyWage;
  }
  function formatRealityMessage(drawdown, hours) {
    const absDrawdown = Math.abs(drawdown);
    if (hours >= 8) {
      return `Session Drawdown: -$${absDrawdown.toFixed(2)} (${hours.toFixed(1)} hrs of labor torched). That's a full shift gone. Step away.`;
    }
    return `Session Drawdown: -$${absDrawdown.toFixed(2)} (${hours.toFixed(1)} hrs of work torched). Step back.`;
  }
  function parseMoney2(text) {
    if (text == null) return null;
    const tokens = text.split(/\s+/).map((token) => token.replace(/,/g, "").replace(/[^\d.-]/g, ""));
    const matches = tokens.filter((token) => /^-?\d+(\.\d+)?$/.test(token));
    if (matches.length !== 1) return null;
    return Number(matches[0]);
  }
  function readBalance(doc) {
    const hostname2 = doc.location?.hostname ?? "";
    const entry = CASINO_SELECTORS.find(
      (item) => hostname2 && hostname2.includes(item.domain) || item.domain === "*"
    );
    const selector = entry?.selectors?.balance;
    if (selector) {
      const elements = doc.querySelectorAll(selector);
      for (const el of elements) {
        const raw = el.getAttribute("data-value") || el.getAttribute("value") || el.textContent;
        const parsed = parseMoney2(raw);
        if (parsed !== null) return parsed;
      }
    }
    const fallbackElements = doc.querySelectorAll('[data-balance], [data-test="balance"], .balance, [class*="balance-value"], [class*="balance"]');
    for (const fallback of fallbackElements) {
      const raw = fallback.getAttribute("data-value") || fallback.getAttribute("value") || fallback.textContent;
      const parsed = parseMoney2(raw);
      if (parsed !== null) return parsed;
    }
    return null;
  }
  function installRealityHud(doc, options) {
    let opts = {
      hourlyWage: clampHourlyWage(options?.hourlyWage ?? DEFAULT_HOURLY_WAGE),
      enabled: options?.enabled ?? DEFAULT_REALITY_HUD_ENABLED,
      thresholdHours: clampThresholdHours(options?.thresholdHours ?? DEFAULT_REALITY_THRESHOLD_HOURS)
    };
    let baselineBalance = null;
    let lastCurrentBalance = null;
    let dismissed = false;
    let lastDismissedDrawdown = 0;
    let stopped = false;
    let pollId = null;
    const removeHud = () => {
      const existing = doc.getElementById(REALITY_HUD_ID);
      if (existing) {
        existing.remove();
      }
    };
    const isVisible = () => {
      const el = doc.getElementById(REALITY_HUD_ID);
      return Boolean(el && el.style.display !== "none" && el.isConnected);
    };
    const dismiss = () => {
      dismissed = true;
      const el = doc.getElementById(REALITY_HUD_ID);
      if (el) {
        el.style.display = "none";
      }
    };
    const renderOrUpdateHud = (drawdown, hours) => {
      let hud = doc.getElementById(REALITY_HUD_ID);
      const message = formatRealityMessage(drawdown, hours);
      if (!hud) {
        hud = doc.createElement("div");
        hud.id = REALITY_HUD_ID;
        hud.setAttribute("role", "status");
        hud.setAttribute("aria-live", "polite");
        hud.style.cssText = [
          "position: fixed",
          "top: 1rem",
          "left: 50%",
          "transform: translateX(-50%)",
          "z-index: 2147483646",
          "background: #0f1115",
          "border: 1px solid #ff4a4a",
          "border-radius: 6px",
          "color: #ffffff",
          'font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace',
          "font-size: 0.875rem",
          "font-weight: 600",
          "padding: 0.75rem 1rem",
          "display: flex",
          "align-items: center",
          "gap: 0.75rem",
          "box-shadow: 0 4px 20px rgba(0, 0, 0, 0.7)",
          "max-width: 90vw",
          "box-sizing: border-box",
          "pointer-events: auto"
        ].join(";");
        const textSpan = doc.createElement("span");
        textSpan.className = "tiltcheck-reality-hud-text";
        textSpan.textContent = message;
        const dismissBtn = doc.createElement("button");
        dismissBtn.type = "button";
        dismissBtn.className = "tiltcheck-reality-hud-dismiss";
        dismissBtn.setAttribute("aria-label", "Dismiss reality HUD");
        dismissBtn.textContent = "x";
        dismissBtn.style.cssText = [
          "background: transparent",
          "border: none",
          "color: #ff4a4a",
          "font-family: inherit",
          "font-size: 1rem",
          "font-weight: bold",
          "cursor: pointer",
          "padding: 0 4px",
          "line-height: 1"
        ].join(";");
        dismissBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          lastDismissedDrawdown = drawdown;
          dismiss();
        });
        const cashoutBtn = doc.createElement("button");
        cashoutBtn.type = "button";
        cashoutBtn.className = "tiltcheck-reality-hud-cashout";
        cashoutBtn.setAttribute("aria-label", "Open casino cashier");
        cashoutBtn.textContent = "Cashier ->";
        cashoutBtn.style.cssText = [
          "background: #17c3b2",
          "border: none",
          "border-radius: 4px",
          "color: #000000",
          "font-family: inherit",
          "font-size: 0.75rem",
          "font-weight: 700",
          "cursor: pointer",
          "padding: 3px 8px",
          "text-transform: uppercase",
          "margin-left: 0.5rem",
          "white-space: nowrap"
        ].join(";");
        cashoutBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          triggerCashoutNavigation(doc);
        });
        hud.appendChild(textSpan);
        hud.appendChild(cashoutBtn);
        hud.appendChild(dismissBtn);
        (doc.body ?? doc.documentElement).appendChild(hud);
      } else {
        const textSpan = hud.querySelector(".tiltcheck-reality-hud-text");
        if (textSpan) {
          textSpan.textContent = message;
        }
        hud.style.display = "flex";
      }
    };
    const check = (balanceOverride) => {
      if (stopped || !opts.enabled) {
        removeHud();
        return;
      }
      const currentBalance = typeof balanceOverride === "number" ? balanceOverride : readBalance(doc) ?? lastCurrentBalance;
      if (currentBalance === null || !Number.isFinite(currentBalance)) {
        return;
      }
      lastCurrentBalance = currentBalance;
      if (baselineBalance === null) {
        baselineBalance = currentBalance;
        return;
      }
      if (currentBalance > baselineBalance) {
        baselineBalance = currentBalance;
        dismissed = false;
        removeHud();
        return;
      }
      const drawdown = baselineBalance - currentBalance;
      const hours = computeWageEquivalence(drawdown, opts.hourlyWage);
      if (drawdown <= 0 || hours < opts.thresholdHours) {
        removeHud();
        return;
      }
      if (dismissed) {
        if (drawdown >= lastDismissedDrawdown + opts.hourlyWage) {
          dismissed = false;
        } else {
          return;
        }
      }
      renderOrUpdateHud(drawdown, hours);
    };
    const onClickCapture = () => {
      check();
    };
    doc.addEventListener("click", onClickCapture, true);
    pollId = setInterval(() => check(), REALITY_HUD_POLL_MS);
    check();
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onClickCapture, true);
      if (pollId !== null) {
        clearInterval(pollId);
        pollId = null;
      }
      removeHud();
    };
    const updateOptions = (newOpts) => {
      if (newOpts.hourlyWage !== void 0) {
        opts.hourlyWage = clampHourlyWage(newOpts.hourlyWage);
      }
      if (newOpts.enabled !== void 0) {
        opts.enabled = newOpts.enabled;
      }
      if (newOpts.thresholdHours !== void 0) {
        opts.thresholdHours = clampThresholdHours(newOpts.thresholdHours);
      }
      check(lastCurrentBalance ?? void 0);
    };
    return {
      stop,
      check,
      getBaseline: () => baselineBalance,
      setBaseline: (b) => {
        baselineBalance = b;
        dismissed = false;
        check(lastCurrentBalance ?? void 0);
      },
      isVisible,
      dismiss,
      getOptions: () => ({ ...opts }),
      updateOptions
    };
  }

  // src/profit-lock.ts
  var DEFAULT_PROFIT_LOCK_ENABLED = true;
  var DEFAULT_TRAILING_PERCENT = 50;
  var DEFAULT_MIN_PROFIT = 50;
  var DEFAULT_CASHOUT_GOALS_ENABLED = true;
  var DEFAULT_HARD_GUARD_COOLDOWN_MS = 6e4;
  var PROFIT_LOCK_MODAL_ID = "tiltcheck-profit-lock-modal";
  var GOAL_TOAST_CONTAINER_ID = "tiltcheck-goals-toast-container";
  var PROFIT_LOCK_STYLES_ID = "tiltcheck-profit-lock-styles";
  var DEFAULT_CASHOUT_GOALS = [
    {
      id: "spotify",
      name: "Spotify Premium (1 Mo)",
      targetAmount: 11,
      linkUrl: "https://www.spotify.com",
      metric: "balance",
      enabled: true
    },
    {
      id: "trash_bags",
      name: "Trash Bags & Essentials",
      targetAmount: 15,
      linkUrl: "https://www.amazon.com",
      metric: "balance",
      enabled: true
    },
    {
      id: "gas_tank",
      name: "Full Tank of Gas",
      targetAmount: 50,
      linkUrl: "",
      metric: "balance",
      enabled: true
    },
    {
      id: "power_bill",
      name: "Power Bill",
      targetAmount: 250,
      linkUrl: "",
      metric: "balance",
      enabled: true
    },
    {
      id: "rent_car",
      name: "Rent / Car Payment",
      targetAmount: 600,
      linkUrl: "",
      metric: "profit",
      enabled: true
    }
  ];
  function computeRatchetFloor(baseline, peak, trailingPercent, minProfit) {
    if (peak <= baseline) return null;
    const profit = peak - baseline;
    if (profit < minProfit) return null;
    const pct = Math.min(95, Math.max(10, trailingPercent));
    const lockedProfit = profit * (pct / 100);
    return Math.round((baseline + lockedProfit) * 100) / 100;
  }
  function isGoalUnlocked(goal, currentBalance, baselineBalance) {
    if (!goal.enabled || goal.targetAmount <= 0) return false;
    if (goal.metric === "profit") {
      if (baselineBalance === null) return false;
      return currentBalance - baselineBalance >= goal.targetAmount;
    }
    return currentBalance >= goal.targetAmount;
  }
  function sanitizeCashoutGoals(raw) {
    if (!Array.isArray(raw)) {
      return [...DEFAULT_CASHOUT_GOALS];
    }
    const result = [];
    for (const item of raw) {
      if (typeof item !== "object" || item === null) continue;
      const obj = item;
      const id = typeof obj["id"] === "string" && obj["id"].trim() ? obj["id"].trim() : `goal_${Date.now()}_${Math.random()}`;
      const name = typeof obj["name"] === "string" && obj["name"].trim() ? obj["name"].trim() : "Unnamed Goal";
      const targetAmount = typeof obj["targetAmount"] === "number" && Number.isFinite(obj["targetAmount"]) ? Math.max(1, obj["targetAmount"]) : 10;
      const linkUrl = typeof obj["linkUrl"] === "string" ? obj["linkUrl"].trim() : "";
      const metric = obj["metric"] === "profit" ? "profit" : "balance";
      const enabled = typeof obj["enabled"] === "boolean" ? obj["enabled"] : true;
      result.push({ id, name, targetAmount, linkUrl, metric, enabled });
    }
    return result.length > 0 ? result : [...DEFAULT_CASHOUT_GOALS];
  }
  function ensureStyles2(doc) {
    if (doc.getElementById(PROFIT_LOCK_STYLES_ID)) return;
    const style = doc.createElement("style");
    style.id = PROFIT_LOCK_STYLES_ID;
    style.textContent = `
    #${GOAL_TOAST_CONTAINER_ID} {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 2147483645;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
      font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .tiltcheck-goal-toast {
      pointer-events: auto;
      background: #080a0e;
      border: 1px solid #17c3b2;
      border-left: 4px solid #17c3b2;
      border-radius: 8px;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.6), 0 0 20px rgba(23, 195, 178, 0.2);
      padding: 14px 16px;
      width: 320px;
      color: #ffffff;
      animation: tiltcheck-toast-slide 0.25s ease-out;
    }
    @keyframes tiltcheck-toast-slide {
      from { transform: translateX(40px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    .tiltcheck-toast-tag {
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: #17c3b2;
      margin-bottom: 4px;
    }
    .tiltcheck-toast-title {
      font-size: 14px;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 4px;
    }
    .tiltcheck-toast-desc {
      font-size: 12px;
      color: rgba(160, 175, 190, 0.9);
      line-height: 1.4;
      margin-bottom: 10px;
    }
    .tiltcheck-toast-actions {
      display: flex;
      gap: 8px;
      align-items: center;
    }
    .tiltcheck-toast-btn-primary {
      background: #17c3b2;
      color: #000000;
      font-weight: 700;
      font-size: 11px;
      padding: 6px 12px;
      border-radius: 4px;
      text-decoration: none;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .tiltcheck-toast-btn-primary:hover {
      background: #1ae5d1;
    }
    .tiltcheck-toast-btn-subtle {
      background: rgba(255, 255, 255, 0.08);
      color: rgba(255, 255, 255, 0.7);
      font-size: 11px;
      padding: 6px 10px;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.12);
      cursor: pointer;
    }
    .tiltcheck-toast-btn-subtle:hover {
      color: #ffffff;
      background: rgba(255, 255, 255, 0.16);
    }
    #${PROFIT_LOCK_MODAL_ID} {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(8, 10, 14, 0.88);
      backdrop-filter: blur(8px);
      z-index: 2147483646;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .tiltcheck-modal-card {
      background: #0d1117;
      border: 1px solid #fbbf24;
      border-radius: 12px;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.8), 0 0 30px rgba(251, 191, 36, 0.2);
      width: 90%;
      max-width: 440px;
      padding: 24px;
      color: #ffffff;
      text-align: center;
      animation: tiltcheck-modal-pop 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes tiltcheck-modal-pop {
      from { transform: scale(0.92); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    .tiltcheck-modal-tag {
      font-size: 11px;
      font-weight: 800;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: #fbbf24;
      margin-bottom: 8px;
    }
    .tiltcheck-modal-title {
      font-size: 20px;
      font-weight: 800;
      margin-bottom: 10px;
      color: #ffffff;
    }
    .tiltcheck-modal-stats {
      background: rgba(255, 255, 255, 0.04);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 8px;
      padding: 12px;
      margin: 16px 0;
      display: flex;
      justify-content: space-around;
      font-size: 12px;
    }
    .tiltcheck-stat-item {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .tiltcheck-stat-label {
      color: rgba(160, 175, 190, 0.8);
      font-size: 10px;
      text-transform: uppercase;
    }
    .tiltcheck-stat-val {
      font-weight: 700;
      font-size: 14px;
      font-family: 'JetBrains Mono', monospace;
    }
    .tiltcheck-modal-body {
      font-size: 13px;
      color: rgba(200, 210, 220, 0.9);
      line-height: 1.5;
      margin-bottom: 20px;
    }
    .tiltcheck-modal-actions {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .tiltcheck-modal-btn-cashout {
      background: #17c3b2;
      color: #000000;
      font-weight: 800;
      font-size: 14px;
      padding: 12px 20px;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .tiltcheck-modal-btn-cashout:hover {
      background: #1ae5d1;
    }
    .tiltcheck-modal-btn-ack {
      background: transparent;
      color: rgba(160, 175, 190, 0.7);
      font-size: 12px;
      padding: 8px;
      border: none;
      cursor: pointer;
    }
    .tiltcheck-modal-btn-ack:hover {
      color: #ffffff;
      text-decoration: underline;
    }
  `;
    (doc.head || doc.documentElement).appendChild(style);
  }
  function showGoalToast(doc, goal, balance) {
    ensureStyles2(doc);
    let container = doc.getElementById(GOAL_TOAST_CONTAINER_ID);
    if (!container) {
      container = doc.createElement("div");
      container.id = GOAL_TOAST_CONTAINER_ID;
      (doc.body || doc.documentElement).appendChild(container);
    }
    const toast = doc.createElement("div");
    toast.className = "tiltcheck-goal-toast";
    toast.setAttribute("data-goal-id", goal.id);
    const metricLabel = goal.metric === "profit" ? "Profit Goal Funded" : "Cashout Goal Unlocked";
    const actionButtonHtml = goal.linkUrl ? `<a href="${goal.linkUrl}" target="_blank" rel="noopener noreferrer" class="tiltcheck-toast-btn-primary">Pay / Buy Now (${goal.targetAmount}) &rarr;</a>` : `<button type="button" class="tiltcheck-toast-btn-primary tiltcheck-goal-cashout-btn">Lock In Profit &rarr;</button>`;
    toast.innerHTML = `
    <div class="tiltcheck-toast-tag">${metricLabel}</div>
    <div class="tiltcheck-toast-title">${goal.name} ($${goal.targetAmount.toFixed(2)})</div>
    <div class="tiltcheck-toast-desc">Current balance is $${balance.toFixed(2)}. Turn electronic casino chips into real-world peace of mind.</div>
    <div class="tiltcheck-toast-actions">
      ${actionButtonHtml}
      <button type="button" class="tiltcheck-toast-btn-subtle tiltcheck-goal-dismiss-btn">Dismiss</button>
    </div>
  `;
    const dismissBtn = toast.querySelector(".tiltcheck-goal-dismiss-btn");
    dismissBtn?.addEventListener("click", () => {
      toast.remove();
    });
    const cashoutBtn = toast.querySelector(".tiltcheck-goal-cashout-btn");
    cashoutBtn?.addEventListener("click", () => {
      toast.remove();
      navigateToCashier(doc);
    });
    container.appendChild(toast);
    setTimeout(() => {
      if (toast.parentElement) {
        toast.remove();
      }
    }, 1e4);
  }
  function navigateToCashier(doc) {
    triggerCashoutNavigation(doc);
  }
  function showSoftWarningModal(doc, data) {
    ensureStyles2(doc);
    if (doc.getElementById(PROFIT_LOCK_MODAL_ID)) return;
    const modal = doc.createElement("div");
    modal.id = PROFIT_LOCK_MODAL_ID;
    const profitMade = data.current - data.baseline;
    const profitText = profitMade >= 0 ? `+$${profitMade.toFixed(2)}` : `-$${Math.abs(profitMade).toFixed(2)}`;
    modal.innerHTML = `
    <div class="tiltcheck-modal-card">
      <div class="tiltcheck-modal-tag">Profit-Lock Intervention</div>
      <div class="tiltcheck-modal-title">Ratchet Floor Touched</div>
      <div class="tiltcheck-modal-stats">
        <div class="tiltcheck-stat-item">
          <span class="tiltcheck-stat-label">Initial</span>
          <span class="tiltcheck-stat-val">$${data.baseline.toFixed(2)}</span>
        </div>
        <div class="tiltcheck-stat-item">
          <span class="tiltcheck-stat-label">Session Peak</span>
          <span class="tiltcheck-stat-val" style="color:#17c3b2;">$${data.peak.toFixed(2)}</span>
        </div>
        <div class="tiltcheck-stat-item">
          <span class="tiltcheck-stat-label">Ratchet Floor</span>
          <span class="tiltcheck-stat-val" style="color:#fbbf24;">$${data.floor.toFixed(2)}</span>
        </div>
        <div class="tiltcheck-stat-item">
          <span class="tiltcheck-stat-label">Current</span>
          <span class="tiltcheck-stat-val">${profitText}</span>
        </div>
      </div>
      <div class="tiltcheck-modal-body">
        You ran your balance up to <strong>$${data.peak.toFixed(2)}</strong>. You have hit your protected floor at <strong>$${data.floor.toFixed(2)}</strong>.
        Cash out now while you are still ahead. If you continue spinning below this floor, a 60-second hard brake will be engaged.
      </div>
      <div class="tiltcheck-modal-actions">
        <button type="button" class="tiltcheck-modal-btn-cashout" id="tiltcheck-modal-cashout-btn">Cash Out at Cashier &rarr;</button>
        <button type="button" class="tiltcheck-modal-btn-ack" id="tiltcheck-modal-ack-btn">I acknowledge the risk (Next spin arms Hard Guard)</button>
      </div>
    </div>
  `;
    modal.querySelector("#tiltcheck-modal-cashout-btn")?.addEventListener("click", () => {
      modal.remove();
      data.onCashout();
      navigateToCashier(doc);
    });
    modal.querySelector("#tiltcheck-modal-ack-btn")?.addEventListener("click", () => {
      modal.remove();
      data.onAcknowledge();
    });
    (doc.body || doc.documentElement).appendChild(modal);
  }
  function installProfitLock(doc, initialOptions) {
    let opts = {
      profitLockEnabled: initialOptions?.profitLockEnabled ?? DEFAULT_PROFIT_LOCK_ENABLED,
      trailingPercent: initialOptions?.trailingPercent ?? DEFAULT_TRAILING_PERCENT,
      minProfit: initialOptions?.minProfit ?? DEFAULT_MIN_PROFIT,
      goalsEnabled: initialOptions?.goalsEnabled ?? DEFAULT_CASHOUT_GOALS_ENABLED,
      goals: initialOptions?.goals ? sanitizeCashoutGoals(initialOptions.goals) : [...DEFAULT_CASHOUT_GOALS],
      hardGuardCooldownMs: initialOptions?.hardGuardCooldownMs ?? DEFAULT_HARD_GUARD_COOLDOWN_MS
    };
    let baselineBalance = null;
    let peakBalance = 0;
    let currentFloor = null;
    let softWarningAcknowledged = false;
    let hardGuardTriggered = false;
    let stopped = false;
    const unlockedGoalIds = /* @__PURE__ */ new Set();
    function evaluate(current) {
      if (stopped || current < 0) return;
      if (baselineBalance === null) {
        baselineBalance = current;
        peakBalance = current;
        return;
      }
      if (current > peakBalance) {
        peakBalance = current;
        if (currentFloor !== null && current > currentFloor) {
          softWarningAcknowledged = false;
        }
      }
      if (opts.goalsEnabled) {
        for (const goal of opts.goals) {
          if (!unlockedGoalIds.has(goal.id) && isGoalUnlocked(goal, current, baselineBalance)) {
            unlockedGoalIds.add(goal.id);
            showGoalToast(doc, goal, current);
          }
        }
      }
      if (opts.profitLockEnabled) {
        const calculatedFloor = computeRatchetFloor(
          baselineBalance,
          peakBalance,
          opts.trailingPercent,
          opts.minProfit
        );
        currentFloor = calculatedFloor;
        if (currentFloor !== null && current <= currentFloor) {
          if (!softWarningAcknowledged) {
            showSoftWarningModal(doc, {
              baseline: baselineBalance,
              peak: peakBalance,
              floor: currentFloor,
              current,
              onAcknowledge: () => {
                softWarningAcknowledged = true;
              },
              onCashout: () => {
                softWarningAcknowledged = true;
              }
            });
          } else if (!hardGuardTriggered) {
            hardGuardTriggered = true;
            triggerTouchGrassTimeout(
              `Profit-Lock Hard Guard: You reached a peak of $${peakBalance.toFixed(2)} with a floor at $${currentFloor.toFixed(2)}. 60-second brake engaged so you don't rage-dump your profit. Step back and cash out.`,
              opts.hardGuardCooldownMs
            );
          }
        }
      }
    }
    function check(balanceOverride) {
      if (stopped) return;
      const balance = balanceOverride !== void 0 ? balanceOverride : readBalance(doc);
      if (balance !== null) {
        evaluate(balance);
      }
    }
    const onSpinClickCapture = (_e) => {
      if (stopped || !opts.profitLockEnabled || currentFloor === null || !softWarningAcknowledged) {
        return;
      }
      const current = readBalance(doc);
      if (current !== null && current <= currentFloor && !hardGuardTriggered) {
        hardGuardTriggered = true;
        triggerTouchGrassTimeout(
          `Profit-Lock Hard Guard: Floor touched at $${currentFloor.toFixed(2)}. 60-second brake engaged so you don't burn your profit.`,
          opts.hardGuardCooldownMs
        );
      }
    };
    doc.addEventListener("click", onSpinClickCapture, true);
    const pollInterval = setInterval(() => {
      check();
    }, 1e3);
    return {
      stop: () => {
        stopped = true;
        clearInterval(pollInterval);
        doc.removeEventListener("click", onSpinClickCapture, true);
        doc.getElementById(PROFIT_LOCK_MODAL_ID)?.remove();
        doc.getElementById(GOAL_TOAST_CONTAINER_ID)?.remove();
        doc.getElementById(PROFIT_LOCK_STYLES_ID)?.remove();
      },
      check,
      getBaseline: () => baselineBalance,
      getPeak: () => peakBalance,
      getFloor: () => currentFloor,
      isSoftWarningActive: () => doc.getElementById(PROFIT_LOCK_MODAL_ID) !== null,
      isHardGuardTriggered: () => hardGuardTriggered,
      getOptions: () => ({ ...opts }),
      updateOptions: (newOpts) => {
        Object.assign(opts, newOpts);
        if (newOpts.goals) {
          opts.goals = sanitizeCashoutGoals(newOpts.goals);
        }
      }
    };
  }

  // src/core-options.ts
  var TILTCHECK_RISK_THRESHOLD_KEY = "tiltcheck_risk_threshold";
  var TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY = "tiltcheck_touch_grass_duration_ms";
  var TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY = "tiltcheck_touch_grass_cooldown_ms";
  var TILTCHECK_TOUCH_GRASS_OPT_IN_KEY = "tiltcheck_touch_grass_opt_in";
  var TILTCHECK_RISK_PROFILE_KEY = "tiltcheck_risk_profile";
  var TILTCHECK_HOURLY_WAGE_KEY = "tiltcheck_hourly_wage";
  var TILTCHECK_REALITY_HUD_ENABLED_KEY = "tiltcheck_reality_hud_enabled";
  var TILTCHECK_REALITY_THRESHOLD_HOURS_KEY = "tiltcheck_reality_threshold_hours";
  var TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY = "tiltcheck_deposit_barrier_enabled";
  var TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY = "tiltcheck_reverse_withdrawal_shield_enabled";
  var TILTCHECK_PROFIT_LOCK_ENABLED_KEY = "tiltcheck_profit_lock_enabled";
  var TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY = "tiltcheck_profit_lock_trailing_percent";
  var TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY = "tiltcheck_profit_lock_min_profit";
  var TILTCHECK_CASHOUT_GOALS_ENABLED_KEY = "tiltcheck_cashout_goals_enabled";
  var TILTCHECK_CASHOUT_GOALS_KEY = "tiltcheck_cashout_goals";
  var TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY = "tiltcheck_cooldown_active_until";
  var DEFAULT_RISK_PROFILE = "moderate";
  var CORE_CIRCUIT_BREAKER_STORAGE_KEYS = [
    TILTCHECK_RISK_THRESHOLD_KEY,
    TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
    TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
    TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
    TILTCHECK_RISK_PROFILE_KEY,
    TILTCHECK_HOURLY_WAGE_KEY,
    TILTCHECK_REALITY_HUD_ENABLED_KEY,
    TILTCHECK_REALITY_THRESHOLD_HOURS_KEY,
    TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY,
    TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY,
    TILTCHECK_PROFIT_LOCK_ENABLED_KEY,
    TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY,
    TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY,
    TILTCHECK_CASHOUT_GOALS_ENABLED_KEY,
    TILTCHECK_CASHOUT_GOALS_KEY,
    TILTCHECK_BONUS_TRACKER_CONFIG_KEY,
    TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY
  ];
  function normalizeRiskProfile(value, legacyRiskLevel) {
    if (value === "conservative" || value === "moderate" || value === "degen") {
      return value;
    }
    if (legacyRiskLevel === "conservative" || legacyRiskLevel === "moderate" || legacyRiskLevel === "degen") {
      return legacyRiskLevel;
    }
    return DEFAULT_RISK_PROFILE;
  }
  var DEFAULT_RISK_THRESHOLD = 85;
  var DEFAULT_TOUCH_GRASS_DURATION_MS = TOUCH_GRASS_DURATION_MS;
  var DEFAULT_TOUCH_GRASS_COOLDOWN_MS = DEFAULT_TOUCH_GRASS_DURATION_MS + 5e3;
  var DEFAULT_HOURLY_WAGE2 = 25;
  var MIN_HOURLY_WAGE2 = 5;
  var MAX_HOURLY_WAGE2 = 2e3;
  var DEFAULT_REALITY_HUD_ENABLED2 = true;
  var DEFAULT_REALITY_THRESHOLD_HOURS2 = 2;
  var MIN_REALITY_THRESHOLD_HOURS2 = 0.5;
  var MAX_REALITY_THRESHOLD_HOURS2 = 24;
  var DEFAULT_DEPOSIT_BARRIER_ENABLED = true;
  var DEFAULT_REVERSE_WITHDRAWAL_SHIELD_ENABLED = true;
  var DEFAULT_PROFIT_LOCK_ENABLED2 = true;
  var DEFAULT_TRAILING_PERCENT2 = 50;
  var DEFAULT_MIN_PROFIT2 = 50;
  var DEFAULT_CASHOUT_GOALS_ENABLED2 = true;
  var MIN_RISK_THRESHOLD = 50;
  var MAX_RISK_THRESHOLD = 100;
  var MIN_DURATION_MS = 3e4;
  var MAX_DURATION_MS = 6e5;
  var MIN_COOLDOWN_MS = 3e4;
  var MAX_COOLDOWN_MS = 9e5;
  function clampInt(value, min, max, fallback) {
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, Math.round(n)));
  }
  function clampFloat(value, min, max, fallback) {
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(max, Math.max(min, n));
  }
  async function loadCoreCircuitBreakerOptions() {
    try {
      const stored = await chrome.storage.local.get([
        TILTCHECK_RISK_THRESHOLD_KEY,
        TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
        TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
        TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
        TILTCHECK_RISK_PROFILE_KEY,
        TILTCHECK_HOURLY_WAGE_KEY,
        TILTCHECK_REALITY_HUD_ENABLED_KEY,
        TILTCHECK_REALITY_THRESHOLD_HOURS_KEY,
        TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY,
        TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY,
        TILTCHECK_PROFIT_LOCK_ENABLED_KEY,
        TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY,
        TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY,
        TILTCHECK_CASHOUT_GOALS_ENABLED_KEY,
        TILTCHECK_CASHOUT_GOALS_KEY,
        TILTCHECK_BONUS_TRACKER_CONFIG_KEY,
        TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY,
        "riskLevel"
      ]);
      const durationMs = clampInt(
        stored[TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY],
        MIN_DURATION_MS,
        MAX_DURATION_MS,
        DEFAULT_TOUCH_GRASS_DURATION_MS
      );
      const cooldownDefault = durationMs + 5e3;
      const cooldownMs = clampInt(
        stored[TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY],
        MIN_COOLDOWN_MS,
        MAX_COOLDOWN_MS,
        cooldownDefault
      );
      const optIn = stored[TILTCHECK_TOUCH_GRASS_OPT_IN_KEY];
      const enforcementEnabled = optIn === void 0 ? true : optIn === true;
      const hourlyWage = clampInt(
        stored[TILTCHECK_HOURLY_WAGE_KEY],
        MIN_HOURLY_WAGE2,
        MAX_HOURLY_WAGE2,
        DEFAULT_HOURLY_WAGE2
      );
      const realityHudOpt = stored[TILTCHECK_REALITY_HUD_ENABLED_KEY];
      const realityHudEnabled = realityHudOpt === void 0 ? DEFAULT_REALITY_HUD_ENABLED2 : realityHudOpt === true;
      const realityThresholdHours = clampFloat(
        stored[TILTCHECK_REALITY_THRESHOLD_HOURS_KEY],
        MIN_REALITY_THRESHOLD_HOURS2,
        MAX_REALITY_THRESHOLD_HOURS2,
        DEFAULT_REALITY_THRESHOLD_HOURS2
      );
      const depositBarrierOpt = stored[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY];
      const depositBarrierEnabled = depositBarrierOpt === void 0 ? DEFAULT_DEPOSIT_BARRIER_ENABLED : depositBarrierOpt === true;
      const reverseWithdrawalShieldOpt = stored[TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY];
      const reverseWithdrawalShieldEnabled = reverseWithdrawalShieldOpt === void 0 ? DEFAULT_REVERSE_WITHDRAWAL_SHIELD_ENABLED : reverseWithdrawalShieldOpt === true;
      const profitLockOpt = stored[TILTCHECK_PROFIT_LOCK_ENABLED_KEY];
      const profitLockEnabled = profitLockOpt === void 0 ? DEFAULT_PROFIT_LOCK_ENABLED2 : profitLockOpt === true;
      const trailingPercent = clampInt(
        stored[TILTCHECK_PROFIT_LOCK_TRAILING_PERCENT_KEY],
        10,
        90,
        DEFAULT_TRAILING_PERCENT2
      );
      const minProfit = clampInt(
        stored[TILTCHECK_PROFIT_LOCK_MIN_PROFIT_KEY],
        10,
        1e4,
        DEFAULT_MIN_PROFIT2
      );
      const goalsOpt = stored[TILTCHECK_CASHOUT_GOALS_ENABLED_KEY];
      const goalsEnabled = goalsOpt === void 0 ? DEFAULT_CASHOUT_GOALS_ENABLED2 : goalsOpt === true;
      const goals = sanitizeCashoutGoals(stored[TILTCHECK_CASHOUT_GOALS_KEY]);
      const bonusConfig = sanitizeBonusConfig(stored[TILTCHECK_BONUS_TRACKER_CONFIG_KEY]);
      const cooldownActiveUntil = typeof stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY] === "number" && Number.isFinite(stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]) ? Math.max(0, stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]) : 0;
      return {
        riskThreshold: clampInt(
          stored[TILTCHECK_RISK_THRESHOLD_KEY],
          MIN_RISK_THRESHOLD,
          MAX_RISK_THRESHOLD,
          DEFAULT_RISK_THRESHOLD
        ),
        touchGrassDurationMs: durationMs,
        touchGrassCooldownMs: Math.max(cooldownMs, durationMs + 1e3),
        riskProfile: normalizeRiskProfile(
          stored[TILTCHECK_RISK_PROFILE_KEY],
          stored["riskLevel"]
        ),
        enforcementEnabled,
        hourlyWage,
        realityHudEnabled,
        realityThresholdHours,
        depositBarrierEnabled,
        reverseWithdrawalShieldEnabled,
        profitLockEnabled,
        trailingPercent,
        minProfit,
        goalsEnabled,
        goals,
        bonusConfig,
        cooldownActiveUntil
      };
    } catch {
      return {
        riskThreshold: DEFAULT_RISK_THRESHOLD,
        touchGrassDurationMs: DEFAULT_TOUCH_GRASS_DURATION_MS,
        touchGrassCooldownMs: DEFAULT_TOUCH_GRASS_COOLDOWN_MS,
        riskProfile: DEFAULT_RISK_PROFILE,
        enforcementEnabled: true,
        hourlyWage: DEFAULT_HOURLY_WAGE2,
        realityHudEnabled: DEFAULT_REALITY_HUD_ENABLED2,
        realityThresholdHours: DEFAULT_REALITY_THRESHOLD_HOURS2,
        depositBarrierEnabled: DEFAULT_DEPOSIT_BARRIER_ENABLED,
        reverseWithdrawalShieldEnabled: DEFAULT_REVERSE_WITHDRAWAL_SHIELD_ENABLED,
        profitLockEnabled: DEFAULT_PROFIT_LOCK_ENABLED2,
        trailingPercent: DEFAULT_TRAILING_PERCENT2,
        minProfit: DEFAULT_MIN_PROFIT2,
        goalsEnabled: DEFAULT_CASHOUT_GOALS_ENABLED2,
        goals: [...DEFAULT_CASHOUT_GOALS],
        bonusConfig: { ...DEFAULT_BONUS_TRACKER_CONFIG },
        cooldownActiveUntil: 0
      };
    }
  }

  // src/presence-game-title.ts
  var AMOUNT_RE = /\$\s*\d|\d+\s*(usd|usdc|sol)\b|\b\d+(\.\d+)?x\b|\bheater\b|\bmultiplier\b/i;
  var WALLET_RE = /\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/;
  var URL_PATTERNS = [
    /\/casino\/slots\/([a-z0-9-]+)/i,
    /\/games?\/([a-z0-9-]+)/i,
    /\/slots?\/([a-z0-9-]+)/i,
    /\/play\/([a-z0-9-]+)/i
  ];
  function sanitizePresenceTitle(raw) {
    if (!raw) return null;
    const title = raw.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
    if (!title || AMOUNT_RE.test(title) || WALLET_RE.test(title)) return null;
    if (title === "unknown game") return null;
    return title;
  }
  function readPresenceGameTitle(loc = window.location, doc = document) {
    const pathname2 = loc.pathname;
    const href = loc.href;
    for (const pattern of URL_PATTERNS) {
      const match = pathname2.match(pattern) || href.match(pattern);
      if (match?.[1]) {
        return sanitizePresenceTitle(match[1]);
      }
    }
    const named = doc.querySelector('[data-game-name], .game-title, [class*="gameTitle"], [class*="gameName"]');
    if (named?.textContent) {
      return sanitizePresenceTitle(named.textContent);
    }
    return sanitizePresenceTitle(doc.title.split("|")[0] ?? null);
  }

  // src/lounge-overlay.ts
  var HOST_ID = "tiltcheck-lounge-host";
  var STORAGE_ID_KEY = "tiltcheck_lounge_user";
  var STORAGE_URL_KEY = "tiltcheck_lounge_url";
  function defaultLoungeUrl() {
    return "http://127.0.0.1:3004";
  }
  async function loungeBase() {
    const stored = await chrome.storage.local.get([STORAGE_URL_KEY]);
    const url = typeof stored[STORAGE_URL_KEY] === "string" ? stored[STORAGE_URL_KEY] : defaultLoungeUrl();
    return url.replace(/\/+$/, "");
  }
  async function identity() {
    const stored = await chrome.storage.local.get([STORAGE_ID_KEY, "userData"]);
    const userData = stored.userData;
    if (userData?.id && userData?.username) {
      return { userId: String(userData.id), username: String(userData.username).slice(0, 32) };
    }
    const row = stored[STORAGE_ID_KEY];
    if (row?.userId && row.username) return row;
    return null;
  }
  async function saveIdentity(user) {
    await chrome.storage.local.set({ [STORAGE_ID_KEY]: user });
  }
  function installLoungeOverlay(doc = document) {
    if (doc.getElementById(HOST_ID)) {
      return () => void 0;
    }
    const host = doc.createElement("div");
    host.id = HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const style = doc.createElement("style");
    style.textContent = `
    :host { all: initial; }
    .panel {
      position: fixed; right: 12px; bottom: 12px; z-index: 2147483645;
      width: 18rem; max-height: 22rem; display: flex; flex-direction: column;
      background: #0f1115; color: #f3f6f8; border: 1px solid #2a3140;
      font: 12px/1.4 ui-monospace, monospace; pointer-events: auto;
    }
    .head { padding: 0.5rem 0.7rem; background: #17c3b2; color: #0f1115; font-weight: 700; }
    .tag { padding: 0.35rem 0.7rem; color: #17c3b2; }
    .log { flex: 1; overflow: auto; padding: 0.5rem 0.7rem; min-height: 7rem; }
    .who { padding: 0.35rem 0.7rem; border-top: 1px solid #2a3140; color: #9aa3b2; }
    form { display: flex; gap: 0.25rem; padding: 0.4rem; }
    input, button { font: inherit; border: 1px solid #2a3140; background: #1a1f29; color: inherit; padding: 0.35rem; }
    button { background: #17c3b2; color: #0f1115; font-weight: 700; }
    .foot { padding: 0.35rem 0.7rem 0.5rem; color: #5a6472; font-size: 10px; }
    .cards, .notice { padding: 0.35rem 0.7rem; color: #9aa3b2; font-size: 11px; }
    .notice { display: none; color: #17c3b2; }
    .flag { font: inherit; padding: 0.1rem 0.3rem; margin-left: 0.25rem; background: #17c3b2; color: #0f1115; border: 0; }
  `;
    const panel = doc.createElement("div");
    panel.className = "panel";
    panel.innerHTML = `
    <div class="head">Degen Lounge</div>
    <div class="tag"></div>
    <div class="notice" role="status"></div>
    <div class="log"></div>
    <div class="who"></div>
    <div class="cards"></div>
    <form class="gate"><input maxlength="32" value="jmenichole" placeholder="username" /><button type="submit">WALK IN</button></form>
    <form class="chat" hidden><input maxlength="500" placeholder="talk to the room. names are on." /><button type="submit">SEND</button></form>
    <div class="foot">Chat is named. Tips stay between you two. Made for Degens. By Degens.</div>
  `;
    shadow.append(style, panel);
    const log = panel.querySelector(".log");
    const who = panel.querySelector(".who");
    const tag = panel.querySelector(".tag");
    const cardsEl = panel.querySelector(".cards");
    const noticeEl = panel.querySelector(".notice");
    const gateForm = panel.querySelector("form.gate");
    const chatForm = panel.querySelector("form.chat");
    const handleInput = gateForm.querySelector("input");
    const chatInput = chatForm.querySelector("input");
    let timer = null;
    let stopped = false;
    const render = (state, me) => {
      tag.textContent = state.tagline;
      log.textContent = "";
      for (const msg of state.messages.slice(-40)) {
        const p = doc.createElement("p");
        p.textContent = `${msg.username}: ${msg.text}`;
        log.appendChild(p);
      }
      log.scrollTop = log.scrollHeight;
      who.textContent = "";
      for (const row of state.presence) {
        const span = doc.createElement("span");
        const game = row.gameTitle ? `, playing ${row.gameTitle}` : "";
        const away = row.awayMessage ? ` \u2014 ${row.awayMessage}` : "";
        const mine = row.userId === me.userId ? " (you)" : "";
        span.textContent = `${row.username}${mine} (${row.status}${game}${away})`;
        if (row.userId && row.userId !== me.userId) {
          const flag = doc.createElement("button");
          flag.type = "button";
          flag.className = "flag";
          flag.textContent = "breather";
          const tip = doc.createElement("button");
          tip.type = "button";
          tip.className = "flag";
          tip.textContent = "tip";
          tip.addEventListener("click", () => {
            void (async () => {
              const me2 = await identity();
              if (!me2) return;
              const amount = window.prompt(`Tip ${row.username} how much USD? Names stay between you two.`, "2.00");
              if (!amount) return;
              const base = await loungeBase();
              const res = await fetch(`${base}/lounge/tip`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userId: me2.userId, username: me2.username, receiverId: row.userId, amountUsd: amount })
              });
              const view = await res.json();
              if (view.line) {
                noticeEl.style.display = "block";
                noticeEl.textContent = view.line;
              }
            })();
          });
          span.appendChild(tip);
          flag.addEventListener("click", () => {
            void (async () => {
              const base = await loungeBase();
              const me2 = await identity();
              if (!me2) return;
              await fetch(`${base}/lounge/flag`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  flaggerId: me2.userId,
                  targetId: row.userId,
                  accountAgeDays: 30,
                  reputationOk: true
                })
              });
            })();
          });
          span.appendChild(flag);
        }
        who.appendChild(span);
        who.appendChild(doc.createTextNode(" \xB7 "));
      }
    };
    const tick = async () => {
      if (stopped) return;
      try {
        const base = await loungeBase();
        const me = await identity();
        if (!me) {
          tag.textContent = "Pick a username. Chat is named. Tips stay private.";
          gateForm.hidden = false;
          chatForm.hidden = true;
          const res2 = await fetch(`${base}/lounge/state`);
          if (!res2.ok) throw new Error("lounge down");
          if (!host.isConnected && doc.body) {
            doc.body.append(host);
          }
          render(await res2.json(), { userId: "", username: "" });
          return;
        }
        gateForm.hidden = true;
        chatForm.hidden = false;
        await fetch(`${base}/lounge/join`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: me.userId,
            username: me.username,
            gameTitle: readPresenceGameTitle(),
            status: "online"
          })
        });
        const res = await fetch(`${base}/lounge/state`);
        if (!res.ok) throw new Error("lounge down");
        if (!host.isConnected && doc.body) {
          doc.body.append(host);
        }
        render(await res.json(), me);
        const [cardsRes, triviaRes, noticeRes] = await Promise.all([
          fetch(`${base}/lounge/scorecards`),
          fetch(`${base}/lounge/trivia`),
          fetch(`${base}/lounge/me/notice?userId=${encodeURIComponent(me.userId)}`)
        ]);
        const cards = cardsRes.ok ? await cardsRes.json() : { cards: [] };
        const trivia = triviaRes.ok ? await triviaRes.json() : {};
        const notice = noticeRes.ok ? await noticeRes.json() : { notice: null };
        cardsEl.textContent = [
          ...(cards.cards ?? []).map((card) => `${card.name}: ${card.payout}`),
          trivia.note ?? ""
        ].filter(Boolean).join(" \xB7 ");
        if (notice.notice?.copy) {
          noticeEl.style.display = "block";
          noticeEl.textContent = notice.notice.copy;
          const skip = doc.createElement("button");
          skip.type = "button";
          skip.className = "flag";
          skip.textContent = "Skip";
          skip.addEventListener("click", () => {
            noticeEl.style.display = "none";
          });
          noticeEl.appendChild(skip);
        }
      } catch {
        if (host.isConnected) {
          host.remove();
        }
      }
    };
    gateForm.addEventListener("submit", (event) => {
      event.preventDefault();
      void (async () => {
        const base = await loungeBase();
        const res = await fetch(`${base}/lounge/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ handle: handleInput.value })
        });
        const body = await res.json();
        if (body.user) {
          await saveIdentity(body.user);
          await tick();
        }
      })();
    });
    chatForm.addEventListener("submit", (event) => {
      event.preventDefault();
      void (async () => {
        const text = chatInput.value;
        chatInput.value = "";
        const base = await loungeBase();
        const me = await identity();
        if (!me) return;
        await fetch(`${base}/lounge/message`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: me.userId, username: me.username, text })
        });
        await tick();
      })();
    });
    void tick();
    timer = setInterval(() => {
      void tick();
    }, 3e3);
    return () => {
      stopped = true;
      if (timer) clearInterval(timer);
      if (host.isConnected) {
        host.remove();
      }
    };
  }

  // src/heater-nudge.ts
  var HEATER_TOAST_TEXT = "You're up right now. Lock half this win before the house claws it back. Skip anytime.";
  var HEATER_RATIO = 1.05;
  function detectHeater(previousBalance, nextBalance) {
    if (previousBalance == null || nextBalance == null) return false;
    if (previousBalance <= 0) return nextBalance > 0;
    return nextBalance / previousBalance >= HEATER_RATIO;
  }
  function installHeaterNudge(doc = document) {
    const host = doc.getElementById(PACE_HOST_ID);
    const shadow = host?.shadowRoot;
    if (!host || !shadow) {
      throw new Error("installHeaterNudge requires #tiltcheck-pace-host");
    }
    let previous = null;
    let armed = false;
    let stopped = false;
    const toast = doc.createElement("div");
    toast.className = "heater-toast";
    toast.setAttribute("role", "status");
    toast.style.cssText = "position:fixed;display:none;left:50%;bottom:4.5rem;transform:translateX(-50%);max-width:22rem;padding:0.75rem 1rem;background:#0f1115;color:#fff;font:600 0.875rem ui-monospace,monospace;z-index:2;pointer-events:auto;";
    toast.textContent = HEATER_TOAST_TEXT;
    const skip = doc.createElement("button");
    skip.type = "button";
    skip.textContent = "Skip";
    skip.style.cssText = "margin-left:0.5rem;font:inherit;background:#17c3b2;color:#0f1115;border:0;padding:0.2rem 0.5rem;";
    skip.addEventListener("click", () => {
      toast.style.display = "none";
      armed = false;
    });
    toast.appendChild(skip);
    shadow.append(toast);
    const onClick = (event) => {
      if (stopped) return;
      const target = event.target;
      if (!(target instanceof Element) || !target.closest(SPIN_CONTROL_SELECTOR)) return;
      const labeled = doc.querySelector('[data-balance], [class*="balance"]');
      const raw = labeled?.getAttribute("data-value") || labeled?.textContent;
      const next = raw ? Number(String(raw).replace(/[^0-9.]/g, "")) : null;
      if (detectHeater(previous, Number.isFinite(next) ? next : null)) {
        armed = true;
        toast.style.display = "block";
      }
      if (Number.isFinite(next)) previous = next;
    };
    doc.addEventListener("click", onClick, true);
    return {
      stop: () => {
        stopped = true;
        doc.removeEventListener("click", onClick, true);
        toast.remove();
      },
      armed: () => armed
    };
  }

  // src/chase-warning.ts
  var CHASE_SETTLE_MS = 5e3;
  var CHASE_TOAST_TEXT = "Last spin lost and you raised the stake. You're chasing, not on a heater. Step back.";
  var CHASE_POLL_MS = 250;
  function parseMoney3(text) {
    if (text == null) return null;
    const tokens = text.split(/\s+/).map((token) => token.replace(/,/g, "").replace(/[^\d.-]/g, ""));
    const matches = tokens.filter((token) => /^-?\d+(\.\d+)?$/.test(token));
    if (matches.length !== 1) return null;
    return Number(matches[0]);
  }
  function readField(doc, field) {
    const hostname2 = doc.location.hostname;
    const entry = CASINO_SELECTORS.find((item) => hostname2.includes(item.domain) || item.domain === "*");
    const selector = entry?.selectors[field];
    if (!selector) return null;
    const element = doc.querySelector(selector);
    if (!element) return null;
    const raw = element.getAttribute("data-value") || element.getAttribute("value") || element.textContent;
    return parseMoney3(raw);
  }
  function installChaseWarning(doc, lockUntil, onChaseEscalation) {
    const host = doc.getElementById(PACE_HOST_ID);
    const shadow = host?.shadowRoot;
    if (!host || !shadow) {
      throw new Error("installChaseWarning requires #tiltcheck-pace-host with an open shadow root");
    }
    const alreadyStyled = Array.from(shadow.querySelectorAll("style")).some(
      (style) => (style.textContent ?? "").includes(".chase-toast")
    );
    if (!alreadyStyled) {
      const style = doc.createElement("style");
      style.textContent = `
      .chase-toast {
        position: fixed;
        display: none;
        left: 50%;
        top: 4.5rem;
        transform: translateX(-50%);
        max-width: 22rem;
        padding: 0.75rem 1rem;
        pointer-events: none;
        background: #0f1115;
        color: #ffffff;
        font: 600 0.875rem ui-monospace, monospace;
      }
    `;
      shadow.append(style);
    }
    let toast = shadow.querySelector(".chase-toast");
    if (!toast) {
      toast = doc.createElement("div");
      toast.className = "chase-toast";
      toast.textContent = CHASE_TOAST_TEXT;
      toast.style.display = "none";
      shadow.append(toast);
    }
    let lastLosingStake = null;
    let pollId = null;
    let settleId = null;
    let stopped = false;
    const clearPoll = () => {
      if (pollId !== null) {
        clearInterval(pollId);
        pollId = null;
      }
      if (settleId !== null) {
        clearTimeout(settleId);
        settleId = null;
      }
    };
    const watchBalance = (stake, baseline) => {
      clearPoll();
      const startedAt = Date.now();
      const finish = (next) => {
        if (stopped) return;
        if (next !== null && next !== baseline) {
          if (next < baseline) {
            lastLosingStake = stake;
          } else {
            lastLosingStake = null;
            toast.style.display = "none";
          }
          clearPoll();
          return;
        }
        if (Date.now() - startedAt >= CHASE_SETTLE_MS) {
          clearPoll();
        }
      };
      pollId = setInterval(() => {
        finish(readField(doc, "balance"));
      }, CHASE_POLL_MS);
      settleId = setTimeout(() => {
        if (stopped) return;
        clearPoll();
      }, CHASE_SETTLE_MS);
    };
    const onClick = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (!target.closest(SPIN_CONTROL_SELECTOR)) return;
      if (Date.now() < lockUntil()) return;
      const stake = readField(doc, "betAmount");
      const balance = readField(doc, "balance");
      if (stake === null || balance === null) return;
      if (typeof lastLosingStake === "number" && stake > lastLosingStake) {
        toast.style.display = "block";
        onChaseEscalation?.(stake, lastLosingStake);
      }
      watchBalance(stake, balance);
    };
    doc.addEventListener("click", onClick, true);
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onClick, true);
      clearPoll();
      toast.style.display = "none";
    };
    return {
      stop,
      lastLosingStake: () => lastLosingStake
    };
  }

  // ../../packages/types/src/index.ts
  var GAME_EXCLUSION_CATEGORIES = [
    "chicken_mines",
    "bonus_buy",
    "live_dealer",
    "slots",
    "crash",
    "table_games"
  ];

  // src/exclusion-taxonomy.ts
  var CATEGORY_KEYWORDS = {
    chicken_mines: ["chicken", "mines", "minefield", "chicken-road", "chickenroad"],
    bonus_buy: ["bonus-buy", "bonusbuy", "feature-buy", "featurebuy"],
    live_dealer: ["live-dealer", "live-casino", "live_dealer", "livecasino"],
    slots: ["slot", "slots"],
    crash: ["crash", "aviator", "jetx", "spaceman"],
    table_games: ["blackjack", "roulette", "baccarat", "poker", "table"]
  };
  function matchExclusion(haystack, slugs, categories) {
    const lower = haystack.toLowerCase();
    if (!lower.trim()) return null;
    for (const category of categories) {
      const keywords = CATEGORY_KEYWORDS[category] ?? [];
      if (keywords.some((keyword) => lower.includes(keyword))) {
        return { kind: "category", value: category };
      }
    }
    for (const slug of slugs) {
      const needle = slug.trim().toLowerCase();
      if (needle.length >= 2 && lower.includes(needle)) {
        return { kind: "slug", value: slug };
      }
    }
    return null;
  }
  function haystackFromLocation(loc) {
    return `${loc.pathname}${loc.search}${loc.href ?? ""}`.toLowerCase();
  }
  function haystackFromElement(el) {
    const card = el.closest('a, button, [role="button"], [data-game-id], [data-game-name], [data-game], article, li');
    const node = card ?? el;
    return [
      node.getAttribute("href"),
      node.getAttribute("src"),
      node.getAttribute("data-game-id"),
      node.getAttribute("data-game-name"),
      node.getAttribute("data-game"),
      node.getAttribute("data-testid"),
      node.textContent
    ].filter(Boolean).join(" ").toLowerCase();
  }

  // src/pro/blocked-games-options.ts
  var TILTCHECK_BLOCKED_GAMES_KEY = "tiltcheck_blocked_games";
  var TILTCHECK_BLOCKED_CATEGORIES_KEY = "tiltcheck_blocked_categories";
  var TILTCHECK_GAME_BLOCK_OPT_IN_KEY = "tiltcheck_game_block_opt_in";
  var MAX_BLOCKED_ENTRIES = 64;
  var MAX_SLUG_LENGTH = 48;
  function normalizeBlockedGameSlug(value) {
    if (typeof value !== "string") return null;
    const slug = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    if (!slug || slug.length > MAX_SLUG_LENGTH) return null;
    return slug;
  }
  function normalizeBlockedGamesList(raw) {
    if (!Array.isArray(raw)) return [];
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of raw) {
      const slug = normalizeBlockedGameSlug(item);
      if (!slug || seen.has(slug)) continue;
      seen.add(slug);
      out.push(slug);
      if (out.length >= MAX_BLOCKED_ENTRIES) break;
    }
    return out;
  }
  async function loadBlockedGameSlugs() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_GAMES_KEY);
      return normalizeBlockedGamesList(stored[TILTCHECK_BLOCKED_GAMES_KEY]);
    } catch {
      return [];
    }
  }
  function normalizeBlockedCategories(raw) {
    if (!Array.isArray(raw)) return [];
    const allowed = new Set(GAME_EXCLUSION_CATEGORIES);
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of raw) {
      if (typeof item !== "string" || !allowed.has(item) || seen.has(item)) continue;
      seen.add(item);
      out.push(item);
    }
    return out;
  }
  async function loadBlockedCategories() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_CATEGORIES_KEY);
      return normalizeBlockedCategories(stored[TILTCHECK_BLOCKED_CATEGORIES_KEY]);
    } catch {
      return [];
    }
  }
  async function loadGameBlockOptIn() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_GAME_BLOCK_OPT_IN_KEY);
      return stored[TILTCHECK_GAME_BLOCK_OPT_IN_KEY] === true;
    } catch {
      return false;
    }
  }

  // src/pro/containment.ts
  var TILTCHECK_SAFETY_ROOT_IDS = [
    "tiltcheck-lockdown-root",
    "tiltcheck-local-game-block-overlay",
    "tiltcheck-cooldown-overlay",
    "tiltcheck-game-block-overlay",
    "tiltcheck-redeem-nudge",
    "tiltcheck-sidebar",
    "tiltcheck-mobile-license-hud"
  ];
  function isInsideTiltcheckSafetyRoot(node) {
    if (!node || typeof Element === "undefined" || !(node instanceof Element)) {
      return false;
    }
    for (const id of TILTCHECK_SAFETY_ROOT_IDS) {
      if (node.closest(`#${id}`)) {
        return true;
      }
    }
    return false;
  }
  function mutationsOnlyTouchSafetyRoots(mutations) {
    const nodes = [];
    for (const m of mutations) {
      for (const n of m.addedNodes) {
        nodes.push(n);
      }
      if (m.target) {
        nodes.push(m.target);
      }
    }
    if (nodes.length === 0) {
      return false;
    }
    return nodes.every((n) => {
      if (typeof Element === "undefined" || !(n instanceof Element)) {
        return true;
      }
      return isInsideTiltcheckSafetyRoot(n);
    });
  }

  // src/pro/local-game-blocker.ts
  var LOCAL_OVERLAY_ID = "tiltcheck-local-game-block-overlay";
  var SANITIZED_ATTR = "data-tiltcheck-local-blocked";
  var PLACEHOLDER_LABEL = "[ GAME EXCLUDED ]";
  var installed = null;
  function installLocalGameBlocker(doc = document) {
    if (installed) return installed;
    installed = new LocalGameBlocker(doc);
    void installed.init();
    return installed;
  }
  var LocalGameBlocker = class {
    blockedSlugs = [];
    blockedCategories = [];
    enforcementEnabled = false;
    observer = null;
    scanScheduled = false;
    storageListenerAttached = false;
    clickBound = false;
    doc;
    constructor(doc = document) {
      this.doc = doc;
    }
    onBlockedPointer = (event) => {
      if (!this.enforcementEnabled) return;
      if (this.blockedSlugs.length === 0 && this.blockedCategories.length === 0) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (isInsideTiltcheckSafetyRoot(target)) return;
      const hit = matchExclusion(haystackFromElement(target), this.blockedSlugs, this.blockedCategories);
      if (!hit) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const card = target.closest('a, button, [role="button"], article, li, div');
      if (card instanceof HTMLElement) {
        this.sanitizeNode(card, hit.value);
      }
    };
    handleStorageChange = (changes, area) => {
      if (area !== "local") return;
      if (changes[TILTCHECK_BLOCKED_GAMES_KEY] || changes[TILTCHECK_BLOCKED_CATEGORIES_KEY] || changes[TILTCHECK_GAME_BLOCK_OPT_IN_KEY]) {
        void this.reloadAndScan();
      }
    };
    async init() {
      await this.reloadAndScan();
      this.startObserver();
      this.attachStorageListener();
      this.attachClickGuard();
    }
    resume(_source = "navigation") {
      void this.reloadAndScan();
    }
    destroy() {
      this.observer?.disconnect();
      this.observer = null;
      if (this.storageListenerAttached) {
        try {
          chrome.storage.onChanged.removeListener(this.handleStorageChange);
        } catch {
        }
        this.storageListenerAttached = false;
      }
      this.removeUrlOverlay();
      this.detachClickGuard();
      if (installed === this) installed = null;
    }
    attachStorageListener() {
      if (this.storageListenerAttached) return;
      try {
        chrome.storage.onChanged.addListener(this.handleStorageChange);
        this.storageListenerAttached = true;
      } catch {
      }
    }
    async reloadAndScan() {
      this.enforcementEnabled = await loadGameBlockOptIn();
      this.blockedSlugs = this.enforcementEnabled ? await loadBlockedGameSlugs() : [];
      this.blockedCategories = this.enforcementEnabled ? await loadBlockedCategories() : [];
      this.scan();
    }
    scheduleScan() {
      if (this.scanScheduled) return;
      this.scanScheduled = true;
      const run = () => {
        this.scanScheduled = false;
        this.scan();
      };
      if (typeof requestAnimationFrame === "function") {
        requestAnimationFrame(run);
      } else {
        setTimeout(run, 0);
      }
    }
    scan() {
      if (this.blockedSlugs.length === 0 && this.blockedCategories.length === 0) {
        this.removeUrlOverlay();
        return;
      }
      const urlHit = this.matchHref(window.location.href);
      if (urlHit) {
        this.injectUrlOverlay(urlHit.value);
        return;
      }
      this.removeUrlOverlay();
      this.redactDomMatches();
    }
    /** Returns matched slug/category when URL path/search references a blocked game. */
    matchUrl(href, slugs = this.blockedSlugs, categories = this.blockedCategories) {
      return this.matchHref(href, slugs, categories)?.value ?? null;
    }
    matchHref(href, slugs = this.blockedSlugs, categories = this.blockedCategories) {
      let loc = { pathname: href, search: "", href };
      try {
        const parsed = new URL(href, window.location.origin);
        loc = { pathname: parsed.pathname, search: parsed.search, href: parsed.href };
      } catch {
      }
      return matchExclusion(haystackFromLocation(loc), slugs, categories);
    }
    redactDomMatches() {
      const nodesByKey = this.collectBlockedNodes();
      for (const [key, nodes] of nodesByKey) {
        for (const node of nodes) {
          this.sanitizeNode(node, key);
        }
      }
    }
    /** Single-pass DOM scan: map each blocked slug/category to nodes that reference it. */
    collectBlockedNodes() {
      const buckets = /* @__PURE__ */ new Map();
      const tryAdd = (el, key) => {
        if (!el || !(el instanceof HTMLElement)) return;
        if (isInsideTiltcheckSafetyRoot(el)) return;
        if (el.closest(`#${LOCAL_OVERLAY_ID}`)) return;
        const card = el.closest('a, button, [role="button"], article, li, div');
        if (!buckets.has(key)) buckets.set(key, /* @__PURE__ */ new Set());
        buckets.get(key)?.add(card ?? el);
      };
      const consider = (el) => {
        const hit = matchExclusion(haystackFromElement(el), this.blockedSlugs, this.blockedCategories);
        if (hit) tryAdd(el, hit.value);
      };
      for (const anchor of this.doc.querySelectorAll("a[href]")) {
        consider(anchor);
      }
      for (const el of this.doc.querySelectorAll(
        'button, [role="button"], [data-game-name], [data-game-id], [data-game], [data-testid*="game"]'
      )) {
        consider(el);
      }
      const result = /* @__PURE__ */ new Map();
      for (const [key, set] of buckets) {
        if (set.size > 0) {
          result.set(key, [...set]);
        }
      }
      return result;
    }
    attachClickGuard() {
      if (this.clickBound) return;
      this.doc.addEventListener("click", this.onBlockedPointer, true);
      this.doc.addEventListener("pointerdown", this.onBlockedPointer, true);
      this.clickBound = true;
    }
    detachClickGuard() {
      if (!this.clickBound) return;
      this.doc.removeEventListener("click", this.onBlockedPointer, true);
      this.doc.removeEventListener("pointerdown", this.onBlockedPointer, true);
      this.clickBound = false;
    }
    disableInteractiveTarget(target) {
      target.style.pointerEvents = "none";
      if (target instanceof HTMLButtonElement) {
        target.disabled = true;
      }
      if (target.getAttribute("role") === "button") {
        target.setAttribute("aria-disabled", "true");
        target.tabIndex = -1;
      }
    }
    sanitizeNode(target, slug) {
      if (target.getAttribute(SANITIZED_ATTR) === slug) return;
      const placeholder = document.createElement("div");
      placeholder.setAttribute(SANITIZED_ATTR, slug);
      placeholder.setAttribute("aria-label", `Game excluded: ${slug}`);
      placeholder.style.cssText = `
      background: #1a1d24;
      color: #ff4a4a;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 72px;
      height: 100%;
      width: 100%;
      font-family: ui-monospace, monospace;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      border: 1px dashed #ff4a4a;
      border-radius: 4px;
      box-sizing: border-box;
      pointer-events: none;
      user-select: none;
    `;
      placeholder.textContent = PLACEHOLDER_LABEL;
      if (target.tagName === "A") {
        const wrap = document.createElement("div");
        wrap.setAttribute(SANITIZED_ATTR, slug);
        wrap.style.pointerEvents = "none";
        wrap.appendChild(placeholder);
        target.replaceChildren(wrap);
        target.removeAttribute("href");
        this.disableInteractiveTarget(target);
        target.setAttribute(SANITIZED_ATTR, slug);
        return;
      }
      target.replaceChildren(placeholder);
      this.disableInteractiveTarget(target);
      target.setAttribute(SANITIZED_ATTR, slug);
    }
    injectUrlOverlay(slug) {
      if (document.getElementById(LOCAL_OVERLAY_ID)) return;
      const overlay = document.createElement("div");
      overlay.id = LOCAL_OVERLAY_ID;
      overlay.setAttribute("role", "dialog");
      overlay.setAttribute("aria-modal", "true");
      overlay.setAttribute("aria-label", `Access denied: ${slug} is on your exclusion list`);
      Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        zIndex: "2147483646",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(10, 12, 16, 0.97)",
        fontFamily: "ui-monospace, monospace",
        color: "#f5f5f5",
        padding: "24px",
        boxSizing: "border-box"
      });
      overlay.innerHTML = `
      <div style="max-width: 420px; text-align: center; border: 1px solid #333; border-radius: 12px; padding: 32px 24px; background: #111;">
        <div style="color: #ff4a4a; font-size: 11px; font-weight: 800; letter-spacing: 0.2em; margin-bottom: 12px;">STRATEGIC FILTER</div>
        <h2 style="margin: 0 0 12px; font-size: 22px; font-weight: 900; color: #fff;">Access denied.</h2>
        <p style="margin: 0 0 8px; font-size: 14px; line-height: 1.5; color: #aaa;">
          <strong style="color: #ff4a4a;">${slug}</strong> is on your local exclusion list.
        </p>
        <p style="margin: 0 0 20px; font-size: 12px; line-height: 1.45; color: #666;">
          You put this on your list. It does not click. Edit the list in the extension Guards tab.
        </p>
        <button type="button" id="tiltcheck-local-block-back" style="
          background: transparent;
          border: 1px solid #444;
          color: #ccc;
          padding: 10px 18px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          text-transform: uppercase;
          letter-spacing: 0.06em;
        ">Go back</button>
        <footer style="margin-top: 20px; font-size: 10px; color: #444;">Made for Degens. By Degens.</footer>
      </div>
    `;
      document.body.appendChild(overlay);
      document.getElementById("tiltcheck-local-block-back")?.addEventListener("click", () => {
        if (window.history.length > 1) {
          window.history.back();
        } else {
          window.location.assign("/");
        }
      });
    }
    removeUrlOverlay() {
      document.getElementById(LOCAL_OVERLAY_ID)?.remove();
    }
    startObserver() {
      if (!this.doc.body) return;
      this.observer = new MutationObserver((mutations) => {
        if (mutationsOnlyTouchSafetyRoots(mutations)) {
          return;
        }
        this.scheduleScan();
      });
      this.observer.observe(this.doc.body, { childList: true, subtree: true });
    }
  };

  // src/deposit-barrier.ts
  var TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2 = "tiltcheck_cooldown_active_until";
  var TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2 = "tiltcheck_deposit_barrier_enabled";
  var ALERT_ID = "tiltcheck-deposit-barrier-alert";
  var ALERT_DISMISS_MS = 4e3;
  var DEPOSIT_SELECTORS = [
    '[data-test="cashier-button"]',
    '[data-testid="cashier-button"]',
    '[data-test="wallet-button"]',
    '[data-testid="wallet-button"]',
    'button[data-testid="cashier-btn"]',
    '[data-testid="deposit-button"]',
    ".wallet-btn",
    'button[data-test="deposit"]',
    '[data-test="deposit-button"]'
  ];
  var ADDITIONAL_DEPOSIT_SELECTORS = [
    'a[href*="/deposit"]',
    'a[href*="/cashier"]',
    '[data-action="deposit"]',
    '[data-action="cashier"]'
  ];
  var DEPOSIT_TEXT_REGEX = /\b(deposit|cashier|add\s+funds|buy\s+crypto|buy\s+coins|wallet|top\s+up|deposito|depósito|dépôt|einzahlen|recharger|recargar)\b/i;
  var EXCLUDED_TEXT_REGEX = /\b(withdraw|withdrawal|redeem|redemption|vault|tip|send|transfer|history|statement|retirer|auszahlung|retirada)\b/i;
  var inMemoryCooldownActiveUntil = 0;
  var inMemoryBarrierEnabled = true;
  function getCooldownActiveUntil() {
    return inMemoryCooldownActiveUntil;
  }
  async function loadCooldownActiveUntil() {
    try {
      const stored = await chrome.storage.local.get([
        TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2,
        TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2
      ]);
      const val = stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2];
      if (typeof val === "number" && Number.isFinite(val)) {
        inMemoryCooldownActiveUntil = Math.max(0, val);
      }
      const enabledVal = stored[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2];
      if (typeof enabledVal === "boolean") {
        inMemoryBarrierEnabled = enabledVal;
      }
    } catch {
    }
    return inMemoryCooldownActiveUntil;
  }
  function isDepositBarrierActive(now) {
    if (!inMemoryBarrierEnabled) {
      return false;
    }
    if (isTouchGrassActive()) {
      return true;
    }
    const currentTime = now ?? Date.now();
    return inMemoryCooldownActiveUntil > currentTime;
  }
  function isDepositTarget(target) {
    const container = target.closest(
      'button, a, [role="button"], input[type="submit"], input[type="button"], ' + DEPOSIT_SELECTORS.join(", ")
    ) ?? target;
    const textContent = (container.textContent ?? "") + " " + (container.getAttribute("aria-label") ?? "") + " " + (container.getAttribute("title") ?? "") + " " + (container.getAttribute("value") ?? "");
    const attrContent = (container.getAttribute("href") ?? "") + " " + (container.getAttribute("data-action") ?? "");
    if (EXCLUDED_TEXT_REGEX.test(textContent) || EXCLUDED_TEXT_REGEX.test(attrContent)) {
      return false;
    }
    for (const selector of DEPOSIT_SELECTORS) {
      if (target.matches(selector) || target.closest(selector) !== null) {
        return true;
      }
    }
    for (const selector of ADDITIONAL_DEPOSIT_SELECTORS) {
      if (target.matches(selector) || target.closest(selector) !== null) {
        return true;
      }
    }
    if (DEPOSIT_TEXT_REGEX.test(textContent) || DEPOSIT_TEXT_REGEX.test(attrContent)) {
      return true;
    }
    return false;
  }
  function installDepositBarrier(doc = document) {
    void loadCooldownActiveUntil();
    let alertTimeoutId = null;
    let stopped = false;
    const showAlert = (message) => {
      let alertEl = doc.getElementById(ALERT_ID);
      if (!alertEl) {
        alertEl = doc.createElement("div");
        alertEl.id = ALERT_ID;
        alertEl.setAttribute("role", "alert");
        alertEl.setAttribute("aria-live", "assertive");
        alertEl.style.cssText = [
          "position: fixed",
          "top: 1.5rem",
          "left: 50%",
          "transform: translateX(-50%)",
          "z-index: 2147483647",
          "background: #0f1115",
          "border: 2px solid #ff4a4a",
          "border-radius: 6px",
          "color: #ffffff",
          "padding: 0.85rem 1.25rem",
          'font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace',
          "font-size: 0.875rem",
          "font-weight: 700",
          "box-shadow: 0 4px 24px rgba(0, 0, 0, 0.85)",
          "text-align: center",
          "pointer-events: none",
          "max-width: 90vw",
          "box-sizing: border-box"
        ].join(";");
        (doc.body ?? doc.documentElement).appendChild(alertEl);
      }
      alertEl.textContent = message;
      if (alertTimeoutId !== null) {
        clearTimeout(alertTimeoutId);
        alertTimeoutId = null;
      }
      alertTimeoutId = setTimeout(() => {
        alertTimeoutId = null;
        alertEl?.remove();
      }, ALERT_DISMISS_MS);
    };
    const onClickCapture = (event) => {
      if (stopped) return;
      const now = Date.now();
      if (!isDepositBarrierActive(now)) {
        return;
      }
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      if (!isDepositTarget(target)) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const cooldownUntil = getCooldownActiveUntil();
      let message;
      if (cooldownUntil > now) {
        const remainingMins = Math.max(1, Math.ceil((cooldownUntil - now) / 6e4));
        message = `Deposit Barrier Active: Voluntary lock engaged (${remainingMins}m remaining). Don't reload. Step away.`;
      } else {
        message = "Deposit Barrier Active: You locked the door. Don't dig the hole deeper. Wait out the timer.";
      }
      showAlert(message);
    };
    const onStorageChanged = (changes, area) => {
      if (area !== "local") return;
      if (TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2 in changes) {
        const val = changes[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2]?.newValue;
        if (typeof val === "number" && Number.isFinite(val)) {
          inMemoryCooldownActiveUntil = Math.max(0, val);
        } else {
          inMemoryCooldownActiveUntil = 0;
        }
      }
      if (TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2 in changes) {
        const val = changes[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2]?.newValue;
        if (typeof val === "boolean") {
          inMemoryBarrierEnabled = val;
        }
      }
    };
    try {
      chrome.storage?.onChanged?.addListener?.(onStorageChanged);
    } catch {
    }
    doc.addEventListener("click", onClickCapture, true);
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onClickCapture, true);
      try {
        chrome.storage?.onChanged?.removeListener?.(onStorageChanged);
      } catch {
      }
      if (alertTimeoutId !== null) {
        clearTimeout(alertTimeoutId);
        alertTimeoutId = null;
      }
      const alertEl = doc.getElementById(ALERT_ID);
      if (alertEl) {
        alertEl.remove();
      }
    };
    return {
      stop,
      isActive: (now) => isDepositBarrierActive(now),
      getCooldownActiveUntil,
      updateCooldown: (timestamp) => {
        inMemoryCooldownActiveUntil = Math.max(0, timestamp);
      },
      updateEnabled: (enabled) => {
        inMemoryBarrierEnabled = enabled;
      }
    };
  }

  // src/reverse-withdrawal-shield.ts
  var TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY2 = "tiltcheck_reverse_withdrawal_shield_enabled";
  var ALERT_ID2 = "tiltcheck-reverse-withdrawal-alert";
  var ALERT_DISMISS_MS2 = 4e3;
  var CANCEL_WITHDRAWAL_SELECTORS = [
    '[data-test*="cancel-withdrawal"]',
    '[data-testid*="cancel-withdrawal"]',
    '[data-test*="cancel-payout"]',
    '[data-testid*="cancel-payout"]',
    '[data-test*="reverse-withdrawal"]',
    '[data-testid*="reverse-withdrawal"]',
    '[data-action*="cancel-withdrawal"]',
    '[data-action*="cancel-cashout"]',
    '[data-action*="cancel-redemption"]',
    '[data-testid*="cancel-redemption"]',
    '[data-test*="cancel-redemption"]',
    ".cancel-withdrawal-btn",
    ".reverse-withdrawal-btn",
    ".pending-withdrawal-cancel",
    ".transaction-cancel-btn",
    'button[name="cancelWithdrawal"]',
    'button[name="reverseWithdrawal"]',
    'a[href*="cancel-withdrawal"]',
    'a[href*="cancel-cashout"]',
    'a[href*="cancel-redemption"]'
  ];
  var EXPLICIT_TEXT_REGEX = /\b(cancel\s+withdrawal|reverse\s+withdrawal|cancel\s+cashout|cancel\s+payout|cancel\s+redemption|reverse\s+cashout|cancel\s+pending|reclaim\s+funds|cancelar\s+retirada|cancelar\s+retiro|annuler\s+le\s+retrait|auszahlung\s+stornieren)\b/i;
  var SLUG_REGEX = /(cancel[-_]withdrawal|reverse[-_]withdrawal|cancel[-_]cashout|cancel[-_]payout|cancel[-_]redemption|reverse[-_]cashout|cancel[-_]pending)/i;
  var GENERIC_CANCEL_TEXT_REGEX = /\b(cancel|reverse|stornieren|annuler|cancelar|reclaim)\b/i;
  var PENDING_CONTEXT_REGEX = /\b(pending|processing|under\s+review|in\s+review|requested|submitted|en\s+attente|ausstehend|pendiente)\b/i;
  var WITHDRAWAL_CONTEXT_REGEX = /\b(withdraw|withdrawal|cashout|payout|redemption|retrait|auszahlung|retirada|retiro)\b/i;
  var EXCLUDED_MODAL_REGEX = /\b(close|dismiss|back|exit|settings|profile|avatar|password|2fa|login|register)\b/i;
  var inMemoryShieldEnabled = true;
  async function loadReverseWithdrawalShieldEnabled() {
    try {
      const stored = await chrome.storage.local.get([
        TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY2
      ]);
      const val = stored[TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY2];
      if (typeof val === "boolean") {
        inMemoryShieldEnabled = val;
      }
    } catch {
    }
    return inMemoryShieldEnabled;
  }
  function isCancelWithdrawalTarget(target) {
    const container = target.closest(
      'button, a, [role="button"], input[type="submit"], input[type="button"], ' + CANCEL_WITHDRAWAL_SELECTORS.join(", ")
    ) ?? target;
    for (const selector of CANCEL_WITHDRAWAL_SELECTORS) {
      try {
        if (container.matches(selector) || container.querySelector(selector) !== null) {
          return true;
        }
      } catch {
      }
    }
    const attrsToCheck = [
      container.getAttribute("data-action"),
      container.getAttribute("data-test"),
      container.getAttribute("data-testid"),
      container.getAttribute("aria-label"),
      container.getAttribute("title"),
      container.getAttribute("href"),
      container.getAttribute("name")
    ];
    for (const attr of attrsToCheck) {
      if (attr && (EXPLICIT_TEXT_REGEX.test(attr) || SLUG_REGEX.test(attr))) {
        return true;
      }
    }
    const hrefAttr = container.getAttribute("href") || container.href;
    if (hrefAttr && SLUG_REGEX.test(hrefAttr)) {
      return true;
    }
    const text = (container.textContent ?? "").trim();
    if (EXPLICIT_TEXT_REGEX.test(text) || SLUG_REGEX.test(text)) {
      return true;
    }
    if (GENERIC_CANCEL_TEXT_REGEX.test(text)) {
      const contextEl = container.closest('tr, [role="row"], .transaction, .withdrawal-item, .pending-item, li, article') ?? container.parentElement?.parentElement ?? container.parentElement;
      if (contextEl) {
        const contextText = (contextEl.textContent ?? "").trim();
        const hasPending = PENDING_CONTEXT_REGEX.test(contextText);
        const hasWithdrawal = WITHDRAWAL_CONTEXT_REGEX.test(contextText);
        const isExcluded = EXCLUDED_MODAL_REGEX.test(contextText);
        if (hasPending && hasWithdrawal && !isExcluded) {
          return true;
        }
      }
    }
    return false;
  }
  function neutralizeCancelElement(el) {
    if (el.getAttribute("data-tiltcheck-shield") === "blocked") {
      return;
    }
    el.setAttribute("data-tiltcheck-shield", "blocked");
    if ("disabled" in el) {
      el.disabled = true;
    }
    const existingStyle = el.getAttribute("style") || "";
    el.setAttribute(
      "style",
      existingStyle + "; opacity: 0.35 !important; cursor: not-allowed !important; pointer-events: none !important; filter: grayscale(1) !important;"
    );
    el.setAttribute(
      "title",
      "Cashout Protected: TiltCheck Reverse-Withdrawal Shield is Active. Let your hit clear."
    );
  }
  function installReverseWithdrawalShield(doc = document) {
    let stopped = false;
    let alertTimeoutId = null;
    let observer = null;
    void loadReverseWithdrawalShieldEnabled();
    const showAlert = (message) => {
      let alertEl = doc.getElementById(ALERT_ID2);
      if (!alertEl) {
        alertEl = doc.createElement("div");
        alertEl.id = ALERT_ID2;
        alertEl.setAttribute("role", "alert");
        alertEl.setAttribute("aria-live", "assertive");
        alertEl.style.cssText = [
          "position: fixed",
          "top: 1.5rem",
          "left: 50%",
          "transform: translateX(-50%)",
          "z-index: 2147483647",
          "background: #0f1115",
          "border: 2px solid #17c3b2",
          "border-radius: 6px",
          "color: #ffffff",
          "padding: 0.85rem 1.25rem",
          'font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace',
          "font-size: 0.875rem",
          "font-weight: 700",
          "box-shadow: 0 4px 24px rgba(0, 0, 0, 0.85)",
          "text-align: center",
          "pointer-events: none",
          "max-width: 90vw",
          "box-sizing: border-box"
        ].join(";");
        (doc.body ?? doc.documentElement).appendChild(alertEl);
      }
      alertEl.textContent = message;
      if (alertTimeoutId !== null) {
        clearTimeout(alertTimeoutId);
        alertTimeoutId = null;
      }
      alertTimeoutId = setTimeout(() => {
        alertTimeoutId = null;
        alertEl?.remove();
      }, ALERT_DISMISS_MS2);
    };
    const scanAndNeutralize = () => {
      if (stopped || !inMemoryShieldEnabled) return 0;
      let count = 0;
      for (const selector of CANCEL_WITHDRAWAL_SELECTORS) {
        const elements = doc.querySelectorAll(selector);
        elements.forEach((el) => {
          if (el.getAttribute("data-tiltcheck-shield") !== "blocked") {
            neutralizeCancelElement(el);
            count++;
          }
        });
      }
      const candidates = doc.querySelectorAll('button, a, [role="button"]');
      candidates.forEach((el) => {
        if (el.getAttribute("data-tiltcheck-shield") !== "blocked" && isCancelWithdrawalTarget(el)) {
          neutralizeCancelElement(el);
          count++;
        }
      });
      return count;
    };
    const onActionCapture = (event) => {
      if (stopped || !inMemoryShieldEnabled) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (!isCancelWithdrawalTarget(target)) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      neutralizeCancelElement(target);
      showAlert(
        "Cashout Protected: Reverse-Withdrawal Shield is active. Do not donate your hit back to the house. Let your cashout clear."
      );
    };
    const onKeydownCapture = (event) => {
      if (stopped || !inMemoryShieldEnabled) return;
      if (event.key !== "Enter" && event.key !== " ") return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (!isCancelWithdrawalTarget(target)) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      neutralizeCancelElement(target);
      showAlert(
        "Cashout Protected: Reverse-Withdrawal Shield is active. Do not donate your hit back to the house. Let your cashout clear."
      );
    };
    const onStorageChanged = (changes, area) => {
      if (area !== "local") return;
      if (TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY2 in changes) {
        const val = changes[TILTCHECK_REVERSE_WITHDRAWAL_SHIELD_ENABLED_KEY2]?.newValue;
        if (typeof val === "boolean") {
          inMemoryShieldEnabled = val;
          if (inMemoryShieldEnabled) {
            scanAndNeutralize();
          }
        }
      }
    };
    try {
      chrome.storage?.onChanged?.addListener?.(onStorageChanged);
    } catch {
    }
    doc.addEventListener("click", onActionCapture, true);
    doc.addEventListener("mousedown", onActionCapture, true);
    doc.addEventListener("pointerdown", onActionCapture, true);
    doc.addEventListener("keydown", onKeydownCapture, true);
    try {
      if (typeof MutationObserver !== "undefined" && doc.body) {
        observer = new MutationObserver(() => {
          scanAndNeutralize();
        });
        observer.observe(doc.body, { childList: true, subtree: true });
      }
    } catch {
    }
    scanAndNeutralize();
    return {
      stop: () => {
        stopped = true;
        if (alertTimeoutId !== null) {
          clearTimeout(alertTimeoutId);
          alertTimeoutId = null;
        }
        doc.removeEventListener("click", onActionCapture, true);
        doc.removeEventListener("mousedown", onActionCapture, true);
        doc.removeEventListener("pointerdown", onActionCapture, true);
        doc.removeEventListener("keydown", onKeydownCapture, true);
        try {
          chrome.storage?.onChanged?.removeListener?.(onStorageChanged);
        } catch {
        }
        if (observer) {
          observer.disconnect();
          observer = null;
        }
        const alertEl = doc.getElementById(ALERT_ID2);
        alertEl?.remove();
      },
      updateEnabled: (enabled) => {
        inMemoryShieldEnabled = enabled;
        if (enabled) {
          scanAndNeutralize();
        }
      },
      scanNow: () => scanAndNeutralize()
    };
  }

  // src/session-velocity.ts
  var TILTCHECK_SESSION_PNL_KEY = "tiltcheck_session_pnl_state";
  var DEFAULT_SESSION_RADAR_ENABLED = true;
  var MAX_RADAR_SAMPLES = 30;
  function calculateNetPnl(current, baseline) {
    if (!Number.isFinite(current) || !Number.isFinite(baseline)) return 0;
    return Math.round((current - baseline) * 100) / 100;
  }
  function calculateVelocityPerMin(samples, windowSec = 180) {
    if (!Array.isArray(samples) || samples.length < 2) return 0;
    const latest = samples[samples.length - 1];
    const cutoff = latest.timestamp - windowSec * 1e3;
    let windowSamples = samples.filter((s) => s.timestamp >= cutoff);
    if (windowSamples.length < 2) {
      windowSamples = samples.slice(-5);
    }
    const s0 = windowSamples[0];
    const sn = windowSamples[windowSamples.length - 1];
    const deltaSec = (sn.timestamp - s0.timestamp) / 1e3;
    if (deltaSec < 3) return 0;
    const deltaPnl = sn.pnl - s0.pnl;
    const ratePerSec = deltaPnl / deltaSec;
    return Math.round(ratePerSec * 60 * 100) / 100;
  }
  function determineVelocityStatus(velocityPerMin, netPnl) {
    if (velocityPerMin <= -20 || velocityPerMin <= -10 && netPnl <= -50) {
      return {
        status: "CLIFF-DIVE",
        label: "CLIFF-DIVE",
        color: "#ef4444",
        reason: `Severe loss acceleration: -$${Math.abs(velocityPerMin).toFixed(2)}/min. Tilt dive detected.`
      };
    }
    if (velocityPerMin <= -5) {
      return {
        status: "BLEED",
        label: "BLEED",
        color: "#f97316",
        reason: `Accelerating drawdown: -$${Math.abs(velocityPerMin).toFixed(2)}/min. Protect bankroll.`
      };
    }
    if (velocityPerMin <= -0.5) {
      return {
        status: "DRAIN",
        label: "DRAIN",
        color: "#fbbf24",
        reason: `Gradual loss rate: -$${Math.abs(velocityPerMin).toFixed(2)}/min. Steady bleed.`
      };
    }
    if (velocityPerMin >= 1) {
      return {
        status: "STEADY",
        label: "STEADY",
        color: "#17c3b2",
        reason: `Positive momentum: +$${velocityPerMin.toFixed(2)}/min. Lock profit.`
      };
    }
    return {
      status: "STEADY",
      label: "STEADY",
      color: "#17c3b2",
      reason: "Pacing steady. No tilt velocity detected."
    };
  }
  function recordBalanceSample(state, balance, timestamp = Date.now()) {
    if (!Number.isFinite(balance) || balance < 0) return state;
    const startingBalance = state.startingBalance === null ? balance : state.startingBalance;
    const startTime = state.startTime === 0 ? timestamp : state.startTime;
    const pnl = calculateNetPnl(balance, startingBalance);
    if (state.samples.length > 0) {
      const last = state.samples[state.samples.length - 1];
      if (last.balance === balance && timestamp - last.timestamp < 2e3) {
        return state;
      }
    }
    const newSample = { timestamp, balance, pnl };
    const updatedSamples = [...state.samples, newSample].slice(-MAX_RADAR_SAMPLES);
    const peakPnl = Math.max(state.peakPnl, pnl);
    const lowestPnl = Math.min(state.lowestPnl, pnl);
    const velocityPerMin = calculateVelocityPerMin(updatedSamples);
    const statusInfo = determineVelocityStatus(velocityPerMin, pnl);
    return {
      startingBalance,
      currentBalance: balance,
      netPnl: pnl,
      peakPnl,
      lowestPnl,
      samples: updatedSamples,
      velocityPerMin,
      status: statusInfo.status,
      statusReason: statusInfo.reason,
      startTime,
      lastUpdated: timestamp
    };
  }
  function resetSessionPnl(startingBalance = null, timestamp = Date.now()) {
    return {
      startingBalance,
      currentBalance: startingBalance,
      netPnl: 0,
      peakPnl: 0,
      lowestPnl: 0,
      samples: startingBalance !== null ? [{ timestamp, balance: startingBalance, pnl: 0 }] : [],
      velocityPerMin: 0,
      status: "STEADY",
      statusReason: "Session reset. Telemetry fresh.",
      startTime: timestamp,
      lastUpdated: timestamp
    };
  }
  var SPIN_CONTROL_SELECTOR2 = [
    'button[data-test="spin-button"]',
    "button.spin-button",
    'button[aria-label="Spin"]',
    'button[class*="SpinButton"]',
    'button[class*="play-button"]',
    'button[data-testid="play-button"]',
    'button[data-testid="spin-button"]',
    'button[class*="bet-button"]',
    'button[data-test="bet-button"]',
    ".game-controls button",
    "#spin-button",
    ".play-btn",
    ".spin-btn"
  ].join(", ");
  function installSessionVelocityRadar(doc, options) {
    let state = resetSessionPnl(options?.initialBalance ?? null);
    let stopped = false;
    const isEnabled = options?.enabled ?? DEFAULT_SESSION_RADAR_ENABLED;
    function doSample(balanceOverride) {
      if (stopped) return state;
      const balance = balanceOverride !== void 0 ? balanceOverride : readBalance(doc);
      if (balance !== null) {
        state = recordBalanceSample(state, balance);
        try {
          if (typeof chrome !== "undefined" && chrome.storage?.local) {
            chrome.storage.local.set({ [TILTCHECK_SESSION_PNL_KEY]: state });
          }
        } catch {
        }
      }
      return state;
    }
    doSample();
    const onSpinClick = () => {
      if (stopped) return;
      setTimeout(() => doSample(), 600);
      setTimeout(() => doSample(), 1800);
    };
    if (isEnabled) {
      doc.addEventListener("click", (e) => {
        const target = e.target;
        if (target && target.closest(SPIN_CONTROL_SELECTOR2)) {
          onSpinClick();
        }
      }, true);
    }
    const intervalId = setInterval(() => {
      if (stopped) return;
      doSample();
    }, 3500);
    return {
      getState: () => state,
      sample: (balanceOverride) => doSample(balanceOverride),
      reset: (startingBalance) => {
        state = resetSessionPnl(startingBalance);
        try {
          if (typeof chrome !== "undefined" && chrome.storage?.local) {
            chrome.storage.local.set({ [TILTCHECK_SESSION_PNL_KEY]: state });
          }
        } catch {
        }
        return state;
      },
      stop: () => {
        stopped = true;
        clearInterval(intervalId);
      }
    };
  }

  // src/streak-volatility.ts
  var STREAK_SPIN_SELECTOR = [
    'button[data-test="spin-button"]',
    "button.spin-button",
    'button[aria-label="Spin"]',
    'button[class*="SpinButton"]',
    'button[class*="play-button"]',
    'button[data-testid="play-button"]',
    'button[data-testid="spin-button"]',
    'button[class*="bet-button"]',
    'button[data-test="bet-button"]',
    ".game-controls button",
    "#spin-button",
    ".play-btn",
    ".spin-btn",
    'button[class*="bet"]',
    'button[class*="spin"]',
    '[data-action="bet"]',
    '[data-action="spin"]'
  ].join(", ");
  var TILTCHECK_STREAK_VOLATILITY_KEY = "tiltcheck_streak_volatility_state";
  var DEAD_SPIN_WARN_THRESHOLD = 10;
  var DEAD_SPIN_CRITICAL_THRESHOLD = 18;
  var WIN_STREAK_ALERT_THRESHOLD = 4;
  var DUE_TRAP_MIN_DEAD_SPINS = 6;
  var DEFAULT_STREAK_VOLATILITY_STATE = {
    currentStreakType: "NEUTRAL",
    consecutiveDeadSpins: 0,
    maxDeadSpins: 0,
    consecutiveWins: 0,
    maxWinStreak: 0,
    totalSpins: 0,
    winCount: 0,
    lossCount: 0,
    hitRate: 0,
    isDueTrapActive: false,
    stakeEscalatedDuringCold: false,
    streakAlertLevel: "NORMAL",
    alertMessage: "Pacing steady. Volatility telemetry active.",
    lastBetAmount: null,
    lastUpdated: 0
  };
  function parseMoney4(text) {
    if (text == null) return null;
    const tokens = text.split(/\s+/).map((token) => token.replace(/,/g, "").replace(/[^\d.-]/g, ""));
    const matches = tokens.filter((token) => /^-?\d+(\.\d+)?$/.test(token));
    if (matches.length !== 1) return null;
    return Number(matches[0]);
  }
  function readBetAmount2(doc) {
    const hostname2 = doc.location?.hostname || "";
    const entry = CASINO_SELECTORS.find((item) => hostname2 && hostname2.includes(item.domain) || item.domain === "*");
    const selector = entry?.selectors?.betAmount;
    if (!selector) return null;
    const element = doc.querySelector(selector);
    if (!element) return null;
    const raw = element.getAttribute("data-value") || element.getAttribute("value") || element.textContent;
    return parseMoney4(raw);
  }
  function recordSpinOutcome(state, currentBet, prevBalance, nextBalance, timestamp = Date.now()) {
    if (prevBalance === null || nextBalance === null) {
      return {
        ...state,
        lastBetAmount: currentBet ?? state.lastBetAmount,
        lastUpdated: timestamp
      };
    }
    const balanceDelta = Math.round((nextBalance - prevBalance) * 100) / 100;
    let {
      consecutiveDeadSpins,
      maxDeadSpins,
      consecutiveWins,
      maxWinStreak,
      totalSpins,
      winCount,
      lossCount,
      currentStreakType,
      isDueTrapActive,
      stakeEscalatedDuringCold
    } = state;
    totalSpins++;
    if (balanceDelta > 1e-3) {
      consecutiveWins++;
      consecutiveDeadSpins = 0;
      currentStreakType = "HOT";
      maxWinStreak = Math.max(maxWinStreak, consecutiveWins);
      winCount++;
      isDueTrapActive = false;
    } else if (balanceDelta < -1e-3) {
      consecutiveDeadSpins++;
      consecutiveWins = 0;
      currentStreakType = "COLD";
      maxDeadSpins = Math.max(maxDeadSpins, consecutiveDeadSpins);
      lossCount++;
      if (consecutiveDeadSpins >= DUE_TRAP_MIN_DEAD_SPINS && currentBet !== null && state.lastBetAmount !== null && currentBet > state.lastBetAmount * 1.15) {
        isDueTrapActive = true;
        stakeEscalatedDuringCold = true;
      }
    }
    const hitRate = totalSpins > 0 ? Math.round(winCount / totalSpins * 1e3) / 10 : 0;
    let streakAlertLevel = "NORMAL";
    let alertMessage = "Pacing steady. Volatility telemetry normal.";
    if (isDueTrapActive) {
      streakAlertLevel = "CRITICAL_COLD";
      alertMessage = `Gambler's Fallacy Trap: ${consecutiveDeadSpins} dead spins and stake raised. The next spin is NOT "due". Volatility has no memory. Step back.`;
    } else if (consecutiveDeadSpins >= DEAD_SPIN_CRITICAL_THRESHOLD) {
      streakAlertLevel = "CRITICAL_COLD";
      alertMessage = `Extreme Cold Run: ${consecutiveDeadSpins} dead spins without a payout. Outlier volatility active. Protect bankroll.`;
    } else if (consecutiveDeadSpins >= DEAD_SPIN_WARN_THRESHOLD) {
      streakAlertLevel = "WARN_COLD";
      alertMessage = `Cold Streak: ${consecutiveDeadSpins} consecutive dead spins. Hit rate down to ${hitRate}%. Do not chase.`;
    } else if (consecutiveWins >= WIN_STREAK_ALERT_THRESHOLD) {
      streakAlertLevel = "HEATER_ALERT";
      alertMessage = `Heater Detected: ${consecutiveWins} consecutive wins. Skim profit before volatility reverses.`;
    }
    return {
      currentStreakType,
      consecutiveDeadSpins,
      maxDeadSpins,
      consecutiveWins,
      maxWinStreak,
      totalSpins,
      winCount,
      lossCount,
      hitRate,
      isDueTrapActive,
      stakeEscalatedDuringCold,
      streakAlertLevel,
      alertMessage,
      lastBetAmount: currentBet ?? state.lastBetAmount,
      lastUpdated: timestamp
    };
  }
  function resetStreakVolatility(timestamp = Date.now()) {
    return {
      ...DEFAULT_STREAK_VOLATILITY_STATE,
      alertMessage: "Streak tracker reset. Fresh volatility session.",
      lastUpdated: timestamp
    };
  }
  var STREAK_BADGE_ID = "tiltcheck-streak-badge";
  var STREAK_TOAST_ID = "tiltcheck-streak-toast";
  var STREAK_STYLES_ID = "tiltcheck-streak-styles";
  function ensureStreakStyles(doc) {
    if (doc.getElementById(STREAK_STYLES_ID)) return;
    const style = doc.createElement("style");
    style.id = STREAK_STYLES_ID;
    style.textContent = `
    #${STREAK_BADGE_ID} {
      position: fixed;
      bottom: 16px;
      right: 16px;
      z-index: 2147483640;
      background: #0f1115;
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 6px;
      padding: 6px 10px;
      color: #ffffff;
      font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.04em;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      gap: 6px;
      pointer-events: auto;
      transition: all 0.2s ease;
    }
    #${STREAK_BADGE_ID}.badge-cold {
      border-color: #f97316;
      color: #f97316;
      background: rgba(249, 115, 22, 0.1);
    }
    #${STREAK_BADGE_ID}.badge-trap {
      border-color: #ef4444;
      color: #ef4444;
      background: rgba(239, 68, 68, 0.15);
      animation: tiltcheck-streak-pulse 1s infinite alternate;
    }
    #${STREAK_BADGE_ID}.badge-hot {
      border-color: #17c3b2;
      color: #17c3b2;
      background: rgba(23, 195, 178, 0.1);
    }
    @keyframes tiltcheck-streak-pulse {
      from { transform: scale(1); }
      to { transform: scale(1.04); }
    }
    #${STREAK_TOAST_ID} {
      position: fixed;
      top: 5rem;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2147483645;
      background: #0d1117;
      border: 1px solid #ef4444;
      border-radius: 8px;
      padding: 12px 16px;
      color: #ffffff;
      font-family: ui-monospace, "Cascadia Code", monospace;
      font-size: 12px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.7);
      display: flex;
      align-items: center;
      gap: 12px;
      max-width: 90vw;
      width: 420px;
      box-sizing: border-box;
      pointer-events: auto;
    }
    .tiltcheck-streak-toast-text {
      flex: 1;
      line-height: 1.4;
      font-weight: 600;
    }
    .tiltcheck-streak-toast-cashier {
      background: #17c3b2;
      color: #000000;
      border: none;
      border-radius: 4px;
      font-weight: 800;
      font-size: 11px;
      padding: 6px 10px;
      cursor: pointer;
      text-transform: uppercase;
      white-space: nowrap;
    }
    .tiltcheck-streak-toast-dismiss {
      background: transparent;
      border: none;
      color: rgba(255, 255, 255, 0.6);
      cursor: pointer;
      font-size: 14px;
      padding: 2px 6px;
    }
    .tiltcheck-streak-toast-dismiss:hover {
      color: #ffffff;
    }
  `;
    (doc.head || doc.documentElement).appendChild(style);
  }
  function installStreakVolatilityTracker(doc = document) {
    ensureStreakStyles(doc);
    let state = { ...DEFAULT_STREAK_VOLATILITY_STATE };
    let lastKnownBalance = readBalance(doc);
    let stopped = false;
    let toastDismissed = false;
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.get([TILTCHECK_STREAK_VOLATILITY_KEY], (res) => {
        const saved = res[TILTCHECK_STREAK_VOLATILITY_KEY];
        if (saved && typeof saved.consecutiveDeadSpins === "number") {
          state = saved;
          updateDomBadge();
        }
      });
    }
    const persist = () => {
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        chrome.storage.local.set({ [TILTCHECK_STREAK_VOLATILITY_KEY]: state });
      }
    };
    const updateDomBadge = () => {
      if (stopped) return;
      let badge = doc.getElementById(STREAK_BADGE_ID);
      if (!badge) {
        badge = doc.createElement("div");
        badge.id = STREAK_BADGE_ID;
        (doc.body || doc.documentElement).appendChild(badge);
      }
      if (state.isDueTrapActive) {
        badge.className = "badge-trap";
        badge.textContent = `FALLACY TRAP: ${state.consecutiveDeadSpins} DEAD SPINS (STAKE UP)`;
      } else if (state.consecutiveDeadSpins >= DEAD_SPIN_WARN_THRESHOLD) {
        badge.className = "badge-cold";
        badge.textContent = `COLD: ${state.consecutiveDeadSpins} DEAD SPINS (${state.hitRate}% HIT)`;
      } else if (state.consecutiveWins >= WIN_STREAK_ALERT_THRESHOLD) {
        badge.className = "badge-hot";
        badge.textContent = `HEATER: ${state.consecutiveWins} WINS IN A ROW`;
      } else if (state.totalSpins > 0) {
        badge.className = "";
        badge.textContent = `SPINS: ${state.totalSpins} | HIT: ${state.hitRate}%`;
      } else {
        badge.className = "";
        badge.textContent = "VOLATILITY TRACKER ACTIVE";
      }
      const shouldShowToast = (state.streakAlertLevel === "CRITICAL_COLD" || state.isDueTrapActive) && !toastDismissed;
      let toast = doc.getElementById(STREAK_TOAST_ID);
      if (shouldShowToast) {
        if (!toast) {
          toast = doc.createElement("div");
          toast.id = STREAK_TOAST_ID;
          const textEl = doc.createElement("span");
          textEl.className = "tiltcheck-streak-toast-text";
          textEl.textContent = state.alertMessage;
          const cashierBtn = doc.createElement("button");
          cashierBtn.type = "button";
          cashierBtn.className = "tiltcheck-streak-toast-cashier";
          cashierBtn.textContent = "Cashier ->";
          cashierBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            triggerCashoutNavigation(doc);
          });
          const dismissBtn = doc.createElement("button");
          dismissBtn.type = "button";
          dismissBtn.className = "tiltcheck-streak-toast-dismiss";
          dismissBtn.textContent = "x";
          dismissBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            toastDismissed = true;
            toast?.remove();
          });
          toast.appendChild(textEl);
          toast.appendChild(cashierBtn);
          toast.appendChild(dismissBtn);
          (doc.body || doc.documentElement).appendChild(toast);
        } else {
          const textEl = toast.querySelector(".tiltcheck-streak-toast-text");
          if (textEl) textEl.textContent = state.alertMessage;
        }
      } else if (toast) {
        toast.remove();
      }
    };
    const handleSpinClick = () => {
      if (stopped) return;
      const currentBet = readBetAmount2(doc);
      const balanceBefore = lastKnownBalance ?? readBalance(doc);
      setTimeout(() => {
        if (stopped) return;
        const balanceAfter = readBalance(doc);
        if (balanceAfter !== null && Number.isFinite(balanceAfter)) {
          state = recordSpinOutcome(state, currentBet, balanceBefore, balanceAfter);
          lastKnownBalance = balanceAfter;
          persist();
          updateDomBadge();
        }
      }, 1200);
    };
    const onDocClick = (e) => {
      const target = e.target;
      if (target instanceof Element && target.closest(STREAK_SPIN_SELECTOR)) {
        handleSpinClick();
      }
    };
    doc.addEventListener("click", onDocClick, true);
    updateDomBadge();
    return {
      getState: () => state,
      reset: () => {
        state = resetStreakVolatility();
        toastDismissed = false;
        persist();
        updateDomBadge();
        return state;
      },
      recordOutcome: (currentBet, prevBalance, nextBalance) => {
        if (stopped) return state;
        state = recordSpinOutcome(state, currentBet, prevBalance, nextBalance);
        if (nextBalance !== null) lastKnownBalance = nextBalance;
        persist();
        updateDomBadge();
        return state;
      },
      stop: () => {
        stopped = true;
        doc.removeEventListener("click", onDocClick, true);
        doc.getElementById(STREAK_BADGE_ID)?.remove();
        doc.getElementById(STREAK_TOAST_ID)?.remove();
        doc.getElementById(STREAK_STYLES_ID)?.remove();
      }
    };
  }

  // src/content.ts
  function isDomain(hostname2, domain) {
    return hostname2 === domain || hostname2.endsWith("." + domain);
  }
  var hostname = window.location.hostname.toLowerCase();
  var pathname = window.location.pathname.toLowerCase();
  var isDiscordAuthRoute = pathname.startsWith("/auth/discord");
  var isExcludedDomain = isDomain(hostname, "discord.com") || hostname === "localhost" && window.location.port === "3333" || hostname === "localhost" && window.location.port === "3001" && isDiscordAuthRoute || isDomain(hostname, "api.tiltcheck.me") && isDiscordAuthRoute;
  if (isExcludedDomain) {
    if (typeof define_process_default !== "undefined" && define_process_default.env?.NODE_ENV !== "production") {
      console.log("[TiltCheck] Skipping - excluded domain:", hostname);
    }
  }
  var TILTCHECK_PRO_MONOLITH_KEY = "tiltcheck_pro_monolith_enabled";
  var TILTCHECK_CORE_RECORD_BET_EVENT = "tiltcheck-core-record-bet";
  var TILTCHECK_TILT_SIGNAL_EVENT = "tiltcheck-tilt-signal";
  var TILTCHECK_TRIGGER_TIMEOUT_EVENT = "tiltcheck-trigger-timeout";
  var paceLock = null;
  var heaterNudge = null;
  var chaseWarning = null;
  var realityHud = null;
  var depositBarrier = null;
  var reverseWithdrawalShield = null;
  var profitLock = null;
  var bonusTracker = null;
  var sessionRadar = null;
  var streakTracker = null;
  var coreOptions = null;
  var proModulePromise = null;
  var proActive = false;
  var clickTimestamps = [];
  var RAPID_CLICK_BURST_COUNT = 5;
  var RAPID_CLICK_WINDOW_MS = 1500;
  function handleRapidClickTilt(target) {
    const isActionControl = target.closest(SPIN_CONTROL_SELECTOR) !== null || target.matches(SPIN_CONTROL_SELECTOR) || target.closest('button, [role="button"]') !== null;
    if (!isActionControl) return false;
    const now = Date.now();
    clickTimestamps = clickTimestamps.filter((t) => now - t <= RAPID_CLICK_WINDOW_MS);
    clickTimestamps.push(now);
    if (clickTimestamps.length >= RAPID_CLICK_BURST_COUNT) {
      clickTimestamps = [];
      const duration = coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
      triggerTouchGrassTimeout(
        "Rapid clicking detected. Turbo mashing only speeds up the house edge. Step back and breathe.",
        duration
      );
      return true;
    }
    return false;
  }
  function installEventDrivenTiltWatcher() {
    const onSignal = (event) => {
      const custom = event;
      const reason = custom.detail?.reason || (custom.detail?.signal === "rapid_clicking" ? "Rapid clicking detected. Turbo mashing only speeds up the house edge. Step back and breathe." : custom.detail?.signal === "loss_chasing" ? "You are down on consecutive spins and ramping stake size. You're chasing, not on a heater. Step back." : "Tilt signal detected. Step back and recalibrate.");
      const duration = custom.detail?.durationMs ?? coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
      triggerTouchGrassTimeout(reason, duration);
    };
    const onTrigger = (event) => {
      const custom = event;
      const reason = custom.detail?.reason || "Hold up. Recalibrate.";
      const duration = custom.detail?.durationMs ?? coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
      triggerTouchGrassTimeout(reason, duration);
    };
    const onClickCapture = (event) => {
      if (event.target instanceof Element) {
        handleRapidClickTilt(event.target);
      }
    };
    window.addEventListener(TILTCHECK_TILT_SIGNAL_EVENT, onSignal);
    window.addEventListener(TILTCHECK_TRIGGER_TIMEOUT_EVENT, onTrigger);
    document.addEventListener("click", onClickCapture, true);
    return () => {
      window.removeEventListener(TILTCHECK_TILT_SIGNAL_EVENT, onSignal);
      window.removeEventListener(TILTCHECK_TRIGGER_TIMEOUT_EVENT, onTrigger);
      document.removeEventListener("click", onClickCapture, true);
    };
  }
  async function waitForDocumentEnd() {
    if (document.readyState !== "loading" && document.body) {
      return;
    }
    await new Promise((resolve) => {
      const resolveWhenReady = () => {
        if (document.body) {
          document.removeEventListener("DOMContentLoaded", resolveWhenReady);
          resolve();
        }
      };
      document.addEventListener("DOMContentLoaded", resolveWhenReady, { once: true });
      setTimeout(resolveWhenReady, 0);
    });
  }
  async function shouldLoadProMonolith() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_PRO_MONOLITH_KEY);
      return stored[TILTCHECK_PRO_MONOLITH_KEY] === true;
    } catch {
      return false;
    }
  }
  async function loadProModule() {
    if (!proModulePromise) {
      proModulePromise = import(chrome.runtime.getURL("pro-monolith-bootstrap.js"));
    }
    return proModulePromise;
  }
  async function setProMonolithEnabled(enabled) {
    if (enabled) {
      if (proActive) return;
      const mod2 = await loadProModule();
      await mod2.startProMonolith();
      proActive = true;
      return;
    }
    if (!proActive) return;
    const mod = await loadProModule();
    mod.deactivateProMonolith();
    proActive = false;
  }
  async function refreshCoreOptions() {
    coreOptions = await loadCoreCircuitBreakerOptions();
    return coreOptions;
  }
  function installCoreOptionsListener() {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if (TILTCHECK_PRO_MONOLITH_KEY in changes) {
          const enabled = changes[TILTCHECK_PRO_MONOLITH_KEY]?.newValue === true;
          void setProMonolithEnabled(enabled);
        }
        const coreKeyTouched = CORE_CIRCUIT_BREAKER_STORAGE_KEYS.some((k) => k in changes);
        if (coreKeyTouched) {
          void refreshCoreOptions().then((opts) => {
            syncPaceLock(opts.enforcementEnabled);
            syncRealityHud(opts);
            syncDepositBarrier(opts);
            syncReverseWithdrawalShield(opts);
            syncProfitLock(opts);
            syncBonusTracker(opts);
          });
        }
      });
    } catch {
    }
  }
  function syncRealityHud(opts) {
    const shouldRun = opts.enforcementEnabled && opts.realityHudEnabled;
    if (shouldRun) {
      if (!realityHud) {
        try {
          realityHud = installRealityHud(document, {
            hourlyWage: opts.hourlyWage,
            enabled: opts.realityHudEnabled,
            thresholdHours: opts.realityThresholdHours
          });
        } catch {
          realityHud = null;
        }
      } else {
        realityHud.updateOptions({
          hourlyWage: opts.hourlyWage,
          enabled: opts.realityHudEnabled,
          thresholdHours: opts.realityThresholdHours
        });
      }
    } else if (realityHud) {
      realityHud.stop();
      realityHud = null;
    }
  }
  function syncDepositBarrier(opts) {
    const shouldRun = opts.enforcementEnabled && opts.depositBarrierEnabled;
    if (shouldRun) {
      if (!depositBarrier) {
        try {
          depositBarrier = installDepositBarrier(document);
        } catch {
          depositBarrier = null;
        }
      }
      depositBarrier?.updateCooldown(opts.cooldownActiveUntil);
      depositBarrier?.updateEnabled(opts.depositBarrierEnabled);
    } else if (depositBarrier) {
      depositBarrier.stop();
      depositBarrier = null;
    }
  }
  function syncReverseWithdrawalShield(opts) {
    const shouldRun = opts.enforcementEnabled && opts.reverseWithdrawalShieldEnabled;
    if (shouldRun) {
      if (!reverseWithdrawalShield) {
        try {
          reverseWithdrawalShield = installReverseWithdrawalShield(document);
        } catch {
          reverseWithdrawalShield = null;
        }
      }
      reverseWithdrawalShield?.updateEnabled(opts.reverseWithdrawalShieldEnabled);
    } else if (reverseWithdrawalShield) {
      reverseWithdrawalShield.stop();
      reverseWithdrawalShield = null;
    }
  }
  function syncProfitLock(opts) {
    const shouldRun = opts.enforcementEnabled && (opts.profitLockEnabled || opts.goalsEnabled);
    if (shouldRun) {
      if (!profitLock) {
        try {
          profitLock = installProfitLock(document, {
            profitLockEnabled: opts.profitLockEnabled,
            trailingPercent: opts.trailingPercent,
            minProfit: opts.minProfit,
            goalsEnabled: opts.goalsEnabled,
            goals: opts.goals
          });
        } catch {
          profitLock = null;
        }
      } else {
        profitLock.updateOptions({
          profitLockEnabled: opts.profitLockEnabled,
          trailingPercent: opts.trailingPercent,
          minProfit: opts.minProfit,
          goalsEnabled: opts.goalsEnabled,
          goals: opts.goals
        });
      }
    } else if (profitLock) {
      profitLock.stop();
      profitLock = null;
    }
  }
  function syncBonusTracker(opts) {
    const shouldRun = opts.enforcementEnabled && opts.bonusConfig?.active;
    if (shouldRun) {
      if (!bonusTracker) {
        try {
          bonusTracker = installBonusTracker(document, opts.bonusConfig);
        } catch {
          bonusTracker = null;
        }
      } else {
        bonusTracker.updateConfig(opts.bonusConfig);
      }
    } else if (bonusTracker) {
      bonusTracker.stop();
      bonusTracker = null;
    }
  }
  function syncPaceLock(enabled) {
    if (enabled && !paceLock) {
      paceLock = installSpinPaceLock();
      if (!heaterNudge) {
        try {
          heaterNudge = installHeaterNudge();
        } catch {
          heaterNudge = null;
        }
      }
      if (!chaseWarning) {
        try {
          chaseWarning = installChaseWarning(
            document,
            () => paceLock ? paceLock.lockUntil() : 0,
            (stake, lastLossStake) => {
              if (stake >= lastLossStake * 1.5) {
                const duration = coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
                triggerTouchGrassTimeout(
                  "You are down on consecutive spins and ramping stake size. You're chasing, not on a heater. Step back.",
                  duration
                );
              }
            }
          );
        } catch {
          chaseWarning = null;
        }
      }
      return;
    }
    if (!enabled && paceLock) {
      chaseWarning?.stop();
      chaseWarning = null;
      heaterNudge?.stop();
      heaterNudge = null;
      paceLock.stop();
      paceLock = null;
    }
  }
  async function startCoreCircuitBreaker() {
    await waitForDocumentEnd();
    const opts = await refreshCoreOptions();
    installCoreOptionsListener();
    window.__tiltcheckCoreShieldActive = true;
    syncPaceLock(opts.enforcementEnabled);
    syncRealityHud(opts);
    syncDepositBarrier(opts);
    syncReverseWithdrawalShield(opts);
    syncProfitLock(opts);
    syncBonusTracker(opts);
    if (!sessionRadar) {
      try {
        sessionRadar = installSessionVelocityRadar(document);
      } catch {
        sessionRadar = null;
      }
    }
    if (!streakTracker) {
      try {
        streakTracker = installStreakVolatilityTracker(document);
      } catch {
        streakTracker = null;
      }
    }
  }
  async function boot() {
    if (isExcludedDomain) {
      return;
    }
    await startCoreCircuitBreaker();
    installEventDrivenTiltWatcher();
    installLoungeOverlay();
    installLocalGameBlocker();
    if (await shouldLoadProMonolith()) {
      await setProMonolithEnabled(true);
    }
  }
  void boot();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (isExcludedDomain && message.type !== "get_sidebar_state") {
      sendResponse({ error: "Feature disabled on this domain" });
      return true;
    }
    if (proActive && (message.type === "toggle_sidebar" || message.type === "open_sidebar" || message.type === "get_sidebar_state")) {
      return false;
    }
    switch (message.type) {
      case "trigger_touch_grass": {
        const duration = message.durationMs ?? coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
        triggerTouchGrassTimeout(
          message.reason || "Tilt signal detected. Step back and recalibrate.",
          duration
        );
        sendResponse({ success: true, active: true });
        return true;
      }
      case "toggle_sidebar":
      case "open_sidebar":
        sendResponse({
          success: false,
          coreOnly: true,
          hint: "Set tiltcheck_pro_monolith_enabled to true in chrome.storage.local to load the full TiltCheck panel."
        });
        return true;
      case "get_sidebar_state":
        sendResponse({
          exists: false,
          visible: false,
          injectionDisabled: false,
          coreOnly: true
        });
        return true;
      case "get_deposit_barrier_state":
        sendResponse({
          active: depositBarrier ? depositBarrier.isActive() : false,
          cooldownUntil: depositBarrier ? depositBarrier.getCooldownActiveUntil() : 0
        });
        return true;
      case "get_reality_hud_state":
        sendResponse({
          visible: realityHud ? realityHud.isVisible() : false,
          baseline: realityHud ? realityHud.getBaseline() : null
        });
        return true;
      case "get_reverse_withdrawal_shield_state":
        sendResponse({
          active: reverseWithdrawalShield !== null
        });
        return true;
      case "get_profit_lock_state":
        sendResponse({
          active: profitLock !== null,
          baseline: profitLock ? profitLock.getBaseline() : null,
          peak: profitLock ? profitLock.getPeak() : 0,
          floor: profitLock ? profitLock.getFloor() : null,
          softWarningActive: profitLock ? profitLock.isSoftWarningActive() : false,
          hardGuardTriggered: profitLock ? profitLock.isHardGuardTriggered() : false
        });
        return true;
      case "get_bonus_tracker_state":
        sendResponse({
          active: bonusTracker !== null,
          config: bonusTracker ? bonusTracker.getConfig() : null,
          progress: bonusTracker ? bonusTracker.getProgress() : null
        });
        return true;
      case "get_session_pnl_state":
        sendResponse(sessionRadar ? sessionRadar.getState() : null);
        return true;
      case "reset_session_pnl":
        sendResponse(sessionRadar ? sessionRadar.reset() : null);
        return true;
      case "get_streak_volatility_state":
        sendResponse(streakTracker ? streakTracker.getState() : DEFAULT_STREAK_VOLATILITY_STATE);
        return true;
      case "reset_streak_volatility":
        sendResponse(streakTracker ? streakTracker.reset() : DEFAULT_STREAK_VOLATILITY_STATE);
        return true;
      case "get_cashout_router_state": {
        const info = detectCashoutTarget(document);
        sendResponse({
          success: true,
          info: {
            isCasinoTab: Boolean(info.route || info.clickTarget),
            casinoName: info.casinoName,
            cashierUrl: info.cashierUrl,
            buttonLabel: info.buttonLabel,
            isSweepstakes: info.isSweepstakes,
            canClick: Boolean(info.clickTarget)
          }
        });
        return true;
      }
      case "trigger_cashout_navigation": {
        const result = triggerCashoutNavigation(document);
        sendResponse(result);
        return true;
      }
      case "trigger_auto_vault": {
        const amount = typeof message.amount === "number" && Number.isFinite(message.amount) ? message.amount : 0;
        const currency = typeof message.currency === "string" ? message.currency : "usd";
        triggerAutoVault(amount, currency, document).then((res) => {
          sendResponse(res);
        });
        return true;
      }
      default:
        return false;
    }
  });
  if (typeof define_process_default !== "undefined" && define_process_default.env?.NODE_ENV !== "production") {
    console.log("[TiltCheck] Core content script loaded");
  }
})();
//# sourceMappingURL=content.js.map
