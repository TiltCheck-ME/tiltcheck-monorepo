(() => {
  // <define:process>
  var define_process_default = { env: {} };

  // apps/chrome-extension/src/touch-grass-timeout.ts
  var TOUCH_GRASS_DURATION_MS = 12e4;
  var TOUCH_GRASS_HUB_ORIGIN = "https://tiltcheck.me";
  var TOUCH_GRASS_HUB_PAUSE_PATH = "/touch-grass?mode=pause";
  var TOUCH_GRASS_HUB_READY_SOURCE = "TILTCHECK_TOUCH_GRASS";
  var HUB_IFRAME_ID = "tiltcheck-lockdown-hub";
  var HUB_IFRAME_LOAD_TIMEOUT_MS = 4e3;
  var CSP_FALLBACK_PROMPTS = [
    "Stand up. Two minutes of legs, not clicking reels.",
    "Get water. The house edge will still be there.",
    "Text a friend who does not have a referral code."
  ];
  function resolveTouchGrassHubUrl(origin = TOUCH_GRASS_HUB_ORIGIN) {
    return `${origin}${TOUCH_GRASS_HUB_PAUSE_PATH}`;
  }
  function resolveTouchGrassHubOrigin() {
    const hostname2 = globalThis.location?.hostname;
    if (hostname2 === "localhost" || hostname2 === "127.0.0.1") {
      return globalThis.location.origin;
    }
    return TOUCH_GRASS_HUB_ORIGIN;
  }
  function isTouchGrassHubReadyPing(event, expectedOrigin) {
    if (event.origin !== expectedOrigin) {
      return false;
    }
    const data = event.data;
    if (data == null || typeof data !== "object") {
      return false;
    }
    const payload = data;
    return payload.source === TOUCH_GRASS_HUB_READY_SOURCE && payload.ready === true;
  }
  var MESSAGE_ROTATE_MS = 2e4;
  var MESSAGE_FADE_SWAP_MS = 450;
  var BREAK_MESSAGES = [
    "You are down 60% in 9 minutes. You are not on a heater, you're chasing. Close the tab.",
    "Ed Craven doesn't need your rent money. Close the browser.",
    "That's 14 dead spins on Hacksaw. You already know how this movie ends.",
    "You're playing a 94.5% downgraded RTP tier on an offshore mirror thinking it's 96.5%.",
    "The bonus buy will not make you whole. Step back and breathe.",
    "Turbo spinning through dead rolls only speeds up the house edge. Walk away for two minutes.",
    "House telemetry loves rage clicking. Take your hand off the mouse.",
    "Unclench your jaw, put the phone down, and drink some water. The reel can wait."
  ];
  var LOCKDOWN_ROOT_ID = "tiltcheck-lockdown-root";
  var MESSAGE_EL_ID = "tiltcheck-lockdown-message";
  var TIMER_ID = "lockdown-timer";
  var overlayActive = false;
  var overlayHubMessageListener = null;
  function isTouchGrassActive() {
    return overlayActive;
  }
  function blockBettingUI(block) {
    const betButtons = document.querySelectorAll(
      'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
    );
    betButtons.forEach((btn) => {
      if (block) {
        if (btn instanceof HTMLButtonElement) {
          btn.disabled = true;
        }
        btn.style.opacity = "0.5";
        btn.style.cursor = "not-allowed";
        btn.dataset.tiltguardBlocked = "true";
      } else if (btn.dataset.tiltguardBlocked) {
        if (btn instanceof HTMLButtonElement) {
          btn.disabled = false;
        }
        btn.style.opacity = "";
        btn.style.cursor = "";
        delete btn.dataset.tiltguardBlocked;
      }
    });
  }
  function injectLockdownStyles(root) {
    const style = document.createElement("style");
    style.textContent = `
    #${LOCKDOWN_ROOT_ID} {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: #0f1115 !important;
      z-index: 2147483647 !important;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace;
      color: #ff4a4a;
      box-sizing: border-box;
      padding: 1.5rem;
      overflow-y: auto;
      user-select: none;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-inner {
      width: 100%;
      max-width: 32rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-eyebrow {
      font-size: 0.6875rem;
      font-weight: 800;
      letter-spacing: 0.28em;
      text-transform: uppercase;
      color: #ff4a4a;
      margin-bottom: 0.75rem;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-headline {
      font-size: 1.625rem;
      font-weight: 900;
      letter-spacing: -0.02em;
      color: #ffffff;
      margin: 0 0 0.75rem;
      line-height: 1.15;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-reason {
      font-size: 0.875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.82);
      margin: 0 0 1.25rem;
      max-width: 28rem;
    }

    /* Center stage: pacer ring + timer digits */
    .tiltcheck-pacer-stage {
      position: relative;
      width: 250px;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 2rem 0;
    }

    .tiltcheck-breath-pacer {
      position: absolute;
      width: 200px;
      height: 200px;
      border: 4px solid #ff4a4a;
      border-radius: 50%;
      box-shadow: 0 0 15px rgba(255, 74, 74, 0.2);
      animation: tiltcheck-breath-pacer 8s ease-in-out infinite;
      pointer-events: none;
    }

    #${TIMER_ID} {
      font-size: 3.5rem;
      font-weight: bold;
      color: #ffffff;
      z-index: 10;
      font-variant-numeric: tabular-nums;
      line-height: 1;
      text-shadow: 0 2px 20px rgba(0, 0, 0, 0.5);
    }

    @keyframes tiltcheck-breath-pacer {
      0%, 100% {
        transform: scale(0.6);
        opacity: 0.3;
        box-shadow: 0 0 10px rgba(255, 74, 74, 0.1);
      }
      50% {
        transform: scale(1.1);
        opacity: 0.9;
        border-color: #4affb4;
        box-shadow: 0 0 30px rgba(74, 255, 180, 0.4);
      }
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-breath-hint {
      position: absolute;
      bottom: -2.25rem;
      left: 50%;
      transform: translateX(-50%);
      width: 18rem;
      font-size: 0.625rem;
      opacity: 0.55;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: rgba(255, 255, 255, 0.55);
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-signal-label {
      font-size: 0.625rem;
      font-weight: 800;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: rgba(255, 74, 74, 0.65);
      margin-bottom: 0.5rem;
      align-self: stretch;
      text-align: left;
    }

    #${MESSAGE_EL_ID} {
      font-size: 0.875rem;
      line-height: 1.5;
      margin: 0;
      text-align: left;
      min-height: 4.5em;
      align-self: stretch;
      color: rgba(245, 245, 245, 0.94);
      transition: opacity 0.45s ease;
    }

    #${HUB_IFRAME_ID} {
      width: 100%;
      max-width: 32rem;
      height: 18rem;
      margin: 0.75rem 0 1rem;
      border: 1px solid rgba(255, 255, 255, 0.12);
      background: #111318;
      pointer-events: auto;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-csp-fallback {
      align-self: stretch;
      text-align: left;
      margin: 0 0 1rem;
      padding: 0 0 0 1.1rem;
      color: rgba(245, 245, 245, 0.94);
      font-size: 0.875rem;
      line-height: 1.5;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-foot {
      font-size: 0.6875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.45);
      margin: 1.25rem 0 0;
      max-width: 26rem;
    }
  `;
    root.insertBefore(style, root.firstChild);
  }
  function triggerTouchGrassTimeout(reason, durationMs = TOUCH_GRASS_DURATION_MS) {
    if (overlayActive) {
      return;
    }
    overlayActive = true;
    blockBettingUI(true);
    const existing = document.getElementById(LOCKDOWN_ROOT_ID);
    if (existing) {
      existing.remove();
    }
    const root = document.createElement("div");
    root.id = LOCKDOWN_ROOT_ID;
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.setAttribute(
      "aria-label",
      "Touch Grass timeout \u2014 session pause with breathing pacer and rotating guidance"
    );
    injectLockdownStyles(root);
    const inner = document.createElement("div");
    inner.className = "tiltcheck-lockdown-inner";
    const eyebrow = document.createElement("div");
    eyebrow.className = "tiltcheck-eyebrow";
    eyebrow.textContent = "Touch Grass Timeout";
    const headline = document.createElement("h1");
    headline.className = "tiltcheck-lockdown-headline";
    headline.textContent = "Hold up. Recalibrate.";
    const reasonEl = document.createElement("p");
    reasonEl.className = "tiltcheck-lockdown-reason";
    reasonEl.textContent = reason;
    const stage = document.createElement("div");
    stage.className = "tiltcheck-pacer-stage";
    const breathRing = document.createElement("div");
    breathRing.className = "tiltcheck-breath-pacer";
    breathRing.setAttribute("aria-hidden", "true");
    const timerWrap = document.createElement("div");
    timerWrap.id = TIMER_ID;
    timerWrap.setAttribute("aria-live", "polite");
    timerWrap.setAttribute("aria-atomic", "true");
    const breathHint = document.createElement("div");
    breathHint.className = "tiltcheck-breath-hint";
    breathHint.textContent = "Inhale as the ring expands \u2014 exhale as it releases.";
    const signalLabel = document.createElement("div");
    signalLabel.className = "tiltcheck-signal-label";
    signalLabel.textContent = "Spotter Signal";
    const messageRegion = document.createElement("div");
    messageRegion.className = "tiltcheck-signal-region";
    messageRegion.setAttribute("role", "region");
    messageRegion.setAttribute("aria-label", "System message updates every 20 seconds");
    const messageEl = document.createElement("p");
    messageEl.id = MESSAGE_EL_ID;
    messageEl.setAttribute("aria-live", "off");
    messageEl.textContent = BREAK_MESSAGES[0] ?? "";
    const foot = document.createElement("p");
    foot.className = "tiltcheck-lockdown-foot";
    foot.textContent = "This tab stays locked until the countdown hits zero. No dismiss. Spotter protocol active.";
    const hubOrigin = resolveTouchGrassHubOrigin();
    const iframe = document.createElement("iframe");
    iframe.id = HUB_IFRAME_ID;
    iframe.title = "Touch Grass games hub";
    iframe.src = resolveTouchGrassHubUrl(hubOrigin);
    iframe.referrerPolicy = "no-referrer";
    const fallbackList = document.createElement("ul");
    fallbackList.className = "tiltcheck-csp-fallback";
    fallbackList.hidden = true;
    fallbackList.setAttribute("aria-label", "Local pause prompts");
    for (const prompt of CSP_FALLBACK_PROMPTS) {
      const item = document.createElement("li");
      item.textContent = prompt;
      fallbackList.appendChild(item);
    }
    stage.appendChild(breathRing);
    stage.appendChild(timerWrap);
    stage.appendChild(breathHint);
    inner.appendChild(eyebrow);
    inner.appendChild(headline);
    inner.appendChild(reasonEl);
    inner.appendChild(stage);
    inner.appendChild(iframe);
    inner.appendChild(fallbackList);
    messageRegion.appendChild(messageEl);
    inner.appendChild(signalLabel);
    inner.appendChild(messageRegion);
    inner.appendChild(foot);
    root.appendChild(inner);
    document.body.appendChild(root);
    const stopBlocking = (e) => {
      if (e.target === iframe) {
        return;
      }
      e.preventDefault();
      e.stopPropagation();
    };
    const captureOpts = { capture: true };
    root.addEventListener("click", stopBlocking, captureOpts);
    root.addEventListener("mousedown", stopBlocking, captureOpts);
    root.addEventListener("mouseup", stopBlocking, captureOpts);
    root.addEventListener("keydown", stopBlocking, captureOpts);
    root.addEventListener("touchstart", stopBlocking, captureOpts);
    document.addEventListener("keydown", stopBlocking, captureOpts);
    let hubSettled = false;
    let hubLoadTimeoutId = null;
    const showCspFallback = (force = false) => {
      if (hubSettled && !force) {
        return;
      }
      hubSettled = true;
      if (hubLoadTimeoutId !== null) {
        clearTimeout(hubLoadTimeoutId);
        hubLoadTimeoutId = null;
      }
      iframe.hidden = true;
      iframe.setAttribute("aria-hidden", "true");
      fallbackList.hidden = false;
    };
    const onHubMessage = (event) => {
      if (hubSettled) {
        return;
      }
      if (!isTouchGrassHubReadyPing(event, hubOrigin)) {
        return;
      }
      hubSettled = true;
      if (hubLoadTimeoutId !== null) {
        clearTimeout(hubLoadTimeoutId);
        hubLoadTimeoutId = null;
      }
    };
    overlayHubMessageListener = onHubMessage;
    window.addEventListener("message", onHubMessage);
    iframe.addEventListener("error", () => {
      showCspFallback(true);
    });
    hubLoadTimeoutId = window.setTimeout(() => {
      hubLoadTimeoutId = null;
      if (!hubSettled) {
        showCspFallback();
      }
    }, HUB_IFRAME_LOAD_TIMEOUT_MS);
    let messageIndex = 0;
    let pendingFadeTimeout = null;
    const clearPendingFade = () => {
      if (pendingFadeTimeout !== null) {
        clearTimeout(pendingFadeTimeout);
        pendingFadeTimeout = null;
      }
    };
    const messageRotateIntervalId = window.setInterval(() => {
      if (!document.getElementById(LOCKDOWN_ROOT_ID) || !messageEl.isConnected) {
        clearInterval(messageRotateIntervalId);
        return;
      }
      messageIndex = (messageIndex + 1) % BREAK_MESSAGES.length;
      messageEl.style.opacity = "0";
      clearPendingFade();
      pendingFadeTimeout = window.setTimeout(() => {
        pendingFadeTimeout = null;
        if (!messageEl.isConnected) return;
        messageEl.textContent = BREAK_MESSAGES[messageIndex] ?? "";
        messageEl.style.opacity = "1";
      }, MESSAGE_FADE_SWAP_MS);
    }, MESSAGE_ROTATE_MS);
    let countdownIntervalId = null;
    const started = Date.now();
    const finish = () => {
      if (countdownIntervalId !== null) {
        clearInterval(countdownIntervalId);
        countdownIntervalId = null;
      }
      if (hubLoadTimeoutId !== null) {
        clearTimeout(hubLoadTimeoutId);
        hubLoadTimeoutId = null;
      }
      window.removeEventListener("message", onHubMessage);
      overlayHubMessageListener = null;
      clearInterval(messageRotateIntervalId);
      clearPendingFade();
      root.remove();
      document.removeEventListener("keydown", stopBlocking, captureOpts);
      blockBettingUI(false);
      overlayActive = false;
    };
    const tick = () => {
      const left = Math.max(0, durationMs - (Date.now() - started));
      const sec = Math.ceil(left / 1e3);
      timerWrap.textContent = `${sec}`;
      if (left <= 0) {
        finish();
      }
    };
    tick();
    countdownIntervalId = window.setInterval(tick, 250);
  }

  // apps/chrome-extension/src/core-options.ts
  var TILTCHECK_RISK_THRESHOLD_KEY = "tiltcheck_risk_threshold";
  var TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY = "tiltcheck_touch_grass_duration_ms";
  var TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY = "tiltcheck_touch_grass_cooldown_ms";
  var TILTCHECK_TOUCH_GRASS_OPT_IN_KEY = "tiltcheck_touch_grass_opt_in";
  var TILTCHECK_RISK_PROFILE_KEY = "tiltcheck_risk_profile";
  var TILTCHECK_HOURLY_WAGE_KEY = "tiltcheck_hourly_wage";
  var TILTCHECK_REALITY_HUD_ENABLED_KEY = "tiltcheck_reality_hud_enabled";
  var TILTCHECK_REALITY_THRESHOLD_HOURS_KEY = "tiltcheck_reality_threshold_hours";
  var TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY = "tiltcheck_deposit_barrier_enabled";
  var TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY = "tiltcheck_cooldown_active_until";
  var DEFAULT_RISK_PROFILE = "moderate";
  var CORE_CIRCUIT_BREAKER_STORAGE_KEYS = [
    TILTCHECK_RISK_THRESHOLD_KEY,
    TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
    TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
    TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
    TILTCHECK_RISK_PROFILE_KEY,
    TILTCHECK_HOURLY_WAGE_KEY,
    TILTCHECK_REALITY_HUD_ENABLED_KEY,
    TILTCHECK_REALITY_THRESHOLD_HOURS_KEY,
    TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY,
    TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY
  ];
  function normalizeRiskProfile(value, legacyRiskLevel) {
    if (value === "conservative" || value === "moderate" || value === "degen") {
      return value;
    }
    if (legacyRiskLevel === "conservative" || legacyRiskLevel === "moderate" || legacyRiskLevel === "degen") {
      return legacyRiskLevel;
    }
    return DEFAULT_RISK_PROFILE;
  }
  var DEFAULT_RISK_THRESHOLD = 85;
  var DEFAULT_TOUCH_GRASS_DURATION_MS = TOUCH_GRASS_DURATION_MS;
  var DEFAULT_TOUCH_GRASS_COOLDOWN_MS = DEFAULT_TOUCH_GRASS_DURATION_MS + 5e3;
  var DEFAULT_HOURLY_WAGE = 25;
  var MIN_HOURLY_WAGE = 5;
  var MAX_HOURLY_WAGE = 2e3;
  var DEFAULT_REALITY_HUD_ENABLED = true;
  var DEFAULT_REALITY_THRESHOLD_HOURS = 2;
  var MIN_REALITY_THRESHOLD_HOURS = 0.5;
  var MAX_REALITY_THRESHOLD_HOURS = 24;
  var DEFAULT_DEPOSIT_BARRIER_ENABLED = true;
  var MIN_RISK_THRESHOLD = 50;
  var MAX_RISK_THRESHOLD = 100;
  var MIN_DURATION_MS = 3e4;
  var MAX_DURATION_MS = 6e5;
  var MIN_COOLDOWN_MS = 3e4;
  var MAX_COOLDOWN_MS = 9e5;
  function clampInt(value, min, max, fallback) {
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, Math.round(n)));
  }
  function clampFloat(value, min, max, fallback) {
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return Math.min(max, Math.max(min, n));
  }
  async function loadCoreCircuitBreakerOptions() {
    try {
      const stored = await chrome.storage.local.get([
        TILTCHECK_RISK_THRESHOLD_KEY,
        TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
        TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
        TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
        TILTCHECK_RISK_PROFILE_KEY,
        TILTCHECK_HOURLY_WAGE_KEY,
        TILTCHECK_REALITY_HUD_ENABLED_KEY,
        TILTCHECK_REALITY_THRESHOLD_HOURS_KEY,
        TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY,
        TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY,
        "riskLevel"
      ]);
      const durationMs = clampInt(
        stored[TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY],
        MIN_DURATION_MS,
        MAX_DURATION_MS,
        DEFAULT_TOUCH_GRASS_DURATION_MS
      );
      const cooldownDefault = durationMs + 5e3;
      const cooldownMs = clampInt(
        stored[TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY],
        MIN_COOLDOWN_MS,
        MAX_COOLDOWN_MS,
        cooldownDefault
      );
      const optIn = stored[TILTCHECK_TOUCH_GRASS_OPT_IN_KEY];
      const enforcementEnabled = optIn === void 0 ? true : optIn === true;
      const hourlyWage = clampInt(
        stored[TILTCHECK_HOURLY_WAGE_KEY],
        MIN_HOURLY_WAGE,
        MAX_HOURLY_WAGE,
        DEFAULT_HOURLY_WAGE
      );
      const realityHudOpt = stored[TILTCHECK_REALITY_HUD_ENABLED_KEY];
      const realityHudEnabled = realityHudOpt === void 0 ? DEFAULT_REALITY_HUD_ENABLED : realityHudOpt === true;
      const realityThresholdHours = clampFloat(
        stored[TILTCHECK_REALITY_THRESHOLD_HOURS_KEY],
        MIN_REALITY_THRESHOLD_HOURS,
        MAX_REALITY_THRESHOLD_HOURS,
        DEFAULT_REALITY_THRESHOLD_HOURS
      );
      const depositBarrierOpt = stored[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY];
      const depositBarrierEnabled = depositBarrierOpt === void 0 ? DEFAULT_DEPOSIT_BARRIER_ENABLED : depositBarrierOpt === true;
      const cooldownActiveUntil = typeof stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY] === "number" && Number.isFinite(stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]) ? Math.max(0, stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY]) : 0;
      return {
        riskThreshold: clampInt(
          stored[TILTCHECK_RISK_THRESHOLD_KEY],
          MIN_RISK_THRESHOLD,
          MAX_RISK_THRESHOLD,
          DEFAULT_RISK_THRESHOLD
        ),
        touchGrassDurationMs: durationMs,
        touchGrassCooldownMs: Math.max(cooldownMs, durationMs + 1e3),
        riskProfile: normalizeRiskProfile(
          stored[TILTCHECK_RISK_PROFILE_KEY],
          stored["riskLevel"]
        ),
        enforcementEnabled,
        hourlyWage,
        realityHudEnabled,
        realityThresholdHours,
        depositBarrierEnabled,
        cooldownActiveUntil
      };
    } catch {
      return {
        riskThreshold: DEFAULT_RISK_THRESHOLD,
        touchGrassDurationMs: DEFAULT_TOUCH_GRASS_DURATION_MS,
        touchGrassCooldownMs: DEFAULT_TOUCH_GRASS_COOLDOWN_MS,
        riskProfile: DEFAULT_RISK_PROFILE,
        enforcementEnabled: true,
        hourlyWage: DEFAULT_HOURLY_WAGE,
        realityHudEnabled: DEFAULT_REALITY_HUD_ENABLED,
        realityThresholdHours: DEFAULT_REALITY_THRESHOLD_HOURS,
        depositBarrierEnabled: DEFAULT_DEPOSIT_BARRIER_ENABLED,
        cooldownActiveUntil: 0
      };
    }
  }

  // apps/chrome-extension/src/spin-pace-lock.ts
  var PACE_LOCK_MS = 2e3;
  var PACE_TICK_MS = 250;
  var PACE_TOAST_TEXT = "Pacing lock active. Let the last spin settle before firing again.";
  var PACE_HOST_ID = "tiltcheck-pace-host";
  var SPIN_CONTROL_SELECTOR = [
    'button[class*="bet"]',
    'button[class*="spin"]',
    '[data-action="bet"]',
    '[data-action="spin"]'
  ].join(", ");
  function installSpinPaceLock(doc = document) {
    let lockUntil = 0;
    let anchor = null;
    let tickId = null;
    let stopped = false;
    const priorDisabled = /* @__PURE__ */ new Map();
    const host = doc.createElement("div");
    host.id = PACE_HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const style = doc.createElement("style");
    style.textContent = `
    :host { position: fixed; inset: 0; z-index: 2147483646; pointer-events: none; }
    .chip {
      position: fixed;
      display: none;
      align-items: center;
      justify-content: center;
      pointer-events: auto;
      background: rgba(15, 17, 21, 0.88);
      color: #ffffff;
      font: 700 1.25rem ui-monospace, monospace;
    }
    .toast {
      position: fixed;
      display: none;
      left: 50%;
      top: 1rem;
      transform: translateX(-50%);
      max-width: 22rem;
      padding: 0.75rem 1rem;
      pointer-events: none;
      background: #0f1115;
      color: #ffffff;
      font: 600 0.875rem ui-monospace, monospace;
    }
  `;
    const chip = doc.createElement("div");
    chip.className = "chip";
    const toast = doc.createElement("div");
    toast.className = "toast";
    toast.textContent = PACE_TOAST_TEXT;
    shadow.append(style, chip, toast);
    doc.body.append(host);
    const matches = () => Array.from(doc.querySelectorAll(SPIN_CONTROL_SELECTOR));
    const showToast = () => {
      toast.style.display = "block";
    };
    const hideToast = () => {
      toast.style.display = "none";
    };
    const placeChip = (target) => {
      const rect = target.getBoundingClientRect();
      chip.style.display = "flex";
      chip.style.left = `${rect.left}px`;
      chip.style.top = `${rect.top}px`;
      chip.style.width = `${Math.max(rect.width, 48)}px`;
      chip.style.height = `${Math.max(rect.height, 32)}px`;
    };
    const release = () => {
      if (tickId !== null) {
        clearInterval(tickId);
        tickId = null;
      }
      for (const [button, wasDisabled] of priorDisabled) {
        button.disabled = wasDisabled;
      }
      priorDisabled.clear();
      chip.style.display = "none";
      hideToast();
      anchor = null;
      lockUntil = 0;
    };
    const applyLockVisuals = () => {
      const left = lockUntil - Date.now();
      if (left <= 0) {
        release();
        return;
      }
      chip.textContent = String(Math.ceil(left / 1e3));
      const current = matches();
      for (const el of current) {
        if (el instanceof HTMLButtonElement) {
          if (!priorDisabled.has(el)) {
            priorDisabled.set(el, el.disabled);
          }
          el.disabled = true;
        }
      }
      const liveAnchor = anchor && anchor.isConnected ? anchor : current[0] ?? null;
      anchor = liveAnchor;
      if (liveAnchor) {
        placeChip(liveAnchor);
      } else {
        chip.style.display = "none";
      }
    };
    const startLock = (spin) => {
      lockUntil = Date.now() + PACE_LOCK_MS;
      const connected = matches();
      anchor = spin.isConnected ? spin : connected[0] ?? null;
      hideToast();
      applyLockVisuals();
      if (tickId !== null) {
        clearInterval(tickId);
      }
      tickId = setInterval(applyLockVisuals, PACE_TICK_MS);
    };
    const swallow = (event) => {
      event.preventDefault();
      event.stopPropagation();
      showToast();
    };
    const onDocumentClick = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const spin = target.closest(SPIN_CONTROL_SELECTOR);
      if (!spin) return;
      if (Date.now() < lockUntil) {
        swallow(event);
        return;
      }
      if (spin instanceof HTMLButtonElement && !priorDisabled.has(spin)) {
        priorDisabled.set(spin, spin.disabled);
      }
      setTimeout(() => {
        if (stopped) return;
        startLock(spin);
      }, 0);
    };
    const onChipClick = (event) => {
      if (Date.now() >= lockUntil) return;
      swallow(event);
    };
    chip.addEventListener("click", onChipClick);
    doc.addEventListener("click", onDocumentClick, true);
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onDocumentClick, true);
      release();
      host.remove();
    };
    return {
      stop,
      lockUntil: () => lockUntil
    };
  }

  // apps/chrome-extension/src/presence-game-title.ts
  var AMOUNT_RE = /\$\s*\d|\d+\s*(usd|usdc|sol)\b|\b\d+(\.\d+)?x\b|\bheater\b|\bmultiplier\b/i;
  var WALLET_RE = /\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/;
  var URL_PATTERNS = [
    /\/casino\/slots\/([a-z0-9-]+)/i,
    /\/games?\/([a-z0-9-]+)/i,
    /\/slots?\/([a-z0-9-]+)/i,
    /\/play\/([a-z0-9-]+)/i
  ];
  function sanitizePresenceTitle(raw) {
    if (!raw) return null;
    const title = raw.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
    if (!title || AMOUNT_RE.test(title) || WALLET_RE.test(title)) return null;
    if (title === "unknown game") return null;
    return title;
  }
  function readPresenceGameTitle(loc = window.location, doc = document) {
    const pathname2 = loc.pathname;
    const href = loc.href;
    for (const pattern of URL_PATTERNS) {
      const match = pathname2.match(pattern) || href.match(pattern);
      if (match?.[1]) {
        return sanitizePresenceTitle(match[1]);
      }
    }
    const named = doc.querySelector('[data-game-name], .game-title, [class*="gameTitle"], [class*="gameName"]');
    if (named?.textContent) {
      return sanitizePresenceTitle(named.textContent);
    }
    return sanitizePresenceTitle(doc.title.split("|")[0] ?? null);
  }

  // apps/chrome-extension/src/lounge-overlay.ts
  var HOST_ID = "tiltcheck-lounge-host";
  var STORAGE_ID_KEY = "tiltcheck_lounge_user";
  var STORAGE_URL_KEY = "tiltcheck_lounge_url";
  function defaultLoungeUrl() {
    return "http://127.0.0.1:3004";
  }
  async function loungeBase() {
    const stored = await chrome.storage.local.get([STORAGE_URL_KEY]);
    const url = typeof stored[STORAGE_URL_KEY] === "string" ? stored[STORAGE_URL_KEY] : defaultLoungeUrl();
    return url.replace(/\/+$/, "");
  }
  async function identity() {
    const stored = await chrome.storage.local.get([STORAGE_ID_KEY, "userData"]);
    const userData = stored.userData;
    if (userData?.id && userData?.username) {
      return { userId: String(userData.id), username: String(userData.username).slice(0, 32) };
    }
    const row = stored[STORAGE_ID_KEY];
    if (row?.userId && row.username) return row;
    return null;
  }
  async function saveIdentity(user) {
    await chrome.storage.local.set({ [STORAGE_ID_KEY]: user });
  }
  function installLoungeOverlay(doc = document) {
    if (doc.getElementById(HOST_ID)) {
      return () => void 0;
    }
    const host = doc.createElement("div");
    host.id = HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });
    const style = doc.createElement("style");
    style.textContent = `
    :host { all: initial; }
    .panel {
      position: fixed; right: 12px; bottom: 12px; z-index: 2147483645;
      width: 18rem; max-height: 22rem; display: flex; flex-direction: column;
      background: #0f1115; color: #f3f6f8; border: 1px solid #2a3140;
      font: 12px/1.4 ui-monospace, monospace; pointer-events: auto;
    }
    .head { padding: 0.5rem 0.7rem; background: #17c3b2; color: #0f1115; font-weight: 700; }
    .tag { padding: 0.35rem 0.7rem; color: #17c3b2; }
    .log { flex: 1; overflow: auto; padding: 0.5rem 0.7rem; min-height: 7rem; }
    .who { padding: 0.35rem 0.7rem; border-top: 1px solid #2a3140; color: #9aa3b2; }
    form { display: flex; gap: 0.25rem; padding: 0.4rem; }
    input, button { font: inherit; border: 1px solid #2a3140; background: #1a1f29; color: inherit; padding: 0.35rem; }
    button { background: #17c3b2; color: #0f1115; font-weight: 700; }
    .foot { padding: 0.35rem 0.7rem 0.5rem; color: #5a6472; font-size: 10px; }
    .cards, .notice { padding: 0.35rem 0.7rem; color: #9aa3b2; font-size: 11px; }
    .notice { display: none; color: #17c3b2; }
    .flag { font: inherit; padding: 0.1rem 0.3rem; margin-left: 0.25rem; background: #17c3b2; color: #0f1115; border: 0; }
  `;
    const panel = doc.createElement("div");
    panel.className = "panel";
    panel.innerHTML = `
    <div class="head">Degen Lounge</div>
    <div class="tag"></div>
    <div class="notice" role="status"></div>
    <div class="log"></div>
    <div class="who"></div>
    <div class="cards"></div>
    <form class="gate"><input maxlength="32" value="jmenichole" placeholder="username" /><button type="submit">WALK IN</button></form>
    <form class="chat" hidden><input maxlength="500" placeholder="talk to the room. names are on." /><button type="submit">SEND</button></form>
    <div class="foot">Chat is named. Tips stay between you two. Made for Degens. By Degens.</div>
  `;
    shadow.append(style, panel);
    const log = panel.querySelector(".log");
    const who = panel.querySelector(".who");
    const tag = panel.querySelector(".tag");
    const cardsEl = panel.querySelector(".cards");
    const noticeEl = panel.querySelector(".notice");
    const gateForm = panel.querySelector("form.gate");
    const chatForm = panel.querySelector("form.chat");
    const handleInput = gateForm.querySelector("input");
    const chatInput = chatForm.querySelector("input");
    let timer = null;
    let stopped = false;
    const render = (state, me) => {
      tag.textContent = state.tagline;
      log.textContent = "";
      for (const msg of state.messages.slice(-40)) {
        const p = doc.createElement("p");
        p.textContent = `${msg.username}: ${msg.text}`;
        log.appendChild(p);
      }
      log.scrollTop = log.scrollHeight;
      who.textContent = "";
      for (const row of state.presence) {
        const span = doc.createElement("span");
        const game = row.gameTitle ? `, playing ${row.gameTitle}` : "";
        const away = row.awayMessage ? ` \u2014 ${row.awayMessage}` : "";
        const mine = row.userId === me.userId ? " (you)" : "";
        span.textContent = `${row.username}${mine} (${row.status}${game}${away})`;
        if (row.userId && row.userId !== me.userId) {
          const flag = doc.createElement("button");
          flag.type = "button";
          flag.className = "flag";
          flag.textContent = "breather";
          const tip = doc.createElement("button");
          tip.type = "button";
          tip.className = "flag";
          tip.textContent = "tip";
          tip.addEventListener("click", () => {
            void (async () => {
              const me2 = await identity();
              if (!me2) return;
              const amount = window.prompt(`Tip ${row.username} how much USD? Names stay between you two.`, "2.00");
              if (!amount) return;
              const base = await loungeBase();
              const res = await fetch(`${base}/lounge/tip`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ userId: me2.userId, username: me2.username, receiverId: row.userId, amountUsd: amount })
              });
              const view = await res.json();
              if (view.line) {
                noticeEl.style.display = "block";
                noticeEl.textContent = view.line;
              }
            })();
          });
          span.appendChild(tip);
          flag.addEventListener("click", () => {
            void (async () => {
              const base = await loungeBase();
              const me2 = await identity();
              if (!me2) return;
              await fetch(`${base}/lounge/flag`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  flaggerId: me2.userId,
                  targetId: row.userId,
                  accountAgeDays: 30,
                  reputationOk: true
                })
              });
            })();
          });
          span.appendChild(flag);
        }
        who.appendChild(span);
        who.appendChild(doc.createTextNode(" \xB7 "));
      }
    };
    const tick = async () => {
      if (stopped) return;
      try {
        const base = await loungeBase();
        const me = await identity();
        if (!me) {
          tag.textContent = "Pick a username. Chat is named. Tips stay private.";
          gateForm.hidden = false;
          chatForm.hidden = true;
          const res2 = await fetch(`${base}/lounge/state`);
          if (!res2.ok) throw new Error("lounge down");
          if (!host.isConnected && doc.body) {
            doc.body.append(host);
          }
          render(await res2.json(), { userId: "", username: "" });
          return;
        }
        gateForm.hidden = true;
        chatForm.hidden = false;
        await fetch(`${base}/lounge/join`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: me.userId,
            username: me.username,
            gameTitle: readPresenceGameTitle(),
            status: "online"
          })
        });
        const res = await fetch(`${base}/lounge/state`);
        if (!res.ok) throw new Error("lounge down");
        if (!host.isConnected && doc.body) {
          doc.body.append(host);
        }
        render(await res.json(), me);
        const [cardsRes, triviaRes, noticeRes] = await Promise.all([
          fetch(`${base}/lounge/scorecards`),
          fetch(`${base}/lounge/trivia`),
          fetch(`${base}/lounge/me/notice?userId=${encodeURIComponent(me.userId)}`)
        ]);
        const cards = cardsRes.ok ? await cardsRes.json() : { cards: [] };
        const trivia = triviaRes.ok ? await triviaRes.json() : {};
        const notice = noticeRes.ok ? await noticeRes.json() : { notice: null };
        cardsEl.textContent = [
          ...(cards.cards ?? []).map((card) => `${card.name}: ${card.payout}`),
          trivia.note ?? ""
        ].filter(Boolean).join(" \xB7 ");
        if (notice.notice?.copy) {
          noticeEl.style.display = "block";
          noticeEl.textContent = notice.notice.copy;
          const skip = doc.createElement("button");
          skip.type = "button";
          skip.className = "flag";
          skip.textContent = "Skip";
          skip.addEventListener("click", () => {
            noticeEl.style.display = "none";
          });
          noticeEl.appendChild(skip);
        }
      } catch {
        if (host.isConnected) {
          host.remove();
        }
      }
    };
    gateForm.addEventListener("submit", (event) => {
      event.preventDefault();
      void (async () => {
        const base = await loungeBase();
        const res = await fetch(`${base}/lounge/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ handle: handleInput.value })
        });
        const body = await res.json();
        if (body.user) {
          await saveIdentity(body.user);
          await tick();
        }
      })();
    });
    chatForm.addEventListener("submit", (event) => {
      event.preventDefault();
      void (async () => {
        const text = chatInput.value;
        chatInput.value = "";
        const base = await loungeBase();
        const me = await identity();
        if (!me) return;
        await fetch(`${base}/lounge/message`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: me.userId, username: me.username, text })
        });
        await tick();
      })();
    });
    void tick();
    timer = setInterval(() => {
      void tick();
    }, 3e3);
    return () => {
      stopped = true;
      if (timer) clearInterval(timer);
      if (host.isConnected) {
        host.remove();
      }
    };
  }

  // apps/chrome-extension/src/heater-nudge.ts
  var HEATER_TOAST_TEXT = "You're up right now. Lock half this win before the house claws it back. Skip anytime.";
  var HEATER_RATIO = 1.05;
  function detectHeater(previousBalance, nextBalance) {
    if (previousBalance == null || nextBalance == null) return false;
    if (previousBalance <= 0) return nextBalance > 0;
    return nextBalance / previousBalance >= HEATER_RATIO;
  }
  function installHeaterNudge(doc = document) {
    const host = doc.getElementById(PACE_HOST_ID);
    const shadow = host?.shadowRoot;
    if (!host || !shadow) {
      throw new Error("installHeaterNudge requires #tiltcheck-pace-host");
    }
    let previous = null;
    let armed = false;
    let stopped = false;
    const toast = doc.createElement("div");
    toast.className = "heater-toast";
    toast.setAttribute("role", "status");
    toast.style.cssText = "position:fixed;display:none;left:50%;bottom:4.5rem;transform:translateX(-50%);max-width:22rem;padding:0.75rem 1rem;background:#0f1115;color:#fff;font:600 0.875rem ui-monospace,monospace;z-index:2;pointer-events:auto;";
    toast.textContent = HEATER_TOAST_TEXT;
    const skip = doc.createElement("button");
    skip.type = "button";
    skip.textContent = "Skip";
    skip.style.cssText = "margin-left:0.5rem;font:inherit;background:#17c3b2;color:#0f1115;border:0;padding:0.2rem 0.5rem;";
    skip.addEventListener("click", () => {
      toast.style.display = "none";
      armed = false;
    });
    toast.appendChild(skip);
    shadow.append(toast);
    const onClick = (event) => {
      if (stopped) return;
      const target = event.target;
      if (!(target instanceof Element) || !target.closest(SPIN_CONTROL_SELECTOR)) return;
      const labeled = doc.querySelector('[data-balance], [class*="balance"]');
      const raw = labeled?.getAttribute("data-value") || labeled?.textContent;
      const next = raw ? Number(String(raw).replace(/[^0-9.]/g, "")) : null;
      if (detectHeater(previous, Number.isFinite(next) ? next : null)) {
        armed = true;
        toast.style.display = "block";
      }
      if (Number.isFinite(next)) previous = next;
    };
    doc.addEventListener("click", onClick, true);
    return {
      stop: () => {
        stopped = true;
        doc.removeEventListener("click", onClick, true);
        toast.remove();
      },
      armed: () => armed
    };
  }

  // apps/chrome-extension/src/extractor.ts
  var CASINO_SELECTORS = [
    {
      casinoId: "stake",
      domain: "stake.com",
      selectors: {
        betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
        winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
        balance: '[data-test="balance"], .balance, [class*="balance-value"]',
        symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
        bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
        freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
        gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
        gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
      }
    },
    {
      casinoId: "stake-us",
      domain: "stake.us",
      selectors: {
        betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
        winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
        balance: '[data-test="balance"], .balance, [class*="balance-value"]',
        symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
        bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
        freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
        gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
        gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
      }
    },
    // Stake mirror domains - same selectors as stake.com
    ...["stake.bet", "stake.games", "staketr.com", "staketr2.com", "staketr3.com", "staketr4.com", "stake.bz", "stake.pet"].map((domain) => ({
      casinoId: "stake",
      domain,
      selectors: {
        betAmount: '[data-test="bet-amount"], .bet-amount, [class*="betAmount"]',
        winAmount: '[data-test="win-amount"], .win-amount, [class*="winAmount"]',
        balance: '[data-test="balance"], .balance, [class*="balance-value"]',
        symbols: '.reel-symbol, [data-symbol], [class*="symbol"]',
        bonusIndicator: '.free-spins-active, [data-bonus="true"], [class*="freeSpins"]',
        freeSpinsCounter: '.free-spins-count, [class*="freeSpinsCount"]',
        gameTitle: '.game-title, [data-game-name], [class*="gameTitle"]',
        gameResult: '[data-test="dice-result"], .dice-result, [class*="resultValue"], .crash-payout'
      }
    })),
    {
      casinoId: "roobet",
      domain: "roobet.com",
      selectors: {
        betAmount: '.bet-input input, [name="bet"], [class*="betInput"]',
        winAmount: '.win-display, .payout-amount, [class*="winAmount"]',
        balance: '.user-balance, [class*="userBalance"], [class*="balance"]',
        symbols: '.slot-symbol, [class*="reelSymbol"]',
        bonusIndicator: '.bonus-round-active, [class*="bonusActive"]',
        gameResult: ".crash-payout, .multiplier-display"
      },
      extractors: {
        extractResult: (doc) => {
          const el = doc.querySelector(".crash-payout, .multiplier-display");
          if (!el || !el.textContent) return null;
          return parseFloat(el.textContent.replace(/x/i, "").trim());
        }
      }
    },
    {
      casinoId: "bc-game",
      domain: "bc.game",
      selectors: {
        betAmount: '[class*="betAmount"], [class*="bet-amount"], input[type="number"]',
        winAmount: '[class*="winAmount"], [class*="win-amount"], [class*="payout"]',
        balance: '[class*="balance"], [class*="userBalance"]',
        symbols: '[class*="symbol"], [class*="reel"]'
      }
    },
    {
      casinoId: "duelbits",
      domain: "duelbits.com",
      selectors: {
        betAmount: '.bet-value, [class*="betValue"], [class*="bet-amount"]',
        winAmount: '.win-value, [class*="winValue"], [class*="win-amount"]',
        balance: '[class*="balance"], .user-balance',
        symbols: '[data-reel] img, .reel-symbol, [class*="symbol"]'
      }
    },
    {
      casinoId: "rollbit",
      domain: "rollbit.com",
      selectors: {
        betAmount: '[class*="betInput"], [class*="bet-amount"], input[name="bet"]',
        winAmount: '[class*="winAmount"], [class*="payout"]',
        balance: '[class*="balance"], [class*="wallet"]',
        symbols: '[class*="symbol"], [class*="reel"]'
      }
    },
    {
      casinoId: "shuffle",
      domain: "shuffle.com",
      selectors: {
        betAmount: '[class*="bet"], input[type="number"]',
        winAmount: '[class*="win"], [class*="payout"]',
        balance: '[class*="balance"], [class*="wallet"]',
        symbols: '[class*="symbol"]'
      }
    },
    {
      casinoId: "gamdom",
      domain: "gamdom.com",
      selectors: {
        betAmount: '[class*="bet-amount"], [class*="betValue"]',
        winAmount: '[class*="win-amount"], [class*="winValue"]',
        balance: '[class*="balance"]',
        symbols: '[class*="symbol"]'
      }
    },
    {
      casinoId: "generic",
      domain: "*",
      selectors: {
        betAmount: '[data-bet], .bet, .bet-amount, input[name="bet"], [class*="betAmount"], [class*="bet-input"]',
        winAmount: '[data-win], .win, .win-amount, .payout, [class*="winAmount"], [class*="payout"]',
        balance: '[data-balance], .balance, .user-balance, [class*="balance"], [class*="wallet"]',
        symbols: '[data-symbol], .symbol, .reel-symbol, [class*="symbol"], [class*="reel"]',
        gameResult: "[data-result], .game-result, .result-value, .outcome"
      }
    }
  ];

  // apps/chrome-extension/src/chase-warning.ts
  var CHASE_SETTLE_MS = 5e3;
  var CHASE_TOAST_TEXT = "Last spin lost and you raised the stake. You're chasing, not on a heater. Step back.";
  var CHASE_POLL_MS = 250;
  function parseMoney(text) {
    if (text == null) return null;
    const tokens = text.split(/\s+/).map((token) => token.replace(/,/g, "").replace(/[^\d.-]/g, ""));
    const matches = tokens.filter((token) => /^-?\d+(\.\d+)?$/.test(token));
    if (matches.length !== 1) return null;
    return Number(matches[0]);
  }
  function readField(doc, field) {
    const hostname2 = doc.location.hostname;
    const entry = CASINO_SELECTORS.find((item) => hostname2.includes(item.domain) || item.domain === "*");
    const selector = entry?.selectors[field];
    if (!selector) return null;
    const element = doc.querySelector(selector);
    if (!element) return null;
    const raw = element.getAttribute("data-value") || element.getAttribute("value") || element.textContent;
    return parseMoney(raw);
  }
  function installChaseWarning(doc, lockUntil, onChaseEscalation) {
    const host = doc.getElementById(PACE_HOST_ID);
    const shadow = host?.shadowRoot;
    if (!host || !shadow) {
      throw new Error("installChaseWarning requires #tiltcheck-pace-host with an open shadow root");
    }
    const alreadyStyled = Array.from(shadow.querySelectorAll("style")).some(
      (style) => (style.textContent ?? "").includes(".chase-toast")
    );
    if (!alreadyStyled) {
      const style = doc.createElement("style");
      style.textContent = `
      .chase-toast {
        position: fixed;
        display: none;
        left: 50%;
        top: 4.5rem;
        transform: translateX(-50%);
        max-width: 22rem;
        padding: 0.75rem 1rem;
        pointer-events: none;
        background: #0f1115;
        color: #ffffff;
        font: 600 0.875rem ui-monospace, monospace;
      }
    `;
      shadow.append(style);
    }
    let toast = shadow.querySelector(".chase-toast");
    if (!toast) {
      toast = doc.createElement("div");
      toast.className = "chase-toast";
      toast.textContent = CHASE_TOAST_TEXT;
      toast.style.display = "none";
      shadow.append(toast);
    }
    let lastLosingStake = null;
    let pollId = null;
    let settleId = null;
    let stopped = false;
    const clearPoll = () => {
      if (pollId !== null) {
        clearInterval(pollId);
        pollId = null;
      }
      if (settleId !== null) {
        clearTimeout(settleId);
        settleId = null;
      }
    };
    const watchBalance = (stake, baseline) => {
      clearPoll();
      const startedAt = Date.now();
      const finish = (next) => {
        if (stopped) return;
        if (next !== null && next !== baseline) {
          if (next < baseline) {
            lastLosingStake = stake;
          } else {
            lastLosingStake = null;
            toast.style.display = "none";
          }
          clearPoll();
          return;
        }
        if (Date.now() - startedAt >= CHASE_SETTLE_MS) {
          clearPoll();
        }
      };
      pollId = setInterval(() => {
        finish(readField(doc, "balance"));
      }, CHASE_POLL_MS);
      settleId = setTimeout(() => {
        if (stopped) return;
        clearPoll();
      }, CHASE_SETTLE_MS);
    };
    const onClick = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (!target.closest(SPIN_CONTROL_SELECTOR)) return;
      if (Date.now() < lockUntil()) return;
      const stake = readField(doc, "betAmount");
      const balance = readField(doc, "balance");
      if (stake === null || balance === null) return;
      if (typeof lastLosingStake === "number" && stake > lastLosingStake) {
        toast.style.display = "block";
        onChaseEscalation?.(stake, lastLosingStake);
      }
      watchBalance(stake, balance);
    };
    doc.addEventListener("click", onClick, true);
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onClick, true);
      clearPoll();
      toast.style.display = "none";
    };
    return {
      stop,
      lastLosingStake: () => lastLosingStake
    };
  }

  // packages/types/src/index.ts
  var GAME_EXCLUSION_CATEGORIES = [
    "chicken_mines",
    "bonus_buy",
    "live_dealer",
    "slots",
    "crash",
    "table_games"
  ];

  // apps/chrome-extension/src/exclusion-taxonomy.ts
  var CATEGORY_KEYWORDS = {
    chicken_mines: ["chicken", "mines", "minefield", "chicken-road", "chickenroad"],
    bonus_buy: ["bonus-buy", "bonusbuy", "feature-buy", "featurebuy"],
    live_dealer: ["live-dealer", "live-casino", "live_dealer", "livecasino"],
    slots: ["slot", "slots"],
    crash: ["crash", "aviator", "jetx", "spaceman"],
    table_games: ["blackjack", "roulette", "baccarat", "poker", "table"]
  };
  function matchExclusion(haystack, slugs, categories) {
    const lower = haystack.toLowerCase();
    if (!lower.trim()) return null;
    for (const category of categories) {
      const keywords = CATEGORY_KEYWORDS[category] ?? [];
      if (keywords.some((keyword) => lower.includes(keyword))) {
        return { kind: "category", value: category };
      }
    }
    for (const slug of slugs) {
      const needle = slug.trim().toLowerCase();
      if (needle.length >= 2 && lower.includes(needle)) {
        return { kind: "slug", value: slug };
      }
    }
    return null;
  }
  function haystackFromLocation(loc) {
    return `${loc.pathname}${loc.search}${loc.href ?? ""}`.toLowerCase();
  }
  function haystackFromElement(el) {
    const card = el.closest('a, button, [role="button"], [data-game-id], [data-game-name], [data-game], article, li');
    const node = card ?? el;
    return [
      node.getAttribute("href"),
      node.getAttribute("src"),
      node.getAttribute("data-game-id"),
      node.getAttribute("data-game-name"),
      node.getAttribute("data-game"),
      node.getAttribute("data-testid"),
      node.textContent
    ].filter(Boolean).join(" ").toLowerCase();
  }

  // apps/chrome-extension/src/pro/blocked-games-options.ts
  var TILTCHECK_BLOCKED_GAMES_KEY = "tiltcheck_blocked_games";
  var TILTCHECK_BLOCKED_CATEGORIES_KEY = "tiltcheck_blocked_categories";
  var TILTCHECK_GAME_BLOCK_OPT_IN_KEY = "tiltcheck_game_block_opt_in";
  var MAX_BLOCKED_ENTRIES = 64;
  var MAX_SLUG_LENGTH = 48;
  function normalizeBlockedGameSlug(value) {
    if (typeof value !== "string") return null;
    const slug = value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    if (!slug || slug.length > MAX_SLUG_LENGTH) return null;
    return slug;
  }
  function normalizeBlockedGamesList(raw) {
    if (!Array.isArray(raw)) return [];
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of raw) {
      const slug = normalizeBlockedGameSlug(item);
      if (!slug || seen.has(slug)) continue;
      seen.add(slug);
      out.push(slug);
      if (out.length >= MAX_BLOCKED_ENTRIES) break;
    }
    return out;
  }
  async function loadBlockedGameSlugs() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_GAMES_KEY);
      return normalizeBlockedGamesList(stored[TILTCHECK_BLOCKED_GAMES_KEY]);
    } catch {
      return [];
    }
  }
  function normalizeBlockedCategories(raw) {
    if (!Array.isArray(raw)) return [];
    const allowed = new Set(GAME_EXCLUSION_CATEGORIES);
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of raw) {
      if (typeof item !== "string" || !allowed.has(item) || seen.has(item)) continue;
      seen.add(item);
      out.push(item);
    }
    return out;
  }
  async function loadBlockedCategories() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_BLOCKED_CATEGORIES_KEY);
      return normalizeBlockedCategories(stored[TILTCHECK_BLOCKED_CATEGORIES_KEY]);
    } catch {
      return [];
    }
  }
  async function loadGameBlockOptIn() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_GAME_BLOCK_OPT_IN_KEY);
      return stored[TILTCHECK_GAME_BLOCK_OPT_IN_KEY] === true;
    } catch {
      return false;
    }
  }

  // apps/chrome-extension/src/pro/containment.ts
  var TILTCHECK_SAFETY_ROOT_IDS = [
    "tiltcheck-lockdown-root",
    "tiltcheck-local-game-block-overlay",
    "tiltcheck-cooldown-overlay",
    "tiltcheck-game-block-overlay",
    "tiltcheck-redeem-nudge",
    "tiltcheck-sidebar",
    "tiltcheck-mobile-license-hud"
  ];
  function isInsideTiltcheckSafetyRoot(node) {
    if (!node || typeof Element === "undefined" || !(node instanceof Element)) {
      return false;
    }
    for (const id of TILTCHECK_SAFETY_ROOT_IDS) {
      if (node.closest(`#${id}`)) {
        return true;
      }
    }
    return false;
  }
  function mutationsOnlyTouchSafetyRoots(mutations) {
    const nodes = [];
    for (const m of mutations) {
      for (const n of m.addedNodes) {
        nodes.push(n);
      }
      if (m.target) {
        nodes.push(m.target);
      }
    }
    if (nodes.length === 0) {
      return false;
    }
    return nodes.every((n) => {
      if (typeof Element === "undefined" || !(n instanceof Element)) {
        return true;
      }
      return isInsideTiltcheckSafetyRoot(n);
    });
  }

  // apps/chrome-extension/src/pro/local-game-blocker.ts
  var LOCAL_OVERLAY_ID = "tiltcheck-local-game-block-overlay";
  var SANITIZED_ATTR = "data-tiltcheck-local-blocked";
  var PLACEHOLDER_LABEL = "[ GAME EXCLUDED ]";
  var installed = null;
  function installLocalGameBlocker(doc = document) {
    if (installed) return installed;
    installed = new LocalGameBlocker(doc);
    void installed.init();
    return installed;
  }
  var LocalGameBlocker = class {
    blockedSlugs = [];
    blockedCategories = [];
    enforcementEnabled = false;
    observer = null;
    scanScheduled = false;
    storageListenerAttached = false;
    clickBound = false;
    doc;
    constructor(doc = document) {
      this.doc = doc;
    }
    onBlockedPointer = (event) => {
      if (!this.enforcementEnabled) return;
      if (this.blockedSlugs.length === 0 && this.blockedCategories.length === 0) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (isInsideTiltcheckSafetyRoot(target)) return;
      const hit = matchExclusion(haystackFromElement(target), this.blockedSlugs, this.blockedCategories);
      if (!hit) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const card = target.closest('a, button, [role="button"], article, li, div');
      if (card instanceof HTMLElement) {
        this.sanitizeNode(card, hit.value);
      }
    };
    handleStorageChange = (changes, area) => {
      if (area !== "local") return;
      if (changes[TILTCHECK_BLOCKED_GAMES_KEY] || changes[TILTCHECK_BLOCKED_CATEGORIES_KEY] || changes[TILTCHECK_GAME_BLOCK_OPT_IN_KEY]) {
        void this.reloadAndScan();
      }
    };
    async init() {
      await this.reloadAndScan();
      this.startObserver();
      this.attachStorageListener();
      this.attachClickGuard();
    }
    resume(_source = "navigation") {
      void this.reloadAndScan();
    }
    destroy() {
      this.observer?.disconnect();
      this.observer = null;
      if (this.storageListenerAttached) {
        try {
          chrome.storage.onChanged.removeListener(this.handleStorageChange);
        } catch {
        }
        this.storageListenerAttached = false;
      }
      this.removeUrlOverlay();
      this.detachClickGuard();
      if (installed === this) installed = null;
    }
    attachStorageListener() {
      if (this.storageListenerAttached) return;
      try {
        chrome.storage.onChanged.addListener(this.handleStorageChange);
        this.storageListenerAttached = true;
      } catch {
      }
    }
    async reloadAndScan() {
      this.enforcementEnabled = await loadGameBlockOptIn();
      this.blockedSlugs = this.enforcementEnabled ? await loadBlockedGameSlugs() : [];
      this.blockedCategories = this.enforcementEnabled ? await loadBlockedCategories() : [];
      this.scan();
    }
    scheduleScan() {
      if (this.scanScheduled) return;
      this.scanScheduled = true;
      const run = () => {
        this.scanScheduled = false;
        this.scan();
      };
      if (typeof requestAnimationFrame === "function") {
        requestAnimationFrame(run);
      } else {
        setTimeout(run, 0);
      }
    }
    scan() {
      if (this.blockedSlugs.length === 0 && this.blockedCategories.length === 0) {
        this.removeUrlOverlay();
        return;
      }
      const urlHit = this.matchHref(window.location.href);
      if (urlHit) {
        this.injectUrlOverlay(urlHit.value);
        return;
      }
      this.removeUrlOverlay();
      this.redactDomMatches();
    }
    /** Returns matched slug/category when URL path/search references a blocked game. */
    matchUrl(href, slugs = this.blockedSlugs, categories = this.blockedCategories) {
      return this.matchHref(href, slugs, categories)?.value ?? null;
    }
    matchHref(href, slugs = this.blockedSlugs, categories = this.blockedCategories) {
      let loc = { pathname: href, search: "", href };
      try {
        const parsed = new URL(href, window.location.origin);
        loc = { pathname: parsed.pathname, search: parsed.search, href: parsed.href };
      } catch {
      }
      return matchExclusion(haystackFromLocation(loc), slugs, categories);
    }
    redactDomMatches() {
      const nodesByKey = this.collectBlockedNodes();
      for (const [key, nodes] of nodesByKey) {
        for (const node of nodes) {
          this.sanitizeNode(node, key);
        }
      }
    }
    /** Single-pass DOM scan: map each blocked slug/category to nodes that reference it. */
    collectBlockedNodes() {
      const buckets = /* @__PURE__ */ new Map();
      const tryAdd = (el, key) => {
        if (!el || !(el instanceof HTMLElement)) return;
        if (isInsideTiltcheckSafetyRoot(el)) return;
        if (el.closest(`#${LOCAL_OVERLAY_ID}`)) return;
        const card = el.closest('a, button, [role="button"], article, li, div');
        if (!buckets.has(key)) buckets.set(key, /* @__PURE__ */ new Set());
        buckets.get(key)?.add(card ?? el);
      };
      const consider = (el) => {
        const hit = matchExclusion(haystackFromElement(el), this.blockedSlugs, this.blockedCategories);
        if (hit) tryAdd(el, hit.value);
      };
      for (const anchor of this.doc.querySelectorAll("a[href]")) {
        consider(anchor);
      }
      for (const el of this.doc.querySelectorAll(
        'button, [role="button"], [data-game-name], [data-game-id], [data-game], [data-testid*="game"]'
      )) {
        consider(el);
      }
      const result = /* @__PURE__ */ new Map();
      for (const [key, set] of buckets) {
        if (set.size > 0) {
          result.set(key, [...set]);
        }
      }
      return result;
    }
    attachClickGuard() {
      if (this.clickBound) return;
      this.doc.addEventListener("click", this.onBlockedPointer, true);
      this.doc.addEventListener("pointerdown", this.onBlockedPointer, true);
      this.clickBound = true;
    }
    detachClickGuard() {
      if (!this.clickBound) return;
      this.doc.removeEventListener("click", this.onBlockedPointer, true);
      this.doc.removeEventListener("pointerdown", this.onBlockedPointer, true);
      this.clickBound = false;
    }
    disableInteractiveTarget(target) {
      target.style.pointerEvents = "none";
      if (target instanceof HTMLButtonElement) {
        target.disabled = true;
      }
      if (target.getAttribute("role") === "button") {
        target.setAttribute("aria-disabled", "true");
        target.tabIndex = -1;
      }
    }
    sanitizeNode(target, slug) {
      if (target.getAttribute(SANITIZED_ATTR) === slug) return;
      const placeholder = document.createElement("div");
      placeholder.setAttribute(SANITIZED_ATTR, slug);
      placeholder.setAttribute("aria-label", `Game excluded: ${slug}`);
      placeholder.style.cssText = `
      background: #1a1d24;
      color: #ff4a4a;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 72px;
      height: 100%;
      width: 100%;
      font-family: ui-monospace, monospace;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      border: 1px dashed #ff4a4a;
      border-radius: 4px;
      box-sizing: border-box;
      pointer-events: none;
      user-select: none;
    `;
      placeholder.textContent = PLACEHOLDER_LABEL;
      if (target.tagName === "A") {
        const wrap = document.createElement("div");
        wrap.setAttribute(SANITIZED_ATTR, slug);
        wrap.style.pointerEvents = "none";
        wrap.appendChild(placeholder);
        target.replaceChildren(wrap);
        target.removeAttribute("href");
        this.disableInteractiveTarget(target);
        target.setAttribute(SANITIZED_ATTR, slug);
        return;
      }
      target.replaceChildren(placeholder);
      this.disableInteractiveTarget(target);
      target.setAttribute(SANITIZED_ATTR, slug);
    }
    injectUrlOverlay(slug) {
      if (document.getElementById(LOCAL_OVERLAY_ID)) return;
      const overlay = document.createElement("div");
      overlay.id = LOCAL_OVERLAY_ID;
      overlay.setAttribute("role", "dialog");
      overlay.setAttribute("aria-modal", "true");
      overlay.setAttribute("aria-label", `Access denied: ${slug} is on your exclusion list`);
      Object.assign(overlay.style, {
        position: "fixed",
        inset: "0",
        zIndex: "2147483646",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(10, 12, 16, 0.97)",
        fontFamily: "ui-monospace, monospace",
        color: "#f5f5f5",
        padding: "24px",
        boxSizing: "border-box"
      });
      overlay.innerHTML = `
      <div style="max-width: 420px; text-align: center; border: 1px solid #333; border-radius: 12px; padding: 32px 24px; background: #111;">
        <div style="color: #ff4a4a; font-size: 11px; font-weight: 800; letter-spacing: 0.2em; margin-bottom: 12px;">STRATEGIC FILTER</div>
        <h2 style="margin: 0 0 12px; font-size: 22px; font-weight: 900; color: #fff;">Access denied.</h2>
        <p style="margin: 0 0 8px; font-size: 14px; line-height: 1.5; color: #aaa;">
          <strong style="color: #ff4a4a;">${slug}</strong> is on your local exclusion list.
        </p>
        <p style="margin: 0 0 20px; font-size: 12px; line-height: 1.45; color: #666;">
          You put this on your list. It does not click. Edit the list in the extension Guards tab.
        </p>
        <button type="button" id="tiltcheck-local-block-back" style="
          background: transparent;
          border: 1px solid #444;
          color: #ccc;
          padding: 10px 18px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          text-transform: uppercase;
          letter-spacing: 0.06em;
        ">Go back</button>
        <footer style="margin-top: 20px; font-size: 10px; color: #444;">Made for Degens. By Degens.</footer>
      </div>
    `;
      document.body.appendChild(overlay);
      document.getElementById("tiltcheck-local-block-back")?.addEventListener("click", () => {
        if (window.history.length > 1) {
          window.history.back();
        } else {
          window.location.assign("/");
        }
      });
    }
    removeUrlOverlay() {
      document.getElementById(LOCAL_OVERLAY_ID)?.remove();
    }
    startObserver() {
      if (!this.doc.body) return;
      this.observer = new MutationObserver((mutations) => {
        if (mutationsOnlyTouchSafetyRoots(mutations)) {
          return;
        }
        this.scheduleScan();
      });
      this.observer.observe(this.doc.body, { childList: true, subtree: true });
    }
  };

  // apps/chrome-extension/src/reality-hud.ts
  var DEFAULT_HOURLY_WAGE2 = 25;
  var MIN_HOURLY_WAGE2 = 5;
  var MAX_HOURLY_WAGE2 = 2e3;
  var DEFAULT_REALITY_HUD_ENABLED2 = true;
  var DEFAULT_REALITY_THRESHOLD_HOURS2 = 2;
  var MIN_REALITY_THRESHOLD_HOURS2 = 0.5;
  var MAX_REALITY_THRESHOLD_HOURS2 = 24;
  var REALITY_HUD_ID = "tiltcheck-reality-hud";
  var REALITY_HUD_POLL_MS = 1e3;
  function clampHourlyWage(val) {
    const n = typeof val === "number" ? val : Number(val);
    if (!Number.isFinite(n)) return DEFAULT_HOURLY_WAGE2;
    return Math.min(MAX_HOURLY_WAGE2, Math.max(MIN_HOURLY_WAGE2, Math.round(n)));
  }
  function clampThresholdHours(val) {
    const n = typeof val === "number" ? val : Number(val);
    if (!Number.isFinite(n) || n <= 0) return DEFAULT_REALITY_THRESHOLD_HOURS2;
    return Math.min(MAX_REALITY_THRESHOLD_HOURS2, Math.max(MIN_REALITY_THRESHOLD_HOURS2, n));
  }
  function computeWageEquivalence(drawdown, hourlyWage) {
    if (drawdown <= 0 || hourlyWage <= 0) {
      return 0;
    }
    return drawdown / hourlyWage;
  }
  function formatRealityMessage(drawdown, hours) {
    const absDrawdown = Math.abs(drawdown);
    if (hours >= 8) {
      return `Session Drawdown: -$${absDrawdown.toFixed(2)} (${hours.toFixed(1)} hrs of labor torched). That's a full shift gone. Step away.`;
    }
    return `Session Drawdown: -$${absDrawdown.toFixed(2)} (${hours.toFixed(1)} hrs of work torched). Step back.`;
  }
  function parseMoney2(text) {
    if (text == null) return null;
    const tokens = text.split(/\s+/).map((token) => token.replace(/,/g, "").replace(/[^\d.-]/g, ""));
    const matches = tokens.filter((token) => /^-?\d+(\.\d+)?$/.test(token));
    if (matches.length !== 1) return null;
    return Number(matches[0]);
  }
  function readBalance(doc) {
    const hostname2 = doc.location?.hostname ?? "";
    const entry = CASINO_SELECTORS.find(
      (item) => hostname2 && hostname2.includes(item.domain) || item.domain === "*"
    );
    const selector = entry?.selectors?.balance;
    if (selector) {
      const elements = doc.querySelectorAll(selector);
      for (const el of elements) {
        const raw = el.getAttribute("data-value") || el.getAttribute("value") || el.textContent;
        const parsed = parseMoney2(raw);
        if (parsed !== null) return parsed;
      }
    }
    const fallbackElements = doc.querySelectorAll('[data-balance], [data-test="balance"], .balance, [class*="balance-value"], [class*="balance"]');
    for (const fallback of fallbackElements) {
      const raw = fallback.getAttribute("data-value") || fallback.getAttribute("value") || fallback.textContent;
      const parsed = parseMoney2(raw);
      if (parsed !== null) return parsed;
    }
    return null;
  }
  function installRealityHud(doc, options) {
    let opts = {
      hourlyWage: clampHourlyWage(options?.hourlyWage ?? DEFAULT_HOURLY_WAGE2),
      enabled: options?.enabled ?? DEFAULT_REALITY_HUD_ENABLED2,
      thresholdHours: clampThresholdHours(options?.thresholdHours ?? DEFAULT_REALITY_THRESHOLD_HOURS2)
    };
    let baselineBalance = null;
    let lastCurrentBalance = null;
    let dismissed = false;
    let lastDismissedDrawdown = 0;
    let stopped = false;
    let pollId = null;
    const removeHud = () => {
      const existing = doc.getElementById(REALITY_HUD_ID);
      if (existing) {
        existing.remove();
      }
    };
    const isVisible = () => {
      const el = doc.getElementById(REALITY_HUD_ID);
      return Boolean(el && el.style.display !== "none" && el.isConnected);
    };
    const dismiss = () => {
      dismissed = true;
      const el = doc.getElementById(REALITY_HUD_ID);
      if (el) {
        el.style.display = "none";
      }
    };
    const renderOrUpdateHud = (drawdown, hours) => {
      let hud = doc.getElementById(REALITY_HUD_ID);
      const message = formatRealityMessage(drawdown, hours);
      if (!hud) {
        hud = doc.createElement("div");
        hud.id = REALITY_HUD_ID;
        hud.setAttribute("role", "status");
        hud.setAttribute("aria-live", "polite");
        hud.style.cssText = [
          "position: fixed",
          "top: 1rem",
          "left: 50%",
          "transform: translateX(-50%)",
          "z-index: 2147483646",
          "background: #0f1115",
          "border: 1px solid #ff4a4a",
          "border-radius: 6px",
          "color: #ffffff",
          'font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace',
          "font-size: 0.875rem",
          "font-weight: 600",
          "padding: 0.75rem 1rem",
          "display: flex",
          "align-items: center",
          "gap: 0.75rem",
          "box-shadow: 0 4px 20px rgba(0, 0, 0, 0.7)",
          "max-width: 90vw",
          "box-sizing: border-box",
          "pointer-events: auto"
        ].join(";");
        const textSpan = doc.createElement("span");
        textSpan.className = "tiltcheck-reality-hud-text";
        textSpan.textContent = message;
        const dismissBtn = doc.createElement("button");
        dismissBtn.type = "button";
        dismissBtn.className = "tiltcheck-reality-hud-dismiss";
        dismissBtn.setAttribute("aria-label", "Dismiss reality HUD");
        dismissBtn.textContent = "x";
        dismissBtn.style.cssText = [
          "background: transparent",
          "border: none",
          "color: #ff4a4a",
          "font-family: inherit",
          "font-size: 1rem",
          "font-weight: bold",
          "cursor: pointer",
          "padding: 0 4px",
          "line-height: 1"
        ].join(";");
        dismissBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          lastDismissedDrawdown = drawdown;
          dismiss();
        });
        hud.appendChild(textSpan);
        hud.appendChild(dismissBtn);
        (doc.body ?? doc.documentElement).appendChild(hud);
      } else {
        const textSpan = hud.querySelector(".tiltcheck-reality-hud-text");
        if (textSpan) {
          textSpan.textContent = message;
        }
        hud.style.display = "flex";
      }
    };
    const check = (balanceOverride) => {
      if (stopped || !opts.enabled) {
        removeHud();
        return;
      }
      const currentBalance = typeof balanceOverride === "number" ? balanceOverride : readBalance(doc) ?? lastCurrentBalance;
      if (currentBalance === null || !Number.isFinite(currentBalance)) {
        return;
      }
      lastCurrentBalance = currentBalance;
      if (baselineBalance === null) {
        baselineBalance = currentBalance;
        return;
      }
      if (currentBalance > baselineBalance) {
        baselineBalance = currentBalance;
        dismissed = false;
        removeHud();
        return;
      }
      const drawdown = baselineBalance - currentBalance;
      const hours = computeWageEquivalence(drawdown, opts.hourlyWage);
      if (drawdown <= 0 || hours < opts.thresholdHours) {
        removeHud();
        return;
      }
      if (dismissed) {
        if (drawdown >= lastDismissedDrawdown + opts.hourlyWage) {
          dismissed = false;
        } else {
          return;
        }
      }
      renderOrUpdateHud(drawdown, hours);
    };
    const onClickCapture = () => {
      check();
    };
    doc.addEventListener("click", onClickCapture, true);
    pollId = setInterval(() => check(), REALITY_HUD_POLL_MS);
    check();
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onClickCapture, true);
      if (pollId !== null) {
        clearInterval(pollId);
        pollId = null;
      }
      removeHud();
    };
    const updateOptions = (newOpts) => {
      if (newOpts.hourlyWage !== void 0) {
        opts.hourlyWage = clampHourlyWage(newOpts.hourlyWage);
      }
      if (newOpts.enabled !== void 0) {
        opts.enabled = newOpts.enabled;
      }
      if (newOpts.thresholdHours !== void 0) {
        opts.thresholdHours = clampThresholdHours(newOpts.thresholdHours);
      }
      check(lastCurrentBalance ?? void 0);
    };
    return {
      stop,
      check,
      getBaseline: () => baselineBalance,
      setBaseline: (b) => {
        baselineBalance = b;
        dismissed = false;
        check(lastCurrentBalance ?? void 0);
      },
      isVisible,
      dismiss,
      getOptions: () => ({ ...opts }),
      updateOptions
    };
  }

  // apps/chrome-extension/src/deposit-barrier.ts
  var TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2 = "tiltcheck_cooldown_active_until";
  var TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2 = "tiltcheck_deposit_barrier_enabled";
  var ALERT_ID = "tiltcheck-deposit-barrier-alert";
  var ALERT_DISMISS_MS = 4e3;
  var DEPOSIT_SELECTORS = [
    '[data-test="cashier-button"]',
    '[data-testid="cashier-button"]',
    '[data-test="wallet-button"]',
    '[data-testid="wallet-button"]',
    'button[data-testid="cashier-btn"]',
    '[data-testid="deposit-button"]',
    ".wallet-btn",
    'button[data-test="deposit"]',
    '[data-test="deposit-button"]'
  ];
  var ADDITIONAL_DEPOSIT_SELECTORS = [
    'a[href*="/deposit"]',
    'a[href*="/cashier"]',
    '[data-action="deposit"]',
    '[data-action="cashier"]'
  ];
  var DEPOSIT_TEXT_REGEX = /\b(deposit|cashier|add\s+funds|buy\s+crypto|buy\s+coins|wallet|top\s+up|deposito|depósito|dépôt|einzahlen|recharger|recargar)\b/i;
  var EXCLUDED_TEXT_REGEX = /\b(withdraw|withdrawal|redeem|redemption|vault|tip|send|transfer|history|statement|retirer|auszahlung|retirada)\b/i;
  var inMemoryCooldownActiveUntil = 0;
  var inMemoryBarrierEnabled = true;
  function getCooldownActiveUntil() {
    return inMemoryCooldownActiveUntil;
  }
  async function loadCooldownActiveUntil() {
    try {
      const stored = await chrome.storage.local.get([
        TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2,
        TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2
      ]);
      const val = stored[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2];
      if (typeof val === "number" && Number.isFinite(val)) {
        inMemoryCooldownActiveUntil = Math.max(0, val);
      }
      const enabledVal = stored[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2];
      if (typeof enabledVal === "boolean") {
        inMemoryBarrierEnabled = enabledVal;
      }
    } catch {
    }
    return inMemoryCooldownActiveUntil;
  }
  function isDepositBarrierActive(now) {
    if (!inMemoryBarrierEnabled) {
      return false;
    }
    if (isTouchGrassActive()) {
      return true;
    }
    const currentTime = now ?? Date.now();
    return inMemoryCooldownActiveUntil > currentTime;
  }
  function isDepositTarget(target) {
    const container = target.closest(
      'button, a, [role="button"], input[type="submit"], input[type="button"], ' + DEPOSIT_SELECTORS.join(", ")
    ) ?? target;
    const textContent = (container.textContent ?? "") + " " + (container.getAttribute("aria-label") ?? "") + " " + (container.getAttribute("title") ?? "") + " " + (container.getAttribute("value") ?? "");
    const attrContent = (container.getAttribute("href") ?? "") + " " + (container.getAttribute("data-action") ?? "");
    if (EXCLUDED_TEXT_REGEX.test(textContent) || EXCLUDED_TEXT_REGEX.test(attrContent)) {
      return false;
    }
    for (const selector of DEPOSIT_SELECTORS) {
      if (target.matches(selector) || target.closest(selector) !== null) {
        return true;
      }
    }
    for (const selector of ADDITIONAL_DEPOSIT_SELECTORS) {
      if (target.matches(selector) || target.closest(selector) !== null) {
        return true;
      }
    }
    if (DEPOSIT_TEXT_REGEX.test(textContent) || DEPOSIT_TEXT_REGEX.test(attrContent)) {
      return true;
    }
    return false;
  }
  function installDepositBarrier(doc = document) {
    void loadCooldownActiveUntil();
    let alertTimeoutId = null;
    let stopped = false;
    const showAlert = (message) => {
      let alertEl = doc.getElementById(ALERT_ID);
      if (!alertEl) {
        alertEl = doc.createElement("div");
        alertEl.id = ALERT_ID;
        alertEl.setAttribute("role", "alert");
        alertEl.setAttribute("aria-live", "assertive");
        alertEl.style.cssText = [
          "position: fixed",
          "top: 1.5rem",
          "left: 50%",
          "transform: translateX(-50%)",
          "z-index: 2147483647",
          "background: #0f1115",
          "border: 2px solid #ff4a4a",
          "border-radius: 6px",
          "color: #ffffff",
          "padding: 0.85rem 1.25rem",
          'font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace',
          "font-size: 0.875rem",
          "font-weight: 700",
          "box-shadow: 0 4px 24px rgba(0, 0, 0, 0.85)",
          "text-align: center",
          "pointer-events: none",
          "max-width: 90vw",
          "box-sizing: border-box"
        ].join(";");
        (doc.body ?? doc.documentElement).appendChild(alertEl);
      }
      alertEl.textContent = message;
      if (alertTimeoutId !== null) {
        clearTimeout(alertTimeoutId);
        alertTimeoutId = null;
      }
      alertTimeoutId = setTimeout(() => {
        alertTimeoutId = null;
        alertEl?.remove();
      }, ALERT_DISMISS_MS);
    };
    const onClickCapture = (event) => {
      if (stopped) return;
      const now = Date.now();
      if (!isDepositBarrierActive(now)) {
        return;
      }
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      if (!isDepositTarget(target)) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const cooldownUntil = getCooldownActiveUntil();
      let message;
      if (cooldownUntil > now) {
        const remainingMins = Math.max(1, Math.ceil((cooldownUntil - now) / 6e4));
        message = `Deposit Barrier Active: Voluntary lock engaged (${remainingMins}m remaining). Don't reload. Step away.`;
      } else {
        message = "Deposit Barrier Active: You locked the door. Don't dig the hole deeper. Wait out the timer.";
      }
      showAlert(message);
    };
    const onStorageChanged = (changes, area) => {
      if (area !== "local") return;
      if (TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2 in changes) {
        const val = changes[TILTCHECK_COOLDOWN_ACTIVE_UNTIL_KEY2]?.newValue;
        if (typeof val === "number" && Number.isFinite(val)) {
          inMemoryCooldownActiveUntil = Math.max(0, val);
        } else {
          inMemoryCooldownActiveUntil = 0;
        }
      }
      if (TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2 in changes) {
        const val = changes[TILTCHECK_DEPOSIT_BARRIER_ENABLED_KEY2]?.newValue;
        if (typeof val === "boolean") {
          inMemoryBarrierEnabled = val;
        }
      }
    };
    try {
      chrome.storage?.onChanged?.addListener?.(onStorageChanged);
    } catch {
    }
    doc.addEventListener("click", onClickCapture, true);
    const stop = () => {
      stopped = true;
      doc.removeEventListener("click", onClickCapture, true);
      try {
        chrome.storage?.onChanged?.removeListener?.(onStorageChanged);
      } catch {
      }
      if (alertTimeoutId !== null) {
        clearTimeout(alertTimeoutId);
        alertTimeoutId = null;
      }
      const alertEl = doc.getElementById(ALERT_ID);
      if (alertEl) {
        alertEl.remove();
      }
    };
    return {
      stop,
      isActive: (now) => isDepositBarrierActive(now),
      getCooldownActiveUntil,
      updateCooldown: (timestamp) => {
        inMemoryCooldownActiveUntil = Math.max(0, timestamp);
      },
      updateEnabled: (enabled) => {
        inMemoryBarrierEnabled = enabled;
      }
    };
  }

  // apps/chrome-extension/src/content.ts
  function isDomain(hostname2, domain) {
    return hostname2 === domain || hostname2.endsWith("." + domain);
  }
  var hostname = window.location.hostname.toLowerCase();
  var pathname = window.location.pathname.toLowerCase();
  var isDiscordAuthRoute = pathname.startsWith("/auth/discord");
  var isExcludedDomain = isDomain(hostname, "discord.com") || hostname === "localhost" && window.location.port === "3333" || hostname === "localhost" && window.location.port === "3001" && isDiscordAuthRoute || isDomain(hostname, "api.tiltcheck.me") && isDiscordAuthRoute;
  if (isExcludedDomain) {
    if (typeof define_process_default !== "undefined" && define_process_default.env?.NODE_ENV !== "production") {
      console.log("[TiltCheck] Skipping - excluded domain:", hostname);
    }
  }
  var TILTCHECK_PRO_MONOLITH_KEY = "tiltcheck_pro_monolith_enabled";
  var TILTCHECK_CORE_RECORD_BET_EVENT = "tiltcheck-core-record-bet";
  var TILTCHECK_TILT_SIGNAL_EVENT = "tiltcheck-tilt-signal";
  var TILTCHECK_TRIGGER_TIMEOUT_EVENT = "tiltcheck-trigger-timeout";
  var paceLock = null;
  var heaterNudge = null;
  var chaseWarning = null;
  var realityHud = null;
  var depositBarrier = null;
  var coreOptions = null;
  var proModulePromise = null;
  var proActive = false;
  var clickTimestamps = [];
  var RAPID_CLICK_BURST_COUNT = 5;
  var RAPID_CLICK_WINDOW_MS = 1500;
  function handleRapidClickTilt(target) {
    const isActionControl = target.closest(SPIN_CONTROL_SELECTOR) !== null || target.matches(SPIN_CONTROL_SELECTOR) || target.closest('button, [role="button"]') !== null;
    if (!isActionControl) return false;
    const now = Date.now();
    clickTimestamps = clickTimestamps.filter((t) => now - t <= RAPID_CLICK_WINDOW_MS);
    clickTimestamps.push(now);
    if (clickTimestamps.length >= RAPID_CLICK_BURST_COUNT) {
      clickTimestamps = [];
      const duration = coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
      triggerTouchGrassTimeout(
        "Rapid clicking detected. Turbo mashing only speeds up the house edge. Step back and breathe.",
        duration
      );
      return true;
    }
    return false;
  }
  function installEventDrivenTiltWatcher() {
    const onSignal = (event) => {
      const custom = event;
      const reason = custom.detail?.reason || (custom.detail?.signal === "rapid_clicking" ? "Rapid clicking detected. Turbo mashing only speeds up the house edge. Step back and breathe." : custom.detail?.signal === "loss_chasing" ? "You are down on consecutive spins and ramping stake size. You're chasing, not on a heater. Step back." : "Tilt signal detected. Step back and recalibrate.");
      const duration = custom.detail?.durationMs ?? coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
      triggerTouchGrassTimeout(reason, duration);
    };
    const onTrigger = (event) => {
      const custom = event;
      const reason = custom.detail?.reason || "Hold up. Recalibrate.";
      const duration = custom.detail?.durationMs ?? coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
      triggerTouchGrassTimeout(reason, duration);
    };
    const onClickCapture = (event) => {
      if (event.target instanceof Element) {
        handleRapidClickTilt(event.target);
      }
    };
    window.addEventListener(TILTCHECK_TILT_SIGNAL_EVENT, onSignal);
    window.addEventListener(TILTCHECK_TRIGGER_TIMEOUT_EVENT, onTrigger);
    document.addEventListener("click", onClickCapture, true);
    return () => {
      window.removeEventListener(TILTCHECK_TILT_SIGNAL_EVENT, onSignal);
      window.removeEventListener(TILTCHECK_TRIGGER_TIMEOUT_EVENT, onTrigger);
      document.removeEventListener("click", onClickCapture, true);
    };
  }
  async function waitForDocumentEnd() {
    if (document.readyState !== "loading" && document.body) {
      return;
    }
    await new Promise((resolve) => {
      const resolveWhenReady = () => {
        if (document.body) {
          document.removeEventListener("DOMContentLoaded", resolveWhenReady);
          resolve();
        }
      };
      document.addEventListener("DOMContentLoaded", resolveWhenReady, { once: true });
      setTimeout(resolveWhenReady, 0);
    });
  }
  async function shouldLoadProMonolith() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_PRO_MONOLITH_KEY);
      return stored[TILTCHECK_PRO_MONOLITH_KEY] === true;
    } catch {
      return false;
    }
  }
  async function loadProModule() {
    if (!proModulePromise) {
      proModulePromise = import(chrome.runtime.getURL("pro-monolith-bootstrap.js"));
    }
    return proModulePromise;
  }
  async function setProMonolithEnabled(enabled) {
    if (enabled) {
      if (proActive) return;
      const mod2 = await loadProModule();
      await mod2.startProMonolith();
      proActive = true;
      return;
    }
    if (!proActive) return;
    const mod = await loadProModule();
    mod.deactivateProMonolith();
    proActive = false;
  }
  async function refreshCoreOptions() {
    coreOptions = await loadCoreCircuitBreakerOptions();
    return coreOptions;
  }
  function installCoreOptionsListener() {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if (TILTCHECK_PRO_MONOLITH_KEY in changes) {
          const enabled = changes[TILTCHECK_PRO_MONOLITH_KEY]?.newValue === true;
          void setProMonolithEnabled(enabled);
        }
        const coreKeyTouched = CORE_CIRCUIT_BREAKER_STORAGE_KEYS.some((k) => k in changes);
        if (coreKeyTouched) {
          void refreshCoreOptions().then((opts) => {
            syncPaceLock(opts.enforcementEnabled);
            syncRealityHud(opts);
            syncDepositBarrier(opts);
          });
        }
      });
    } catch {
    }
  }
  function syncRealityHud(opts) {
    const shouldRun = opts.enforcementEnabled && opts.realityHudEnabled;
    if (shouldRun) {
      if (!realityHud) {
        try {
          realityHud = installRealityHud(document, {
            hourlyWage: opts.hourlyWage,
            enabled: opts.realityHudEnabled,
            thresholdHours: opts.realityThresholdHours
          });
        } catch {
          realityHud = null;
        }
      } else {
        realityHud.updateOptions({
          hourlyWage: opts.hourlyWage,
          enabled: opts.realityHudEnabled,
          thresholdHours: opts.realityThresholdHours
        });
      }
    } else if (realityHud) {
      realityHud.stop();
      realityHud = null;
    }
  }
  function syncDepositBarrier(opts) {
    const shouldRun = opts.enforcementEnabled && opts.depositBarrierEnabled;
    if (shouldRun) {
      if (!depositBarrier) {
        try {
          depositBarrier = installDepositBarrier(document);
        } catch {
          depositBarrier = null;
        }
      }
      depositBarrier?.updateCooldown(opts.cooldownActiveUntil);
      depositBarrier?.updateEnabled(opts.depositBarrierEnabled);
    } else if (depositBarrier) {
      depositBarrier.stop();
      depositBarrier = null;
    }
  }
  function syncPaceLock(enabled) {
    if (enabled && !paceLock) {
      paceLock = installSpinPaceLock();
      if (!heaterNudge) {
        try {
          heaterNudge = installHeaterNudge();
        } catch {
          heaterNudge = null;
        }
      }
      if (!chaseWarning) {
        try {
          chaseWarning = installChaseWarning(
            document,
            () => paceLock ? paceLock.lockUntil() : 0,
            (stake, lastLossStake) => {
              if (stake >= lastLossStake * 1.5) {
                const duration = coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
                triggerTouchGrassTimeout(
                  "You are down on consecutive spins and ramping stake size. You're chasing, not on a heater. Step back.",
                  duration
                );
              }
            }
          );
        } catch {
          chaseWarning = null;
        }
      }
      return;
    }
    if (!enabled && paceLock) {
      chaseWarning?.stop();
      chaseWarning = null;
      heaterNudge?.stop();
      heaterNudge = null;
      paceLock.stop();
      paceLock = null;
    }
  }
  async function startCoreCircuitBreaker() {
    await waitForDocumentEnd();
    const opts = await refreshCoreOptions();
    installCoreOptionsListener();
    window.__tiltcheckCoreShieldActive = true;
    syncPaceLock(opts.enforcementEnabled);
    syncRealityHud(opts);
    syncDepositBarrier(opts);
  }
  async function boot() {
    if (isExcludedDomain) {
      return;
    }
    await startCoreCircuitBreaker();
    installEventDrivenTiltWatcher();
    installLoungeOverlay();
    installLocalGameBlocker();
    if (await shouldLoadProMonolith()) {
      await setProMonolithEnabled(true);
    }
  }
  void boot();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (isExcludedDomain && message.type !== "get_sidebar_state") {
      sendResponse({ error: "Feature disabled on this domain" });
      return true;
    }
    if (proActive && (message.type === "toggle_sidebar" || message.type === "open_sidebar" || message.type === "get_sidebar_state")) {
      return false;
    }
    switch (message.type) {
      case "trigger_touch_grass": {
        const duration = message.durationMs ?? coreOptions?.touchGrassDurationMs ?? TOUCH_GRASS_DURATION_MS;
        triggerTouchGrassTimeout(
          message.reason || "Tilt signal detected. Step back and recalibrate.",
          duration
        );
        sendResponse({ success: true, active: true });
        return true;
      }
      case "toggle_sidebar":
      case "open_sidebar":
        sendResponse({
          success: false,
          coreOnly: true,
          hint: "Set tiltcheck_pro_monolith_enabled to true in chrome.storage.local to load the full TiltCheck panel."
        });
        return true;
      case "get_sidebar_state":
        sendResponse({
          exists: false,
          visible: false,
          injectionDisabled: false,
          coreOnly: true
        });
        return true;
      case "get_deposit_barrier_state":
        sendResponse({
          active: depositBarrier ? depositBarrier.isActive() : false,
          cooldownUntil: depositBarrier ? depositBarrier.getCooldownActiveUntil() : 0
        });
        return true;
      case "get_reality_hud_state":
        sendResponse({
          visible: realityHud ? realityHud.isVisible() : false,
          baseline: realityHud ? realityHud.getBaseline() : null
        });
        return true;
      default:
        return false;
    }
  });
  if (typeof define_process_default !== "undefined" && define_process_default.env?.NODE_ENV !== "production") {
    console.log("[TiltCheck] Core content script loaded");
  }
})();
//# sourceMappingURL=content.js.map
