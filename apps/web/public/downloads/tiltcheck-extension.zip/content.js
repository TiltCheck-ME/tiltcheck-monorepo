(() => {
  // <define:process>
  var define_process_default = { env: {} };

  // src/tilt-detector.ts
  var PROFILE_MULTIPLIERS = {
    conservative: 1.2,
    moderate: 1,
    degen: 0.8
  };
  var ANIMATION_LOOP_MS = 500;
  var MICRO_PACING_RETENTION_MS = 6e4;
  var TiltDetector = class {
    bets = [];
    clicks = [];
    // Timestamps of clicks
    sessionStartTime = Date.now();
    baselineAvgBet = 0;
    consecutiveLosses = 0;
    totalWagered = 0;
    totalWon = 0;
    currentBalance = null;
    initialBalance = null;
    redeemThreshold = null;
    riskProfile = "moderate";
    // Configuration
    config = {
      // Rage betting thresholds
      fastBetThreshold: 2e3,
      // ms between bets
      rageBetCount: 5,
      // consecutive fast bets
      // Chasing losses
      betIncreaseMultiplier: 2.5,
      // 2.5x increase after loss
      chasingPattern: 3,
      // consecutive increasing bets after losses
      // Fast clicks — "Auto-Pilot Trance" detection.
      // Triggers when bet events arrive faster than 300ms apart (sub-human pacing = autopilot state).
      clickThreshold: 5,
      // clicks in window
      clickWindow: 300,
      // ms — reduced from 3000ms to detect Auto-Pilot Trance pattern
      // Session duration
      warningDuration: 60 * 60 * 1e3,
      // 1 hour
      criticalDuration: 2 * 60 * 60 * 1e3,
      // 2 hours
      // Vault recommendations
      vaultThreshold: 5,
      // 5x initial balance
      profitVaultPercent: 0.5,
      // Vault 50% of profits
      // Stop loss
      stopLossPercent: 0.5,
      // Stop at 50% loss
      // Real-world comparisons (common items people forget to buy)
      realWorldItems: [
        { item: "trash bags", avgCost: 15 },
        { item: "toilet paper", avgCost: 20 },
        { item: "groceries", avgCost: 100 },
        { item: "gas", avgCost: 50 },
        { item: "phone bill", avgCost: 80 },
        { item: "utilities", avgCost: 150 },
        { item: "rent", avgCost: 1500 }
      ]
    };
    constructor(initialBalance, riskLevel = "moderate", redeemThreshold) {
      this.currentBalance = initialBalance;
      this.initialBalance = initialBalance;
      this.redeemThreshold = redeemThreshold || null;
      this.setRiskProfile(riskLevel);
    }
    setRiskProfile(level) {
      this.riskProfile = level;
      this.applyRiskProfile(level);
    }
    getRiskProfile() {
      return this.riskProfile;
    }
    classifyBetResult(bet, payout) {
      if (bet <= 0) {
        return payout > 0 ? "win" : "push";
      }
      if (payout <= 0 || payout < bet) {
        return "loss";
      }
      if (payout === bet) {
        return "push";
      }
      return "win";
    }
    /**
     * Apply risk profile configuration
     */
    applyRiskProfile(level) {
      if (level === "conservative") {
        this.config.fastBetThreshold = 3e3;
        this.config.betIncreaseMultiplier = 1.5;
        this.config.warningDuration = 30 * 60 * 1e3;
        this.config.criticalDuration = 1 * 60 * 1e3;
        this.config.stopLossPercent = 0.3;
      } else if (level === "degen") {
        this.config.fastBetThreshold = 1e3;
        this.config.betIncreaseMultiplier = 5;
        this.config.warningDuration = 4 * 60 * 60 * 1e3;
        this.config.criticalDuration = 8 * 60 * 60 * 1e3;
        this.config.stopLossPercent = 0.8;
      }
    }
    /**
     * Record a bet event
     */
    recordBet(bet, payout) {
      const now = Date.now();
      const result = this.classifyBetResult(bet, payout);
      this.bets.push({
        amount: bet,
        timestamp: now,
        result,
        payout
      });
      this.totalWagered += bet;
      this.totalWon += payout;
      if (this.currentBalance !== null) {
        this.currentBalance = this.currentBalance - bet + payout;
      }
      if (result === "loss") {
        this.consecutiveLosses++;
      } else {
        this.consecutiveLosses = 0;
      }
      const baselineBets = this.bets.filter((entry) => entry.amount > 0).slice(0, 10);
      if (baselineBets.length > 0) {
        this.baselineAvgBet = baselineBets.reduce((sum, entry) => sum + entry.amount, 0) / baselineBets.length;
      }
    }
    /**
     * Update the current balance from an external source.
     */
    updateBalance(newBalance) {
      if (newBalance !== this.currentBalance) {
        this.currentBalance = newBalance;
      }
    }
    setRedeemThreshold(redeemThreshold) {
      this.redeemThreshold = redeemThreshold && redeemThreshold > 0 ? redeemThreshold : null;
    }
    /**
     * Record a click event (for erratic clicking detection)
     */
    recordClick() {
      const now = Date.now();
      this.clicks.push(now);
      this.clicks = this.clicks.filter((t) => now - t < MICRO_PACING_RETENTION_MS);
    }
    /** Recent inter-click deltas (ms), oldest first. */
    computeRecentClickDeltas(maxDeltas = 8) {
      const sorted = [...this.clicks].sort((a, b) => a - b);
      const deltas = [];
      for (let i = 1; i < sorted.length && deltas.length < maxDeltas; i++) {
        deltas.push(sorted[i] - sorted[i - 1]);
      }
      return deltas;
    }
    getLastClickDeltaMs() {
      const deltas = this.computeRecentClickDeltas();
      return deltas.length > 0 ? deltas[deltas.length - 1] : null;
    }
    /**
     * Continuous velocity contribution (0–45) from compressing click pacing.
     */
    getMicroPacingComponent() {
      const deltas = this.computeRecentClickDeltas();
      if (deltas.length < 2) return 0;
      const lastDelta = deltas[deltas.length - 1];
      const recent = deltas.slice(-4);
      const avgDelta = recent.reduce((sum, d) => sum + d, 0) / recent.length;
      let velocity = 0;
      if (lastDelta < ANIMATION_LOOP_MS) {
        velocity += (ANIMATION_LOOP_MS - lastDelta) / ANIMATION_LOOP_MS * 28;
      }
      if (avgDelta < ANIMATION_LOOP_MS) {
        velocity += (ANIMATION_LOOP_MS - avgDelta) / ANIMATION_LOOP_MS * 12;
      }
      let compressingSteps = 0;
      for (let i = 1; i < recent.length; i++) {
        if (recent[i] < recent[i - 1] * 0.92) {
          compressingSteps++;
        }
      }
      if (compressingSteps >= 2 && lastDelta < ANIMATION_LOOP_MS + 100) {
        velocity += compressingSteps * 6;
      }
      return Math.min(45, velocity);
    }
    /**
     * Exponential loss-streak weight when pacing is hot (co-occurrence required).
     */
    getLossStreakCompoundComponent() {
      if (this.consecutiveLosses <= 3) return 0;
      const pacingHot = this.getMicroPacingComponent() >= 10 || this.getLastClickDeltaMs() !== null && this.getLastClickDeltaMs() < ANIMATION_LOOP_MS;
      if (!pacingHot) return 0;
      const streakExcess = this.consecutiveLosses - 3;
      const exponential = Math.pow(1.35, streakExcess);
      const linear = streakExcess * 7;
      return Math.min(35, linear * Math.min(2.5, exponential / 1.8));
    }
    getIndicatorCompositeScore() {
      const tiltSigns = this.detectAllTiltSigns();
      const weights = {
        rage_betting: 22,
        chasing_losses: 26,
        fast_clicks: 12,
        bet_escalation: 18,
        duration_warning: 8,
        emotional_pattern: 16,
        fatigue: 12,
        martingale: 20
      };
      const severityMultipliers = {
        low: 0.5,
        medium: 1,
        high: 1.5,
        critical: 2
      };
      let score = 0;
      for (const sign of tiltSigns) {
        const weight = weights[sign.type] ?? 10;
        const multiplier = severityMultipliers[sign.severity];
        score += weight * multiplier * sign.confidence;
      }
      return Math.min(55, score);
    }
    /**
     * Detect rage betting (fast consecutive bets)
     */
    detectRageBetting() {
      if (this.bets.length < this.config.rageBetCount) return null;
      const recentBets = this.bets.slice(-this.config.rageBetCount);
      const intervals = [];
      for (let i = 1; i < recentBets.length; i++) {
        intervals.push(recentBets[i].timestamp - recentBets[i - 1].timestamp);
      }
      const avgInterval = intervals.reduce((sum, i) => sum + i, 0) / intervals.length;
      if (avgInterval < this.config.fastBetThreshold) {
        const severity = avgInterval < 1e3 ? "critical" : avgInterval < 1500 ? "high" : "medium";
        return {
          type: "rage_betting",
          severity,
          confidence: Math.min(1, this.config.fastBetThreshold / avgInterval - 1),
          description: `Betting very quickly (${(avgInterval / 1e3).toFixed(1)}s between bets)`,
          evidence: {
            avgInterval,
            recentBets: recentBets.length,
            threshold: this.config.fastBetThreshold
          },
          triggeredAt: Date.now()
        };
      }
      return null;
    }
    /**
     * Detect chasing losses (increasing bets after losses)
     */
    detectChasingLosses() {
      if (this.bets.length < this.config.chasingPattern + 1) return null;
      if (this.consecutiveLosses < this.config.chasingPattern) return null;
      const recentBets = this.bets.slice(-this.config.chasingPattern - 1);
      const isChasing = recentBets.every((bet, i) => {
        if (i === 0) return true;
        return bet.amount > recentBets[i - 1].amount * this.config.betIncreaseMultiplier;
      });
      if (isChasing) {
        const increase = recentBets[recentBets.length - 1].amount / recentBets[0].amount;
        const severity = increase > 10 ? "critical" : increase > 5 ? "high" : increase > 3 ? "medium" : "low";
        return {
          type: "chasing_losses",
          severity,
          confidence: Math.min(1, increase / 10),
          description: `Bet size increased ${increase.toFixed(1)}x after ${this.consecutiveLosses} losses`,
          evidence: {
            consecutiveLosses: this.consecutiveLosses,
            betIncrease: increase,
            startBet: recentBets[0].amount,
            currentBet: recentBets[recentBets.length - 1].amount
          },
          triggeredAt: Date.now()
        };
      }
      return null;
    }
    /**
     * Detect fast/erratic clicking (Auto-Pilot Trance detection).
     * At 300ms window, this fires when bet events arrive faster than humanly intentional.
     */
    detectFastClicks() {
      if (this.clicks.length < this.config.clickThreshold) return null;
      const recentClicks = this.clicks.filter(
        (t) => Date.now() - t < this.config.clickWindow
      );
      if (recentClicks.length >= this.config.clickThreshold) {
        const severity = recentClicks.length > 10 ? "high" : "medium";
        const sortedRecent = [...recentClicks].sort((a, b) => b - a);
        const lastClickDeltaMs = sortedRecent.length >= 2 ? sortedRecent[0] - sortedRecent[1] : 0;
        return {
          type: "fast_clicks",
          severity,
          confidence: Math.min(1, recentClicks.length / 10),
          description: `${recentClicks.length} clicks in ${this.config.clickWindow}ms \u2014 Auto-Pilot Trance detected`,
          evidence: {
            clickCount: recentClicks.length,
            window: this.config.clickWindow,
            last_click_delta_ms: lastClickDeltaMs
          },
          triggeredAt: Date.now()
        };
      }
      return null;
    }
    /**
     * Detect bet escalation (beyond baseline)
     */
    detectBetEscalation() {
      if (this.bets.filter((entry) => entry.amount > 0).length < 10 || this.baselineAvgBet <= 0) return null;
      const recentBet = this.bets[this.bets.length - 1];
      if (recentBet.amount <= 0) return null;
      const escalationFactor = recentBet.amount / this.baselineAvgBet;
      if (escalationFactor > 5) {
        const severity = escalationFactor > 20 ? "critical" : escalationFactor > 10 ? "high" : "medium";
        return {
          type: "bet_escalation",
          severity,
          confidence: Math.min(1, escalationFactor / 20),
          description: `Bet ${escalationFactor.toFixed(1)}x larger than your average`,
          evidence: {
            currentBet: recentBet.amount,
            baselineAvg: this.baselineAvgBet,
            escalationFactor
          },
          triggeredAt: Date.now()
        };
      }
      return null;
    }
    /**
     * Detect session duration warnings
     */
    detectDurationWarning() {
      const duration = Date.now() - this.sessionStartTime;
      if (duration > this.config.criticalDuration) {
        return {
          type: "duration_warning",
          severity: "critical",
          confidence: 1,
          description: `You've been playing for ${(duration / 36e5).toFixed(1)} hours`,
          evidence: {
            duration,
            hours: duration / 36e5
          },
          triggeredAt: Date.now()
        };
      } else if (duration > this.config.warningDuration) {
        return {
          type: "duration_warning",
          severity: "medium",
          confidence: 0.8,
          description: `Session duration: ${(duration / 6e4).toFixed(0)} minutes`,
          evidence: {
            duration,
            minutes: duration / 6e4
          },
          triggeredAt: Date.now()
        };
      }
      return null;
    }
    /**
     * Detect Martingale Desperation pattern.
     *
     * Pattern: loss -> bet * 1.7x-2.5x -> loss -> bet * 1.7x-2.5x -> ... (3+ consecutive steps).
     * Uses 1.7x floor — real-world players rarely double exactly.
     */
    detectMartingale() {
      if (this.bets.length < 4) return null;
      const window2 = this.bets.slice(-6);
      let consecutiveSteps = 0;
      for (let i = 1; i < window2.length; i++) {
        const prev = window2[i - 1];
        const curr = window2[i];
        const prevWasLoss = prev.result === "loss";
        const multiplier = prev.amount > 0 ? curr.amount / prev.amount : 0;
        const isMartingaleStep = prevWasLoss && multiplier >= 1.7 && multiplier <= 2.5;
        if (isMartingaleStep) {
          consecutiveSteps++;
        } else {
          consecutiveSteps = 0;
        }
        if (consecutiveSteps >= 3) {
          const increase = curr.amount / window2[i - consecutiveSteps].amount;
          const severity = increase > 8 ? "critical" : increase > 4 ? "high" : "medium";
          return {
            type: "emotional_pattern",
            severity,
            confidence: Math.min(1, consecutiveSteps / 4),
            description: `Martingale pattern: ${consecutiveSteps} consecutive loss-double cycles detected`,
            evidence: {
              consecutiveSteps,
              startAmount: window2[i - consecutiveSteps].amount,
              currentAmount: curr.amount,
              multiplierRange: "1.7x-2.5x"
            },
            triggeredAt: Date.now()
          };
        }
      }
      return null;
    }
    /**
     * Detect all tilt indicators
     */
    detectAllTiltSigns() {
      const indicators = [];
      const rageBetting = this.detectRageBetting();
      if (rageBetting) indicators.push(rageBetting);
      const chasing = this.detectChasingLosses();
      if (chasing) indicators.push(chasing);
      const fastClicks = this.detectFastClicks();
      if (fastClicks) indicators.push(fastClicks);
      const escalation = this.detectBetEscalation();
      if (escalation) indicators.push(escalation);
      const duration = this.detectDurationWarning();
      if (duration) indicators.push(duration);
      const martingale = this.detectMartingale();
      if (martingale) indicators.push(martingale);
      return indicators;
    }
    /**
     * Generate vault recommendation
     */
    generateVaultRecommendation() {
      if (this.currentBalance === null || this.initialBalance === null || this.initialBalance <= 0) {
        return null;
      }
      const profit = this.currentBalance - this.initialBalance;
      const profitMultiple = this.currentBalance / this.initialBalance;
      if (profitMultiple >= this.config.vaultThreshold) {
        const suggestedAmount = profit * this.config.profitVaultPercent;
        const comparison = this.findRealWorldComparison(suggestedAmount);
        return {
          reason: `Your balance is ${profitMultiple.toFixed(1)}x your starting amount`,
          suggestedAmount,
          urgency: profitMultiple > 10 ? "critical" : profitMultiple > 7 ? "high" : "medium",
          realWorldComparison: comparison
        };
      }
      const lossPercent = (this.initialBalance - this.currentBalance) / this.initialBalance;
      if (lossPercent >= this.config.stopLossPercent) {
        return {
          reason: `You've lost ${(lossPercent * 100).toFixed(0)}% of your starting balance`,
          suggestedAmount: this.currentBalance,
          // Vault everything
          urgency: "critical",
          realWorldComparison: void 0
        };
      }
      return null;
    }
    /**
     * Detect opportunity to redeem/cash out (Redeem-to-Win)
     */
    detectRedeemOpportunity() {
      if (!this.redeemThreshold || this.currentBalance === null || this.currentBalance < this.redeemThreshold) return null;
      const diff = this.currentBalance - this.redeemThreshold;
      const overshootPercent = diff / this.redeemThreshold * 100;
      let urgency = "medium";
      if (overshootPercent > 50) urgency = "critical";
      else if (overshootPercent > 20) urgency = "high";
      return {
        amount: this.currentBalance,
        threshold: this.redeemThreshold,
        urgency,
        message: `\u{1F3AF} PROFIT GOAL REACHED! You're at $${this.currentBalance.toFixed(2)}, which is above your $${this.redeemThreshold} goal. Secure the win and cash out now!`
      };
    }
    /**
     * Find real-world item comparison
     */
    findRealWorldComparison(amount) {
      const affordableItems = this.config.realWorldItems.filter(
        (item2) => amount >= item2.avgCost
      );
      if (affordableItems.length === 0) return void 0;
      const item = affordableItems[Math.floor(Math.random() * affordableItems.length)];
      const quantity = Math.floor(amount / item.avgCost);
      return {
        item: item.item,
        cost: item.avgCost,
        quantity,
        message: `Hey, you mentioned needing ${item.item}. Your balance is ${quantity}x what they cost - maybe pull $${item.avgCost} and grab them now?`
      };
    }
    /**
     * Generate intervention recommendations
     */
    generateInterventions() {
      const interventions = [];
      const tiltSigns = this.detectAllTiltSigns();
      const vaultRec = this.generateVaultRecommendation();
      const redeemRec = this.detectRedeemOpportunity();
      const criticalSigns = tiltSigns.filter((t) => t.severity === "critical");
      if (criticalSigns.length > 0) {
        interventions.push({
          type: "cooldown",
          message: `\u{1F6D1} TILT DETECTED: ${criticalSigns.map((t) => t.description).join(", ")}. Take a 5-minute break.`,
          actionRequired: true,
          data: { duration: 5 * 60 * 1e3, tiltSigns: criticalSigns }
        });
      }
      const highSigns = tiltSigns.filter((t) => t.severity === "high" || t.severity === "critical");
      if (highSigns.length >= 2) {
        interventions.push({
          type: "phone_friend",
          message: "\u{1F4DE} Multiple tilt indicators detected. Maybe call someone before continuing?",
          actionRequired: false,
          data: { tiltSigns: highSigns }
        });
      }
      if (vaultRec) {
        if (vaultRec.urgency === "critical") {
          interventions.push({
            type: "stop_loss_triggered",
            message: `\u26A0\uFE0F STOP LOSS: ${vaultRec.reason}. Strongly recommend vaulting your remaining balance.`,
            actionRequired: true,
            data: vaultRec
          });
        } else if (vaultRec.realWorldComparison) {
          interventions.push({
            type: "spending_reminder",
            message: vaultRec.realWorldComparison.message,
            actionRequired: false,
            data: vaultRec
          });
        } else {
          interventions.push({
            type: "vault_balance",
            message: `\u{1F4B0} ${vaultRec.reason}. Consider vaulting $${vaultRec.suggestedAmount.toFixed(2)}.`,
            actionRequired: false,
            data: vaultRec
          });
        }
      }
      if (redeemRec) {
        interventions.push({
          type: "redeem_nudge",
          message: redeemRec.message,
          actionRequired: true,
          data: redeemRec
        });
      }
      const durationWarning = tiltSigns.find((t) => t.type === "duration_warning");
      if (durationWarning && durationWarning.severity === "critical") {
        interventions.push({
          type: "session_break",
          message: `\u23F0 ${durationWarning.description}. Time for a break?`,
          actionRequired: false,
          data: durationWarning
        });
      }
      return interventions;
    }
    /**
     * Composite tilt risk (0–100): indicators + micro-pacing + loss-streak compound, scaled by profile.
     */
    getTiltRiskScore() {
      const indicatorScore = this.getIndicatorCompositeScore();
      const velocityScore = this.getMicroPacingComponent();
      const lossCompound = this.getLossStreakCompoundComponent();
      const raw = indicatorScore + velocityScore + lossCompound;
      const profileMu = PROFILE_MULTIPLIERS[this.riskProfile];
      return Math.min(100, Math.round(raw * profileMu));
    }
    /**
     * Get session summary
     */
    getSessionSummary() {
      const duration = Date.now() - this.sessionStartTime;
      const netProfit = this.currentBalance !== null && this.initialBalance !== null ? this.currentBalance - this.initialBalance : null;
      const roi = netProfit !== null && this.initialBalance !== null && this.initialBalance > 0 ? netProfit / this.initialBalance * 100 : null;
      return {
        duration,
        // ms
        startTime: this.sessionStartTime,
        totalBets: this.bets.length,
        totalWagered: this.totalWagered,
        totalWon: this.totalWon,
        netProfit,
        roi,
        currentBalance: this.currentBalance,
        initialBalance: this.initialBalance,
        avgBetSize: this.bets.length > 0 ? this.totalWagered / this.bets.length : 0,
        consecutiveLosses: this.consecutiveLosses,
        tiltRisk: this.getTiltRiskScore()
      };
    }
  };

  // src/touch-grass-timeout.ts
  var TOUCH_GRASS_DURATION_MS = 12e4;
  var MESSAGE_ROTATE_MS = 2e4;
  var MESSAGE_FADE_SWAP_MS = 450;
  var BREAK_MESSAGES = [
    "Click velocity anomaly detected. Your brain is scrambling to patch a sudden dopamine drop, not a mathematical edge.",
    "Fact: Fast-clicking alters nothing but the speed at which the house edge resolves against your balance.",
    "House algorithms monitor pacing. When you accelerate play, you transition from choice to pure execution of the machine's loop.",
    "Drop your shoulders. Unclench your jaw. Exhale completely. Mechanically cut the physical adrenaline loop.",
    "The platform has a memory; house telemetry tracks your live click-velocity to categorize your risk and volatility tolerance in real time.",
    "Turbo spins and short-cycling cut off your brain's natural evaluation window. The house relies on your auto-pilot.",
    "Prefrontal cortex (rational limit) is offline. Amygdala (fight-or-flight) is driving. You cannot out-gamble a system while hijacked.",
    "Inhale for 4 seconds. Exhale for 4 seconds. Let the neural chemical spike clear before the layout unlocks."
  ];
  var LOCKDOWN_ROOT_ID = "tiltcheck-lockdown-root";
  var MESSAGE_EL_ID = "tiltcheck-lockdown-message";
  var TIMER_ID = "lockdown-timer";
  var overlayActive = false;
  function blockBettingUI(block) {
    const betButtons = document.querySelectorAll(
      'button[class*="bet"], button[class*="spin"], [data-action="bet"], [data-action="spin"]'
    );
    betButtons.forEach((btn) => {
      if (block) {
        if (btn instanceof HTMLButtonElement) {
          btn.disabled = true;
        }
        btn.style.opacity = "0.5";
        btn.style.cursor = "not-allowed";
        btn.dataset.tiltguardBlocked = "true";
      } else if (btn.dataset.tiltguardBlocked) {
        if (btn instanceof HTMLButtonElement) {
          btn.disabled = false;
        }
        btn.style.opacity = "";
        btn.style.cursor = "";
        delete btn.dataset.tiltguardBlocked;
      }
    });
  }
  function injectLockdownStyles(root) {
    const style = document.createElement("style");
    style.textContent = `
    #${LOCKDOWN_ROOT_ID} {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: #0f1115 !important;
      z-index: 2147483647 !important;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      font-family: ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, monospace;
      color: #ff4a4a;
      box-sizing: border-box;
      padding: 1.5rem;
      overflow-y: auto;
      user-select: none;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-inner {
      width: 100%;
      max-width: 32rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-eyebrow {
      font-size: 0.6875rem;
      font-weight: 800;
      letter-spacing: 0.28em;
      text-transform: uppercase;
      color: #ff4a4a;
      margin-bottom: 0.75rem;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-headline {
      font-size: 1.625rem;
      font-weight: 900;
      letter-spacing: -0.02em;
      color: #ffffff;
      margin: 0 0 0.75rem;
      line-height: 1.15;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-reason {
      font-size: 0.875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.82);
      margin: 0 0 1.25rem;
      max-width: 28rem;
    }

    /* Center stage: pacer ring + timer digits */
    .tiltcheck-pacer-stage {
      position: relative;
      width: 250px;
      height: 250px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 2rem 0;
    }

    .tiltcheck-breath-pacer {
      position: absolute;
      width: 200px;
      height: 200px;
      border: 4px solid #ff4a4a;
      border-radius: 50%;
      box-shadow: 0 0 15px rgba(255, 74, 74, 0.2);
      animation: tiltcheck-breath-pacer 8s ease-in-out infinite;
      pointer-events: none;
    }

    #${TIMER_ID} {
      font-size: 3.5rem;
      font-weight: bold;
      color: #ffffff;
      z-index: 10;
      font-variant-numeric: tabular-nums;
      line-height: 1;
      text-shadow: 0 2px 20px rgba(0, 0, 0, 0.5);
    }

    @keyframes tiltcheck-breath-pacer {
      0%, 100% {
        transform: scale(0.6);
        opacity: 0.3;
        box-shadow: 0 0 10px rgba(255, 74, 74, 0.1);
      }
      50% {
        transform: scale(1.1);
        opacity: 0.9;
        border-color: #4affb4;
        box-shadow: 0 0 30px rgba(74, 255, 180, 0.4);
      }
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-breath-hint {
      position: absolute;
      bottom: -2.25rem;
      left: 50%;
      transform: translateX(-50%);
      width: 18rem;
      font-size: 0.625rem;
      opacity: 0.55;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: rgba(255, 255, 255, 0.55);
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-signal-label {
      font-size: 0.625rem;
      font-weight: 800;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: rgba(255, 74, 74, 0.65);
      margin-bottom: 0.5rem;
      align-self: stretch;
      text-align: left;
    }

    #${MESSAGE_EL_ID} {
      font-size: 0.875rem;
      line-height: 1.5;
      margin: 0;
      text-align: left;
      min-height: 4.5em;
      align-self: stretch;
      color: rgba(245, 245, 245, 0.94);
      transition: opacity 0.45s ease;
    }

    #${LOCKDOWN_ROOT_ID} .tiltcheck-lockdown-foot {
      font-size: 0.6875rem;
      line-height: 1.45;
      color: rgba(255, 255, 255, 0.45);
      margin: 1.25rem 0 0;
      max-width: 26rem;
    }
  `;
    root.insertBefore(style, root.firstChild);
  }
  function triggerTouchGrassTimeout(reason, durationMs = TOUCH_GRASS_DURATION_MS) {
    if (overlayActive) {
      return;
    }
    overlayActive = true;
    blockBettingUI(true);
    const existing = document.getElementById(LOCKDOWN_ROOT_ID);
    if (existing) {
      existing.remove();
    }
    const root = document.createElement("div");
    root.id = LOCKDOWN_ROOT_ID;
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.setAttribute(
      "aria-label",
      "Touch Grass timeout \u2014 session pause with breathing pacer and rotating guidance"
    );
    injectLockdownStyles(root);
    const inner = document.createElement("div");
    inner.className = "tiltcheck-lockdown-inner";
    const eyebrow = document.createElement("div");
    eyebrow.className = "tiltcheck-eyebrow";
    eyebrow.textContent = "Touch Grass Timeout";
    const headline = document.createElement("h1");
    headline.className = "tiltcheck-lockdown-headline";
    headline.textContent = "Hold the line. Recalibrate.";
    const reasonEl = document.createElement("p");
    reasonEl.className = "tiltcheck-lockdown-reason";
    reasonEl.textContent = reason;
    const stage = document.createElement("div");
    stage.className = "tiltcheck-pacer-stage";
    const breathRing = document.createElement("div");
    breathRing.className = "tiltcheck-breath-pacer";
    breathRing.setAttribute("aria-hidden", "true");
    const timerWrap = document.createElement("div");
    timerWrap.id = TIMER_ID;
    timerWrap.setAttribute("aria-live", "polite");
    timerWrap.setAttribute("aria-atomic", "true");
    const breathHint = document.createElement("div");
    breathHint.className = "tiltcheck-breath-hint";
    breathHint.textContent = "Inhale as the ring expands \u2014 exhale as it releases.";
    const signalLabel = document.createElement("div");
    signalLabel.className = "tiltcheck-signal-label";
    signalLabel.textContent = "Signal";
    const messageRegion = document.createElement("div");
    messageRegion.className = "tiltcheck-signal-region";
    messageRegion.setAttribute("role", "region");
    messageRegion.setAttribute("aria-label", "System message updates every 20 seconds");
    const messageEl = document.createElement("p");
    messageEl.id = MESSAGE_EL_ID;
    messageEl.setAttribute("aria-live", "off");
    messageEl.textContent = BREAK_MESSAGES[0] ?? "";
    const foot = document.createElement("p");
    foot.className = "tiltcheck-lockdown-foot";
    foot.textContent = "This tab stays locked until the counter hits zero. No dismiss. Future settings: explicit opt-in for duration and policy.";
    stage.appendChild(breathRing);
    stage.appendChild(timerWrap);
    stage.appendChild(breathHint);
    inner.appendChild(eyebrow);
    inner.appendChild(headline);
    inner.appendChild(reasonEl);
    inner.appendChild(stage);
    messageRegion.appendChild(messageEl);
    inner.appendChild(signalLabel);
    inner.appendChild(messageRegion);
    inner.appendChild(foot);
    root.appendChild(inner);
    document.body.appendChild(root);
    const stopBlocking = (e) => {
      e.preventDefault();
      e.stopPropagation();
    };
    const captureOpts = { capture: true };
    root.addEventListener("click", stopBlocking, captureOpts);
    root.addEventListener("mousedown", stopBlocking, captureOpts);
    root.addEventListener("mouseup", stopBlocking, captureOpts);
    root.addEventListener("keydown", stopBlocking, captureOpts);
    root.addEventListener("touchstart", stopBlocking, captureOpts);
    document.addEventListener("keydown", stopBlocking, captureOpts);
    let messageIndex = 0;
    let pendingFadeTimeout = null;
    const clearPendingFade = () => {
      if (pendingFadeTimeout !== null) {
        clearTimeout(pendingFadeTimeout);
        pendingFadeTimeout = null;
      }
    };
    const messageRotateIntervalId = window.setInterval(() => {
      if (!document.getElementById(LOCKDOWN_ROOT_ID) || !messageEl.isConnected) {
        clearInterval(messageRotateIntervalId);
        return;
      }
      messageIndex = (messageIndex + 1) % BREAK_MESSAGES.length;
      messageEl.style.opacity = "0";
      clearPendingFade();
      pendingFadeTimeout = window.setTimeout(() => {
        pendingFadeTimeout = null;
        if (!messageEl.isConnected) return;
        messageEl.textContent = BREAK_MESSAGES[messageIndex] ?? "";
        messageEl.style.opacity = "1";
      }, MESSAGE_FADE_SWAP_MS);
    }, MESSAGE_ROTATE_MS);
    let countdownIntervalId = null;
    const started = Date.now();
    const finish = () => {
      if (countdownIntervalId !== null) {
        clearInterval(countdownIntervalId);
        countdownIntervalId = null;
      }
      clearInterval(messageRotateIntervalId);
      clearPendingFade();
      root.remove();
      document.removeEventListener("keydown", stopBlocking, captureOpts);
      blockBettingUI(false);
      overlayActive = false;
    };
    const tick = () => {
      const left = Math.max(0, durationMs - (Date.now() - started));
      const sec = Math.ceil(left / 1e3);
      timerWrap.textContent = `${sec}`;
      if (left <= 0) {
        finish();
      }
    };
    tick();
    countdownIntervalId = window.setInterval(tick, 250);
  }

  // src/core-options.ts
  var TILTCHECK_RISK_THRESHOLD_KEY = "tiltcheck_risk_threshold";
  var TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY = "tiltcheck_touch_grass_duration_ms";
  var TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY = "tiltcheck_touch_grass_cooldown_ms";
  var TILTCHECK_TOUCH_GRASS_OPT_IN_KEY = "tiltcheck_touch_grass_opt_in";
  var TILTCHECK_RISK_PROFILE_KEY = "tiltcheck_risk_profile";
  var DEFAULT_RISK_PROFILE = "moderate";
  var CORE_CIRCUIT_BREAKER_STORAGE_KEYS = [
    TILTCHECK_RISK_THRESHOLD_KEY,
    TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
    TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
    TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
    TILTCHECK_RISK_PROFILE_KEY
  ];
  function normalizeRiskProfile(value, legacyRiskLevel) {
    if (value === "conservative" || value === "moderate" || value === "degen") {
      return value;
    }
    if (legacyRiskLevel === "conservative" || legacyRiskLevel === "moderate" || legacyRiskLevel === "degen") {
      return legacyRiskLevel;
    }
    return DEFAULT_RISK_PROFILE;
  }
  var DEFAULT_RISK_THRESHOLD = 85;
  var DEFAULT_TOUCH_GRASS_DURATION_MS = TOUCH_GRASS_DURATION_MS;
  var DEFAULT_TOUCH_GRASS_COOLDOWN_MS = DEFAULT_TOUCH_GRASS_DURATION_MS + 5e3;
  var MIN_RISK_THRESHOLD = 50;
  var MAX_RISK_THRESHOLD = 100;
  var MIN_DURATION_MS = 3e4;
  var MAX_DURATION_MS = 6e5;
  var MIN_COOLDOWN_MS = 3e4;
  var MAX_COOLDOWN_MS = 9e5;
  function clampInt(value, min, max, fallback) {
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, Math.round(n)));
  }
  async function loadCoreCircuitBreakerOptions() {
    try {
      const stored = await chrome.storage.local.get([
        TILTCHECK_RISK_THRESHOLD_KEY,
        TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY,
        TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY,
        TILTCHECK_TOUCH_GRASS_OPT_IN_KEY,
        TILTCHECK_RISK_PROFILE_KEY,
        "riskLevel"
      ]);
      const durationMs = clampInt(
        stored[TILTCHECK_TOUCH_GRASS_DURATION_MS_KEY],
        MIN_DURATION_MS,
        MAX_DURATION_MS,
        DEFAULT_TOUCH_GRASS_DURATION_MS
      );
      const cooldownDefault = durationMs + 5e3;
      const cooldownMs = clampInt(
        stored[TILTCHECK_TOUCH_GRASS_COOLDOWN_MS_KEY],
        MIN_COOLDOWN_MS,
        MAX_COOLDOWN_MS,
        cooldownDefault
      );
      const optIn = stored[TILTCHECK_TOUCH_GRASS_OPT_IN_KEY];
      const enforcementEnabled = optIn === void 0 ? true : optIn === true;
      return {
        riskThreshold: clampInt(
          stored[TILTCHECK_RISK_THRESHOLD_KEY],
          MIN_RISK_THRESHOLD,
          MAX_RISK_THRESHOLD,
          DEFAULT_RISK_THRESHOLD
        ),
        touchGrassDurationMs: durationMs,
        touchGrassCooldownMs: Math.max(cooldownMs, durationMs + 1e3),
        riskProfile: normalizeRiskProfile(
          stored[TILTCHECK_RISK_PROFILE_KEY],
          stored["riskLevel"]
        ),
        enforcementEnabled
      };
    } catch {
      return {
        riskThreshold: DEFAULT_RISK_THRESHOLD,
        touchGrassDurationMs: DEFAULT_TOUCH_GRASS_DURATION_MS,
        touchGrassCooldownMs: DEFAULT_TOUCH_GRASS_COOLDOWN_MS,
        riskProfile: DEFAULT_RISK_PROFILE,
        enforcementEnabled: true
      };
    }
  }

  // src/content.ts
  function isDomain(hostname2, domain) {
    return hostname2 === domain || hostname2.endsWith("." + domain);
  }
  var hostname = window.location.hostname.toLowerCase();
  var pathname = window.location.pathname.toLowerCase();
  var isDiscordAuthRoute = pathname.startsWith("/auth/discord");
  var isExcludedDomain = isDomain(hostname, "discord.com") || hostname === "localhost" && window.location.port === "3333" || hostname === "localhost" && window.location.port === "3001" && isDiscordAuthRoute || isDomain(hostname, "api.tiltcheck.me") && isDiscordAuthRoute;
  if (isExcludedDomain) {
    if (typeof define_process_default !== "undefined" && define_process_default.env?.NODE_ENV !== "production") {
      console.log("[TiltCheck] Skipping - excluded domain:", hostname);
    }
  }
  var TILTCHECK_PRO_MONOLITH_KEY = "tiltcheck_pro_monolith_enabled";
  var TILTCHECK_CORE_RECORD_BET_EVENT = "tiltcheck-core-record-bet";
  var tiltDetector = null;
  var corePoll = null;
  var coreClickListener = null;
  var touchGrassCooldownUntil = 0;
  var coreOptions = null;
  var proModulePromise = null;
  var proActive = false;
  async function waitForDocumentEnd() {
    if (document.readyState !== "loading" && document.body) {
      return;
    }
    await new Promise((resolve) => {
      const resolveWhenReady = () => {
        if (document.body) {
          document.removeEventListener("DOMContentLoaded", resolveWhenReady);
          resolve();
        }
      };
      document.addEventListener("DOMContentLoaded", resolveWhenReady, { once: true });
      setTimeout(resolveWhenReady, 0);
    });
  }
  async function shouldLoadProMonolith() {
    try {
      const stored = await chrome.storage.local.get(TILTCHECK_PRO_MONOLITH_KEY);
      return stored[TILTCHECK_PRO_MONOLITH_KEY] === true;
    } catch {
      return false;
    }
  }
  async function loadProModule() {
    if (!proModulePromise) {
      proModulePromise = import(chrome.runtime.getURL("pro-monolith-bootstrap.js"));
    }
    return proModulePromise;
  }
  async function setProMonolithEnabled(enabled) {
    if (enabled) {
      if (proActive) return;
      const mod2 = await loadProModule();
      await mod2.startProMonolith();
      proActive = true;
      return;
    }
    if (!proActive) return;
    const mod = await loadProModule();
    mod.deactivateProMonolith();
    proActive = false;
  }
  async function refreshCoreOptions() {
    coreOptions = await loadCoreCircuitBreakerOptions();
    tiltDetector?.setRiskProfile(coreOptions.riskProfile);
    return coreOptions;
  }
  function installCoreOptionsListener() {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if (TILTCHECK_PRO_MONOLITH_KEY in changes) {
          const enabled = changes[TILTCHECK_PRO_MONOLITH_KEY]?.newValue === true;
          void setProMonolithEnabled(enabled);
        }
        const coreKeyTouched = CORE_CIRCUIT_BREAKER_STORAGE_KEYS.some((k) => k in changes);
        if (coreKeyTouched) {
          void refreshCoreOptions();
        }
      });
    } catch {
    }
  }
  async function startCoreCircuitBreaker() {
    await waitForDocumentEnd();
    await refreshCoreOptions();
    installCoreOptionsListener();
    window.__tiltcheckCoreShieldActive = true;
    tiltDetector = new TiltDetector(null, coreOptions.riskProfile);
    coreClickListener = () => {
      tiltDetector?.recordClick();
    };
    document.addEventListener("click", coreClickListener, true);
    window.addEventListener(TILTCHECK_CORE_RECORD_BET_EVENT, (event) => {
      const detail = event.detail;
      const bet = Number(detail?.bet);
      const payout = Number(detail?.payout);
      if (!tiltDetector || !Number.isFinite(bet)) return;
      tiltDetector.recordBet(bet, Number.isFinite(payout) ? payout : 0);
    });
    corePoll = window.setInterval(() => {
      const opts = coreOptions;
      if (!tiltDetector || !opts || Date.now() < touchGrassCooldownUntil) {
        return;
      }
      if (!opts.enforcementEnabled) {
        return;
      }
      const fast = tiltDetector.detectFastClicks();
      if (fast && (fast.severity === "high" || fast.severity === "critical")) {
        touchGrassCooldownUntil = Date.now() + opts.touchGrassCooldownMs;
        triggerTouchGrassTimeout(fast.description, opts.touchGrassDurationMs);
        return;
      }
      const risk = tiltDetector.getTiltRiskScore();
      if (risk >= opts.riskThreshold) {
        touchGrassCooldownUntil = Date.now() + opts.touchGrassCooldownMs;
        triggerTouchGrassTimeout("Pacing looks off \u2014 take a break.", opts.touchGrassDurationMs);
      }
    }, 2e3);
  }
  async function boot() {
    if (isExcludedDomain) {
      return;
    }
    await startCoreCircuitBreaker();
    if (await shouldLoadProMonolith()) {
      await setProMonolithEnabled(true);
    }
  }
  void boot();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (isExcludedDomain && message.type !== "get_sidebar_state") {
      sendResponse({ error: "Feature disabled on this domain" });
      return true;
    }
    if (proActive && (message.type === "toggle_sidebar" || message.type === "open_sidebar" || message.type === "get_sidebar_state")) {
      return false;
    }
    switch (message.type) {
      case "toggle_sidebar":
      case "open_sidebar":
        sendResponse({
          success: false,
          coreOnly: true,
          hint: "Set tiltcheck_pro_monolith_enabled to true in chrome.storage.local to load the full TiltCheck panel."
        });
        return true;
      case "get_sidebar_state":
        sendResponse({
          exists: false,
          visible: false,
          injectionDisabled: false,
          coreOnly: true
        });
        return true;
      default:
        return false;
    }
  });
  if (typeof define_process_default !== "undefined" && define_process_default.env?.NODE_ENV !== "production") {
    console.log("[TiltCheck] Core content script loaded");
  }
})();
//# sourceMappingURL=content.js.map
